import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "../middleware/apiActions";

const slice = createSlice({
    name: "bikeData",
    initialState: {
      bikeData: [],
      loading:false
    },
    reducers: {
      updateBikeData: (state, action) => {
        state.bikeData = action.payload;
      },
      bikeDataRequested:(state, action)=>{
        state.loading = true
      },
      bikeDataReceived:(state, action)=>{
        state.loading = false
      },
      bikeDataRequestFailed:(state, action)=>{
        state.loading = false
      }
      
    },
  });

export const {
    updateBikeData,
    bikeDataRequested,
    bikeDataReceived,
    bikeDataRequestFailed
} = slice.actions;

export default slice.reducer;

const url="https://apix.revoltmotors.com/api/v1/ecu/dataByCompanyName"
const url1 = "https://apix.revoltmotors.com/api/v1/user/fleetUserLogin"

export const fetchTrackingData = (params, callback)=>(dispatch,getState)=>{
  return dispatch(apiCallBegan({
    url,
    method:"POST",
    data:params,
    callback,
    onStart:bikeDataRequested.type,
    onSuccess:bikeDataReceived.type,
    onError:bikeDataRequestFailed.type
  }))
}

export const userLogin = (params, callback)=>(dispatch,getState)=>{
  return dispatch(apiCallBegan({
    url:url1,
    method:"POST",
    data:params,
    callback,
    onStart:bikeDataRequested.type,
    onSuccess:bikeDataReceived.type,
    onError:bikeDataRequestFailed.type
  }))
}


export const trackingData=createSelector((state)=>state.entities.bikeData, (bikeData)=>bikeData)