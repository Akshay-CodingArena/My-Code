import { combineReducers } from "redux";
import bikeData from "./slices/bikeData";

export default combineReducers({
    bikeData
})