const PATH = {
    PUBLIC : {
        INDEX:"/"
    },
    PRIVATE:{
        CHINDEX:"lota"
    }
}

export default PATH