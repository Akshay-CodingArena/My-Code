import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./Dashboard";
import Layout from "./components/common/Layout";
import Form from "./components/common/Form"
import PrivateRoute from "./components/common/privateRoute";
// import PrivateRoute from "./components/common/privateRoute";
// import BackDropComponent from "./components/common/BackDropComponent";
// import ErrorBoundary from "./ErrorHandling/ErrorBoundary";
//import PATH from "./paths/Paths";
const LoginMain = React.lazy(() => import("./components/common/LoginMain"));

const AppRoutes = () => {
  useEffect(() => {}, []);
  return (
    // <React.Suspense fallback={<BackDropComponent/>}>
    <>
      {/* <ErrorBoundary> */}
      <Router>
        <Routes>
          <Route path="/" element={<Form Component={LoginMain} />} />
          <Route path="/dashboard" element={<PrivateRoute><Dashboard/></PrivateRoute>}/>
        </Routes>
      </Router>
      {/* </ErrorBoundary> */}
    </>
    // </React.Suspense>
  );
};

export default AppRoutes;
