import { useEffect, useState, useRef, useContext } from "react";
import { Maps } from "./components/Maps";
import CustomDropdown from "./components/common/Dropdown";
import { fetchTrackingData, trackingData } from "./store/slices/bikeData";
import { useDispatch } from "react-redux";
import BackDropComponent from "./components/common/BackDropComponent";
import { ToggleContext } from "./components/common/Layout";

export const Dashboard = () => {
  let [bikeList, setBikeList] = useState([]);
  let [index, setIndex] = useState(-1);
  let [filteredList, setFilteredList] = useState([]);
  const [bike, setBike] = useState({});
  const [search, setSearch] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const dropDownRef = useRef();
  const searchbarRef = useRef();
  const dispatch = useDispatch();
  const { toggle } = useContext(ToggleContext);

  useEffect(() => {
    let formData = {
      companyName: "SWYTCHD Mobility Private Limited",
    };
    dispatch(fetchTrackingData(formData, callBackTrackingData));
    setFilteredList(
      bikeList.filter((bike) =>
        bike.ecu_num
          ?.toString()
          .toUpperCase()
          .includes(search.toString().toUpperCase())
      )
    );
  }, [search]);

  useEffect(() => {
    setSearch(bike.ecu_num);
    setShowDropdown(false);
  }, [bike]);

  useEffect(() => {
    if (bikeList) {
      setFilteredList(bikeList);
    }
  }, [bikeList]);
  const checkBlur = (e) => {
    const { top, left, height, width } =
      dropDownRef.current.getBoundingClientRect();
    console.log(
      "clicked area",
      e.clientX,
      dropDownRef.current.getBoundingClientRect()
    );
    if (showDropdown) {
      if (
        !(
          left < e.clientX &&
          e.clientX < left + width &&
          e.clientY > top &&
          e.clientY < top + height
        )
      ) {
        setShowDropdown(false);
        setSearch(bike.ecu_num);
      }
    }
    // e.clientX
    // e.clientY
  };

  const callBackTrackingData = (res) => {
    if (res.data) {
      console.log("Tracking data is", res.data);
      let bikes = res.data.data.filter((bike)=>{
        if(bike.lat == -99 || bike.lng == -99){
          return false
        }else{
          return true
        }
      })
      setBikeList(bikes);
    }
  };

  const handleKeyDown = (e) => {
    if (e.code === "ArrowDown") {
      if (index < filteredList.length) {
        setIndex(index + 1);
      }
    } else if (e.code === "ArrowUp") {
      if (index > -1) {
        setIndex(index - 1);
      }
    } else if (e.code === "Enter") {
      searchbarRef.current.blur();
      setBike(filteredList[index]);
    }

    console.log("key pressed is", e);
  };
  console.log("Toggled context", toggle);
  return (
    <main id="main" className={`${toggle ? "active" : ""}`} onClick={checkBlur}>
      {trackingData.loading ? <BackDropComponent /> : null}

      <section>
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-7">
              <div class="pagetitle">
                <h1>Dashboard</h1>
              </div>
            </div>
            <div className="col-sm-5">
              {" "}
              <div ref={dropDownRef}>
                <div className="searchList">
                  <input
                    ref={searchbarRef}
                    onKeyDown={handleKeyDown}
                    onFocus={() => setShowDropdown(true)}
                    placeholder="Search Bike Id"
                    className="searchBike"
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                  {showDropdown ? (
                    <CustomDropdown
                      options={filteredList}
                      setBike={setBike}
                      index={index}
                      setIndex={setIndex}
                    />
                  ) : null}
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-sm-12">
              {bikeList.length ? (
                <Maps bikeList={bikeList} bike={bike} />
              ) : null}
            </div>
          </div>
        </div>
      </section>
      <footer id="footer" class="footer">
        <div class="copyright">
          Copyright © 2023
          <strong>
            <span> Revolt Intellicorp Private Limited. </span>
          </strong>
          All right reserved.
        </div>
      </footer>
    </main>
  );
};

export default Dashboard;
