function CustomIcon(){
    console.log("I am called")
    return (
        <img src={'/clusterMarker.png'}/>
    )
}

export default CustomIcon