import { Route } from "react-router-dom";
import LoginMain from "./LoginMain";
import Layout from "./Layout";

function PrivateRoute({ children }) {
  const auth = localStorage.getItem("accessToken")
  const deviceId = "6ebc0c18e7609755"
  if (!localStorage.getItem("deviceId")) {
    localStorage.setItem("deviceId", deviceId)
  }

  if(!auth){
    window.location.href = window.location.origin
  }
  return (
    <>
    {auth?<Layout Component={children} />:null}
    </>
  );
}
export default PrivateRoute;
