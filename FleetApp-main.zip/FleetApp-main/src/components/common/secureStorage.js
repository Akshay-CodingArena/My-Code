import SecureLS from "secure-ls"

const localStore = new SecureLS({encodingType:'aes'})
export const decryptStore = (id)=>{
    return localStore.get(id).data
}
export const encryptStore = (id, data)=>{
    return localStore.set(id,{data})
}