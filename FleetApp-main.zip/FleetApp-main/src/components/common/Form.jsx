import { useState } from "react"
import Joi from "joi-browser";

const Form = ({Component})=>{
    const [state, setState] = useState({data:{},error:{}})
    const [isValidated, setValidated] = useState()
    const [schema, setSchema] = useState()

    const validate = ()=>{
        const options = { abortEarly: false };
        console.log("state is",state)
        const {error} = Joi.validate(state.data, schema, options)
        console.log("Obj errro",Joi.validate(state.data, schema, options))
        validateProperty(error)
        return {error}
    }

    const validateProperty = (error)=>{
        const errors={}
        error?.details?.forEach(
            err=>{
                if(!errors[err.context.key]){
                errors[err.context.key] = err.message
                }
            }
        )
        setState({...state,error:{...errors}})
    }

    return (
        <Component state={state} schema={schema} setState={setState} setSchema={setSchema} validate={validate}/>
    )
}

export default Form