import { createContext, useState } from "react";

import Header from "./Header";

import Sidebar from "./Sidebar";

export const ToggleContext = createContext(null);
const Layout = ({ Component }) => {
  const [toggle, setToggle] = useState(true);

  return (
    <div>
      <ToggleContext.Provider  value={{ toggle, setToggle }}>
      <Header setToggle={setToggle} toggle={toggle} />

      {toggle ? <Sidebar /> : null}

      {Component}
      </ToggleContext.Provider>
    </div>
  );
};

export default Layout;
