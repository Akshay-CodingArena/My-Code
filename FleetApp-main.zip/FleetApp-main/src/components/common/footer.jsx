const Footer = () => {
  return (
    <footer id="footer" class="footer">
      <div class="copyright">
        Copyright © 2023
        <strong>
          <span> Revolt Intellicorp Private Limited. </span>
        </strong>
        All right reserved.
      </div>
    </footer>
  );
};

export default Footer;
