import { useEffect, useState } from "react";
import "../../include/css/login.css";
import { userLogin } from "../../store/slices/bikeData";
import { useDispatch } from "react-redux";
import Joi from "joi-browser";
import { decryptStore, encryptStore } from "./secureStorage";

const LoginMain = ({ state, setState, schema, setSchema, validate }) => {
  const [isChecked, setChecked] = useState(false)
  const dispatch = useDispatch();
  console.log("I am liaded");
  useEffect(() => {
    console.log("state is", state);
  });

  useEffect(() => {
    setState({ ...state, data: { email: "", password: "" }, error: {} });
    setSchema(
      Joi.object({
        email: Joi.string()
          .required()
          .email()
          .max(30)
          .label("email")
          .error((errors) => {
            errors.forEach((err) => {
              switch (err.type) {
                case "any.required":
                case "any.empty":
                  err.message = "Email field is required.";
                  break;
                case "string.email":
                  err.message = "Email field is invalid.";
                  break;
                case "string.max":
                  err.message = "Email field is invalid.";
                  break;
                default:
                  break;
              }
            });
            return errors;
          }),
        password: Joi.string()
          .required()
          // .regex(
          //     new RegExp("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$ %^&*-]).{8,}$")
          // )
          .label("password")
          .error((errors) => {
            errors.forEach((err) => {
              console.log(err);
              switch (err.type) {
                case "any.empty":
                case "any.required":
                  err.message = "Password is required.";
                  break;
                case "string.regex.base":
                  err.message = "Password should be complex";
                  break;
              }
            });
            return errors;
          }),
      })
    );
  }, []);

  const callBackLogin = (res) => {
    console.log("callback called", res);
    if (res?.data) {
      const data = res.data.data[0];
      localStorage.clear()
      localStorage.setItem("email", data.email);
      if(isChecked){
        encryptStore(data.email,{"password": state.data.password})
        console.log("password",decryptStore(data.email))
        debugger
      }
      localStorage.setItem("id", data.id);
      localStorage.setItem("firstname", data.first_name);
      localStorage.setItem("lastname", data.last_name);
      localStorage.setItem("accessToken", data.jwt_token);
      window.location.href = window.location.origin + "/dashboard";
    }
  };

  const handleLogin = () => {
    const { error } = validate();
    console.log("errors are", error);
    const formData = {
      email: state.data.email,
      password: state.data.password,
    };
    if (!Object.keys(state.error).length) {
      dispatch(userLogin(formData, callBackLogin));
    }
  };

  const handleRemember = (e) => {
    console.log(e," value is ",e.target.checked)
    setChecked(e.target.checked)
  }

  useEffect(()=>{
    let email = localStorage.getItem("email")
    let password = decryptStore(email)?.password
    console.log("password",decryptStore(email))
    if(email && password){
      setState({...state,data:{...state.data, email:email, password:password}})
    }
    else if(email){
      setState({...state,data:{...state.data, email:email}})
    }
    else if(password){
      setState({...state,data:{...state.data, password:password}})
    }
  },[])
  return (
    <main>
      <div class="container">
        <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
          <div class="container">
            <div class="row justify-content-center">
              <div class="col-lg-5 col-md-6 d-flex flex-column align-items-center justify-content-center">
                <div class="d-flex justify-content-center py-4">
                  <img
                    style={{ maxHeight: "60px", width: "100%" }}
                    src="new-logo.png"
                    alt=""
                  />
                </div>

                <div class="card mb-3">
                  <div class="card-body">
                    <div class="pt-4 pb-2">
                      <h5 class="card-title text-center pb-0 fs-4">
                        Login to Your Account
                      </h5>
                      <p class="text-center small">
                        Enter your email & password to login
                      </p>
                    </div>

                    <div class="row g-3 needs-validation">
                      <div class="col-12">
                        <div class="input-group has-validation">
                          {/* <span class="input-group-text" id="inputGroupPrepend">@</span> */}
                          <input
                            type="text"
                            name="email"
                            placeholder="Enter Email Id"
                            class="form-control"
                            onChange={(e) =>
                              setState({
                                ...state,
                                data: { ...state.data, email: e.target.value },
                              })
                            }
                            value={state.data.email}
                            required
                          />
                          <div
                            className={`invalid-feedback ${
                              state.error?.email ? "active" : ""
                            }`}
                          >
                            {state.error?.email}
                          </div>
                        </div>
                      </div>

                      <div class="col-12">
                        <input
                          placeholder="Enter Password"
                          type="password"
                          name="password"
                          class="form-control"
                          onChange={(e) =>
                            setState({
                              ...state,
                              data: { ...state.data, password: e.target.value },
                            })
                          }
                          value={state.data.password}
                          required
                        />
                        <div
                          className={`invalid-feedback ${
                            state.error?.password ? "active" : ""
                          }`}
                        >
                          {state.error?.password}
                        </div>
                      </div>

                      <div class="col-12">
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            name="remember"
                            id="rememberMe"
                            onChange={handleRemember}
                          />
                          <label class="form-check-label" htmlFor="rememberMe">
                            Remember me
                          </label>
                        </div>
                      </div>
                      <div class="col-12">
                        <button
                          class="btn btn-primary w-100"
                          onClick={handleLogin}
                        >
                          Login
                        </button>
                      </div>
                      {/* <div class="col-12">
                      <p class="small mb-0">Don't have account? <a href="pages-register.html">Create an account</a></p>
                    </div> */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
};

export default LoginMain;
