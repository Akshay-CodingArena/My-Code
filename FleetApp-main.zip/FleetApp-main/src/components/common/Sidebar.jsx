import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <aside id="sidebar" class="sidebar">
      <ul class="sidebar-nav" id="sidebar-nav">
        <li class="nav-item">
          <Link class="nav-link" href="/dashboard">
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
          </Link>
        </li>
      </ul>
    </aside>
  );
};

export default Sidebar;
