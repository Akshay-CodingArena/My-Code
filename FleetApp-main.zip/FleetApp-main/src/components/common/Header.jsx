import { useState } from "react";
import { Link } from "react-router-dom";
import { decryptStore } from "./secureStorage";

const Header = ({ toggle, setToggle }) => {
  const [showOptions, setShowOptions] = useState(false)
  const handleLogout = () => {
    const email = localStorage.getItem("email")
    console.log(decryptStore(email)?.password)
    debugger
    if(!decryptStore(email)?.password){
    localStorage.clear();
    }
    window.location.href = window.location.origin;
  };

  const handleToggle = () => {
    setToggle(!toggle);
  };

  return (
    <header className="header fixed-top d-flex align-items-center">
      <div className="d-flex align-items-center justify-content-between">
        <i className="bi bi-list toggle-sidebar-btn" onClick={handleToggle}></i>
        <Link href="/" className="logo d-flex align-items-center">
          <img src="logo-name.png" alt="" />
        </Link>
      </div>
      <nav className="header-nav ms-auto">
        <ul className="d-flex align-items-center">
          <li className="nav-item pe-3" style={{position:'relative'}}>
            <Link
              className="nav-link nav-profile d-flex align-items-center pe-0"
              href="#"
              data-bs-toggle="dropdown"
              onClick={()=>setShowOptions(!showOptions)}
            >
              <img
                src="assets/img/profile-img.jpg"
                alt="Profile"
                className="rounded-circle"
              />
              <span className="d-none d-md-block dropdown-toggle ps-2">
                {localStorage.getItem("firstname") +
                  " " +
                  localStorage.getItem("lastname")}
              </span>
            </Link>
            <div className={`dropDownProfile ${showOptions?"active":""}`}> 
            <Link
              style={{textAlign:'right', padding:"5px 0px", fontSize:'15px'}}
              className="nav-link nav-profile  align-items-center pe-0 dropDownOptions"
              onClick={handleLogout}
            >
              {" "}
              Log Out
            </Link>
            </div>
          </li>
          <li className="nav-item pe-3">
            {/* <Link
              className="nav-link nav-profile d-flex align-items-center pe-0"
              onClick={handleLogout}
            >
              {" "}
              Log Out
            </Link> */}
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
