const CustomDropdown = ({options, setBike, index})=>{
    return (
        <div className="optionsContainer">
            {
            options.map((bike,id)=>(
                <div  key={"item"+id} className={`option ${id===index?"active":""}`} onClick={()=>setBike(bike)}>{bike.ecu_num}</div>
            ))
            }
        </div>
    )
}

export default CustomDropdown