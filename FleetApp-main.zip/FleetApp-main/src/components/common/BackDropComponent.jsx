import React from "react";
import Card from "react-bootstrap/Card";

const BackDropComponent = (props) => {
  return (
    <div style={{height:'100vh', width:'100%', display:"flex", justifyContent:'center', alignItems:"center"}}>
        <div className="loadingSpinner">
          <div className="spinner-border spinner-border-sm" role="status">
            <span className="visually-hidden"></span>
          </div>
          <div className="spinner-grow spinner-grow-sm" role="status">
            <span className="visually-hidden"></span>
          </div>
          <div className="spinner-grow spinner-grow-sm" role="status">
            <span className="visually-hidden"></span>
          </div>
        </div>
    </div>
  );
};

export default BackDropComponent;
