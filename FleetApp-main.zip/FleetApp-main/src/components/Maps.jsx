import { useEffect, useRef, useState } from 'react';
import React from "react"
import {LoadScript, GoogleMap, MarkerClusterer, Marker, Renderer} from '@react-google-maps/api'; 
import { InfoBox, InfoWindow } from '@react-google-maps/api';
import Geocode from "react-geocode";
import CustomIcon from './CustomIcon';

export const Maps = ({bikeList, bike}) => { 
    const cor1 =  28.6455413;
    const cor2 =  77.3024774;
    const [centerLati, setcenterLati] = React.useState(cor1);
    const [centerLong, setcenterLong] = React.useState(cor2);
    const mapRef =  useRef(null)
    const [activeMarker, setActiveMarker] = useState()
    const handleActiveMarker = (marker) => {
        if (marker.ecu_num === activeMarker) {
              return;
        }
        const { lat, lng } = marker;
        // Geocode.fromLatLng( lat, lng ).then((results) => {
        //     console.log("Geocode",results[0].formattedAddress);
        //   });
        // geocode.geocode({ lat, lng }, (results) => {
        // console.log("Geocode",results[0].formattedAddress);
        setActiveMarker({...marker}); 
        setcenterLati(lat);
        setcenterLong(lng);   
    };

    useEffect(()=>{
        Geocode.setApiKey("");
    },[])
    const [address, setAddress] = React.useState("");
    const onMarkerClick = (e) => {
        const { lat, lng } = e.latLng;
        // geocode.geocode({ lat, lng }, (results) => {
        // setAddress(results[0].formattedAddress);
        // });
    };
    const divStyle = {
        'padding'    : 0,
        'fontFamily' : 'Montserrat',
        'fontWeight' : '600',
        'maxWidth'   : '230px',
    };
      
    const divMargin = {
         'padding' : '5px 0',
    };
  
    const divMargin1 = {
        'padding' : '5px 0',
        'fontSize': '15px',
        'fontWeight' : '700',
    };
    
    const linkStyle = {
        'color' : '#363638'
    }

    const loadMap = React.useCallback(function callback(map) {
      if(!activeMarker?.ecu_num){
        var bound = new window.google.maps.LatLngBounds();
        console.log("Mapped bound",bound)
       // bound.extend( new window.google.maps.LatLng(bike?.lat, bike?.lng) );
        markers?.map((bike,index)=>{
            bound.extend(new window.google.maps.LatLng(bike?.lat, bike?.lng))
        })
        // console.log("bound is having",bound, bound.fitBounds())
        setcenterLati(bound.getCenter().lat);
        setcenterLong(bound.getCenter().lng);
        mapRef.current?.state.map.setCenter( bound.getCenter() );
        console.log(mapRef.current)
        mapRef.current?.state.map.fitBounds(bound)
      }  
    }, )
      
    useEffect(()=>{
        const id = setInterval(()=>{
        const images = Array.from(document.querySelectorAll(".cluster img"))
        if(images.length){
          console.log("Image data is",images)
          if(images?.length){
              images?.map(image=>{
                if(image.src !== "/clusterIcon.png"){
                  if(image?.src){
                    console.log("updating cluster")
                    image.src = "/clusterIcon.png"
                    // image.height = "45px"
                  //  image.style.width = "100%"
                  //  image.style.height = "45px"
                    
                }
                }   
              })
          }
        }
        })
 
    },[])
    
   useEffect(()=>{
   // mapRef.setCenter()
   if(bike?.lat){
    var bound = new window.google.maps.LatLngBounds();
    bound.extend( new window.google.maps.LatLng(bike?.lat, bike?.lng) );
    setcenterLati(bound.getCenter().lat);
    setcenterLong(bound.getCenter().lng);
    // mapRef.current.state.map.setCenter( bound.getCenter() );
    mapRef.current?.state.map.setZoom(15)
    console.log("Mapping",mapRef.current)
   }

   },[bike])

//    useEffect(()=>{
//     if(bikeList[0]?.lat){
//         console.log("Ghossla")
//     var bound = new window.google.maps.LatLngBounds();
//     bound.extend( new window.google.maps.LatLng(bike?.lat, bike?.lng) );
//     bikeList?.map((bike,index)=>{
//         bound.extend(new window.google.maps.LatLng(bike?.lat, bike?.lng))
//     })
//     setcenterLati(bound.getCenter().lat);
//     setcenterLong(bound.getCenter().lng);
//     mapRef.current?.state.map.setCenter( bound.getCenter() );
// }},[])

   let markers = []
   markers = bikeList?.map((bike,index)=>{
    return {title:`bike${index}`,lat:bike.lat, lng:bike.lng, ecu_num:bike.ecu_num, battery_temp:bike.battery_temp, battery_soc:bike.battery_soc}
  })

  markers = markers.filter((bike)=>{
    if(bike.lat!=-99 && bike.lng!=-99){
      return true
    }
    else{
      return false
    }
  })

  let duplicate = bikeList?.map((bike,index)=>{
    return {title:`bike${index}`,lat:bike.lat+(Math.random() - 0.5) / 5000, lng:bike.lng+(Math.random() - 0.5) / 5000}
  })

  //markers = [...markers, ...duplicate]

  const customStyle = {
    textColor: 'white',
    textSize: 14,
    width: "40px", // Adjust icon width
    height: "40", // Adjust icon height
    url: '/clusterMarker.png', // URL to your custom cluster icon image
  }

  return (
    <div className="googleMap">
      <LoadScript > 
          <GoogleMap
              mapContainerStyle={{ height: '400px', width: '100%' }}
              center={{ lat: centerLati, lng: centerLong }} 
              zoom={13} 
              id="kml-layer-example" 
              onLoad = {loadMap}
              ref={mapRef}
          >
            <MarkerClusterer   gridSize={60} // Adjust this value as needed
            minimumClusterSize={2} style={{height:"45px", width:"30px"}} >
            {(clusterer) =>
            markers.map((loc,index) => (
              <Marker
                // icon={"/images/map-pin.png"}
                key={"marker"+index}
                icon={{url:"/clusterMarkerResized.png",
                        scaledSize:new window.google.maps.Size(30, 45)
                        }}
                position={loc}
                clusterer={clusterer}
                onClick={() => handleActiveMarker(loc)}
              >
                            {activeMarker && activeMarker.ecu_num === loc.ecu_num ? (
                                      <InfoWindow position={{ lat: activeMarker.lat, lng: activeMarker.lng }} onCloseClick={()=>setActiveMarker(null)}>
                                          <div style={{...divStyle, height:"140px"}}>
                                             {/* //     <div style={divMargin1}>{loc.ecu_num}</div> */}
                                             <p style={{color:'grey'}}>Temperature</p>
                                                  <div style={{divMargin, display:"flex"}}>
                                                    {/* <div className="tempContainer">
                                                    <div className="tempMeter"></div>  
                                                    </div> */}
                                                  <img src="/assets/thermometer-level.png" className="iconSvg" style={{ width:"30px", height:'30px'}} />
                                                    <p style={{marginLeft:'5px'}}> {loc.battery_temp}°C</p>
                                                    </div>
                                                  <p style={{color:'grey'}}>Battery</p>
                                                  <div style={{...divMargin,position:'relative', marginBottom:"20px", display:"flex", marginTop:"-10px"}}>
                                                    <img src="/assets/battery-level.svg" className="iconSvg" style={{ transform:"rotate(-90deg)", width:"30px"}} />
                                                    <div style={{position:"absolute",width:`10px`,height:`${20*(loc.battery_soc/100)}px`, backgroundColor:`${loc.battery_soc<20?"red":"green"}`,marginTop:"9px", marginLeft:"10px", borderRadius:"1px", bottom:"16px"}}>                                                      
                                                    </div>
                                                    <p style={{position:"absolute",marginLeft:"30px", marginTop:"8px", zIndex:"9999999", color:"black"}}>{loc.battery_soc} %</p>
                                                  </div>
                                                  {/* {
                                                      e.dealer_link ? (
                                                              <>
                                                                  <div style={divMargin}><a style={linkStyle} target="_blank" href={e.dealer_link}>View</a></div>
                                                              </>
                                                      ) : ( <></> )
                                                  }  */}
                                                  </div>
                                                  </InfoWindow>
                                          ) : null}
                </Marker>
            ))
          }    
            </MarkerClusterer>
          </GoogleMap>
      </LoadScript>
  </div>
  );
};

//apiKey='AIzaSyBG5UBB3yJRO10Txi0JkfpW_dZO9XOmg60'
        // {/* <>
        //       {bikeList?.map((e, key) => {   
        //               return(
        //                   <Marker
        //                       key={e.ecu_num}
        //                       position={{ lat: parseFloat(e.lat), lng: parseFloat(e.lng) }}
        //                       name={e.ecu_num} 
        //                       title={"m"+e.ecu_num}
        //                       icon={"/images/map-pin.png"}
        //                       onMarkerAdded={marker => {console.log("added marker")}}
        //                       onClick={() => handleActiveMarker(e)}
        //                   >
        //                       {activeMarker === e.ecu_num ? (
        //                               <InfoWindow >
        //                                   <div style={divStyle}>
        //                                           <div style={divMargin1}>{e.ecu_num}</div>
        //                                           <div style={divMargin}>{e.battery_temp}</div>
        //                                           <div style={divMargin}>{e.battery_soc}</div>
        //                                           {/* {
        //                                               e.dealer_link ? (
        //                                                       <>
        //                                                           <div style={divMargin}><a style={linkStyle} target="_blank" href={e.dealer_link}>View</a></div>
        //                                                       </>
        //                                               ) : ( <></> )
        //                                           }  */}
        //                                           </div>
        //                                           </InfoWindow>
        //                                   ) : null}
            
        //                               </Marker>  
        //                           )
        //                   })}
        //               </> 
        //               <>
        //                   {bikeList?.map((e, key) => {   
        //                           return(
        //                               <Marker
        //                                   key={e.ecu_num}
        //                                   position={{ lat: parseFloat(e.lat + (Math.random() - 0.5) / 5000), lng: parseFloat(e.lng + (Math.random() - 0.5) / 5000) }}
        //                                   name={e.ecu_num} 
        //                                   icon={"/images/map-pin.png"}
        //                                   onMarkerAdded={marker => {console.log("added marker")}}
        //                                   onClick={() => handleActiveMarker(e)}
        //                               >
        //                                   {activeMarker === e.ecu_num ? (
        //                                           <InfoWindow >
        //                                               <div style={divStyle}>
        //                                                       <div style={divMargin1}>{e.ecu_num}</div>
        //                                                       <div style={divMargin}>{e.battery_temp}</div>
        //                                                       <div style={divMargin}>{e.battery_soc}</div>
        //                                                       {/* {
        //                                                           e.dealer_link ? (
        //                                                                   <>
        //                                                                       <div style={divMargin}><a style={linkStyle} target="_blank" href={e.dealer_link}>View</a></div>
        //                                                                   </>
        //                                                           ) : ( <></> )
        //                                                       }  */}
        //                                               </div>
        //                                           </InfoWindow>
        //                                   ) : null}
            
        //                               </Marker>  
        //                           )
        //                   })}
        //               </>  */}