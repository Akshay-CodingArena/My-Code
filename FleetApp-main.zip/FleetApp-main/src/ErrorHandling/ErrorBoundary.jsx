import React from "react";
// import errorImg from "../include/assets/error.png";
// import CreditFooter from "../components/cibilFlow/footer";
// import TopNavBar from "../common/TopNavBar";
import SecureLS from "secure-ls";
import { withRouter } from "./withRouter";
import PATH from "../paths/Paths";

let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: "",
      otpSeconds: 5,
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error: error && error.toString() };
  }

  componentDidCatch(error, errorInfo) {
    this.handleOTPTimer();
  }

  handleOTPTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.otpSeconds > 0) {
        this.setState(({ otpSeconds }) => ({ otpSeconds: otpSeconds - 1 }));
      } else {
        this.handlePageRedirection();
        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };

  handlePageRedirection = () => {
    if (!localStorage.getItem("accessToken")) {
      localStorage.clear();
      localStore.removeAll();
      this.props.history.push(PATH.PUBLIC.INDEX);
    } else {
      (() => {
        this.props.history.goBack();
      })();
    }
  };

  componentWillUnmount = () => {
    clearInterval(this.handleOTPTimer);
  };

  render() {
    if (this.state.hasError && this.state.otpSeconds > 0) {
      return (
        <>
          {/* {this.props.isAuth && <TopNavBar />} */}
          <section className={this.props.isAuth && "bs-cs-section"}>
            {" "}
            <div className="errorBoundaryBlock">
              <div className="container">
                <div className="row align-items-center">
                  <div className="col-12 col-sm-12 col-md-6 col-lg-6 order-2 order-md-1 ">
                    <h1>Error Occured</h1>
                    <p>Something went wrong, Backtracking issue.</p>
                    <p>
                      Redirecting to login page{" "}
                      {this.state.otpSeconds.toString().length < 2
                        ? `0${this.state.otpSeconds}`
                        : this.state.otpSeconds}{" "}
                      secs
                    </p>
                  </div>
                  <div className="col-12 col-sm-12 col-md-6 col-lg-6 order-1 order-sm-2 order-md-2">
                    <img src={errorImg} height="200px" alt="" />
                  </div>
                </div>
              </div>
            </div>
            <CreditFooter />
          </section>
        </>
      );
    } else {
      return this.props.children;
    }
  }
}

export default withRouter(ErrorBoundary);
