import Routes from "./Routes";
import configureStore from "./store/configureStore.js";
import { Provider } from "react-redux";
import "./include/css/dev.css"
import 'react-loading-skeleton/dist/skeleton.css';
const store = configureStore();

function App() {
  // useEffect(() => {
  //   gaLogEvent(CONSTANTS.GA_EVENTS.WEB_PLATFORM);
  //   return () => {};
  // }, []);
  return (
    <div className="App">
      <Provider store={store}>
        <Routes />
      </Provider>
    </div>
  );
}

export default App;