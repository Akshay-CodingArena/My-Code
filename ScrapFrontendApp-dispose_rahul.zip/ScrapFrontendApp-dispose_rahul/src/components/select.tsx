import * as React from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { makeStyles } from '@mui/styles';
import { Typography } from '@mui/material'
import { CONSTANTS } from '../constants/constants';
import { ThemeProvider, createTheme } from '@mui/material/styles';






const MySelect = (props: any) => {

    const { onChange, menuItems, value, label, error, errormessage, selectors = { value: "value", label: "label" } } = props;


    return (
        <Box >

            <FormControl fullWidth error={error} >
                <InputLabel id="demo-simple-select-label">{label}</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    name={label}
                    value={value}
                    label={label || "No Label"}
                    onChange={onChange}
                >
                    {menuItems?.length > 0 && menuItems?.map((data: any) => {
                        return <MenuItem value={data[selectors?.value]}>{data[selectors?.label]}</MenuItem>
                    })}

                </Select>
            </FormControl>
            <Typography variant="subtitle1" color="error" >
                {errormessage ? errormessage : ""}
            </Typography>


        </Box>
    );
}

export default React.memo(MySelect);