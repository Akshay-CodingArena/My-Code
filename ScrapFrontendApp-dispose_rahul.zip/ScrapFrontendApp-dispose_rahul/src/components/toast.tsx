import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { CONSTANTS } from '../constants/constants';

// ---------------TWO TYPES OF TOAST ARE THERE--------------
// 1.SUCCESS
// 2.ERROR
export const showToast = (type: any, message: any) => {
    switch (type) {
        case 'SUCCESS': toast.success(message, { style: { backgroundColor: CONSTANTS.COLORS.GREEN } })
            break;
        case 'ERROR': toast.error(message, { style: { backgroundColor: CONSTANTS.COLORS.RED } })
            break;
    }
}

const Toast = () => {
    return <>
        <ToastContainer
            position="top-center"
            autoClose={1500}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            theme='colored'
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            toastStyle={{ backgroundColor: "crimson" }}
        />
    </>
}

export default Toast;