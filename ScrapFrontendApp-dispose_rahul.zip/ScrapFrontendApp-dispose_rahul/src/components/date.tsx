import * as React from 'react';
import dayjs, { Dayjs } from 'dayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { propsToClassKey } from '@mui/styles';

export default function DatePickerValue(props: any) {
    const { value,onChange,label} = props;
    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={['DatePicker', 'DatePicker']}>
                <DatePicker
                    label={label}
                    value={value}
                    onChange={onChange}
                    sx={{width:"100%"}}
                />
            </DemoContainer>
        </LocalizationProvider>
    );
}