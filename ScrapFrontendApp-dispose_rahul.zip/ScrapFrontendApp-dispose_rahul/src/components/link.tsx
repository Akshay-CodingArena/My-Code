import { NavLink } from "react-router-dom";


const CustomLink = (props: any) => {
    const { label, path } = props;
    return <div className="nav-link">
        <NavLink to={path}>
            {label}
        </NavLink>
    </div>
}

export default CustomLink;