import { useNavigate } from "react-router-dom";
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { CONSTANTS } from "../constants/constants";


const BackButton = () => {
    
    let navigate = useNavigate();
    return <>
        <KeyboardBackspaceIcon
        style={{cursor:"pointer"}}
        onClick={() => navigate(-1)}/> 
    </>
}
export default BackButton;