import * as React from 'react';
import { TextField, Typography } from '@mui/material';
import Autocomplete, { createFilterOptions } from '@mui/material/Autocomplete';
import { CONSTANTS } from '../constants/constants';

const filterOptions = createFilterOptions({
    matchFrom: 'start',
    stringify: (option: any) => option.label,
});



const style = {
    "& label.Mui-focused": {
      color: CONSTANTS.COLORS.GREEN
    },
    "& .MuiOutlinedInput-root": {
      "&.Mui-focused fieldset": {
        borderColor: CONSTANTS.COLORS.GREEN
      }
    }
  }  
const MyAutocomplete = (props: any) => {
    const { 
        name,
        options,
        label,
        onChange,
        onInputChange,
        error,
        value,
        errormessage ,
        disableClearable
    } = props;


    return (
        <div>
            <Autocomplete
                id={name}
                options={options}
                getOptionLabel={(option) => option.label}
                filterSelectedOptions={true}
                filterOptions={filterOptions}
                onChange={onChange}
                onInputChange={onInputChange}
                value={value}
                renderInput={(params) => <TextField
                    error={error || false}

                    sx={style}

                    {...params}
                    label={label || "No label"} />}
                isOptionEqualToValue={(option: any, value: any) => option.label === value.label}
                disableClearable={disableClearable === false? false:true }
            />

            <Typography variant="subtitle1" color="error" >
                {errormessage ? errormessage : ""}
            </Typography>
        </div>
    );

}

export default MyAutocomplete;

