import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import {CONSTANTS} from "../constants/constants";

const Loading = (props: any) => {
    const { loading } = props;
    return (
        <div>
            <Backdrop
                sx={{ color: CONSTANTS.COLORS.GREEN, zIndex: 9999 }}
                open={loading || false}
            >
                <CircularProgress color="inherit" />
            </Backdrop>
        </div>
    );
}

export default Loading;
