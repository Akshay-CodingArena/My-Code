import Grid from '@mui/material/Grid';
import MySelect from '../../components/select';
import { useAppSelector } from '../../store/hooks';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { departmentMasterList } from '../../store/slices/list';

const DepartmentFilter = ({state, setState})=>{
    const {departmentList} = useAppSelector(state=>state.list)
    const dispatch = useDispatch()

    useEffect(()=>{
        if(!departmentList.length){
            dispatch(departmentMasterList())
        }
    },[])

    const handleChange = (e)=>{
        console.log("department is", e.target.value)
        setState({...state, department: e.target.value})
    }
    
    return (
            <select style={{margin:"0px", padding:"4px 8px"}} id="id_select" onChange={handleChange}>
                <option value={''} selected>All Departments</option>
                {departmentList.map((dept,index)=>(
                    <option  value={dept.value} label={dept.label}></option>
                ))}
            </select>
    )
}

export default DepartmentFilter