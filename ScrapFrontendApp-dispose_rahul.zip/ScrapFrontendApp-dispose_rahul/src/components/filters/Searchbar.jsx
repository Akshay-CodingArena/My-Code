import { useState } from "react"

const Searchbar = ({search, setSearch})=>{
    const handleSearch = (e)=>{
        setSearch(e.target.value)
    }
    return (
       <input style={{width:'100%'}} values={search} placeholder="Search" onChange={handleSearch}/>
    )
}

export default Searchbar