import DateRangePicker from '@wojtekmaj/react-daterange-picker'
import moment from 'moment'
import { useEffect, useState } from 'react'
import Grid from '@mui/material/Grid';
import DateIcon from "../../assets/images/icons/date-icon.jpg"


const DateRange = ({state, setState})=>{
    const [dateFilter, setDateFilter] = useState([moment(state?.date?.[0]).format(`DD/MM/YYYY`),moment(state?.date?.[1]).format(`DD/MM/YYYY`)])
    const [calender, setCalender] = useState(false)
    const changeDate = (range) => {
        if (range) {
            setDateFilter([moment(range[0]).format('DD/MM/YYYY'), moment(range[1]).format('DD/MM/YYYY')])
            console.log("Date is",moment(range[0]).format('DD/MM/YYYY'))
            console.log("Date is",moment(range[1]).format('DD/MM/YYYY'))
            if(range[1]){
                setCalender(false)
            }
            setState({...state, date:[moment(range[0]).format('YYYY/MM/DD'), moment(range[1]).format('YYYY/MM/DD')]})
            //moment(range[0]).formate('YYYY/MM/DD')
            // const fromDay = getFullDay(range[0].getDate())
            // const toDay = getFullDay(range[1].getDate())
            // const fromMonth = getMonthName(range[0].getMonth() + 1)
            // const toMonth = getMonthName(range[1].getMonth() + 1)
            // const fromYear = range[0].getFullYear()
            // const toYear = range[1].getFullYear()

            // setDateFilter([`${fromDay} ${fromMonth} ${fromYear}`, `${toDay} ${toMonth} ${toYear}`])
        }
    }

    // useEffect(()=>{
    //     let fromDate = new Date()
    //     fromDate.setDate(fromDate.getDate() - 7)
    //     setDateFilter([moment(fromDate).format(`DD/MM/YYYY`), moment(new Date()).format(`DD/MM/YYYY`)])
    //     setState({...state, date:[moment(fromDate).format('YYYY/MM/DD'), moment(new Date()).format('YYYY/MM/DD')]})
    //    // setDateFilter([moment(fromDate).format('YYYY/MM/DD'), moment(new Date()).format('YYYY/MM/DD')])
    // },[])

    return (
        <>
        {calender?<div style={{position:"relative"}}>
        <DateRangePicker id="dateSelector" calendarIcon={<img style={{height:'25px', zIndex:"9999"}} src={DateIcon} />} isOpen={calender}  returnValue="range" onCalenderClose={()=>setCalender(false)}  onChange={changeDate} value={[dateFilter[0].slice(3,5)+"/"+dateFilter[0].slice(0,2)+"/"+dateFilter[0].slice(6),dateFilter[1].slice(3,5)+"/"+dateFilter[1].slice(0,2)+"/"+dateFilter[1].slice(6)]} maxDate={new Date()} />
        </div>
        :<div style={{position:"relative"}}><p style={{ border:"1px solid black", width:"205px", padding:"4px 0px 4px 40px" , margin:"0px"}} onClick={()=>setCalender(true)} > {dateFilter[0] + "  -  " + dateFilter[1]} </p>
            <img onClick={()=>setCalender(true)} src={DateIcon} style={{position:"absolute", zIndex:"9999", height:'25px', top:"3px", left:"5px"}}/>
        </div>}
        </>
    )
}

export default DateRange