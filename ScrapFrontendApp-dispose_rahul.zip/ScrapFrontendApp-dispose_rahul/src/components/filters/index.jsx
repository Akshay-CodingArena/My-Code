import { Grid } from "@mui/material"
import Searchbar from "./Searchbar"
import DepartmentFilter from "./Department"
import DateRange from "./DateRange"
import { useEffect, useRef, useState } from "react"
import { useDispatch } from "react-redux"
import useLocalStorage from "../../utils/localStorage"
import { downloadRequestScrapList, getRequestScrapList, getScrapListHOD, getStoreCNCDepositList } from "../../store/slices/list"
import { useLocation } from "react-router-dom"
import MyButton from "../button"

const OFFSET = 5;

const Filters = ({ page, setPage, state, setState, listType, listCategory }) => {
    const filter = useRef()
    const [search, setSearch] = useState("")
    const dispatch = useDispatch()

    const handleFilterUpdate = () => {
        handleSearch(1)
        setPage(1);
    }



    const handleRequestDownload = async () => {
        let userData = useLocalStorage.getItem("userData");
        let formData = {
            // page_number: page,
            // offset: OFFSET,
            list_type: listType,
            user_id: userData.id,
            scrap_id_params: search,
            start_date: state.date?.length > 1 ? state.date[0] : "",
            end_date: state.date?.length > 1 ? state.date[1] : "",
            department: state?.department ? state?.department : ""
        }
        let response = await dispatch(downloadRequestScrapList(formData))

        if (response.payload.data.data) {
            var iframe = document.createElement('iframe');
            iframe.id = "1";
            iframe.style.display = 'none';
            document.body.appendChild(iframe);
            iframe.src = response.payload.data.data
        }
        console.log("data log")

        // window.location.href = response.payload.data.data
        // console.log("My response is",response.payload.data.data)
    }

    const handleSearch = async (page) => {
        let userData = useLocalStorage.getItem("userData");
        let formData = {
            page_number: page - 1,
            offset: OFFSET,
            list_type: listType,
            user_id: userData.id,
            scrap_id_params: search,
            start_date: state.date?.length > 1 ? state.date[0] : "",
            end_date: state.date?.length > 1 ? state.date[1] : "",
            department: state?.department ? state?.department : ""
        }
        switch (listCategory) {
            case "MANAGER" || "USER": await dispatch(getRequestScrapList(formData))
                break;
            case "HOD": formData["hod_id"] = userData.id
                delete formData.user_id
                let response = await dispatch(getScrapListHOD(formData));
                break;
            case "STORE_MANAGER":
                await dispatch(getStoreCNCDepositList(formData))
                break;
            case "CNCHead":
                dispatch(getStoreCNCDepositList(formData))
                break

        }
    }

    useEffect(() => {
        handleSearch(page);
    }, [page])

    console.log("state is", state)
    return (<>
        <Grid item xs={12} lg={9} sm={12} style={{marginBottom:"10px"}}>
            <div className="scrapFilters">
                <DateRange state={state} setState={setState} />
                <DepartmentFilter state={state} setState={setState} />
                <div className="scrapFilters">
                    <Searchbar search={search} setSearch={setSearch} />
                </div>

                <div onClick={handleFilterUpdate} style={{ color: "white", backgroundColor: "green", border: "none", padding: "5px 20px", fontSize: "12px", borderRadius: '5px', cursor: "pointer" }}>Filter</div>

            </div>
        </Grid>
        <Grid lg={3} style={{marginBottom:"10px"}}>
            <MyButton onClick={handleRequestDownload} label={"Download Requests"} style={{height:"28px",  backgroundColor: "green", margin: "0px", textTransform: "capitalize !important" }} />
        </Grid>
    </>
    )
}

export default Filters