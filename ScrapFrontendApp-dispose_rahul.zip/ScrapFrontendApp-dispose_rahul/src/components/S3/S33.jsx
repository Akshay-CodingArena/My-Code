import AWS from 'aws-sdk';
import { PATH } from '../../paths/path';
import { showToast } from '../toast';

const S3_ACCESS_KEY_ID = process.env.REACT_APP_S3_ACCESS_KEY_ID;
const S3_SECRET_ACCESS_KEY = process.env.REACT_APP_S3_SECRET_ACCESS_KEY
const S3_BUCKET_NAME = process.env.REACT_APP_S3_BUCKET_NAME
const S3_REGION = process.env.REACT_APP_S3_REGION;

const config = {
  region: S3_REGION, // Replace with your S3 bucket region
  accessKeyId: S3_ACCESS_KEY_ID, // Replace with your S3 access key ID
  secretAccessKey: S3_SECRET_ACCESS_KEY, // Replace with your S3 secret access key
};



const uploadImage = async (files, path) => {

  const s3 = new AWS.S3(config);
  var reader = new FileReader();
  if (Object.keys(files).length) {
    Object.keys(files).map(async (key, index) => {
      // reader.readAsArrayBuffer(files[key])
      // reader.onload = async () => {
      console.log("Data url", reader.result)
      // const binaryData = new Uint8Array(reader.result)
      const params = {
        Bucket: S3_BUCKET_NAME, // Replace with your S3 bucket name
        Key: path?.[key]?.image_location, // Set the object key dynamically
        Body: files[key], // The image file itself
        ContentType: "image/jpeg", // Set the content type based on file extension
      };
      // try {
       
      let resp = await s3.putObject(params).promise();
      
    })
  }
  //return await true;
};

export { uploadImage }