import React, { useImperativeHandle, forwardRef, useState } from "react";
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { Grid } from "@mui/material";
import Button from "../components/button";
import { CONSTANTS } from "../constants/constants";
import CrossImage from "../assets/images/cross.png";

const ConfirmDialog: React.FC<any> = forwardRef((props: any, ref: any) => {

    const [open, setOpen] = useState(false);

    useImperativeHandle(ref, () =>
    ({
        handleClickOpen: () => {
            setOpen(true);
        },
        handleClose: () => {
            setOpen(false);
        }
    }));

    const closeModal = () => {
        setOpen(false);
    }


    return (
        <div>
            <Dialog
                className='dialogAlertStyle'
                open={open}
                onClose={closeModal}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
                    <img onClick={(e: any) => {
                        setOpen(false)
                    }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
                </div>
                <DialogTitle id="alert-dialog-title">
                    <p className="dialog_title h3">
                        {props.title ? props.title : ""}
                    </p>
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <b>{props.description ? props.description : null}</b>
                    </DialogContentText>
                </DialogContent>

                <DialogActions
                    className="dialogactions"
                >
                    <Grid container style={{ marginTop: "-10px" }}>
                        <Grid item xs={6} sm={6} md={6} lg={6}>
                            <Button label={props.discard} onClick={props.onDiscard} style={{ backgroundColor: CONSTANTS.COLORS.RED, marginRight: "10px" }} />
                        </Grid>

                        <Grid item xs={6} sm={6} md={6} lg={6}>
                            <Button label={props.confirm} onClick={props.onConfirm} style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} />
                        </Grid>
                    </Grid>
                </DialogActions>
            </Dialog>

        </div>
    );
});

export default ConfirmDialog;
