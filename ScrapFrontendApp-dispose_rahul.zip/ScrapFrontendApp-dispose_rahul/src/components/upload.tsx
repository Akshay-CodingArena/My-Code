import * as React from 'react';
import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { Typography } from '@mui/material'
import { CONSTANTS } from '../constants/constants';

const VisuallyHiddenInput = styled('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1,
});

export default function InputFileUpload(props: any) {

    const { onChange, value, label, errormessage,optional } = props;

    return (
        <div>
            <Button component="label" variant="contained" startIcon={<CloudUploadIcon />}>
                {label ? label : "Upload file"}
                <VisuallyHiddenInput accept="image/png, image/gif, image/jpeg" type="file" onChange={onChange} />
            </Button>

            <Typography variant="subtitle1"  style={{color:value ? CONSTANTS.COLORS.GREEN :CONSTANTS.COLORS.RED,marginTop:"10px"}}>
                    {value? value.name : optional ? "":"Please upload a file"}
                </Typography>
        </div>




    );
}