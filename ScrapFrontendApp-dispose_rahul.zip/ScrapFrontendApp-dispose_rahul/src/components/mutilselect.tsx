import * as React from 'react';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const MultiSelect=(props: any)=> 
{
    const { options, onChange, value,label,placeholder } = props;

    return (
        <Autocomplete
            multiple
            limitTags={2}
            id="multiple-limit-tags"
            options={options}
            getOptionLabel={(option:any) => option.label}
            onChange={onChange}
            value={value}
            isOptionEqualToValue={(option, value) => option.label === value.label}
            defaultValue={[]}
            renderInput={(params) => (
                <TextField {...params} label={label} placeholder={placeholder} />
            )}
            sx={{ width: '100%' }}
        />
    );
}
export default React.memo(MultiSelect);