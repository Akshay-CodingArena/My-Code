import React from "react";
import { Button } from "@mui/material";
import { CONSTANTS } from "../constants/constants";
import EditIcon from "../assets/images/icons/edit.png"
import DeleteIcon from "../assets/images/icons/delete_icon.png"
import ViewIcon from "../assets/images/icons/view.png"


const MyButton = (props: any) => {
    const { fullWidth, type, label, style,onClick ,disabled} = props;
    return <React.Fragment>
        <Button
            type={type || "button"}
            fullWidth={fullWidth || false}
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
            style={{
                backgroundColor: CONSTANTS.COLORS.GREEN,
                ...style}
            }
            disabled={disabled || false}
            onClick={onClick}
        >
            {label}
        </Button>

    </React.Fragment>
}

const EditButton = (props:any)=>{
    return (<>
        {props.disabled?<div style={{  height:"25px", opacity:"0.4", }} {...props}>
        <img src={EditIcon} style={{width:"30px", cursor:"not-allowed"}}/>
        </div>:<div style={{  height:"25px" }}
                {...props}
            >
                <img src={EditIcon} style={{width:"30px", cursor:"pointer"}}/>
            </div>}
            </>
    )
}

const DeleteButton = (props:any)=>{
    return (<>
        {props.disabled?<div style={{  height:"25px", opacity:"0.4", }} {...props}>
        <img src={DeleteIcon} style={{width:"30px", cursor:"not-allowed"}}/>
        </div>:<div style={{  height:"25px" }}
                {...props}
            >
                <img src={DeleteIcon} style={{width:"30px", cursor:"pointer"}}/>
            </div>}
            </>
    )
}

const ViewButton = (props:any)=>{
    return (<>
        {props.disabled?<div style={{  height:"25px", opacity:"0.4", padding:"0 15%" }} {...props}>
        <img src={ViewIcon} style={{width:"30px", cursor:"not-allowed"}}/>
        </div>:<div style={{  height:"25px", padding:"0 15%" }}
                {...props}
            >
                <img src={ViewIcon} style={{width:"25px", cursor:"pointer", }}/>
            </div>}
            </>
    )
}

export {EditButton, DeleteButton, ViewButton}

export default MyButton;