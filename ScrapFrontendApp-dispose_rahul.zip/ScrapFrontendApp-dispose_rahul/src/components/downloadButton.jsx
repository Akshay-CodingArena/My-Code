import DownloadIcon from "../assets/images/icons/MRN_Download.png"

const DownloadButton = ({enable,onClick})=>{
    return (
        <div className={enable?"active-button":"disable-button"}  label={"Download"} onClick={enable?onClick:()=>{}}>
                    <img style={{width:'30px'}} src={DownloadIcon}/>
        </div>
    )
}

export default DownloadButton