import * as React from 'react';
import dayjs, { Dayjs, locale } from 'dayjs';
import { DemoContainer, DemoItem } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers-pro';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateRange } from '@mui/x-date-pickers-pro';
import { DateRangePicker } from '@mui/x-date-pickers-pro/DateRangePicker';


export default function DateRangePickerValue(props: any) {

    const { value, onChange, label } = props;

    return (
        <LocalizationProvider dateAdapter={AdapterDayjs} >
            <DemoContainer  components={['DateRangePicker', 'DateRangePicker']}>
                <DemoItem label={label ? label : "Select Date Range"} component="DateRangePicker">
                    <DateRangePicker
                        value={value}
                        onChange={onChange}
                    />
                </DemoItem>
            </DemoContainer>
        </LocalizationProvider>
    );
}