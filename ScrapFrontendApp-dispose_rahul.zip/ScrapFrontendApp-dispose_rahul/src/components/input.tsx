import { TextField,Typography  } from '@mui/material'
import React, { useState } from 'react';
import { IconButton, InputAdornment } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import {CONSTANTS }from "../constants/constants";

const style = {
    "& label.Mui-focused": {
      color: CONSTANTS.COLORS.GREEN
    },
    "& .MuiOutlinedInput-root": {
      "&.Mui-focused fieldset": {
        borderColor: CONSTANTS.COLORS.GREEN
      }
    }
  }

const Input = (props: any) => {

    ///////////////////PROPS/////////////////////////////
    let { register,
        label,
        type,
        required,
        autoFocus,
        error,
        onChange,
        defaultValue,
        disabled,
        errormessage,
        isPassword,
        showPassword,
        setShowPassword,
        value,
        multiline,
        minRows,
        onPaste,
        size

    } = props;

    /////////////////////////////////////////////////////
    return <React.Fragment>
        <div style={{ cursor: disabled ? 'not-allowed' : 'pointer' }}>
            <div style={{ pointerEvents: disabled ? 'none' : 'visible' }}>
                <TextField
                    sx={style}
                    multiline={multiline || false}
                    onPaste={onPaste}
                    autoComplete='on'
                    disabled={disabled}
                    margin="normal"
                    required={required || false}
                    type={type}
                    fullWidth
                    label={label}
                    {...register}
                    autoFocus={autoFocus || false}
                    error={error || false}
                    onChange={onChange}
                    value = {value}
                    minRows={minRows}
                    size={size || ""}
                    pattern="d{10}"
                    InputProps={isPassword ? {
                        // <-- This is where the toggle button is added. 
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    aria-label="toggle password visibility"
                                    onClick={setShowPassword}
                                >
                                    {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                                </IconButton>
                            </InputAdornment>
                        )
                    } : {}}
                />

                <Typography variant="subtitle1" color="error" >
                    {errormessage ? errormessage : ""}
                </Typography>

            </div>
        </div>

    </React.Fragment>
}

export default React.memo(Input);