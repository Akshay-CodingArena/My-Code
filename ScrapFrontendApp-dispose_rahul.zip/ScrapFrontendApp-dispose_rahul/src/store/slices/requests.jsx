import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';

const initialState = {
    loadingScrapRequest: false,
    loadingGenerateMRN:false
}

const EDIT_SCRAP = "/scrap/editScrapRequest"
const ADD_SCRAP = "/scrap/addScrapRequest";
const EDIT_DISPOSE = "/scrap/editDisposeRequest"
const EDIT_PHYSICAL_DISPOSE="/dispose/editPhysicalDisposalMovement"
const ADD_DISPOSE = "/dispose/addDisposalRequest";
const ADD_PHYSICAL_DISPOSE= "/dispose/addPhysicalMovement"
const STORE_MANAGER_APPROVAL = "/scrap/scrapRequestApproval"
const GENERATE_MRN_SHEET = "/scrap/downloadMRNList"
const GET_AVAILABLE_QUANTITY = "/dispose/disposeMaterialCategoryList" 

const namespace  = "scrapRequests"

export const editScrap = createAsyncThunk(`${namespace}/editScrap`, async (payload, { rejectWithValue }) => {
    
    let apiPayload = { method: "PUT", data: payload, url: EDIT_SCRAP,headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    } }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestScrap = createAsyncThunk(`${namespace}/requestScrap`, async (payload, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: ADD_SCRAP, headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    } }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const editDispose = createAsyncThunk(`${namespace}/editDispose`, async (payload, { rejectWithValue }) => {
    
    let apiPayload = { method: "PUT", data: payload, url: EDIT_DISPOSE,headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    } }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const editPhysicalDispose = createAsyncThunk(`${namespace}/editPhysicalDispose`, async (payload, { rejectWithValue }) => {
    
    let apiPayload = { method: "PUT", data: payload, url: EDIT_PHYSICAL_DISPOSE,headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    } }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestDispose = createAsyncThunk(`${namespace}/requestDispose`, async (payload, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: ADD_DISPOSE, headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    } }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const addPhysicalDispose = createAsyncThunk(`${namespace}/physical-dispose`, async (payload, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: ADD_PHYSICAL_DISPOSE, headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    } }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const storeManagerApproval = createAsyncThunk(`${namespace}/storeManagerApproval`, async (payload, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: STORE_MANAGER_APPROVAL, headerInfo:{
        // "Content-Type": "multipart/form-data"
        "Content-Type": "application/json"
    }}

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const generateMRNSheet = createAsyncThunk(`${namespace}/getScrapListHOD`, async (payload: any, { rejectWithValue }) => {

    debugger
    let apiPayload = { method: "POST", data: payload, url: `${GENERATE_MRN_SHEET}` }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response; 
})

export const getAvailableQuantity = createAsyncThunk(`${namespace}/getAvailableQuantity`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${GET_AVAILABLE_QUANTITY}?material_code=${payload.material_code}&bincode=${payload.bincode}` }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response; 
})

const requestSlice = createSlice({
    name: 'scrapRequests',
    initialState,
    reducers: {

    },
    extraReducers: builder => {
        //////////////////////////////////////////////////////
        builder.addCase(editScrap.pending, state => {
            state.loadingScrapRequest = true
        })
        builder.addCase(
            editScrap.fulfilled,
            (state, action) => {
                state.loadingScrapRequest = false
            }
        )
        builder.addCase(editScrap.rejected, (state, action) => {
            state.loadingScrapRequest = false
        })

        ////////////////////////////////////////////////////////
        builder.addCase(requestScrap.pending, state => {
            
            state.loadingScrapRequest = true
        })
        builder.addCase(
            requestScrap.fulfilled,
            (state, action) => {
                state.loadingScrapRequest = false
            }
        )
        builder.addCase(requestScrap.rejected, (state, action) => {
            state.loadingScrapRequest = false
        })

        ////////////////////////////////////////////////////////
        builder.addCase(requestDispose.pending, state => {
           
            state.loadingScrapRequest = true
        })
        builder.addCase(
            requestDispose.fulfilled,
            (state, action) => {
                state.loadingScrapRequest = false
            }
        )
        builder.addCase(requestDispose.rejected, (state, action) => {
            state.loadingScrapRequest = false
        })

        ////////////////////////////////////////////////////////
        builder.addCase(addPhysicalDispose.pending, state => {
           
            state.loadingScrapRequest = true
        })
        builder.addCase(
            addPhysicalDispose.fulfilled,
            (state, action) => {
                state.loadingScrapRequest = false
            }
        )
        builder.addCase(addPhysicalDispose.rejected, (state, action) => {
            state.loadingScrapRequest = false
        })

        //////////////////// Store Approval ////////////////////////////
        builder.addCase(storeManagerApproval.pending, state => {
            state.loadingScrapRequest = true
        })
        builder.addCase(
            storeManagerApproval.fulfilled,
            (state, action) => {
                state.loadingScrapRequest = false
            }
        )
        builder.addCase(storeManagerApproval.rejected, (state, action) => {
            state.loadingScrapRequest = false
        })
        builder.addCase(generateMRNSheet.pending, state => {
            debugger
            state.loadingGenerateMRN = true
        })
        builder.addCase(
            generateMRNSheet.fulfilled,
            (state, action) => {
                state.loadingGenerateMRN = false
            }
        )
        builder.addCase(generateMRNSheet.rejected, (state, action) => {
            state.loadingGenerateMRN = false
        })
        }
    })

export default requestSlice.reducer;