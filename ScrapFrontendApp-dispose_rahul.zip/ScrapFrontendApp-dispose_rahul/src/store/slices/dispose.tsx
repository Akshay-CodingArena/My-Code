import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';
import useLocalStorage from '../../utils/localStorage';


type InitialState = {
    loadingScrapDisposeRequestsList: boolean,
    scrapDisposeRequestsList: Array<any>,
    totalDisposeRequestsCount: number,
    loadingScrapDisposeCommitteeApproval: boolean,
    loadingScrapDisposeApprovalCNC: boolean,
    loadingScrapDisposeRequestView: boolean,
    scrapDisposeRequestData: any,
    loadingScrapDisposeEdit: boolean
}
const initialState: InitialState = {
    loadingScrapDisposeRequestsList: false,
    scrapDisposeRequestsList: [],
    totalDisposeRequestsCount: 0,
    loadingScrapDisposeCommitteeApproval: false,
    loadingScrapDisposeApprovalCNC: false,
    loadingScrapDisposeRequestView: false,
    scrapDisposeRequestData: {},
    loadingScrapDisposeEdit: false
}

const namespace = "dispose"
// Generates pending, fulfilled and rejected action types

const SCRAP_DISPOSE_REQUEST_LIST = "/dispose/disposalRequestList";
const PHYSICAL_DISPOSE_REQUEST_LIST = "/dispose/CNCphysicalDisposeList";
const SCRAP_DISPOSE_COMMITTEE_APPROVAL = "/dispose/disposalCommitteeApproval";
const SCRAP_DISPOSE_APPROVAL_CNC = "/dispose/disposalRequestApprovalByCNC";
const PHYSICAL_DISPOSE_APPROVAL_CNC = "/dispose/physicalRequestApprovalByCNC";
const SCRAP_DISPOSE_REQUEST_VIEW = "/dispose/viewDisposalRequest";
const SCRAP_DISPOSE_REQUEST_EDIT = "/dispose/editDisposalRequest";
const SCRAP_PHYSICAL_DISPOSE_VIEW= "/dispose/viewDisposalRequest";
const CNC_PHYSICAL_DISPOSE_VIEW= "/dispose/viewCNCdisposalRequest";

export const getScrapDisposeRequestView = createAsyncThunk(`${namespace}/getScrapDisposeRequestView`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${SCRAP_DISPOSE_REQUEST_VIEW}?scrap_disposal_id=${payload.scrap_disposal_id}&is_permanent=${payload.is_permanent}`;

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getScrapPhysicalDisposeView = createAsyncThunk(`${namespace}/getPhysicalDisposeView`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${SCRAP_PHYSICAL_DISPOSE_VIEW}?scrap_disposal_id=${payload.scrap_disposal_id}&is_permanent=${payload.is_permanent}`;

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getCNCPhysicalDisposeView = createAsyncThunk(`${namespace}/getPhysicalDisposeCNCView`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${CNC_PHYSICAL_DISPOSE_VIEW}?scrap_disposal_id=${payload.scrap_disposal_id}&movement_group=${payload.movement_group}`;

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const ScrapDisposeRequestEdit = createAsyncThunk(`${namespace}/getScrapDisposeRequestEdit`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "PUT", data: payload, url: SCRAP_DISPOSE_REQUEST_EDIT }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})




export const getScrapDisposeRequestsList = createAsyncThunk(`${namespace}/getScrapDisposeRequestsList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${SCRAP_DISPOSE_REQUEST_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.scrap_disposal_id_params) {
        newUrl += `&scrap_disposal_id_params=${payload.scrap_disposal_id_params}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getPhysicalDisposeRequestsList = createAsyncThunk(`${namespace}/getPhysicalDisposeRequestsList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${PHYSICAL_DISPOSE_REQUEST_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.searchParam) {
        newUrl += `&searchParam=${payload.searchParam}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const getScrapDisposeApprovalCNC = createAsyncThunk(`${namespace}/getScrapDisposeApprovalCNC`, async (payload: any, { rejectWithValue }) => {


    let apiPayload = { method: "POST", data: payload, url: SCRAP_DISPOSE_APPROVAL_CNC }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getPhysicalDisposeApprovalCNC = createAsyncThunk(`${namespace}/getPhysicalDisposeApprovalCNC`, async (payload: any, { rejectWithValue }) => {


    let apiPayload = { method: "POST", data: payload, url: PHYSICAL_DISPOSE_APPROVAL_CNC }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getScrapDisposeCommitteeApproval = createAsyncThunk(`${namespace}/getScrapDisposeCommitteeApproval`, async (payload: any, { rejectWithValue }) => {


    let apiPayload = { method: "POST", data: payload, url: SCRAP_DISPOSE_COMMITTEE_APPROVAL }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


const disposeSlice = createSlice({
    name: 'dispose',
    initialState,
    reducers: {},
    extraReducers: builder => {

        ///////////////////////////////////////////////////////////
        builder.addCase(getScrapDisposeRequestsList.pending, state => {
            state.loadingScrapDisposeRequestsList = true;
        })
        builder.addCase(
            getScrapDisposeRequestsList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeRequestsList = false;
                state.scrapDisposeRequestsList = action.payload.data.data.dispose_list;
                state.totalDisposeRequestsCount = action.payload.data.data.dispose_list_count.count
            }
        )
        builder.addCase(getScrapDisposeRequestsList.rejected, (state, action) => {

            state.loadingScrapDisposeRequestsList = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(getPhysicalDisposeRequestsList.pending, state => {
            state.loadingScrapDisposeRequestsList = true;
        })
        builder.addCase(
            getPhysicalDisposeRequestsList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeRequestsList = false;
                state.scrapDisposeRequestsList = action.payload.data.data.getPhysicalDisposalMovementList;
                state.totalDisposeRequestsCount = action.payload.data.data.count
            }
        )
        builder.addCase(getPhysicalDisposeRequestsList.rejected, (state, action) => {

            state.loadingScrapDisposeRequestsList = false;

        })


        /////////////////////////////////////////////////////////////
        builder.addCase(getScrapDisposeCommitteeApproval.pending, state => {
            state.loadingScrapDisposeCommitteeApproval = true;
        })
        builder.addCase(
            getScrapDisposeCommitteeApproval.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeCommitteeApproval = false;
            }
        )
        builder.addCase(getScrapDisposeCommitteeApproval.rejected, (state, action) => {
            state.loadingScrapDisposeCommitteeApproval = false;

        })

        //////////////////////////////////////////////////////
        builder.addCase(getScrapDisposeApprovalCNC.pending, state => {
            state.loadingScrapDisposeApprovalCNC = true;
        })
        builder.addCase(
            getScrapDisposeApprovalCNC.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeApprovalCNC = false;
            }
        )
        builder.addCase(getScrapDisposeApprovalCNC.rejected, (state, action) => {
            state.loadingScrapDisposeApprovalCNC = false;

        })
        //////////////////////////////////////////////////////
        builder.addCase(getPhysicalDisposeApprovalCNC.pending, state => {
            state.loadingScrapDisposeApprovalCNC = true;
        })
        builder.addCase(
            getPhysicalDisposeApprovalCNC.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeApprovalCNC = false;
            }
        )
        builder.addCase(getPhysicalDisposeApprovalCNC.rejected, (state, action) => {
            state.loadingScrapDisposeApprovalCNC = false;

        })
        ///////////////////////////////////////////////////////////
        builder.addCase(getScrapDisposeRequestView.pending, state => {

            state.loadingScrapDisposeRequestView = true;
        })
        builder.addCase(
            getScrapDisposeRequestView.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeRequestView = false;
                state.scrapDisposeRequestData = action.payload.data.data.disposalDetails[0];
            }
        )
        builder.addCase(getScrapDisposeRequestView.rejected, (state, action) => {
            state.loadingScrapDisposeRequestView = false;

        })
        ///////////////////////////////////////////////////////////
        builder.addCase(getScrapPhysicalDisposeView.pending, state => {

            state.loadingScrapDisposeRequestView = true;
        })
        builder.addCase(
            getScrapPhysicalDisposeView.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeRequestView = false;
                state.scrapDisposeRequestData = action.payload.data.data.disposalDetails[0];
                // debugger
            }
        )
        builder.addCase(getScrapPhysicalDisposeView.rejected, (state, action) => {
            state.loadingScrapDisposeRequestView = false;

        })
        //////////////////////////////////////////////////
        builder.addCase(ScrapDisposeRequestEdit.pending, state => {
            state.loadingScrapDisposeEdit = true;
        })
        builder.addCase(
            ScrapDisposeRequestEdit.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapDisposeEdit = false;
            }
        )
        builder.addCase(ScrapDisposeRequestEdit.rejected, (state, action) => {
            state.loadingScrapDisposeEdit = false;
        })

    }
})

export default disposeSlice.reducer;