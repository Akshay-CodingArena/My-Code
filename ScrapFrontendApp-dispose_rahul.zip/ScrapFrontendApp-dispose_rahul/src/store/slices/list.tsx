import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';



type InitialState = {
    ///////////////list having information regarding user auth and modification status's///////////
    loadingManagerUserList: boolean,
    managerUsersListData: Array<any>,
    managerUsersListTotalCount: number,
    loadingMaterialList: boolean,
    materialList: Array<any>,
    departmentList: Array<any>,
    loadingDepartmentList: boolean,
    loadingAddScrap: boolean,
    loadingScrapList: boolean,
    loadingStoreList: boolean,
    scrapRequestlist: Array<any>,
    scrapListTotalCount: number,
    loadingScrapApproval: boolean,
    loadingScrapListHOD: boolean,
    scrapListHOD: Array<any>,
    scrapListCountHOD: number,
    loadingScrapRequestView: boolean,
    scrapRequestView: any
    scrapListSTORE: any,
    scrapListCountSTORE: any,
    scrapCategories: any,
    loadingCategories: boolean,
    loadingBinCode: boolean,
    scrapBinCodes: Array<any>,
    tempRequestView: Array<any>,
    loadingDeleteDisposeDraft: boolean,
    loadingDisposeDraftList: boolean,
    totalCountDisposeDraftList: number,
    loadingScrapDisposalListSheet: boolean,
    loadingInventoryListSheet: boolean,
    loadingMaterialDepositList: boolean,
    loadingMaterialDisposeList:boolean
}
const initialState: InitialState = {
    loadingManagerUserList: false,
    managerUsersListData: [],
    managerUsersListTotalCount: 0,
    loadingMaterialList: false,
    materialList: [],
    departmentList: [],
    loadingDepartmentList: false,
    loadingAddScrap: false,
    loadingScrapList: false,
    scrapRequestlist: [],
    scrapListTotalCount: 0,
    loadingScrapApproval: false,
    loadingScrapListHOD: false,
    loadingScrapRequestView: false,
    loadingStoreList: false,
    scrapListHOD: [],
    scrapListCountHOD: 0,
    scrapListSTORE: [],
    scrapListCountSTORE: 0,
    scrapRequestView: {},
    scrapCategories: [],
    loadingCategories: false,
    loadingBinCode: false,
    scrapBinCodes: [],
    tempRequestView: [],
    loadingDeleteDisposeDraft: false,
    loadingDisposeDraftList: false,
    totalCountDisposeDraftList: 0,
    loadingScrapDisposalListSheet: false,
    loadingInventoryListSheet: false,
    loadingMaterialDepositList: false,
    loadingMaterialDisposeList:false
}

const namespace = "list"
// Generates pending, fulfilled and rejected action types

const MANAGER_USER_LIST = "/user/managerUserList";
const MATERIAL_LIST = "/scrap/materialList";
const DISPOSE_MATERIAL_LIST = "/dispose/disposeMaterialList";
const DEPARTMENT_LIST = "user/listdepartment";
// const ADD_SCRAP = "/scrap/addScrapRequest";
const LIST_SCRAP_REQUEST = "/scrap/userListScrapRequest";
const DOWNLOAD_LIST_SCRAP_REQUEST = "/scrap/downloadScrapDepositList"
const DOWNLOAD_SCRAP_DISPOSAL_LIST = "/dispose/downloadScrapDisposalList"
const DOWNLOAD_PHYSICAL_DISPOSAL_LIST = "/dispose/downloadPhysicalDisposalList"
const DOWNLOAD_PHYSICAL_DISPOSAL_LIST_CNC = "/dispose/downloadPhysicalDisposalListForCNC"
const LIST_SCRAP_DRAFT_REQUESTS = "/scrap/userDraftedListScrapRequest"
const VIEW_DISPOSE_REQUEST = "/dispose/viewDisposalRequest"
const LIST_SCRAP_DISPOSE_DRAFT_REQUESTS = "/dispose/userDraftedListDisposalRequest"
const LIST_PHYSICAL_DISPOSE = "/dispose/physicalDisposeList"
const VIEW_SCRAP_REQUESt = "scrap/viewDepositRequest"
const SCRAP_LIST_HOD = "/scrap/hodListScrapDeposit"
const SCRAP_APPROVAL = "/scrap/scrapRequestApproval";
// const EDIT_SCRAP = "/scrap/editScrapRequest"
const DELETE_DRAFT_REQUEST = "/scrap/deleteDraftScrapRequest"
const DELETE_DISPOSE_DRAFT_REQUEST = "/dispose/deleteDraftDisposalRequest"
const SCRAP_LIST_STORE = "/scrap/storeCNCscrapDepositList"
const CATEGORY_LIST = "/scrap/listCategory"
const DISPOSE_CATEGORY_LIST = "/dispose/disposeMaterialCategoryList"
const BINCODE_LIST = "/scrap/listBincode"
const DISPOSE_BINCODE_LIST = "/dispose/disposeMaterialBincodeList"
const DOWNLOAD_INVENTORY_LIST = "/inventory/downloadInventoryList";

const MATERIAL_DEPOSIT_LIST_REPORT = "/scrap/allMaterialDepositList";
const MATERIAL_DISPOSE_LIST_REPORT="/dispose/allMaterialMovementList";


export const materialDisposeList = createAsyncThunk(`${namespace}/materialDisposeList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload: any = { method: "POST", data: payload, url: MATERIAL_DISPOSE_LIST_REPORT }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const materialDepositList = createAsyncThunk(`${namespace}/materialDepositList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload: any = { method: "POST", data: payload, url: MATERIAL_DEPOSIT_LIST_REPORT }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})



export const getScrapListHOD = createAsyncThunk(`${namespace}/getScrapListHOD`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${SCRAP_LIST_HOD}?hod_id=${payload.hod_id}&list_type=${payload.list_type}&page_number=${payload.page_number}&count=${payload.offset}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : "&scrap_id_params=" + ""}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const getStoreCNCDepositList = createAsyncThunk(`${namespace}/sgetScrapStoreLIST`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${SCRAP_LIST_STORE}?page_number=${payload.page_number}&count=${payload.offset}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : "&scrap_id_params=" + ""}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const scrapApproval = createAsyncThunk(`${namespace}/scrapApproval`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: SCRAP_APPROVAL }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const managerUserList = createAsyncThunk(`${namespace}/managerUserList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${MANAGER_USER_LIST}?user_id=${payload.user_id}&list_type=${payload.list_type}&page_number=${payload.page_number}&count=${payload.offset}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const materialMasterList = createAsyncThunk(`${namespace}/materialList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${MATERIAL_LIST}?page_number=${payload?.page_number}&count=${payload.count}&material_code=${payload.material_code}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const disposeMaterialList = createAsyncThunk(`${namespace}/disposeMaterialList`, async (payload: any, { rejectWithValue }) => {

    // let newurl=`${DISPOSE_MATERIAL_LIST}?page_number=${payload?.page_number}&count=${payload.count}`
    let newurl = `${DISPOSE_MATERIAL_LIST}?page_number=${payload?.page_number}`
    if (payload.count) {
        newurl += `count=${payload.count}`
    }
    if (payload.material_code) {
        newurl += `&material_code=${payload.material_code}`
    }
    let apiPayload = { method: "GET", data: payload, url: newurl }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const departmentMasterList = createAsyncThunk(`${namespace}/departmentList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: DEPARTMENT_LIST }

    let response: any = await useApiService(apiPayload);

    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


// export const requestScrap = createAsyncThunk(`${namespace}/requestScrap`, async (payload: any, { rejectWithValue }) => {

//     let apiPayload = { method: "POST", data: payload, url: ADD_SCRAP, headerInfo:{
//         // "Content-Type": "multipart/form-data"
//         "Content-Type": "application/json"
//     } }

//     let response: any = await useApiService(apiPayload);
//     //////////////If API CRASHES//////////
//     if (response.isCrash) {
//         return rejectWithValue(response.error);
//     }
//     return response;
// })

// export const editScrap = createAsyncThunk(`${namespace}/editScrap`, async (payload: any, { rejectWithValue }) => {

//     let apiPayload = { method: "PUT", data: payload, url: EDIT_SCRAP,headerInfo:{
//         // "Content-Type": "multipart/form-data"
//         "Content-Type": "application/json"
//     } }

//     let response: any = await useApiService(apiPayload);
//     //////////////If API CRASHES//////////
//     if (response.isCrash) {
//         return rejectWithValue(response.error);
//     }
//     return response;
// })


export const requestScrapDrafts = createAsyncThunk(`${namespace}/requestScrapDrafts`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${LIST_SCRAP_DRAFT_REQUESTS}?user_id=${payload.user_id}&page_number=${payload.page_number}&count=${payload.offset}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestDisposeDrafts = createAsyncThunk(`${namespace}/requestDisposeDrafts`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${LIST_SCRAP_DISPOSE_DRAFT_REQUESTS}?page_number=${payload.page_number}&count=${payload.offset}&user_id=${payload.user_id}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestPhysicalDispose = createAsyncThunk(`${namespace}/requestPhysicalDispose`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${LIST_PHYSICAL_DISPOSE}?page_number=${payload.page_number}&count=${payload.offset}`;

    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.disposal_id) {
        newUrl += `&searchParam=${payload.disposal_id}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const viewScrapRequest = createAsyncThunk(`${namespace}/requestScrapDraft`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${VIEW_SCRAP_REQUESt}?scrap_id=${payload.scrap_id}&is_permanent=${payload.isPermanent}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const viewDisposalRequest = createAsyncThunk(`${namespace}/requestDisposeDraft`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${VIEW_DISPOSE_REQUEST}?scrap_disposal_id=${payload.scrap_id}&is_permanent=${payload.isPermanent}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getRequestScrapList = createAsyncThunk(`${namespace}/requestScrapList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${LIST_SCRAP_REQUEST}?user_id=${payload.user_id}&list_type=${payload.list_type}&page_number=${payload.page_number}&count=${payload.offset}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : ""}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const downloadRequestScrapList = createAsyncThunk(`${namespace}/downloadRequestScrapList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_LIST_SCRAP_REQUEST}?user_id=${payload.user_id}&list_type=${payload.list_type}&page_number=${payload.page_number ? payload.page_number : ""}&count=${payload.offset ? payload.offset : ""}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : ""}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const downloadScrapDisposalList = createAsyncThunk(`${namespace}/downloadScrapDisposalList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_SCRAP_DISPOSAL_LIST}?&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}&scrap_disposal_id_params=${payload?.scrap_disposal_id_params || ""}` }
    // ?user_id=${payload.user_id}&list_type=${payload.list_type}&page_number=${payload.page_number ? payload.page_number : ""}&count=${payload.offset ? payload.offset : ""}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : ""}
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const downloadPhysicalDisposalList = createAsyncThunk(`${namespace}/downloadPhysicalDisposalList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_PHYSICAL_DISPOSAL_LIST}?&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}&searchParam=${payload?.disposal_id || ""}` }
    // let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_PHYSICAL_DISPOSAL_LIST}?&searchParam=${payload?.disposal_id || ""}` }
    // ?user_id=${payload.user_id}&list_type=${payload.list_type}&page_number=${payload.page_number ? payload.page_number : ""}&count=${payload.offset ? payload.offset : ""}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : ""}
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const downloadPhysicalDisposalListCNC = createAsyncThunk(`${namespace}/downloadPhysicalDisposalListCNC`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_PHYSICAL_DISPOSAL_LIST_CNC}?&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}&searchParam=${payload?.disposal_id || ""}` }
    // let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_PHYSICAL_DISPOSAL_LIST}?&searchParam=${payload?.disposal_id || ""}` }
    // ?user_id=${payload.user_id}&list_type=${payload.list_type}&page_number=${payload.page_number ? payload.page_number : ""}&count=${payload.offset ? payload.offset : ""}&start_date=${payload?.start_date || ""}&end_date=${payload?.end_date || ""}${payload.department ? "&department_params=" + payload.department : ""}${payload.scrap_id_params != undefined ? "&scrap_id_params=" + payload.scrap_id_params : ""}
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const downloadInventoryList = createAsyncThunk(`${namespace}/downloadInventoryList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_INVENTORY_LIST}?&material_search_param=${payload?.material_search_param || ""}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const deleteDraftScrapRequest = createAsyncThunk('delete/draft', async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "PUT", data: payload, url: `${DELETE_DRAFT_REQUEST}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const deleteDraftDisposeRequest = createAsyncThunk('delete/deleteDraftDisposeRequest', async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "PUT", data: payload, url: `${DELETE_DISPOSE_DRAFT_REQUEST}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const listCategory = createAsyncThunk(`${namespace}/categoryList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${CATEGORY_LIST}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const disposeListCategory = createAsyncThunk(`${namespace}/disposeCategoryList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DISPOSE_CATEGORY_LIST}?material_code=${payload.material_code}&bincode=${payload.bincode}` }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    response.index = payload.index;
    return response;
})

export const listBinCode = createAsyncThunk(`${namespace}/binCodeList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${BINCODE_LIST}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const disposeListBinCode = createAsyncThunk(`${namespace}/disposeBinCodeList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DISPOSE_BINCODE_LIST}?material_code=${payload.material_code}` }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    response.index = payload.index
    return response;
})

const listSlice = createSlice({
    name: 'list',
    initialState,
    reducers: {
        dumpRequest: (state, action) => {
            state.scrapRequestView = {};
        },
        dumpRequestList: (state, action) => {
            state.scrapRequestlist = []
        }
    },
    extraReducers: builder => {
        //////////////////////////////////////////////////////
        builder.addCase(managerUserList.pending, state => {
            state.loadingManagerUserList = true
        })
        builder.addCase(
            managerUserList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingManagerUserList = false;
                state.managerUsersListData = action.payload.data.data.manager_user_list;
                state.managerUsersListTotalCount = action.payload.data.data.count;
            }
        )
        builder.addCase(managerUserList.rejected, (state, action) => {
            state.loadingManagerUserList = false
        })

        ////////////////////////////////////////////////////////////

        builder.addCase(materialMasterList.pending, state => {
            state.loadingMaterialList = true;
        })
        builder.addCase(
            materialMasterList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMaterialList = false;
                state.materialList = action.payload.data.data;
            }
        )
        builder.addCase(materialMasterList.rejected, (state, action) => {
            state.loadingMaterialList = false
        })

        ////////////////////////////////////////////////////////////

        builder.addCase(disposeMaterialList.pending, state => {
            state.loadingMaterialList = true;
        })
        builder.addCase(
            disposeMaterialList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMaterialList = false;
                state.materialList = action.payload.data.data;
            }
        )
        builder.addCase(disposeMaterialList.rejected, (state, action) => {
            state.loadingMaterialList = false
        })
        ////////////////////////////////////////////////
        builder.addCase(departmentMasterList.pending, state => {
            state.loadingDepartmentList = true;
        })
        builder.addCase(
            departmentMasterList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingDepartmentList = false;

                state.departmentList = action.payload.data?.data?.map((data: any) => {
                    return { label: data.department, value: data.id }
                });
            }
        )
        builder.addCase(departmentMasterList.rejected, (state, action) => {
            state.loadingDepartmentList = false
        })



        /////////////////////////////////////////////////

        // builder.addCase(requestScrap.pending, state => {
        //     state.loadingAddScrap = true;
        // })
        // builder.addCase(
        //     requestScrap.fulfilled,
        //     (state, action: PayloadAction<any>) => {
        //         state.loadingAddScrap = false;
        //     }
        // )
        // builder.addCase(requestScrap.rejected, (state, action) => {
        //     state.loadingAddScrap = false
        // })

        //////////////////////////////////////

        builder.addCase(getRequestScrapList.pending, state => {
            state.loadingScrapList = true;
        })
        builder.addCase(
            getRequestScrapList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapList = false;
                state.scrapRequestlist = action.payload.data.data.getListData;
                state.scrapListTotalCount = action.payload.data.data.scrap_request_count
            }
        )
        builder.addCase(getRequestScrapList.rejected, (state, action) => {
            state.loadingScrapList = false
        })
        ////////////////////////////////////////////////////


        builder.addCase(scrapApproval.pending, state => {
            state.loadingScrapApproval = true;
        })
        builder.addCase(
            scrapApproval.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapApproval = false;
            }
        )
        builder.addCase(scrapApproval.rejected, (state, action) => {
            state.loadingScrapApproval = false
        })

        ////////////////////////////////////////////////////////////


        builder.addCase(getScrapListHOD.pending, state => {

            state.loadingScrapListHOD = true;

        })
        builder.addCase(
            getScrapListHOD.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapListHOD = false;

                state.scrapListHOD = action.payload.data.data.hod_list_scrap_deposit;
                state.scrapListCountHOD = action.payload.data.data.hod_list_scrap_deposit_count;
            }
        )
        builder.addCase(getScrapListHOD.rejected, (state, action) => {
            state.loadingScrapListHOD = false
        })

        // Request CNC and Store List

        builder.addCase(
            getStoreCNCDepositList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingStoreList = false;
                console.log("list is sndjsa", action.payload)
                state.scrapListSTORE = action.payload.data.data.StoreDepositList ?? action.payload.data.data.CNCDepositList;
                state.scrapListCountSTORE = action.payload.data.data.StoreDepositListCount ?? action.payload.data.data.CNCScrapDepositListCount;
            }
        )
        builder.addCase(getStoreCNCDepositList.pending, state => {
            state.loadingStoreList = true;
        })
        builder.addCase(getStoreCNCDepositList.rejected, (state, action) => {
            state.loadingStoreList = false
        })

        // Request View Scrap
        builder.addCase(viewScrapRequest.pending, (state, action) => {
            state.loadingScrapRequestView = true
        })
        builder.addCase(viewScrapRequest.fulfilled, (state, action) => {
            // state.scrapRequestView = action.payload.data.data.depositDetails     Temp Change
            state.scrapRequestView = action.payload.data.data.depositDetails
            state.tempRequestView = action.payload.data.data.temp_store_material_data
            state.loadingScrapRequestView = false
        })
        builder.addCase(viewScrapRequest.rejected, (state, action) => {
            state.loadingScrapRequestView = false
        })

        // Request View Scrap
        builder.addCase(viewDisposalRequest.pending, (state, action) => {
            state.loadingScrapRequestView = true
        })
        builder.addCase(viewDisposalRequest.fulfilled, (state, action) => {
            // state.scrapRequestView = action.payload.data.data.depositDetails     Temp Change
            state.scrapRequestView = action.payload.data.data.depositDetails
            state.tempRequestView = action.payload.data.data.temp_store_material_data
            state.loadingScrapRequestView = false
        })
        builder.addCase(viewDisposalRequest.rejected, (state, action) => {
            state.loadingScrapRequestView = false
        })


        // Category List    
        builder.addCase(listCategory.pending, (state, action) => {
            state.loadingCategories = true
        })
        builder.addCase(listCategory.fulfilled, (state, action) => {
            state.scrapCategories = action.payload.data.data
            state.loadingCategories = false
        })
        builder.addCase(listCategory.rejected, (state, action) => {
            state.loadingCategories = false
        })
        // DisposeCategory List    
        builder.addCase(disposeListCategory.pending, (state, action) => {
            state.loadingCategories = true
        })
        builder.addCase(disposeListCategory.fulfilled, (state, action) => {
            console.log(action)
            state.scrapCategories[action.payload.index] = action.payload.data.data
            state.loadingCategories = false
        })
        builder.addCase(disposeListCategory.rejected, (state, action) => {
            state.loadingCategories = false
        })
        // Bincode list disposeListBinCode    
        builder.addCase(disposeListBinCode.pending, (state, action) => {
            state.loadingBinCode = true
        })
        builder.addCase(disposeListBinCode.fulfilled, (state, action) => {
            state.scrapBinCodes[action.payload.index] = action.payload.data.data
            debugger
            state.loadingBinCode = false
        })
        builder.addCase(disposeListBinCode.rejected, (state, action) => {
            state.loadingBinCode = false
        })

        // Bincode list ;istBinCode    
        builder.addCase(listBinCode.pending, (state, action) => {
            state.loadingBinCode = true
        })
        builder.addCase(listBinCode.fulfilled, (state, action) => {
            state.scrapBinCodes = action.payload.data.data
            state.loadingBinCode = false
        })
        builder.addCase(listBinCode.rejected, (state, action) => {
            state.loadingBinCode = false
        })

        builder.addCase(deleteDraftDisposeRequest.pending, (state, action) => {
            state.loadingDeleteDisposeDraft = true;

        })
        builder.addCase(deleteDraftDisposeRequest.fulfilled, (state, action) => {
            state.loadingDeleteDisposeDraft = false;
        })
        builder.addCase(deleteDraftDisposeRequest.rejected, (state, action) => {
            state.loadingDeleteDisposeDraft = false;
        })

        /////////////////////////////////////////////////////

        builder.addCase(requestDisposeDrafts.pending, (state, action) => {
            state.loadingDisposeDraftList = true;

        })
        builder.addCase(requestDisposeDrafts.fulfilled, (state, action) => {
            state.loadingDisposeDraftList = false;
            state.totalCountDisposeDraftList = action.payload.data.data.scrap_request_count;
        })
        builder.addCase(requestDisposeDrafts.rejected, (state, action) => {
            state.loadingDisposeDraftList = false;

        })

        builder.addCase(requestPhysicalDispose.pending, (state, action) => {
            state.loadingDisposeDraftList = true;

        })
        builder.addCase(requestPhysicalDispose.fulfilled, (state, action) => {
            state.loadingDisposeDraftList = false;
            state.totalCountDisposeDraftList = action.payload.data.data.Count[0].physical_disposal_count;
        })
        builder.addCase(requestPhysicalDispose.rejected, (state, action) => {
            state.loadingDisposeDraftList = false;

        })

        /////////////////////////////////////////////////////////
        builder.addCase(downloadScrapDisposalList.pending, (state, action) => {
            state.loadingScrapDisposalListSheet = true;

        })
        builder.addCase(downloadScrapDisposalList.fulfilled, (state, action) => {
            state.loadingScrapDisposalListSheet = false;
        })
        builder.addCase(downloadScrapDisposalList.rejected, (state, action) => {
            state.loadingScrapDisposalListSheet = false;

        })

        /////////////////////////////////////////////////////////
        builder.addCase(downloadPhysicalDisposalList.pending, (state, action) => {
            state.loadingScrapDisposalListSheet = true;

        })
        builder.addCase(downloadPhysicalDisposalList.fulfilled, (state, action) => {
            state.loadingScrapDisposalListSheet = false;
        })
        builder.addCase(downloadPhysicalDisposalList.rejected, (state, action) => {
            state.loadingScrapDisposalListSheet = false;

        })

        /////////////////////////////////////////////////////////
        builder.addCase(downloadPhysicalDisposalListCNC.pending, (state, action) => {
            state.loadingScrapDisposalListSheet = true;

        })
        builder.addCase(downloadPhysicalDisposalListCNC.fulfilled, (state, action) => {
            state.loadingScrapDisposalListSheet = false;
        })
        builder.addCase(downloadPhysicalDisposalListCNC.rejected, (state, action) => {
            state.loadingScrapDisposalListSheet = false;

        })
        /////////////////////////////////////////////////////////
        builder.addCase(downloadInventoryList.pending, (state, action) => {
            state.loadingInventoryListSheet = true;

        })
        builder.addCase(downloadInventoryList.fulfilled, (state, action) => {
            state.loadingInventoryListSheet = false;
        })
        builder.addCase(downloadInventoryList.rejected, (state, action) => {
            state.loadingInventoryListSheet = false;

        })
        /////////////////////////////////////////////////////////////////////
        builder.addCase(materialDepositList.pending, (state, action) => {
            state.loadingMaterialDepositList = true;
        })
        builder.addCase(materialDepositList.fulfilled, (state, action) => {
            debugger
            state.loadingMaterialDepositList = false;
        })
        builder.addCase(materialDepositList.rejected, (state, action) => {
            state.loadingMaterialDepositList = false;

        })
        ////////////////////////////////////////////////
        builder.addCase(materialDisposeList.pending, (state, action) => {
            state.loadingMaterialDisposeList = true;
        })
        builder.addCase(materialDisposeList.fulfilled, (state, action) => {
            state.loadingMaterialDisposeList = false;
        })
        builder.addCase(materialDisposeList.rejected, (state, action) => {
            state.loadingMaterialDisposeList = false;

        })
    }
})

export const { dumpRequest, dumpRequestList } = listSlice.actions

export default listSlice.reducer;
