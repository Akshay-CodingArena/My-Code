import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';
import useLocalStorage from '../../utils/localStorage';


type InitialState = {
    loadingInventoryList: boolean,
    inventoryList: Array<any>,
    totalInventoryItemCount: number,
    binCodesByMcode: Array<any>,
    loadingBinCodes: boolean,
    loadingInventoryBinList: boolean,
    inventoryBinList: Array<any>
    loadingInventoryShiftList: boolean,
    inventoryShiftList: Array<any>,
    loadingMaterialDisposeLogs: boolean,
    totalMaterialDisposeLogs: number,
    materialDisposeLogs: Array<any>,
    totalMovementItemCount: number,
    loadingMovementList: boolean,
    movementList: Array<any>,
    totalMaterialDepositLogs: number,
    loadingMaterialDepositLogs: boolean,
    materialDepositLogs: Array<any>,
    materialDepositTransactionLogs: Array<any>,
    totalMaterialDepositTransactionLogs: number,
    loadingMaterialDepositTransactionLogs: boolean,
    materialDisposeTransactionLogs: Array<any>,
    totalMaterialDisposeTransactionLogs: number,
    loadingMaterialDisposeTransactionLogs: boolean,
    totalCountChangeList: number,
    loadingChangeList: boolean,
    loadingChangeListApproval: boolean,
    loadingInventoryCategoryList: boolean,
    allCategories: Array<any>,
    loadingGetBincodeChangeExcel:boolean
}
const initialState: InitialState = {
    loadingInventoryList: false,
    inventoryList: [],
    totalInventoryItemCount: 0,
    binCodesByMcode: [],
    loadingBinCodes: false,
    loadingInventoryBinList: false,
    inventoryBinList: [],
    loadingInventoryShiftList: false,
    inventoryShiftList: [],
    loadingMaterialDisposeLogs: false,
    totalMaterialDisposeLogs: 0,
    materialDisposeLogs: [],
    totalMovementItemCount: 0,
    loadingMovementList: false,
    movementList: [],
    totalMaterialDepositLogs: 0,
    loadingMaterialDepositLogs: false,
    materialDepositLogs: [],
    materialDepositTransactionLogs: [],
    loadingMaterialDepositTransactionLogs: false,
    totalMaterialDepositTransactionLogs: 0,
    materialDisposeTransactionLogs: [],
    totalMaterialDisposeTransactionLogs: 0,
    loadingMaterialDisposeTransactionLogs: false,
    totalCountChangeList: 0,
    loadingChangeList: false,
    loadingChangeListApproval: false,
    loadingInventoryCategoryList: false,
    allCategories: [],
    loadingGetBincodeChangeExcel:false
}

const namespace = "inventory"
const INVENTORY_LIST = "/inventory/inventoryList"
const MOVEMENT_LIST = "/dispose/movementListForAudit"
const MATERIAL_DISPOSE_LOGS = "/dispose/disposalRequestList"
const MATERIAL_DEPOSIT_LOGS = "/admin/adminScrapList"
const BINCODES_BY_MCODE = "/inventory/getBinCodeByMaterialCode"
const MATERIAL_DEPOSIT_TRANSACTION_LOGS = "/admin/scrapApprovalLogs"
const MATERIAL_DISPOSE_TRANSACTION_LOGS = "/admin/disposalApprovalLogs"
const INVENTORY_BINCODE_LIST = "/inventory/fetchBinCodeList"
const INVENTORY_CATEGORY_LIST = "/scrap/listCategory"
const INVENTORY_SHIFT_LIST = "/inventory/materialShiftingByBinCodeOrMaterialCode"
const CATEGORY_SHIFT_LIST = "/inventory/inventoryCategoryListByMaterialCode"
const ADD_BINCODE_CHANGE = "/inventory/requestForQuantityShifting"
const ADD_CATEGORY_CHANGE = "/inventory/requestForCategoryShifting"
const GET_CHANGE_LIST = "/inventory/listOfShiftingRequest"
const GET_CATEGORY_CHANGE_LIST = "/inventory/listOfCategoryShiftingRequest"
const BIN_CODE_CHANGE_CNC_APPROVAL = "/inventory/shiftingApprovalByCNC"
const CATEGORY_CHANGE_CNC_APPROVAL = "/inventory/categoryShiftingApprovalCNC";
const GET_BINCODE_CHANGE_EXCEL="/inventory/downloadExcelSheetlistOfShiftingRequest";


export const getBincodeChangeExcel = createAsyncThunk(`${namespace}/getBincodeChangeExcel`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: GET_BINCODE_CHANGE_EXCEL }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})




export const getInventoryList = createAsyncThunk(`${namespace}/getInventoryList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${INVENTORY_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.material_code) {
        newUrl += `&material_search_param=${payload.material_code}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getMovementList = createAsyncThunk(`${namespace}/getMovementList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${MOVEMENT_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.disposal_id) {
        newUrl += `&disposal_id_params=${payload.disposal_id}`;
    }
    if (payload.material_code) {
        newUrl += `&material_code_params=${payload.material_code}`;
    }


    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const downloadMaterialDepositTransactionLogs = createAsyncThunk(`${namespace}/downloadMaterialDepositTransactionLogs`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${MATERIAL_DEPOSIT_TRANSACTION_LOGS}${payload.isDownload?"?isDownload=true":"?page_number="+payload.page_number+"&"+"count="+payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.scrap_id) {
        newUrl += `&scrap_id=${payload.scrap_id}`;
    }
    // if (payload.material_code) {
    //     newUrl += `&material_code_params=${payload.material_code}`;
    // }


    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getMaterialDepositTransactionLogs = createAsyncThunk(`${namespace}/getMaterialDepositTransactionLogs`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${MATERIAL_DEPOSIT_TRANSACTION_LOGS}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.scrap_id) {
        newUrl += `&scrap_id=${payload.scrap_id}`;
    }
    // if (payload.material_code) {
    //     newUrl += `&material_code_params=${payload.material_code}`;
    // }


    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getMaterialDisposeTransactionLogs = createAsyncThunk(`${namespace}/getMaterialDisposeTransactionLogs`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${MATERIAL_DISPOSE_TRANSACTION_LOGS}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.disposal_id) {
        newUrl += `&scrap_disposal_id=${payload.disposal_id}`;
    }
    if (payload.material_code) {
        newUrl += `&material_code_params=${payload.material_code}`;
    }


    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getMaterialDisposeLogs = createAsyncThunk(`${namespace}/getMaterialDisposeLogs`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${MATERIAL_DISPOSE_LOGS}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }

    if (payload.disposal_id) {
        newUrl += `&scrap_disposal_id_params=${payload.disposal_id}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getMaterialDepositLogs = createAsyncThunk(`${namespace}/getMaterialDepositLogs`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${MATERIAL_DEPOSIT_LOGS}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }


    if (payload.scrap_id) {
        newUrl += `&scrap_id_params=${payload.scrap_id}`;
    }

    if (payload.department) {
        newUrl += `&department_params=${payload.department}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getBinCodesByMcode = createAsyncThunk(`${namespace}/getBinCodesByMcode`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${BINCODES_BY_MCODE}?page_number=${payload.page_number}&count=${payload.count}&material_code=${payload.material_code}`;
    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const inventoryListBinCode = createAsyncThunk(`${namespace}/inventoryBinCodeList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${INVENTORY_BINCODE_LIST}?bincode=${payload.bincode}` }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    response.index = payload.index
    return response;
})

export const inventoryListCategory = createAsyncThunk(`${namespace}/inventoryCategoryList`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${INVENTORY_CATEGORY_LIST}` }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getInventoryShiftList = createAsyncThunk(`${namespace}/getInventoryShiftList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${INVENTORY_SHIFT_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.material_code) {
        newUrl += `&material_code=${payload.material_code}`;
    }

    if (payload.bincode) {
        newUrl += `&bincode=${payload.bincode}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getCategoryShiftList = createAsyncThunk(`${namespace}/getCategoryShiftList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${CATEGORY_SHIFT_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.material_code) {
        newUrl += `&material_code=${payload.material_code}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestBinCodeChange = createAsyncThunk(`${namespace}/requestBinCodeChange`, async (payload, { rejectWithValue }) => {

    let apiPayload = {
        method: "POST", data: payload, url: ADD_BINCODE_CHANGE, headerInfo: {
            // "Content-Type": "multipart/form-data"
            "Content-Type": "application/json"
        }
    }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestCategoryChange = createAsyncThunk(`${namespace}/requestCategoryChange`, async (payload, { rejectWithValue }) => {

    let apiPayload = {
        method: "POST", data: payload, url: ADD_CATEGORY_CHANGE, headerInfo: {
            // "Content-Type": "multipart/form-data"
            "Content-Type": "application/json"
        }
    }

    let response = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestChangeList = createAsyncThunk(`${namespace}/requestChangeList`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${GET_CHANGE_LIST}?page_number=${payload.page_number}&count=${payload.offset}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const requestCategoryChangeList = createAsyncThunk(`${namespace}/requestCategoryChangeList`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "GET", data: payload, url: `${GET_CATEGORY_CHANGE_LIST}?page_number=${payload.page_number}&count=${payload.offset}` }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getBinCodeChangeApprovalCNC = createAsyncThunk(`${namespace}/getBinCodeChangeApprovalCNC`, async (payload: any, { rejectWithValue }) => {


    let apiPayload = { method: "POST", data: payload, url: BIN_CODE_CHANGE_CNC_APPROVAL }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const getCategoryChangeApprovalCNC = createAsyncThunk(`${namespace}/getCategoryChangeApprovalCNC`, async (payload: any, { rejectWithValue }) => {


    let apiPayload = { method: "POST", data: payload, url: CATEGORY_CHANGE_CNC_APPROVAL }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

const inventorySlice = createSlice({
    name: 'inventory',
    initialState,
    reducers: {},
    extraReducers: builder => {

        ///////////////////////////////////////////////////////////
        builder.addCase(getInventoryList.pending, state => {
            state.loadingInventoryList = true;
        })
        builder.addCase(
            getInventoryList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingInventoryList = false;
                state.inventoryList = action.payload.data.data.fetchInventoryData;
                state.totalInventoryItemCount = action.payload.data.data.count[0].count
            }
        )
        builder.addCase(getInventoryList.rejected, (state, action) => {

            state.loadingInventoryList = false;

        })
        ///////////////////////////////////////////////////////////
        builder.addCase(requestBinCodeChange.pending, state => {
            state.loadingInventoryList = true;
        })
        builder.addCase(
            requestBinCodeChange.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingInventoryList = false;
            }
        )
        builder.addCase(requestBinCodeChange.rejected, (state, action) => {

            state.loadingInventoryList = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(requestCategoryChange.pending, state => {
            state.loadingInventoryList = true;
        })
        builder.addCase(
            requestCategoryChange.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingInventoryList = false;
            }
        )
        builder.addCase(requestCategoryChange.rejected, (state, action) => {

            state.loadingInventoryList = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(getMovementList.pending, state => {
            state.loadingMovementList = true;
        })
        builder.addCase(
            getMovementList.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMovementList = false;
                state.movementList = action.payload.data.data.movementList;
                state.totalMovementItemCount = action.payload.data.data.count[0].count
            }
        )
        builder.addCase(getMovementList.rejected, (state, action) => {

            state.loadingMovementList = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(getMaterialDisposeLogs.pending, state => {
            state.loadingMaterialDisposeLogs = true;
        })
        builder.addCase(
            getMaterialDisposeLogs.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMaterialDisposeLogs = false;
                state.materialDisposeLogs = action.payload.data.data.dispose_list;
                state.totalMaterialDisposeLogs = action.payload.data.data.dispose_list_count.count
            }
        )
        builder.addCase(getMaterialDisposeLogs.rejected, (state, action) => {

            state.loadingMaterialDisposeLogs = false;

        })

        ///////////////////////downloadMaterialDepositTransactionLogs////////////////////////////////////

        builder.addCase(downloadMaterialDepositTransactionLogs.pending, state => {
            state.loadingMaterialDepositTransactionLogs = true;
        })
        builder.addCase(
            downloadMaterialDepositTransactionLogs.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMaterialDepositTransactionLogs = false;
                // state.materialDepositTransactionLogs = action.payload.data.data.getAllScrapListData;
                // state.totalMaterialDepositTransactionLogs = action.payload?.data?.data?.depositLogsCount ? action.payload.data.data.depositLogsCount : 0;
            }
        )
        builder.addCase(downloadMaterialDepositTransactionLogs.rejected, (state, action) => {

            state.loadingMaterialDepositTransactionLogs = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(getMaterialDepositTransactionLogs.pending, state => {
            state.loadingMaterialDepositTransactionLogs = true;
        })
        builder.addCase(
            getMaterialDepositTransactionLogs.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMaterialDepositTransactionLogs = false;
                state.materialDepositTransactionLogs = action.payload.data.data.getAllScrapListData;
                state.totalMaterialDepositTransactionLogs = action.payload?.data?.data?.depositLogsCount ? action.payload.data.data.depositLogsCount : 0;
            }
        )
        builder.addCase(getMaterialDepositTransactionLogs.rejected, (state, action) => {

            state.loadingMaterialDepositTransactionLogs = false;

        })
        ///////////////////////////////////////////////////////////
        builder.addCase(getMaterialDisposeTransactionLogs.pending, state => {
            state.loadingMaterialDisposeTransactionLogs = true;
        })
        builder.addCase(
            getMaterialDisposeTransactionLogs.fulfilled,
            (state, action: PayloadAction<any>) => {
                debugger
                state.loadingMaterialDisposeTransactionLogs = false;
                state.materialDisposeTransactionLogs = action.payload.data.data.disposalApprovalLogs;
                state.totalMaterialDisposeTransactionLogs = action.payload.data.data.disposeLogsCount;
            }
        )
        builder.addCase(getMaterialDisposeTransactionLogs.rejected, (state, action) => {

            state.loadingMaterialDisposeTransactionLogs = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(getMaterialDepositLogs.pending, state => {
            state.loadingMaterialDepositLogs = true;
        })
        builder.addCase(
            getMaterialDepositLogs.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingMaterialDepositLogs = false;
                state.materialDepositLogs = action.payload.data.data.getAllScrapListData;
                state.totalMaterialDepositLogs = action.payload.data.data.getAllScrapListDataCount[0].request_count
            }
        )
        builder.addCase(getMaterialDepositLogs.rejected, (state, action) => {

            state.loadingMaterialDepositLogs = false;

        })

        ///////////////////////////////////////////////////////////
        builder.addCase(getBinCodesByMcode.pending, state => {
            state.loadingBinCodes = true;
        })
        builder.addCase(
            getBinCodesByMcode.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingBinCodes = false;
                state.binCodesByMcode = action.payload.data.data;
            }
        )
        builder.addCase(getBinCodesByMcode.rejected, (state, action) => {

            state.loadingBinCodes = false;

        })

        ////////////////////////////////////////////////////////////

        builder.addCase(inventoryListBinCode.pending, state => {
            state.loadingInventoryBinList = true;
        })
        builder.addCase(
            inventoryListBinCode.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingInventoryBinList = false;
                state.inventoryBinList[action.payload.index] = action.payload.data.data;
            }
        )
        builder.addCase(inventoryListBinCode.rejected, (state, action) => {
            state.loadingInventoryBinList = false
        })



        ////////////////////////////////////////////////////////////

        builder.addCase(inventoryListCategory.pending, state => {
            state.loadingInventoryCategoryList = true;
        })
        builder.addCase(
            inventoryListCategory.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingInventoryCategoryList = false;
                debugger
                state.allCategories = action.payload.data.data;
            }
        )
        builder.addCase(inventoryListCategory.rejected, (state, action) => {
            state.loadingInventoryCategoryList = false
        })
        ////////////////////////////////////////////////////////////

        builder.addCase(getInventoryShiftList.pending, (state, action) => {
            state.loadingInventoryShiftList = true
        })
        builder.addCase(getInventoryShiftList.fulfilled, (state, action) => {
            state.inventoryShiftList = action.payload.data.data
            state.loadingInventoryShiftList = false
        })
        builder.addCase(getInventoryShiftList.rejected, (state, action) => {
            state.loadingInventoryShiftList = false
        })


        ////////////////////////////////////////////////////////////

        builder.addCase(getCategoryShiftList.pending, (state, action) => {
            state.loadingInventoryShiftList = true
        })
        builder.addCase(getCategoryShiftList.fulfilled, (state, action) => {
            state.inventoryShiftList = action.payload.data.data.list
            state.loadingInventoryShiftList = false
        })
        builder.addCase(getCategoryShiftList.rejected, (state, action) => {
            state.loadingInventoryShiftList = false
        })
        /////////////////////////////////////////////////////

        builder.addCase(requestChangeList.pending, (state, action) => {
            state.loadingChangeList = true;

        })
        builder.addCase(requestChangeList.fulfilled, (state, action) => {
            state.loadingChangeList = false;
            state.totalCountChangeList = action.payload.data.data.count[0].count;
        })
        builder.addCase(requestChangeList.rejected, (state, action) => {
            state.loadingChangeList = false;

        })


        /////////////////////////////////////////////////////

        builder.addCase(requestCategoryChangeList.pending, (state, action) => {
            state.loadingChangeList = true;

        })
        builder.addCase(requestCategoryChangeList.fulfilled, (state, action) => {
            state.loadingChangeList = false;
            state.totalCountChangeList = action.payload.data.data.count[0].count;
        })
        builder.addCase(requestCategoryChangeList.rejected, (state, action) => {
            state.loadingChangeList = false;

        })

        //////////////////////////////////////////////////////
        builder.addCase(getBinCodeChangeApprovalCNC.pending, state => {
            state.loadingChangeListApproval = true;
        })
        builder.addCase(
            getBinCodeChangeApprovalCNC.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingChangeListApproval = false;
            }
        )
        builder.addCase(getBinCodeChangeApprovalCNC.rejected, (state, action) => {
            state.loadingChangeListApproval = false;

        })

        //////////////////////////////////////////////////////
        builder.addCase(getCategoryChangeApprovalCNC.pending, state => {
            state.loadingChangeListApproval = true;
        })
        builder.addCase(
            getCategoryChangeApprovalCNC.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingChangeListApproval = false;
            }
        )
        builder.addCase(getCategoryChangeApprovalCNC.rejected, (state, action) => {
            state.loadingChangeListApproval = false;

        })
        ///////////////////////////////////
    
        builder.addCase(getBincodeChangeExcel.pending, state => {
            state.loadingGetBincodeChangeExcel = true;
        })
        builder.addCase(
            getBincodeChangeExcel.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingGetBincodeChangeExcel = false;
            }
        )
        builder.addCase(getBincodeChangeExcel.rejected, (state, action) => {
            state.loadingGetBincodeChangeExcel = false;
        })
    }
})

export default inventorySlice.reducer;