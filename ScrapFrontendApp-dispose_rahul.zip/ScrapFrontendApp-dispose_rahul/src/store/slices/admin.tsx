import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';
import useLocalStorage from '../../utils/localStorage';
type InitialState = {
    loadingCreateUser: boolean,
    loadingGetAccounts: boolean,
    accounts: Array<any>,
    total_accounts: any,
    loadingDownloadSheet: boolean,
    loadingBincodeSheet: boolean,
    loadingMaterialcodeSheet: boolean,
    loadingMaterialCategory: boolean,
    loadingEnableOrDisableUser: boolean,
    loadingScrapList: boolean,
    scrapList: Array<any>,
    totalScrapCount: any,
    loadingScrapListSheet: boolean,
}
const initialState: InitialState = {
    loadingCreateUser: false,
    loadingGetAccounts: false,
    accounts: [],
    total_accounts: 0,
    loadingDownloadSheet: false,
    loadingBincodeSheet: false,
    loadingMaterialcodeSheet: false,
    loadingMaterialCategory: false,
    loadingEnableOrDisableUser: false,
    loadingScrapList: false,
    scrapList: [],
    totalScrapCount: 0,
    loadingScrapListSheet: false,
}

const namespace = "admin"
// Generates pending, fulfilled and rejected action types

const CREATE_USER = "/admin/adminAddUser";
const GET_USERS = "/admin/AdminUserList";
const DOWNLOAD_SHEET_USERS = "/admin/AdminUserSheet";

const UPLOAD_BINCODE = "/admin/uploadBinCode"
const UPLOAD_MATERIALCODE = "/admin/addMaterialData";
const ADD_MATERIAL_CATEGORY = "/admin/addMaterialCategory";
const ENABLE_DISABLE_USER = "/admin/adminDataDelete";
const SCRAP_LIST = "/admin/adminScrapList";
const ADMIN_SCRAP_LIST_SHEET = "/admin/AdminDepositSheet";

export const scrapListSheetDownload = createAsyncThunk(`${namespace}/scrapListSheetDownload`, async (payload: any, { rejectWithValue }) => {


    let newUrl = `${ADMIN_SCRAP_LIST_SHEET}?start_date=${payload.start_date}&end_date=${payload.end_date}`;

    if (payload.department_params) {
        newUrl += `&department_params=${payload.department_params}`
    }

    if (payload.scrap_id_params) {
        newUrl += `&scrap_id_params=${payload.scrap_id_params}`
    }



    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})



export const getScrapDepositList = createAsyncThunk(`${namespace}/getScrapDepositList`, async (payload: any, { rejectWithValue }) => {
    let newUrl = `${SCRAP_LIST}?page_number=${payload.page_number}&count=${payload.count}`;
    if (payload.start_date && payload.end_date) {
        newUrl += `&start_date=${payload.start_date}&end_date=${payload.end_date}`;
    }
    if (payload.department_params) {
        newUrl += `&department_params=${payload.department_params}`;
    }

    if (payload.scrap_id_params) {
        newUrl += `&scrap_id_params=${payload.scrap_id_params}`;
    }

    let apiPayload = { method: "GET", data: payload, url: newUrl }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})





export const enableOrDisableUser = createAsyncThunk(`${namespace}/enableOrDisableUser`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "PUT", data: payload, url: `${ENABLE_DISABLE_USER}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const uploadMaterialCategory = createAsyncThunk(`${namespace}/uploadMaterialCategory`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: `${ADD_MATERIAL_CATEGORY}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const uploadMaterialCodeSheet = createAsyncThunk(`${namespace}/uploadMaterialCodeSheet`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = {
        method: "POST", headerInfo: {
            'Content-type': 'multipart/form-data'
        }, data: payload, url: `${UPLOAD_MATERIALCODE}`
    }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const uploadBincodeSheet = createAsyncThunk(`${namespace}/uploadBincodeSheet`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = {
        method: "POST", data: payload, headerInfo: {
            'Content-type': 'multipart/form-data'
        }, url: `${UPLOAD_BINCODE}`
    }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const downloadUsersSheet = createAsyncThunk(`${namespace}/downloadUsersSheet`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", data: payload, url: `${DOWNLOAD_SHEET_USERS}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const createUser = createAsyncThunk(`${namespace}/createUser`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: `${CREATE_USER}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const getAccounts = createAsyncThunk(`${namespace}/getAccounts`, async (payload: any, { rejectWithValue }) => {

    let url = `${GET_USERS}?page_number=${payload.page_number}&count=${payload.offset}`;

    if (payload.search_name.trim()) {
        url += `&search_name=${payload.search_name.trim()}`
    }
    let apiPayload = { method: "GET", data: {}, url: url }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


const adminSlice = createSlice({
    name: 'admin',
    initialState,
    reducers: {},
    extraReducers: builder => {
        ////////////////////////////////////////////////
        builder.addCase(createUser.pending, state => {
            state.loadingCreateUser = true;
        })
        builder.addCase(
            createUser.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingCreateUser = false;
            }
        )
        builder.addCase(createUser.rejected, (state, action) => {
            state.loadingCreateUser = false
        })

        ////////////////////////////////////////////////
        builder.addCase(getAccounts.pending, state => {
            state.loadingGetAccounts = true;
        })
        builder.addCase(
            getAccounts.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingGetAccounts = false;
                state.accounts = action.payload.data.data.admin_user_list;
                state.total_accounts = action.payload.data.data.admin_user_list_count;
            }
        )
        builder.addCase(getAccounts.rejected, (state, action) => {
            state.loadingGetAccounts = false
        })

        ////////////////////////////////////////////////
        builder.addCase(downloadUsersSheet.pending, state => {
            state.loadingDownloadSheet = true;
        })
        builder.addCase(
            downloadUsersSheet.fulfilled,
            (state, action: PayloadAction<any>) => {

                state.loadingDownloadSheet = false;

            }
        )
        builder.addCase(downloadUsersSheet.rejected, (state, action) => {
            state.loadingDownloadSheet = false;
        })

        ///////////////////////////////////////////////////////////


        builder.addCase(uploadMaterialCodeSheet.pending, state => {
            state.loadingMaterialcodeSheet = true;
        })
        builder.addCase(
            uploadMaterialCodeSheet.fulfilled,
            (state, action: PayloadAction<any>) => {

                state.loadingMaterialcodeSheet = false;

            }
        )
        builder.addCase(uploadMaterialCodeSheet.rejected, (state, action) => {
            state.loadingMaterialcodeSheet = false;
        })

        ///////////////////////////////////////////////////////////


        builder.addCase(uploadBincodeSheet.pending, state => {
            state.loadingBincodeSheet = true;
        })
        builder.addCase(
            uploadBincodeSheet.fulfilled,
            (state, action: PayloadAction<any>) => {

                state.loadingBincodeSheet = false;

            }
        )
        builder.addCase(uploadBincodeSheet.rejected, (state, action) => {
            state.loadingBincodeSheet = false;
        })




        ///////////////////////////////////////////////////////////


        builder.addCase(uploadMaterialCategory.pending, state => {
            state.loadingMaterialCategory = true;
        })
        builder.addCase(
            uploadMaterialCategory.fulfilled,
            (state, action: PayloadAction<any>) => {

                state.loadingMaterialCategory = false;

            }
        )
        builder.addCase(uploadMaterialCategory.rejected, (state, action) => {
            state.loadingMaterialCategory = false;
        })



        ///////////////////////////////////////////////////////////


        builder.addCase(enableOrDisableUser.pending, state => {
            state.loadingEnableOrDisableUser = true;
        })
        builder.addCase(
            enableOrDisableUser.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingEnableOrDisableUser = false;
            }
        )
        builder.addCase(enableOrDisableUser.rejected, (state, action) => {
            state.loadingEnableOrDisableUser = false;
        })




        ///////////////////////////////////////////////////////////


        builder.addCase(getScrapDepositList.pending, state => {
            state.loadingScrapList = true;
        })
        builder.addCase(
            getScrapDepositList.fulfilled,
            (state, action: PayloadAction<any>) => {
                debugger

                state.loadingScrapList = false;
                state.scrapList = action.payload.data.data.getAllScrapListData;
                state.totalScrapCount = action.payload.data.data.getAllScrapListDataCount[0].request_count
            }
        )
        builder.addCase(getScrapDepositList.rejected, (state, action) => {
            state.loadingScrapList = false;

        })


        ///////////////////////////////////////////////////////////


        builder.addCase(scrapListSheetDownload.pending, state => {
            state.loadingScrapListSheet = true;
        })
        builder.addCase(
            scrapListSheetDownload.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingScrapListSheet = false;

            }
        )
        builder.addCase(scrapListSheetDownload.rejected, (state, action) => {
            state.loadingScrapListSheet = false;

        })

    }
})

export default adminSlice.reducer;