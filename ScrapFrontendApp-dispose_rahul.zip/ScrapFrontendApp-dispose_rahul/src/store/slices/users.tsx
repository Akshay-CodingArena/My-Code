import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';


type InitialState = {
    loadingViewUser: boolean,
    loadingUpdateProfile: boolean,
    loadingApproveProfile: boolean,
    loadingApproveSignup: boolean
}
const initialState: InitialState = {
    loadingViewUser: false,
    loadingUpdateProfile: false,
    loadingApproveProfile: false,
    loadingApproveSignup: false
}

const namespace = "users"
// Generates pending, fulfilled and rejected action types

const VIEW_PROFILE = "/user/viewProfile";
const UPDATE_PROFILE = "/user/updateProfile";
const APPROVE_PROFILE = "/user/approveProfile";
const APPROVE_SIGNUP = "/auth/approveSignup";

export const viewProfile = createAsyncThunk(`${namespace}/viewProfile`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "GET", url: `${VIEW_PROFILE}?user_id=${payload.user_id}` }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const updateProfile = createAsyncThunk(`${namespace}/updateProfile`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "PUT", data: payload, url: UPDATE_PROFILE }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const approveProfile = createAsyncThunk(`${namespace}/approveProfile`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "PUT", data: payload, url: APPROVE_PROFILE }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const approveSignup = createAsyncThunk(`${namespace}/approveSignup`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "POST", data: payload, url: APPROVE_SIGNUP }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {},
    extraReducers: builder => {
        ///////////////////////////////////////////////////
        builder.addCase(viewProfile.pending, state => {

            state.loadingViewUser = true
        })
        builder.addCase(
            viewProfile.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingViewUser = false;
            }
        )
        builder.addCase(viewProfile.rejected, (state, action) => {
            state.loadingViewUser = false
        })
        //////////////////////////////////////////////////////

        builder.addCase(updateProfile.pending, state => {
            state.loadingUpdateProfile = true
        })
        builder.addCase(
            updateProfile.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingUpdateProfile = false;
            }
        )
        builder.addCase(updateProfile.rejected, (state, action) => {
            state.loadingUpdateProfile = false
        })

        /////////////////////////////////////////////////////////

        builder.addCase(approveProfile.pending, state => {
            state.loadingApproveProfile = true
        })
        builder.addCase(
            approveProfile.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingApproveProfile = false;
            }
        )
        builder.addCase(approveProfile.rejected, (state, action) => {
            state.loadingApproveProfile = false
        })
        ///////////////////////////////////////////////////////
        builder.addCase(approveSignup.pending, state => {
            state.loadingApproveSignup = true
        })
        builder.addCase(
            approveSignup.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingApproveSignup = false;
            }
        )
        builder.addCase(approveSignup.rejected, (state, action) => {
            state.loadingApproveSignup = false
        })


    }
})

export default userSlice.reducer;