import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { useApiService } from '../api/api';
import useLocalStorage from '../../utils/localStorage';
type InitialState = {
    loading: boolean,
    loadingLoginUser: boolean,
    loginUserData: any,
    signupUserData: any,
    loadingForgotPassword: boolean,
    forgotPasswordData: any,
    loadingVerifyOtp: boolean,
    loadingUpdatePassword: boolean,
    loadingLogout:boolean
}
const initialState: InitialState = {
    loading: false,
    loadingLoginUser: false,
    loginUserData: {},
    signupUserData: {},
    loadingForgotPassword: false,
    forgotPasswordData: {},
    loadingVerifyOtp: false,
    loadingUpdatePassword: false,
    loadingLogout:false
}

const namespace = "auth"
// Generates pending, fulfilled and rejected action types

const SIGN_UP = "/auth/signup";
const LOGIN = "/auth/login";
const FORGOT_PASSWORD = "/auth/forgotPassword";
const VERIFY_OTP = "/auth/verifyOTP";
const UPDATE_PASSWORD = "/auth/updatePassword";
const LOGOUT = "/user/logout"


export const logout = createAsyncThunk(`${namespace}/logout`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: LOGOUT }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})



export const forgotPassword = createAsyncThunk(`${namespace}/forgotPassword`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: FORGOT_PASSWORD }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const createUser = createAsyncThunk(`${namespace}/createUser`, async (payload: any, { rejectWithValue }) => {

    let apiPayload = { method: "POST", data: payload, url: SIGN_UP }

    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

export const loginUser = createAsyncThunk(`${namespace}/loginUser`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "POST", data: payload, url: LOGIN }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})


export const verifyOtp = createAsyncThunk(`${namespace}/verifyOtp`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "POST", data: payload, url: VERIFY_OTP }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})
export const updatePassword = createAsyncThunk(`${namespace}/updatePassword`, async (payload: any, { rejectWithValue }) => {
    let apiPayload = { method: "PUT", data: payload, url: UPDATE_PASSWORD }
    let response: any = await useApiService(apiPayload);
    //////////////If API CRASHES//////////
    if (response.isCrash) {
        return rejectWithValue(response.error);
    }
    return response;
})

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {},
    extraReducers: builder => {

        ///////////////////////////////////////////////////
        builder.addCase(createUser.pending, state => {

            state.loading = true
        })
        builder.addCase(
            createUser.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loading = false;
                state.signupUserData = action.payload.data
            }
        )
        builder.addCase(createUser.rejected, (state, action) => {
            state.loading = false
        })
        //////////////////////////////////////////////////////



        builder.addCase(loginUser.pending, state => {  
            state.loadingLoginUser = true
        })
        builder.addCase(
            loginUser.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingLoginUser = false;
                state.loginUserData = action.payload.data;
                localStorage.setItem("accessToken", action.payload.data.authToken);
                useLocalStorage.setItem("userData", action.payload.data.data);
            }
        )

        builder.addCase(loginUser.rejected, (state, action) => {
            state.loadingLoginUser = false
        })

        /////////////////////////////////////////////////



        builder.addCase(forgotPassword.pending, state => {
            state.loadingForgotPassword = true
        })
        builder.addCase(
            forgotPassword.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingForgotPassword = false;
                state.forgotPasswordData = action.payload.data.data;
            }
        )

        builder.addCase(forgotPassword.rejected, (state, action) => {
            state.loadingForgotPassword = false
        })
        //////////////////////////////////////////////////////////////////


        builder.addCase(verifyOtp.pending, state => {
            state.loadingVerifyOtp = true
        })
        builder.addCase(
            verifyOtp.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingVerifyOtp = false;
            }
        )
        builder.addCase(verifyOtp.rejected, (state, action) => {
            state.loadingVerifyOtp = false
        })

        ////////////////////////////////////////////////////////////

        builder.addCase(updatePassword.pending, state => {
            state.loadingUpdatePassword = true
        })
        builder.addCase(
            updatePassword.fulfilled,
            (state, action: PayloadAction<any>) => {

                state.loadingUpdatePassword = false;
            }
        )
        builder.addCase(updatePassword.rejected, (state, action) => {
            state.loadingUpdatePassword = false;
        })

        ////////////////////////////////////////////////////////

        builder.addCase(logout.pending, state => {
            state.loadingLogout = true
        })
        builder.addCase(
            logout.fulfilled,
            (state, action: PayloadAction<any>) => {
                state.loadingLogout = false;
            }
        )
        builder.addCase(logout.rejected, (state, action) => {
            state.loadingLogout = false;
        })


    }
})

export default authSlice.reducer;