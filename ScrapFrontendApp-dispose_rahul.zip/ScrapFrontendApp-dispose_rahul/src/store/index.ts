import { configureStore } from '@reduxjs/toolkit';
import authSlice from './slices/auth';
import userSlice from './slices/users';
import listSlice from "./slices/list";
import requestSlice from "./slices/requests"
import adminSlice from './slices/admin';
import disposeSlice from './slices/dispose';
import inventorySlice from './slices/inventory';

export const store = configureStore({
  reducer: {
    auth:authSlice,
    user:userSlice,
    list:listSlice,
    scrapRequests:requestSlice,
    admin:adminSlice,
    dispose:disposeSlice,
    inventory:inventorySlice
  },
})

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch