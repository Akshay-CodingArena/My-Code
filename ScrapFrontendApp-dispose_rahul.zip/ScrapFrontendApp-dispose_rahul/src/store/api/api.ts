import axios from "axios";
import { showToast } from "../../components/toast";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import 'react-toastify/dist/ReactToastify.css';




export const useApiService = async ({ url, method, data, headerInfo }: any) => {



    axios.interceptors.response.use((response: any) => {

        if (response.data.status === 401) {
            window.location= PATH.PUBLIC.SIGN_IN;
        } else {
            return response;
        }
    }, (error) => {
        if (error.response && error.response.data) {
            return Promise.reject(error.response.data);
        }
        return Promise.reject(error.message);
    });


    let headers: any = {};

    if (headerInfo) {
        headers = { ...headerInfo }

    } else {
        headers = {
            "Content-Type": "application/json"
        }
    }

    if (localStorage.getItem("accessToken")) {
        headers.Authorization = localStorage.getItem("accessToken");
    }


    try {
        let response: any = await axios.request({
            baseURL: process.env.REACT_APP_APIBASE,
            headers,
            url,
            method,
            data,
        });

        console.log(response)
        return response;
    }
    catch (errorMessage: any) {
        return {
            isCrash: true,
            error: errorMessage || 'Something went wrong'
        }
    }
}

