export const CONSTANTS: any = {
    COLORS: {
        GREEN: "rgba(0, 120, 74)",
        RED: "rgb(230, 0, 0)",
        INFO: '#17a2b8',
        PRIMARY: "#3B71CA",
        WHITE: "#FFFFFF",
        NONE: "none"
    }
}

export const COMAPANY: any = [
    {
        label: "Amravati", value: "Amravati"
    }
]

// export const scrapCategory:any = [{
//     label:
// }]
