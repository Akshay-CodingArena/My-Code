import { useEffect, useRef, useState } from "react";
import {
  deleteDraftDisposeRequest,
  deleteDraftScrapRequest,
  departmentMasterList,
  dumpRequest,
  requestDisposeDrafts,
  requestScrapDrafts,
  viewScrapRequest,
  viewDisposalRequest,
  requestPhysicalDispose,
  downloadPhysicalDisposalList,
} from "../../store/slices/list";
import { useDispatch } from "react-redux";
import Datatable from "../../components/Datatable";
import moment from "moment";
import { useAppSelector } from "../../store/hooks";
import { CONSTANTS } from "../../constants/constants";
import MyButton, {
  DeleteButton,
  EditButton,
  ViewButton,
} from "../../components/button";
import { ref } from "yup";
import useLocalStorage from "../../utils/localStorage";
import { PATH } from "../../paths/path";
import { useNavigate } from "react-router";
import { Button, Container, Grid } from "@mui/material";
import { viewProfile } from "../../store/slices/users";
import DeleteIcon from "../../assets/images/icons/delete_icon.png";
import EditIcon from "../../assets/images/icons/edit.png";
import Loading from "../../components/backdrop";

import DownloadIcon from "../../assets/images/images.png";
import Pagination from "../../components/pagination";
import { showToast } from "../../components/toast";
import {
  getScrapDisposeRequestView,
  getScrapPhysicalDisposeView,
} from "../../store/slices/dispose";

import dayjs, { Dayjs } from "dayjs";

import DateRange from "../../components/daterange";
import Input from "../../components/input";

const OFFSET = 5;

const ScrapPhysicalDisposeList = () => {
  let [page, setPage] = useState(1);
  const dispatch = useDispatch();
  const actionTaken = useRef(false);
  const navigate = useNavigate();
  const requestEdited = useRef("");
  const [list, setList] = useState([]);
  let {
    departmentList,
    scrapRequestView,
    loadingDeleteDisposeDraft,
    loadingDisposeDraftList,
    totalCountDisposeDraftList,
    loadingScrapRequestView,
    tempRequestView,
  } = useAppSelector((state) => state.list);

  const confirmTaskRef = useRef();
  const dataRef = useRef();
  let [open, setOpen] = useState(false);
  const [userData, setUserData] = useState([]);

  let [dateRange, setDateRange] = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [requestNo, setRequestNo] = useState();
  const getScrapPhysicalDisposeData = async (id, pid) => {

    let formData = {
      scrap_disposal_id: id,
      is_permanent: 1,
    };

    // debugger
    let response = await dispatch(getScrapPhysicalDisposeView(formData));
    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      let editData = { ...listData.data.disposalDetails[0] };
      // editData['committee_members'] = [...editData.committee];
      // delete editData['committee'];

      // editData['material_details'] = editData['material_details'].map((value) => {

      //     return {
      //         ...value,
      //         'bincode': scrapBinCodes.filter((item, index) => item.bincode === value.bincode)[0].id.toString(),
      //         'category': scrapCategories.filter((item, index) => item.category === value.category)[0].id.toString(),
      //     }
      // })

      useLocalStorage.setItem("scrapDisposeRequest", JSON.stringify(editData));
      navigate(PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_REQUEST, {
        state: { mode: "edit", id: pid, s_id: id },
      });
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  const getStatus = (data) => {
    if (data.status === 0) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.BLUE, fontWeight: "bolder" }}>No Action</p>
        </div>
      );
    } else if (data.status === 1) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (data.status === 2) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            APPROVAL PENDING
          </p>
        </div>
      );
    } else if (data.status === 3) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    }
  };

  const getMovementStatus = (data) => {
    if (data.remaining_disposed_quantity === 0) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.RED }}>Movement Completed</p>
        </div>
      );
    } else if (data.created_on > new Date(new Date().setDate(new Date().getDate() + 90))) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.RED }}>Movement Expired</p>
        </div>
      );
    }
    else if (data.status === 0 || data.status == 1) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.BLUE }}>ADD MOVEMENT</p>
        </div>
      );
    } else if (data.status === 2) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.BLUE, cursor: "not-allowed" }}>
            ADD MOVEMENT
          </p>
        </div>
      );
    } else if (data.status === 3) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.RED }}>EDIT MOVEMENT</p>
        </div>
      );
    }
  };

  console.log("PHYSICAL DISPOSE");

  const getDraftsList = async (page) => {
    let data = useLocalStorage.getItem("userData");
    let formData = {
      page_number: page - 1,
      offset: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (requestNo) {
      formData["disposal_id"] = requestNo;
    }
    let result = await dispatch(requestPhysicalDispose(formData));
    let temp = result.payload.data.data.getPhysicalDisposalList;
    const final = temp?.map((row) => {
      return {
        ...row,
      };
    });
    setPage(page);
    setList(final);
  };

  useEffect(() => {
    getDraftsList(page);
  }, []);

  const downloadSheet = async () => {
    let formData = {};
    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }


    if (requestNo) {
      formData["disposal_id"] = requestNo;
    }


    let response = await dispatch(downloadPhysicalDisposalList(formData));

    if (response.payload.data.data) {
      var iframe = document.createElement("iframe");
      iframe.id = "1";
      iframe.style.display = "none";
      document.body.appendChild(iframe);
      iframe.src = response.payload.data.data;
    }
    console.log("data log");
  };

  const columns = [
    {
      name: "Request No.",
      selector: "disposal_id",
      wrap: true,
    },
    {
      name: "Status",
      selector: "status",
      wrap: true,
      cell: (row) => {
        return getStatus(row);
      },
    },
    {
      name: "Start Movement",
      wrap: true,
      cell: (row) => {
        return (
          <div className="text-center">
            <div class="wrapper" style={{ cursor: (row['status'] === 2) || (row['remaining_disposed_quantity'] === 0 || moment(Date.now(),"DD-MM-YYYY") > moment(row['created_on'], "DD-MM-YYYY").add(90, 'days')) ? "not-allowed" : "pointer" }}>
             
                <Button
                  onClick={(e) => {
                    getScrapPhysicalDisposeData(
                      row["disposal_id"],
                      row["physical_disposal_id"],
                      row
                    );
                  }}
                  style={{ pointerEvents: (row['status'] === 2) || (row['remaining_disposed_quantity'] === 0 || moment(Date.now(),"DD-MM-YYYY") > moment(row['created_on'], "DD-MM-YYYY").add(90, 'days')) ? "none" : "visible" }}
                >
                  {" "}
                  {getMovementStatus(row)}
                </Button>
            </div>
          </div>
        );
      },
    },
    {
      name: "View Details",
      wrap: true,
      cell: (row) => {
        return (<div className="text-center">
          <ViewButton onClick={() => {
            navigate(PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_REVIEW, {
              state: {
                scrapId: row["disposal_id"],
                mode: "view",
              },
            });
          }} />
        </div>);
      },
    },
    // {
    //   name: "Final Closure",
    //   wrap: true,
    //   cell: (row) => {
    //     return (
    //       <div className="text-center">
    //         <Button
    //           onClick={(e) => {
    //             navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
    //               // state: {
    //               //     "isPermanent": 0,
    //               //     "scrap_disposal_id": row['requestNo']
    //               // }
    //             });
    //           }}
    //         >
    //           {" "}
    //           Final Closure
    //         </Button>
    //       </div>
    //     );
    //   },
    // },
    // {
    //   name: "Final Closure date",
    //   selector: "final_closure_date",
    //   wrap: true,
    // },
  ];

  const handlePageChange = (e, value) => {
    getDraftsList(value);
  };

  return (
    <>
      {loadingDeleteDisposeDraft ||
        loadingDisposeDraftList ||
        loadingScrapRequestView ? (
        <Loading loading={true} />
      ) : (
        ""
      )}
      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Grid container style={{
          minWidth: "95vw",
        }} spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">Physical Movement of Material</h3>
          </Grid>
          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>
          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Request Number"
              type="text"
              value={requestNo}
              onChange={(e) => {
                if (/^(0|[1-9][0-9]*)$/g.test(e.target.value)) {
                  setRequestNo(e.target.value);
                } else {
                  setRequestNo(e.target.value.replace(/[^0-9]/g, ''))
                }
              }}
            />
          </Grid>
          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "25px" }}
          >
            <MyButton
              label={"Search"}
              type="button"
              onClick={() => {
                getDraftsList(1);
              }}
            />
          </Grid>
          <Datatable columns={columns} data={list} />

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {list?.length ? (
              <Pagination
                page={page}
                onChange={(event, value) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalCountDisposeDraftList / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>
    </>
  );
};

export default ScrapPhysicalDisposeList;
