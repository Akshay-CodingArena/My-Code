import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import {
  Container,
  Dialog,
  DialogActions,
  DialogTitle,
  Grid,
} from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import { departmentMasterList, downloadPhysicalDisposalList, downloadPhysicalDisposalListCNC } from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton, { ViewButton } from "../../components/button";
import {
  getCNCPhysicalDisposeView,
  getPhysicalDisposeApprovalCNC,
  getPhysicalDisposeRequestsList,
  getScrapDisposeApprovalCNC,
  getScrapDisposeRequestsList,
  getScrapPhysicalDisposeView,
} from "../../store/slices/dispose";

import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import CrossImage from "../../assets/images/cross.png";

const OFFSET = 5;

const PhysicalDisposeRequestsCNC = () => {
  const navigate = useNavigate();
  let [page, setPage] = useState(1);

  const confirmTaskRef = useRef();
  const dataRef = useRef();
  let [open, setOpen] = useState(false);
  const [userData, setUserData] = useState([]);

  let [disposeRequestsList, setDisposeRequestsList] = useState([]);
  let [dateRange, setDateRange] = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [requestNo, setRequestNo] = useState();

  const {
    loadingScrapDisposeRequestsList,
    scrapDisposeRequestsList,
    totalDisposeRequestsCount,
    loadingScrapDisposeApprovalCNC,
  } = useAppSelector((state) => state.dispose);

  const dispatch = useAppDispatch();

  const approveOrReject = (response) => {
    setOpen(true);
    dataRef.current = {
      userData: { ...dataRef.current.userData, response: response },
    };
  };

  const validationSchema = Yup.object().shape({
    remarks: Yup.string()
      .trim()
      .required("Remarks is required")
      .min(5, "Remarks must be atleast 5 characters long."),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    control,
    getValues,
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onConfirm = async () => {
    ///////////confirm//////

    confirmTaskRef.current.handleClose();
    approveOrReject(1);
  };

  const onDiscard = () => {
    //////////dis card////////
    confirmTaskRef.current.handleClose();
    approveOrReject(2);
  };

  const getStatus = (data) => {
    if (data.cnc_approval === 1) {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (data.cnc_approval === 2) {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    } else if (data.cnc_approval === 0) {
      return (
        <div
          style={{ cursor: "pointer" }}
          onClick={(e) => {
            confirmTaskRef.current.handleClickOpen();
            dataRef.current = {
              userData: data,
            };
          }}
        >
          <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>
            PENDING
          </p>
        </div>
      );
    }
  };

  const onSubmit = async (data) => {
    let inputData = dataRef.current.userData;
    let formData = {
      scrap_disposal_id: inputData.disposal_id,
      physical_movement_approval: inputData.response,
      movement_group: inputData.movement_group,
      remarks: data.remarks,
    };

    let response = await dispatch(getPhysicalDisposeApprovalCNC(formData));

    let responseData = response.payload.data ? response.payload.data : {};

    if (responseData.status === 200) {
      let tempData = disposeRequestsList.map((value) => {
        if (
          value.disposal_id === inputData.disposal_id &&
          inputData.movement_group === value.movement_group
        ) {
          return {
            ...value,
            cnc_remarks: data.remarks,
            cnc_approval: inputData.response,
          };
        }
        return value;
      });
      showToast("SUCCESS", "Request submitted successfully");
      setDisposeRequestsList(tempData);
    } else {
      showToast("ERROR", responseData.status || "Some Error Occurred...");
    }
    setOpen(false);
  };

  const getCNCViewPhysicalDisposeData = async (group, id) => {
    let formData = {
      scrap_disposal_id: id,
      movement_group: group,
    };

    // debugger
    let response = await dispatch(getCNCPhysicalDisposeView(formData));
    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      let data = { ...listData.data.disposalDetails[0] };

      useLocalStorage.setItem(
        "scrapPhysicalDisposeRequest",
        JSON.stringify(data)
      );
      navigate(PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_VIEW_CNC);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };
  const columns = [
    {
      name: "Request No.",
      selector: "disposal_id",
      wrap: true,
      width: "120px",
      style: {
        minHeight: "70px",
      },
    },
    {
      name: "Movement Group",
      selector: "movement_group",
      wrap: true,
      width: "170px",
    },
    {
      name: "View Details",
      wrap: true,
      cell: (row) => {
        return (<div className="text-center">
          <ViewButton onClick={() => {
            getCNCViewPhysicalDisposeData(
              row["movement_group"],
              row["disposal_id"]
            );
          }} />
        </div>);
      }

    },
    {
      name: "C&C Remarks",
      selector: "cnc_remarks",
      wrap: true,
      cell: (row) => {
        return row["cnc_remarks"] ? (
          <div >{row["cnc_remarks"]}</div>
        ) : (
          "N/A"
        );
      },
    },
    {
      name: "C&C Approval",
      wrap: true,
      cell: (row) => {
        return getStatus(row);
      },
    }
  ];

  const getList = async (page) => {
    let formData = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (requestNo) {
      formData["searchParam"] = requestNo;
    }

    let response = await dispatch(getPhysicalDisposeRequestsList(formData));

    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setDisposeRequestsList(listData.data.getPhysicalDisposalMovementList);
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    setDisposeRequestsList(scrapDisposeRequestsList);
  }, [scrapDisposeRequestsList]);

  useEffect(() => {
    getList(page);
  }, []);

  const handlePageChange = (e, value) => {
    getList(value);
  };

  const downloadSheet = async () => {
    let formData = {};
    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }


    if (requestNo) {
      formData["disposal_id"] = requestNo;
    }


    let response = await dispatch(downloadPhysicalDisposalListCNC(formData));

    if (response.payload.data.data) {
      var iframe = document.createElement("iframe");
      iframe.id = "1";
      iframe.style.display = "none";
      document.body.appendChild(iframe);
      iframe.src = response.payload.data.data;
    }
    console.log("data log");
  };

  return (
    <React.Fragment>
      {loadingScrapDisposeRequestsList || loadingScrapDisposeApprovalCNC ? (
        <Loading loading={true} />
      ) : (
        ""
      )}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      ><Grid container style={{
        minWidth: "95vw",
      }} spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">
              Physical Dispose Requests for Approval
            </h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Request Number"
              type="text"
              value={requestNo}
              onChange={(e) => {
                if (/^(0|[1-9][0-9]*)$/g.test(e.target.value)) {
                  setRequestNo(e.target.value);
                } else {
                  setRequestNo(e.target.value.replace(/[^0-9]/g, ''))
                }
              }}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "25px" }}
          >
            <MyButton
              label={"Search"}
              type="button"
              onClick={() => {
                getList(1);
              }}
            />
          </Grid>

          <Grid item xs={12} lg={12} sm={12}>
            <Datatable columns={columns} data={disposeRequestsList} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {disposeRequestsList.length ? (
              <Pagination
                page={page}
                onChange={(event, value) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalDisposeRequestsCount / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>

      <Suspense fallback={<Loading />}>
        <ConfirmDialog
          ref={confirmTaskRef}
          description={"Are you sure you want to Approve/Reject?"}
          title={""}
          confirm={"Approve"}
          discard={"Reject"}
          onConfirm={onConfirm}
          onDiscard={onDiscard}
        ></ConfirmDialog>
      </Suspense>

      <Suspense fallback={<Loading />}>
        <Dialog
          className="dialogAlertStyle"
          open={open}
          onClose={(e) => setOpen(false)}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
            <img onClick={(e) => {
              setOpen(false)
            }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
          </div>
          <DialogTitle id="alert-dialog-title">
            <p className="dialog_title h4">Remarks Section</p>
          </DialogTitle>

          <DialogActions className="dialogactions">
            <Grid container style={{ marginTop: "-20px", padding: "5px 0px" }}>
              <form onSubmit={handleSubmit(onSubmit)}>
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  lg={12}
                  style={{ minWidth: "400px" }}
                >
                  <Input
                    style={{ width: "350px" }}
                    required={true}
                    multiline={true}
                    fullWidth={true}
                    autoFocus={true}
                    label="Remarks"
                    type="text"
                    autoComplete="on"
                    onChange={(e) => {
                      setValue("remarks", e.target.value);
                    }}
                    error={errors.remarks ? true : false}
                    errormessage={errors.remarks?.message}
                    minRows={3}
                  />
                </Grid>

                <Grid item xs={12} sm={12} md={12} lg={12}>
                  <MyButton
                    type="submit"
                    fullWidth={true}
                    label="Submit"
                    style={{
                      backgroundColor: CONSTANTS.COLORS.GREEN,
                    }}
                  />
                </Grid>
              </form>
            </Grid>
          </DialogActions>
        </Dialog>
      </Suspense>
    </React.Fragment>
  );
};

export default PhysicalDisposeRequestsCNC;
