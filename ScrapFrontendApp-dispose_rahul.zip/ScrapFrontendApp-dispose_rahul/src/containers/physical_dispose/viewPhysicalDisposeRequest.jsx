
// import React, { useEffect, useState } from "react";
// import Loading from "../../components/backdrop";
// import { Box, Grid, Paper, Typography } from "@mui/material";
// import { ScrapDisposeRequestEdit, getScrapDisposeRequestView } from "../../store/slices/dispose";
// import { useAppDispatch, useAppSelector } from "../../store/hooks";
// import { useLocation, useNavigate } from "react-router-dom";
// import { showToast } from "../../components/toast";
// import moment from "moment";
// import MyButton from "../../components/button";
// import { requestDispose } from "../../store/slices/requests";
// import { PATH } from "../../paths/path";
// import { listBinCode, listCategory } from "../../store/slices/list";




import React, { useEffect, useRef, useState } from 'react';
import { Button, InputAdornment, InputLabel, OutlinedInput, TextField } from "@mui/material";
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import moment from "moment";
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { materialMasterList, departmentMasterList, viewScrapRequest, getScrapListHOD, dumpRequestList, listCategory, listBinCode } from '../../store/slices/list';

// import { getMaxListeners } from 'process';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S3';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import { useDispatch } from 'react-redux';
import MyButton from '../../components/button';
import Loading from '../../components/backdrop';
import { addPhysicalDispose, editPhysicalDispose, editScrap, requestScrap, storeManagerApproval } from '../../store/slices/requests';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { getScrapPhysicalDisposeView } from '../../store/slices/dispose';

///////////get list of all bincode and material code///////



const ViewPhysicalDisposeRequest = () => {


    const saveValidation = useRef();
    let [idd, setid] = useState("");
    let [sid, setscrapid] = useState("");
    let [mode, setmode] = useState("");
    let [mgroup, setmgroup] = useState("");
    let [movement, setmovement] = useState([])

    // let PurposeList=["Dipose Off","Internal Use","Write-Off"];
    let PurposeList = [{ purpose: "Dispose Off", id: "1" }, { purpose: "Internal Use", id: "2" }, { purpose: "Write Off", id: "3" }];
    const getPurpose = (data) => {

        if (data === 1) {
            return <span >
                Dispose Off
            </span>

        }
        else if (data === 2) {
            return <span>
                Internal Use
            </span>
        } else if (data === 3) {
            return <span>
                WriteOff
            </span>

        }
    }
    const getWStatus = (data) => {

        if (data === 1) {
            return <span >
                Yes
            </span>

        }
        else {
            return <span>
                No
            </span>
        }
    }
    const getCNCStatus = (data) => {

        if (data === 1) {
            return <span style={{color:"green"}}>
                Approved
            </span>

        }
        else if(data === 2){
            return <span style={{color:"RED"}}>
                Rejected
            </span>
        }
        else{
            return <span style={{color:"RED"}}>
                Approval Pending
            </span>
        }
    }
    const { state } = useLocation();
    const navigate = useNavigate();


    const [toggle, setToggle] = useState(false)
    const [disposeData, setDisposeData] = useState({});

    let [committee, setCommittee] = useState("");


    const dispatch = useAppDispatch()


    const { loadingScrapDisposeRequestView, scrapDisposeRequestData, loadingScrapDisposeEdit } = useAppSelector(state => state.dispose);

    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests);

    const { loadingBinCode, loadingCategories, scrapCategories, scrapBinCodes } = useAppSelector(state => state.list);

    const scrapDisposeData = async () => {
        let data = state;

        let formData =
        {
            scrap_disposal_id: data.scrapId,
            is_permanent: 1,
        }
        setid(data.physicalId)
        setmgroup(data.movement_group)
        setmode(data.mode)
        setscrapid(data.scrapId)
        setmovement(data.movement)

        debugger
        let response = await dispatch(getScrapPhysicalDisposeView(formData));
        let listData = response.payload.data ? response.payload.data : {};
        debugger
        if (listData.status === 200) {
            let str = "";
            listData.data.disposalDetails?.[0]?.committee?.map((value, index) => {
                str += (index + 1) + "." + (value.user_email) + " ";
            })
            setCommittee(str);
            debugger
            setDisposeData(listData.data.disposalDetails[0])

            listData.data.disposalDetails[0].material_details.map((material, index) => {
                if(material.physical_disposal_data.length==0 || (material.physical_disposal_data.length==1&&material.physical_disposal_data[material.physical_disposal_data.length-1].cnc_approval==2)){
                    setValue(`material_details.${index}.remaining_quantityy`,material.quantity)
                }
                else if(material.physical_disposal_data.length>0 && material.physical_disposal_data[material.physical_disposal_data.length-1].cnc_approval==1){
                    setValue(`material_details.${index}.remaining_quantityy`,material.physical_disposal_data[material.physical_disposal_data.length-1].remaining_quantity)
                }
                else if(material.physical_disposal_data.length>1 && material.physical_disposal_data[material.physical_disposal_data.length-1].cnc_approval==2){
                    setValue(`material_details.${index}.remaining_quantityy`,material.physical_disposal_data[material.physical_disposal_data.length-2].remaining_quantity)
                }
                debugger
                // setValue(`material_details.${index}.physical_disposal[0].weighment_required`, 'false')
                setValue(`material_details.${index}.material_id`, material.dispose_material_id)
                setValue(`material_details.${index}.requested_quantity`, material.quantity)
                setValue(`material_details.${index}.approved_quantity`, material.available_quantity)
                // if(material.temp_physical_disposal_data.length){
                setValue(`material_details.${index}.physical_disposal[0].quantity_moved`, material.temp_physical_disposal_data?.[0]?.quantity_moved)
                setValue(`material_details.${index}.physical_disposal[0].purpose`, material.temp_physical_disposal_data?.[0]?.purpose)
                setValue(`material_details.${index}.physical_disposal[0].weighment_required`, material.temp_physical_disposal_data?.[0]?.weighment_required == 1 ? 'true' : 'false')
                setValue(`material_details.${index}.physical_disposal[0].weighment_slip`, material.temp_physical_disposal_data?.[0]?.weighment_slip)
                setValue(`material_details.${index}.physical_disposal[0].remarks`, material.temp_physical_disposal_data?.[0]?.remarks)
                // }
            })
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }



    const {
        register,
        unregister,
        handleSubmit,
        formState: { errors },
        reset,
        control,
        getValues,
        setValue
    } = useForm({
        defaultValues: {
            submitted_by: "",
            datetime: "",
            schedule_inspection_date: "",
            schedule_inspection_time: "",
            committee: [{
                user_email: "",
            }],
            material_details: [{
                material_id: "",
                material_code: "",
                material_group: "",
                bincode: "",
                category: "",
                material_description: "",
                uom: "",
                requested_quantity: "",
                approved_quantity: "",
                comments: "",
                image: "",
                remaining_quantityy: 0,
                physical_disposal: [{
                    balance_approved_quantity: "",
                    quantity_moved: "",
                    purpose: "",
                    weighment_required: 'false',
                    weighment_slip: "",
                    remarks: "",
                }]
            }]
        }
    });

    useEffect(() => {
        scrapDisposeData();
    }, [])

    const savePermanently = async () => {



        debugger
        console.log("tanuuu"+mode)
        let responseData
        if (mode == "EDITTT") {
            let fData = {
                "physical_disposal_id": idd,
                "isPermanent": 1,
                "movement_group": mgroup,
                "physical_material_movement": movement
            }
            responseData = await dispatch(editPhysicalDispose(fData))
        }
        else {
            let formData = {
                "physical_disposal_id": idd,
                "isPermanent": 1,
            }
            responseData = await dispatch(addPhysicalDispose(formData))
        }

        if (responseData?.payload?.data?.status === 200) {
            showToast('SUCCESS', responseData?.payload?.data?.message);
            navigate(PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE)
        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
        }

    }


    return <React.Fragment>

        {loadingScrapDisposeRequestView || loadingScrapRequest || loadingScrapDisposeEdit || loadingBinCode || loadingCategories ? <Loading loading={true} /> : null}


        <Grid className="scrapSection" container component="main" sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
            marginBottom: "10px"
        }}>

            <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
            >
                <h4 className="text-center mt-3">
                    Review Summary
                </h4>

                <Box
                    sx={{
                        my: 2,
                        mx: 4,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center'
                    }}
                >
                    <Box key={`FieldStatic`} style={{ width: "100%" }}>
                        <Grid container style={{ position: "sticky", top: "65px", backgroundColor: "white", zIndex: "99" }} spacing={2}>
                        <Grid item md={6} lg={6} xs={12}  >
                                        <p>Request No. <b> : {disposeData.disposal_id ? disposeData.disposal_id : "N/A"}</b></p>
                                    </Grid>
                            <Grid item md={6} lg={6} xs={12}  >
                                <p>Submitted By <b> : {disposeData.submitted_by ? disposeData.submitted_by : "N/A"}</b></p>
                            </Grid>
                            <Grid item md={6} lg={6} xs={12} >
                                <p> Date|Time<b>: {disposeData.actual_inspection_date ? moment(disposeData.actual_inspection_date).format('DD/MM/YYYY') + " | " + disposeData.actual_inspection_time : "N/A"}</b></p>
                            </Grid>

                            <Grid item md={6} lg={6} xs={12} >
                                <p>Scheduled Inspection Date | Time<b>: {moment(disposeData.schedule_inspection_date).format('DD/MM/YYYY') + " | " + disposeData.schedule_inspection_time}</b></p>
                            </Grid>

                            <Grid item md={12} lg={12} xs={12} >
                                <p>Committee Members<b>: {committee ? committee : "N/A"}</b></p>
                            </Grid>

                        </Grid>
                        <hr />

                        <Grid container spacing={2} >

                            {disposeData?.material_details && disposeData?.material_details?.map((
                                material, index) => (<Grid item md={6} lg={6} xl={6} xs={12} >
                                    <Grid component={Paper} elevation={3} sx={{ padding: "20px" }}>
                                        <div>
                                            <p><strong>Material {index + 1}</strong></p>
                                            <Grid item md={8} lg={8} xs={8} >
                                                {/* {...register(`material_details.${index}.material_id`,
                                                      setValue(`material_details.${index}.material_id`,material.disposal_id))
                                                    } */}
                                                <p>Material Code <b>: {material.material_code ? material.material_code : "N/A"}</b></p>

                                            </Grid>
                                            <Grid item md={8} lg={8} xs={8} >
                                                <p>Material Group <b>: {material.material_group ? material.material_group : "N/A"}</b></p>

                                            </Grid>
                                            <Grid item md={8} lg={8} xs={8} >
                                                <p>Material Description <b>: {material.material_description ? material.material_description : "N/A"}</b></p>

                                            </Grid>

                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Category <b>: {material.category ? material.category : "N/A"}</b></p>
                                            </Grid>

                                            <Grid item md={8} lg={8} xs={8} >
                                                <p>Unit Of Measurement(UOM)<b>: {material.unit ? material.unit : "N/A"}</b></p>

                                            </Grid>

                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Bincode <b>: {material.bincode ? material.bincode : "N/A"}</b></p>
                                            </Grid>

                                            <Grid item md={8} lg={8} xs={8} >
                                                <p>Requested Quantity <b>: {material.quantity ? material.quantity : "N/A"}</b></p>

                                            </Grid>
                                            <Grid item md={8} lg={8} xs={8} >
                                                <p>Approved Deposit Quantity <b>: {material.available_quantity ? material.available_quantity : "N/A"}</b></p>

                                            </Grid>

                                            <Grid item md={8} lg={8} xs={8} >
                                                <p>Comments <b>: {material.comments}</b></p>
                                            </Grid>


                                            {material.image_url ? <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
                                                Image Preview <b>:</b>
                                                <div style={{ position: "relative" }}>
                                                    <img className="previewImg" src={material?.image_url + "?" + Math.random()} />
                                                </div></div>
                                                : ""}

                                            <p><strong>Physical Disposal</strong></p>
                                            {material?.physical_disposal_data?.map((data, index) => ((data.cnc_approval!=2||material.temp_physical_disposal_data.length==0)&&<>
                                                <Grid component={Paper} elevation={3} sx={{ padding: "20px" }}>


                                                    <p><strong>Movement {index + 1}</strong></p>
                                                    <p>C&C Approval: {getCNCStatus(data.cnc_approval)}   </p>
                                                    <p>C&C Remarks: {data.cnc_remarks}</p>
                                                    <Grid lg={12} sm={12} xl={12}>
                                                        <p>Quantity Moved <b>: {data.quantity_moved}</b></p>
                                                    </Grid>
                                                    <Grid lg={12} sm={12} xl={12}>
                                                        <p>Purpose <b>: {getPurpose(data.purpose)}</b></p>
                                                    </Grid>
                                                    <Grid lg={12} sm={12} xl={12}>
                                                        <p>Weighment Required <b>: {getWStatus(data.weighment_required)}</b></p>
                                                    </Grid>
                                                    <Grid lg={12} sm={12} xl={12}>
                                                        <p>Weighment Slip Number <b>: {data.weighment_slip?data.weighment_slip:"N/A"}</b></p>
                                                    </Grid>
                                                    <Grid lg={12} sm={12} xl={12}>
                                                        <p>Remarks <b>: {data.remarks}</b></p>
                                                    </Grid>
                                                </Grid>
                                            </>
                                            ))}

                                            {material.temp_physical_disposal_data.length ? (<>
                                                <Grid item md={8} lg={8} xs={8} >
                                                <Input label={"Balance Approved Quantity"}
                                                        isRequired={true}
                                                        {...register(`material_details.${index}.remaining_quantityy`, { required: { value: true, message: "Remaining qunatity is required" } })}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.remaining_quantityy`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.remaining_quantityy`) ?getValues(`material_details.${index}.remaining_quantityy`): ""}
                                                        error={errors.material_details?.[index]?.remaining_quantityy ? true : false}
                                                        errormessage={errors.material_details?.[index]?.remaining_quantityy?.message}
                                                        disabled={true}
                                                    />
                                                </Grid>
                                                <TextField
                                                    id="outlined-adornment-amount"
                                                    InputProps={{ endAdornment: <InputAdornment position="end">{material.unit}</InputAdornment> }}
                                                    label=""
                                                    style={{ width: '100%', marginBottom: "10px" }}
                                                    defaultValue={""}
                                                    type={"text"}

                                                    {...register(`material_details.${index}.physical_disposal[0].quantity_moved`, {
                                                        required: { value: true, message: "Accepted quantity is required" },
                                                        // max: { value: material.quantity, message: `Maximum Quantity is ${material.quantity}` },
                                                        // min: { value: 1, message: `Minimum Quantity is 1` },
                                                        // validate: (value) => {
                                                        //     if (parseFloat(value) > material.quantity) {
                                                        //         return "Accepted quantity cannot be greater than requested quantity"
                                                        //     }
                                                        // },
                                                        // setValue(`material_details.${index}.physical_disposal[0].quantity_moved`, temp_physical_disposal_data?.[0].quantity_moved)
                                                        onChange: (e) => {
                                                            // debugger
                                                            saveValidation.current = {};
                                                            if (e.target.value < 0) {
                                                                saveValidation.current = {
                                                                    error: true,
                                                                    errormsg: "Value should be positive"
                                                                }

                                                            }
                                                            setValue(`material_details.${index}.physical_disposal[0].quantity_moved`, (e.target.value))
                                                            setToggle(!toggle)

                                                        }
                                                    })}
                                                    disabled={true}
                                                    error={errors.material_details?.[index]?.physical_disposal[0].quantity_moved ? true : saveValidation?.current?.error ? saveValidation.current.error : false}
                                                    errormessage={errors.material_details?.[index]?.physical_disposal[0].quantity_moved?.message ? errors.material_details?.[index]?.store_quantity_accepted?.message : saveValidation?.current?.errormsg ? saveValidation.current.errormsg : ""}
                                                />
                                                <Typography variant="subtitle1" color="error" >
                                                    {errors.material_details?.[index]?.physical_disposal[0].quantity_moved?.message ? errors.material_details?.[index]?.store_quantity_accepted?.message : ""}
                                                </Typography>
                                                {/* <Input isQuantity={true} required={true} label={"Accepted Quantity"} /> */}

                                                {/* </Grid> */}
                                                <Grid lg={12} sm={12} xl={12}>
                                                    <MySelect
                                                        required={true}
                                                        {...register(`material_details.${index}.physical_disposal[0].purpose`, {
                                                            required: { value: true, message: "Purpose is required" },
                                                        })}
                                                        // {...register(`department`,  {required:{value:true, message:"Please select a department"}})}   
                                                        label={'Purpose'}
                                                        menuItems={PurposeList}

                                                        selectors={{
                                                            label: "purpose",
                                                            value: "id"
                                                        }}

                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.physical_disposal[0].purpose`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}

                                                        value={getValues(`material_details.${index}.physical_disposal[0].purpose`) ?? ""}
                                                        error={errors.material_details?.[index]?.physical_disposal[0].purpose ? true : false}
                                                        errormessage={errors.material_details?.[index]?.physical_disposal[0].purpose?.message}
                                                        disabled={true}

                                                    />

                                                </Grid>
                                                <Grid lg={12} sm={12} xl={12} style={{ marginBottom: "10px", marginTop: "10px" }}>
                                                    <label>Weighment Required<span className='text-danger'>*</span></label>
                                                    <span style={{ marginLeft: "10px" }}><input
                                                        {...register(`material_details.${index}.physical_disposal[0].weighment_required`)}
                                                        // checked={material.physical_disposal?.[0]?.weighment_required ? true : false} 
                                                        // checked={getValues(`material_details.${index}.physical_disposal[0].weighment_required`)=='true'?true:false}
                                                        name={`YES${index}`} id={`YES${index}`}
                                                        type={"radio"}
                                                        value={true}
                                                        onClick={() => {
                                                            setValue(`material_details.${index}.physical_disposal[0].weighment_required`, 'true')
                                                            setToggle(!toggle)
                                                            // debugger
                                                        }}
                                                        disabled={true}
                                                    />

                                                        <label htmlFor="YES"> Yes</label>
                                                    </span>
                                                    <span style={{ marginLeft: "10px" }}>
                                                        <input
                                                            {...register(`material_details.${index}.physical_disposal[0].weighment_required`)}
                                                            // checked={getValues(`material_details.${index}.physical_disposal[0].weighment_required`)=='false'?true:false} 
                                                            name={`NO${index}`} id={`NO${index}`}
                                                            type={"radio"}
                                                            value={false}
                                                            onClick={() => {
                                                                unregister(`material_details.${index}.physical_disposal[0].weighment_slip`)
                                                                console.log("register is", register(`material_details.${index}.physical_disposal[0].weighment_required`))
                                                                setValue(`material_details.${index}.physical_disposal[0].weighment_required`, 'false')
                                                                setToggle(!toggle)
                                                            }}
                                                            disabled={true}
                                                        />
                                                        <label htmlFor="NO"> No</label></span>
                                                </Grid>
                                                {getValues(`material_details.${index}.physical_disposal[0].weighment_required`) == "true" ? <Grid lg={12} sm={12} xl={12}>
                                                    <Input label={"Weighment Slip No*"} {...register(`material_details.${index}.physical_disposal[0].weighment_slip`, {
                                                        required: { value: true, message: "Weighment slip no. is required" },
                                                        onChange: (e) => {
                                                            setValue(`material_details.${index}.physical_disposal[0].weighment_slip`, e.target.value)
                                                            setToggle(!toggle)
                                                        }
                                                    })}
                                                        type={"number"}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.physical_disposal[0].weighment_slip`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.physical_disposal[0].weighment_slip`) ?? ""}
                                                        error={errors.material_details?.[index]?.physical_disposal[0].weighment_slip ? true : false}
                                                        errormessage={errors.material_details?.[index]?.physical_disposal[0].weighment_slip?.message}
                                                        disabled={true}
                                                    />
                                                </Grid> : null
                                                }

                                                <Grid lg={12} sm={12} xl={12} style={{ marginTop: "10px" }}>
                                                    <Input label={"Remarks*"}
                                                        isRequired={true}
                                                        {...register(`material_details.${index}.physical_disposal[0].remarks`, { required: { value: true, message: "Remarks is required" } })}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.physical_disposal[0].remarks`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.physical_disposal[0].remarks`) ?? ""}
                                                        error={errors.material_details?.[index]?.physical_disposal[0].remarks ? true : false}
                                                        errormessage={errors.material_details?.[index]?.physical_disposal[0].remarks?.message}
                                                        disabled={true}
                                                    />
                                                </Grid>
                                            </>) : null}
                                        </div>
                                    </Grid>
                                </Grid>))}

                        </Grid>
                        
                        {(mode!="view")&&<>
                        <Grid lg={12} style={{ display: "flex", justifyContent: "center", gap: "20px" }}>

                        <MyButton type="button"  label="Submit" style={{
                      backgroundColor: CONSTANTS.COLORS.GREEN,
                    }} onClick={savePermanently} />
                        </Grid>
                        </>}

                    </Box>
                </Box>
            </Grid>




        </Grid>

    </React.Fragment>
}

export default ViewPhysicalDisposeRequest;