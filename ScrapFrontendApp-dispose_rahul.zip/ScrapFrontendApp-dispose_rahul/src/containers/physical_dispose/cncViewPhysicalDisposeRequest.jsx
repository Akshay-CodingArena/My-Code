
import React, { useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";

import { Button, InputAdornment, InputLabel, OutlinedInput, TextField } from "@mui/material";
import { Box, Grid, Paper, Typography } from "@mui/material";
import { ScrapDisposeRequestEdit, getScrapDisposeRequestView } from "../../store/slices/dispose";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from "../../components/toast";
import moment from "moment";
import MyButton from "../../components/button";

import { createTheme, ThemeProvider } from '@mui/material/styles';
import useLocalStorage from '../../utils/localStorage';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S3';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import { useDispatch } from 'react-redux';
import { addPhysicalDispose, editScrap, requestScrap, storeManagerApproval } from '../../store/slices/requests';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { getScrapPhysicalDisposeView } from '../../store/slices/dispose';



///////////get list of all bincode and material code///////


const defaultTheme = createTheme();

const CNCViewPhysicalDisposeRequest = () => {
    let [disposeData, setDisposeData] = useState({});
    let [committee, setCommittee] = useState("");
    // let PurposeList=["Dipose Off","Internal Use","Write-Off"];
    let PurposeList = [{ purpose: "Dispose Off", id: "1" }, { purpose: "Internal Use", id: "2" }, { purpose: "Write Off", id: "3" }];
    const getPurpose = (data) => {

        if (data === 1) {
            return <span >
                Dispose Off
            </span>

        }
        else if (data === 2) {
            return <span>
                Internal Use
            </span>
        } else if (data === 3) {
            return <span>
                Write Off
            </span>

        }
    }
    const getWStatus = (data) => {

        if (data === 1) {
            return <span >
                Yes
            </span>

        }
        else {
            return <span>
                No
            </span>
        }
    }
    useEffect(() => {

        let scrapDisposeData = JSON.parse(useLocalStorage.getItem("scrapPhysicalDisposeRequest"));
        setDisposeData(scrapDisposeData);
        let str = ""
        setToggle(!toggle)
        scrapDisposeData.committee?.map((value, index) => {
            str += (index + 1) + "." + (value.user_email) + " ";
        })
        setCommittee(str);
    }
        , [])


    const navigate = useNavigate()
    const actionRef = useRef("")
    const [toggle, setToggle] = useState(false)
    const { departmentList, scrapRequestView, tempRequestView, loadingScrapRequestView, loadingDepartmentList, scrapCategories, loadingCategories, scrapBinCodes, loadingBinCode } = useAppSelector(state => state.list);
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests)
    console.log("categories are", scrapCategories)
    const [mode, setMode] = useState("review")
    const dispatch = useDispatch()
    const location = useLocation()
    const [open, setOpen] = useState(false)



    return (
        <ThemeProvider theme={defaultTheme}>
            {loadingBinCode || loadingScrapRequestView || loadingDepartmentList || loadingScrapRequest || loadingScrapRequestView ? <Loading loading={true} /> : null}
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >

                    <Typography component="h1" variant="h5" className='scrap_header'>
                        {"Physical Disposal Request C&C View"}
                    </Typography>
                    <Box
                        sx={{
                            my: 2,
                            mx: 4,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center'
                        }}
                    >
                        <Box key={`FieldStatic`} style={{ width: "100%" }}>
                            <Grid style={{ position: "sticky", top: "65px", backgroundColor: "white", zIndex: "9999" }} container spacing={2}>
                            <Grid item md={6} lg={6} xs={12}  >
                                        <p>Request No. <b> : {disposeData.disposal_id ? disposeData.disposal_id : "N/A"}</b></p>
                                    </Grid>
                                <Grid item md={6} lg={6} xs={12}  >
                                    <p>Submitted By <b> : {disposeData.submitted_by ? disposeData.submitted_by : "N/A"}</b></p>
                                </Grid>
                                <Grid item md={6} lg={6} xs={12} >
                                    <p> Date | Time<b>: {disposeData.actual_inspection_date ? moment(disposeData.actual_inspection_date).format('DD/MM/YYYY') + " | " + disposeData.actual_inspection_time : "N/A"}</b></p>
                                </Grid>

                                <Grid item md={6} lg={6} xs={12} >
                                    <p>Scheduled Inspection Date | Time<b>: {moment(disposeData.schedule_inspection_date).format('DD/MM/YYYY') + " | " + disposeData.schedule_inspection_time}</b></p>
                                </Grid>

                                <Grid item md={12} lg={12} xs={12} >
                                    <p>Committee Members<b>: {committee ? committee : "N/A"}</b></p>
                                </Grid>

                            </Grid>
                            <hr />

                            <Grid container spacing={2} >

                                {disposeData?.movement_group && disposeData?.movement_group?.map((data, index) => (<Grid item md={6} lg={6} xl={6} xs={12} >
                                    <Grid component={Paper} elevation={3} sx={{ padding: "20px" }}>
                                        <div>
                                            <p><strong>Material {index + 1}</strong></p>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Material Code <b>: {data.material_code}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Material Group <b>: {data.material_group}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Bincode <b>: {data.bincode}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Category <b>: {data.category}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Description <b>: {data.material_description}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>UOM <b>: {data.unit}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Requested Quantity <b>: {data.quantity}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Approved Quantity <b>: {data.available_quantity}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Comments <b>: {data.comments}</b></p>
                                            </Grid>
                                            {data.image_url ? <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
                                                    Image Preview <b>:</b>
                                                    <div style={{ position: "relative" }}>
                                                        <img className="previewImg" src={data?.image_url + "?" + Math.random()} />
                                                    </div></div>
                                                    : ""}
                                            <p><strong>Physical Disposal</strong></p>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Quantity Moved <b>: {data.quantity_moved}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Purpose <b>: {getPurpose(data.purpose)}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Weighment Required <b>: {getWStatus(data.weighment_required)}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Weighment Slip Number <b>: {data.weighment_slip?data.weighment_slip:"N/A"}</b></p>
                                            </Grid>
                                            <Grid lg={12} sm={12} xl={12}>
                                                <p>Remarks <b>: {data.remarks}</b></p>
                                            </Grid>

                                        </div>
                                    </Grid>
                                </Grid>))}

                            </Grid>

                        </Box>
                    </Box>

                </Grid>
            </Grid >
        </ThemeProvider >
    )
}

export default CNCViewPhysicalDisposeRequest;