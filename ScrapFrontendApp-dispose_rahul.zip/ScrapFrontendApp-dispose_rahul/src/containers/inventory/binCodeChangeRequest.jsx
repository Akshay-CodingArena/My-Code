import React, { useEffect, useRef, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import { Button, InputAdornment } from "@mui/material";
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { createUser } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";
import classnames from "classnames"

import { useForm, Controller, useFieldArray } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { departmentMasterList, listBinCode, listCategory, disposeMaterialList, disposeListBinCode, disposeListCategory } from '../../store/slices/list';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S33';
import BasicDatePicker from '../../components/basicDatePicker';
import BasicTimePicker from '../../components/timePicker';
import DateTimePickerValue from "../../components/dateTimePicker";
import { editDispose, editScrap, getAvailableQuantity, requestDispose, requestScrap } from '../../store/slices/requests';
import moment from 'moment';
import { DateTimePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';

import RemoveIcon from "../../assets/images/icons/delete.png";
import { ScrapDisposeRequestEdit } from '../../store/slices/dispose';
import { getInventoryShiftList, inventoryListBinCode, requestBinCodeChange } from '../../store/slices/inventory';
import Datatable from '../../components/Datatable';

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();
let renderCount = 0
const BinCodeChangeRequest = (props) => {
    const location = useLocation()
    const [tempId, setTempId] = useState(false)
    const [type, setType] = useState("bincode")
    const [toggle, setToggle] = useState(false)
    const [proceed, setProceed] = useState({})
    const [materialCount, setMaterialCount] = useState(1)
    const AddScrapInfoRef = useRef({});
    let [open, setOpen] = useState(false);
    let [imagePreview, setImagePreview] = useState({})
    const navigate = useNavigate();
    const saveRef = useRef(false);
    let [state, setState] = useState({});
    const disposalIds = useRef();
    const saveValidation = useRef();
    let [allBinCodes, setAllBinCodes] = useState([]);




    //1.create mode 2.view 3.edit

    //create ---> view --->
    let [mode, setMode] = useState("create")

    let dispatch = useAppDispatch();
    let [loading, setLoading] = useState(false);

    let { loadingMaterialList, materialList, departmentList, loadingDepartmentList, scrapRequestView, scrapBinCodes, scrapCategories, loadingBinCode, loadingCategories } = useAppSelector(state => state.list);
    let { inventoryBinList, inventoryShiftList } = useAppSelector(state => state?.inventory)
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests);
    const { loadingScrapDisposeEdit } = useAppSelector(state => state.dispose);


    const columns = [
        {
            name: "Material Code",
            selector: "material_code",
            wrap: true,
            width: "30%",
            style: {
                minHeight: "70px"
            }
        },
        {
            name: "Bin Code",
            selector: "bincode_name",
            wrap: true,
            width: "30%",
            style: {
                minHeight: "70px"
            }
        },
        {
            name: "Quantity",
            selector: "quantity",
            wrap: true,
            width: "30%",
            style: {
                minHeight: "70px"
            }
        },
    ]

    const getMaterialList = async (formData) => {
        let response = await dispatch(disposeMaterialList(formData));
        if (response?.payload?.data?.status === 200) { } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }

    const getBinCodeList = async (formData) => {
        let response = await dispatch(inventoryListBinCode(formData));
        if (response?.payload?.data?.status === 200) {

        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }


    const getShiftList = async (formData) => {
        let response = await dispatch(getInventoryShiftList(formData));
        if (response?.payload?.data?.status === 200) {


        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }

    // const getAllBinCodeList = async (formData) => {
    //     let response = await dispatch(inventoryListBinCode(formData));
    //     if (response?.payload?.data?.status === 200) {

    //         console.log("TTTTTT")
    //         console.log(response)
    //         setAllBinCodes(response.payload.data.data)
    //         console.log(allBinCodes)

    //     } else {
    //         showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
    //     }
    // }


    useEffect(() => {
        let formData = {
            page_number: 0,
            count: 10,
        }

        getMaterialList(formData)
        let formData2 = {
            page_number: 0,
            count: 10,
            bincode: "",
            index: 0
        }
        let formData3 = {
            page_number: 0,
            count: 10,
            bincode: "",
            index: 1
        }
        getBinCodeList(formData2)
        getBinCodeList(formData3)
    }, []);

    useEffect(() => {
        setValue(`mcode`, "");
        setValue(`bincode1`, "");
        setValue(`bincode2`, "");
        setValue(`quantity`, "");
        let formData = {
            page_number: 0,
            count: 10,
        }

        getMaterialList(formData)
        let formData2 = {
            page_number: 0,
            count: 10,
            bincode: "",
            index: 0
        }
        let formData3 = {
            page_number: 0,
            count: 10,
            bincode: "",
            index: 1
        }
        getBinCodeList(formData2)
        getBinCodeList(formData3)
    }, [type])




    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        setError,
        clearErrors,
        control,
        getValues,
        setValue
    } = useForm({
        // resolver: yupResolver(validationSchema),
        defaultValues: {
            bincode1: "",
            bincode2: "",
            mcode: "",
            quantity: "",
            total_quantity: ""
        }
    });






    const onSubmit = async (data) => {
        // console.log(errors);
        // console.log(getValues())
        // debugger
        // if(errors?.quantity?.message){
        //     showToast('ERROR', 'Error in quantity.Please check.');
        //     return;
        // }
        let formData = {};
        debugger
        if (type == "materialcode") {
            formData['material_code'] = getValues().mcode.material_code
        }
        else {
            formData['material_code'] = getValues().mcode;
        }

        if (type == "materialcode") {

            formData['bincode'] = getValues().bincode1;
        }
        else {

            formData['bincode'] = getValues().bincode1.bincode;
        }
        formData['quantity'] = getValues().quantity;
        formData['shiftBinCode'] = getValues().bincode2.bincode;



        let responseData;

        responseData = await dispatch(requestBinCodeChange(formData));
        if (responseData?.payload?.data?.status === 200) {

            showToast('SUCCESS', responseData?.payload?.data?.message);


            // navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
            //     state: {
            //         "isPermanent": 0,
            //         "scrap_disposal_id": scrapId,
            //         "is_submit_enable": true
            //     }
            // })

        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
        }
    }



    return (<>


        {loading || loadingScrapDisposeEdit || loadingScrapRequest || loadingMaterialList || loadingBinCode || loadingCategories ? <Loading loading={true} /> : ""}


        <ThemeProvider theme={defaultTheme}>
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>
                
                <Typography component="h5" variant="h5" className='mb-3 scrap_header'>
                        Bin Code Change Request Form
                    </Typography>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div style={{ cursor: mode === "view" ? "not-allowed" : "pointer" }}>
                            <div style={{ pointerEvents: mode === "view" ? "none" : "visible" }}>
                                <ul className="nav justify-content-center mt-3">
                                    <li className="nav-item">
                                        <a className={classnames("nav-link", type == "bincode" ? "fw-bold" : "")} aria-current="page" href="javascript:void(0);" onClick={(e) => setType("bincode")}>By Bin Code</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className={classnames("nav-link", type == "materialcode" ? "fw-bold" : "")} href="javascript:void(0);" onClick={(e) => setType("materialcode")}>By Material Code</a>
                                    </li>
                                </ul>





                                <Box
                                    sx={{
                                        my: 4,
                                        mx: 4,
                                        display: 'flex',
                                        alignItems: 'center',
                                        marginTop: "20px",
                                        padding: "0 25vw"
                                    }}>
                                    <Grid container spacing={1} component="main">

                                        <Grid item md={12} lg={12} xs={12} style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                            {(type == "materialcode") && (<><MyAutocomplete
                                                options={materialList.length ? materialList.map((value, index) => {
                                                    return { label: value.material_code, ...value }
                                                }) : []}
                                                label='Material Code *'
                                                {...register(`mcode`)}
                                                onChange={(e, value) => {
                                                    setValue(`mcode`, value);
                                                    setToggle(!toggle)
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 30,
                                                        material_code: value?.material_code
                                                    }
                                                    getShiftList(formData);
                                                }}
                                                onInputChange={(e, value) => {
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 10,
                                                        material_code: value
                                                    }
                                                    if (value != "undefined")
                                                        getMaterialList(formData)
                                                }}
                                                value={getValues()?.mcode ? getValues().mcode : null}
                                                error={errors?.mcode ? true : false}
                                                errormessage={errors?.mcode?.message}
                                            />
                                            </>)}

                                            {(type == "bincode") && (<><MyAutocomplete
                                                options={inventoryBinList[0]?.length ? inventoryBinList[0].map((value, index) => {
                                                    return { label: value.bincode_name, ...value }
                                                }) : []}
                                                label='Bin Code *'
                                                {...register(`bincode1`)}
                                                onChange={(e, value) => {
                                                    setValue(`bincode1`, value);
                                                    setToggle(!toggle)
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 30,
                                                        bincode: value?.bincode
                                                    }
                                                    getShiftList(formData)
                                                }}
                                                onInputChange={(e, value) => {
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 10,
                                                        bincode: value,
                                                        index: 0
                                                    }
                                                    getBinCodeList(formData)
                                                }}
                                                value={getValues()?.bincode1 ? getValues().bincode1 : null}
                                                error={errors?.bincode1 ? true : false}
                                                errormessage={errors?.bincode1?.message}
                                            />
                                            </>)}
                                        </Grid>

                                        {/* <Grid item xs={12} lg={12} sm={12}>
                                            <Datatable
                                                columns={columns}
                                                data={inventoryShiftList}
                                            />
                                        </Grid> */}

                                        {(getValues(`bincode1`)||getValues(`mcode`))&&(<><Grid item xs={12} sm={12} md={12} >
                                            <ul className="scrapList">
                                                <ul>

                                                    <li>Material code</li>
                                                    <li>Bin Code</li>
                                                    <li>Quantity</li>
                                                </ul>
                                                {inventoryShiftList.map((value, index) => {
                                                    return <ul>
                                                        <li>{value.material_code}</li>
                                                        <li>{value.bincode_name}</li>
                                                        <li>{value.quantity}</li>
                                                    </ul>
                                                })}
                                            </ul>
                                        </Grid>
                                        </>)}

                                        <Grid item md={12} lg={12} xs={12}>
                                            <p><strong>Shift From</strong></p>
                                        </Grid>

                                        <Grid item md={12} lg={12} xs={12}>
                                            {(type == "materialcode") && (<><MySelect
                                                required={true}
                                                {...register(`bincode1`)}
                                                label={'Bin Code'}
                                                menuItems={inventoryShiftList}
                                                selectors={{
                                                    label: "bincode_name",
                                                    value: "bincode"
                                                }}
                                                onChange={(e, value) => {
                                                    setValue(`bincode1`, value.props.value);
                                                    let temp = inventoryShiftList.filter((object) => {
                                                        return object.bincode == getValues(`bincode1`);
                                                    })
                                                    setValue(`total_quantity`, temp[0].quantity);
                                                    setToggle(!toggle)
                                                }}
                                                value={getValues(`bincode1`) ? getValues(`bincode1`) : ""}
                                                error={errors.bincode1 ? true : false}
                                                errormessage={errors.bincode1?.message}
                                            />

                                            </>)}

                                            {(type == "bincode") && (<><MySelect
                                                required={true}
                                                {...register(`mcode`)}
                                                label={'Material Code'}
                                                menuItems={inventoryShiftList}
                                                selectors={{
                                                    label: "material_code",
                                                    value: "material_code"
                                                }}
                                                onChange={(e, value) => {
                                                    setValue(`mcode`, value.props.value);
                                                    let temp = inventoryShiftList.filter((object) => {
                                                        return object.material_code == getValues(`mcode`);
                                                    })
                                                    setValue(`total_quantity`, temp[0].quantity);
                                                    setToggle(!toggle)
                                                }}
                                                value={getValues(`mcode`) ? getValues(`mcode`) : ""}
                                                error={errors.mcode ? true : false}
                                                errormessage={errors.mcode?.message}
                                            />

                                            </>)}
                                        </Grid>

                                        <Grid item md={12} lg={12} xs={12}>
                                            <p><strong>Shift To</strong></p>
                                        </Grid>

                                        <Grid item md={4} lg={4} xs={12}>
                                            <MyAutocomplete
                                                options={inventoryBinList[1]?.length ? inventoryBinList[1].map((value, index) => {
                                                    return { label: value.bincode_name, ...value }
                                                }) : []}
                                                label='Bin Code *'
                                                {...register(`bincode2`)}
                                                onChange={(e, value) => {
                                                    setValue(`bincode2`, value);
                                                    setToggle(!toggle)
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 30,
                                                        bincode: value?.bincode
                                                    }
                                                }}
                                                onInputChange={(e, value) => {
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 10,
                                                        bincode: value,
                                                        index: 1
                                                    }
                                                    getBinCodeList(formData)
                                                }}
                                                value={getValues()?.bincode2 ? getValues().bincode2 : null}
                                                error={errors?.bincode2 ? true : false}
                                                errormessage={errors?.bincode2?.message}
                                            />


                                        </Grid>

                                        <Grid item md={4} lg={4} xs={6}>
                                            <Controller
                                                control={control}
                                                name={`quantity`}
                                                render={({ field: any }) => (
                                                    <TextField
                                                        InputProps={{ endAdornment: <InputAdornment position="end">{ }</InputAdornment> }}
                                                        {...register(`quantity`,{
                                                            validate: (value) => {
                                                                if (parseFloat(value) > getValues(`total_quantity`)) {
                                                                    return "Error in Quantity";
                                                                }
                                                            }
                                                        })}
                                                        fullWidth={true}
                                                        control={control}
                                                        label="Quantity"
                                                        type="number"
                                                        autoComplete='on'
                                                        onChange={(e) => {
                                                            clearErrors(`quantity`);
                                                            if (e.target.value < 0) {
                                                                setError(`quantity`, {
                                                                    type: 'manual',
                                                                    message: 'Quantity must be positive',
                                                                });

                                                            }
                                                            if (e.target.value > getValues(`total_quantity`)) {
                                                                setError(`quantity`, {
                                                                    type: 'manual',
                                                                    message: 'Quantity should be less than available quantity',
                                                                });
                                                            }
                                                            
                                                            console.log(errors)
                                                            debugger
                                                            setValue(`quantity`, e.target.value);
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`quantity`) ? getValues(`quantity`) : ""}
                                                        error={errors.quantity ? true : false}
                                                        errormessage={errors.quantity?.message ? errors.quantity.message : ""}
                                                    />)}
                                            />
                                        </Grid>

                                        <Typography variant="subtitle1" color="error" style={{marginTop:"-px"}}>
                                                            {errors.quantity?.message ? errors.quantity.message : ""}
                                                        </Typography>



                                    </Grid>
                                </Box>



                            </div>
                        </div>

                        <Box sx={{
                            my: 4,
                            mx: 4,
                        }}>
                            <Grid container spacing={2}>
                                <Grid item md={12} sm={12} lg={12} style={{ display: "flex", justifyContent: "center", alignItems: "center", cursor: "pointer !important" }}>




                                    {(mode === "create" || mode === "edit") ? <MyButton type="submit" fullWidth={false} label={'Submit'}

                                    /> : ""}
                                </Grid>
                            </Grid>
                        </Box>
                    </form>
                    <DevTool control={control} />
                </Grid>




                <Dialog
                    className='dialogAlertStyle'
                    open={open}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">
                        <p className="dialog_title h3">
                            Material Deposit
                        </p>
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description" className='text-center'>
                            <b >
                                Your Material Deposit Form has been submitted successfully to your Reporting Manager for Approval,
                            </b>

                            <p className='h5 text-center mt-2'>
                                {`Request No : ${AddScrapInfoRef?.current?.request_no ? AddScrapInfoRef?.current?.request_no : ""}`}
                            </p>
                        </DialogContentText>
                    </DialogContent>

                    <DialogActions
                        className="dialogactions"
                    >
                        <Grid container style={{ marginTop: "-20px" }}>
                            <Grid item xs={5} sm={5} md={5} lg={5}>
                                <MyButton
                                    fullWidth={true}
                                    label='OK'
                                    onClick={(e) => {
                                        navigate(PATH.PRIVATE.DASHBOARD)
                                    }}
                                    style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} />
                            </Grid>
                        </Grid>
                    </DialogActions>
                </Dialog>


            </Grid>

        </ThemeProvider >

    </>
    );
}
export default BinCodeChangeRequest;