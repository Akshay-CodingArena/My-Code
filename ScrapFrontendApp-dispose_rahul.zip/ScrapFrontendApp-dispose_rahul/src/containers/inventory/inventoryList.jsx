import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import {
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  Paper,
} from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import { departmentMasterList, downloadInventoryList } from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton from "../../components/button";
import {
  getCNCPhysicalDisposeView,
  getPhysicalDisposeApprovalCNC,
  getPhysicalDisposeRequestsList,
  getScrapDisposeApprovalCNC,
  getScrapDisposeRequestsList,
  getScrapPhysicalDisposeView,
} from "../../store/slices/dispose";

import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  getBinCodesByMcode,
  getInventoryList,
} from "../../store/slices/inventory";
import CrossImage from "../../assets/images/cross.png";

const OFFSET = 5;

const InventoryList = () => {
  const navigate = useNavigate();
  let [page, setPage] = useState(1);

  const confirmTaskRef = useRef();
  const dataRef = useRef();
  let [open, setOpen] = useState(false);
  const [userData, setUserData] = useState([]);

  let [inventoryList, setInventoryList] = useState([]);
  let [binCodeList, setBinCodeList] = useState([]);
  let [dateRange, setDateRange] = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [materialCode, setMaterialCode] = useState();

  const {
    loadingScrapDisposeRequestsList,
    scrapDisposeRequestsList,
    totalDisposeRequestsCount,
    loadingScrapDisposeApprovalCNC,
  } = useAppSelector((state) => state.dispose);
  const { totalInventoryItemCount, loadingInventoryListSheet } = useAppSelector(
    (state) => state.inventory
  );

  const dispatch = useAppDispatch();

  const columns = [
    {
      name: "Material Code",
      selector: "material_code",
      wrap: true,
      width: "170px",
    },
    {
      name: "Material Group",
      selector: "material_group",
      wrap: true,
      width: "170px",
    },
    {
      name: "Material Description",
      selector: "material_description",
      wrap: true,
      width: "170px",
    },
    {
      name: "Categories",
      selector: "categories",
      wrap: true,
      width: "170px",
    },
    {
      name: "Latest Updated Price",
      selector: "last_updated_price",
      wrap: true,
      width: "170px",
    },
    {
      name: "Quantity",
      selector: "diffrenceOfQuantity",
      wrap: true,
      width: "170px",
    },
    {
      name: "UOM",
      selector: "Unit",
      wrap: true,
      width: "170px",
    },
    {
      name: "Bincodes",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div className="text-center">
            <b
              style={{ color: CONSTANTS.COLORS.INFO, cursor: "pointer" }}
              onClick={(e) => {
                getBinCodes(row["material_code"]);
                setOpen(true);
              }}
            >
              View Details
            </b>
          </div>
        );
      },
    },
    {
      name: "Last Updated (Date & Time)",
      selector: "latest_updated_date",
      wrap: true,
      width: "230px",
      cell: (row) => {
        return (
          <div>
            {row["latest_updated_date"]
              ? moment(row["latest_updated_date"]).format("DD/MM/YYYY") +
              " | " +
              moment(row["latest_updated_date"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
  ];

  const getBinCodes = async (mcode) => {
    let formData = {
      page_number: 0,
      count: 200,
      material_code: mcode,
    };
    let response = await dispatch(getBinCodesByMcode(formData));

    let data = response.payload.data ? response.payload.data : {};

    if (data.status === 200) {
      setBinCodeList(data.data);
    } else {
      showToast("ERROR", data.message || "Some Error Occurred...");
    }
  };

  const getList = async (page) => {
    let formData = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (materialCode) {
      formData["material_code"] = materialCode;
    }

    let response = await dispatch(getInventoryList(formData));

    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setInventoryList(listData.data.fetchInventoryData);
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    setInventoryList(scrapDisposeRequestsList);
  }, [scrapDisposeRequestsList]);

  useEffect(() => {
    getList(page);
  }, []);

  const handlePageChange = (e, value) => {
    getList(value);
  };


  const downloadSheet = async () => {
    let formData = {
      material_search_param: materialCode,
    };
    let response = await dispatch(downloadInventoryList(formData));


    if (response.payload.data.data) {
      var iframe = document.createElement('iframe');
      iframe.id = "1";
      iframe.style.display = 'none';
      document.body.appendChild(iframe);
      iframe.src = response.payload.data.data
    }
  }
  return (
    <React.Fragment>
      {loadingScrapDisposeRequestsList || loadingScrapDisposeApprovalCNC || loadingInventoryListSheet ? (
        <Loading loading={true} />
      ) : (
        ""
      )}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      ><Grid container style={{
        minWidth: "95vw",
      }} spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">
              Inventory List
            </h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Material Code"
              type="text"
              value={materialCode}
              onChange={(e) => {
                setMaterialCode(e.target.value);
              }}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "25px" }}
          >
            <MyButton
              label={"Search"}
              type="button"
              onClick={() => {
                getList(1);
              }}
            />
          </Grid>

          <Grid item xs={12} lg={12} sm={12}>
            <Datatable columns={columns} data={inventoryList} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {inventoryList.length ? (
              <Pagination
                page={page}
                onChange={(event, value) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalInventoryItemCount / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>

      <Suspense fallback={<Loading />}>
        <Dialog
          className="dialogAlertStyle"
          open={open}
          onClose={(e) => setOpen(false)}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
            <img onClick={(e) => {
              setOpen(false)
            }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
          </div>

          <DialogTitle id="alert-dialog-title">
            <p className="dialog_title h3">Bin Codes</p>
          </DialogTitle>
          <DialogContent>
            <DialogContentText
              id="alert-dialog-description"
              className="text-center"
            >
              <Grid>
                <ul className="scrapList">
                  <ul>
                    <li>Bin Codes</li>
                    <li>Quantity</li>
                  </ul>
                  {binCodeList.map((value, index) => {
                    return <ul>
                      <li>{value.bincode_name}</li>
                      <li>{value.quantity}</li>
                    </ul>
                  })}
                </ul>


              </Grid>
            </DialogContentText>
          </DialogContent>
        </Dialog>
      </Suspense>
    </React.Fragment>
  );
};

export default InventoryList;
