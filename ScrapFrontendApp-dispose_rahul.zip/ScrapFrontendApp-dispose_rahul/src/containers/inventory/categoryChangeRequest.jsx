import React, { useEffect, useRef, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import { Button, InputAdornment } from "@mui/material";
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { createUser } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";
import classnames from "classnames"

import { useForm, Controller, useFieldArray } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { departmentMasterList, listBinCode, listCategory, disposeMaterialList, disposeListBinCode, disposeListCategory } from '../../store/slices/list';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S33';
import BasicDatePicker from '../../components/basicDatePicker';
import BasicTimePicker from '../../components/timePicker';
import DateTimePickerValue from "../../components/dateTimePicker";
import { editDispose, editScrap, getAvailableQuantity, requestDispose, requestScrap } from '../../store/slices/requests';
import moment from 'moment';
import { DateTimePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';

import RemoveIcon from "../../assets/images/icons/delete.png";
import { ScrapDisposeRequestEdit } from '../../store/slices/dispose';
import { getCategoryShiftList, getInventoryShiftList, inventoryListBinCode, inventoryListCategory, requestBinCodeChange, requestCategoryChange } from '../../store/slices/inventory';
import Datatable from '../../components/Datatable';

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();
let renderCount = 0
const CategoryChangeRequest = (props) => {
    const location = useLocation()
    const [tempId, setTempId] = useState(false)
    const [toggle, setToggle] = useState(false)
    const [proceed, setProceed] = useState({})
    const [materialCount, setMaterialCount] = useState(1)
    const AddScrapInfoRef = useRef({});
    let [open, setOpen] = useState(false);
    let [imagePreview, setImagePreview] = useState({})
    const navigate = useNavigate();
    const saveRef = useRef(false);
    let [state, setState] = useState({});
    const disposalIds = useRef();
    const saveValidation = useRef();
    let [allBinCodes, setAllBinCodes] = useState([]);




    //1.create mode 2.view 3.edit

    //create ---> view --->
    let [mode, setMode] = useState("create")

    let dispatch = useAppDispatch();
    let [loading, setLoading] = useState(false);

    let { loadingMaterialList, materialList, departmentList, loadingDepartmentList, scrapRequestView, scrapBinCodes, scrapCategories, loadingBinCode, loadingCategories } = useAppSelector(state => state.list);
    let { inventoryBinList, inventoryShiftList, allCategories } = useAppSelector(state => state?.inventory)
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests);
    const { loadingScrapDisposeEdit } = useAppSelector(state => state.dispose);



    const getMaterialList = async (formData) => {
        let response = await dispatch(disposeMaterialList(formData));
        if (response?.payload?.data?.status === 200) { } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }

    const getCategoryList = async () => {
        let response = await dispatch(inventoryListCategory());
        if (response?.payload?.data?.status === 200) {

        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }


    const getShiftList = async (formData) => {
        let response = await dispatch(getCategoryShiftList(formData));
        if (response?.payload?.data?.status === 200) {


        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }



    useEffect(() => {
        let formData = {
            page_number: 0,
            count: 10,
        }
        getCategoryList()
        getMaterialList(formData)
    }, []);





    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        setError,
        clearErrors,
        control,
        getValues,
        setValue
    } = useForm({
        // resolver: yupResolver(validationSchema),
        defaultValues: {
            mcode: "",
            shift_details: [{
                category: "",
                new_category: "",
                available_quantity: "",
                quantity: ""
            }]

        }
    });






    const onSubmit = async (data) => {
        let formData = [];
        debugger
        let values = getValues();
        inventoryShiftList.map((item, index) => {
            console.log("YYYYYY")
            if (values.shift_details[index].new_category) {
                formData.push({
                    material_code: values.mcode.material_code,
                    category: inventoryShiftList?.[index]?.category,
                    shiftCategory: values.shift_details[index].new_category,
                    quantity: inventoryShiftList?.[index]?.quantity
                })

            }

        })



        let responseData;

        responseData = await dispatch(requestCategoryChange(formData));
        if (responseData?.payload?.data?.status === 200) {

            showToast('SUCCESS', responseData?.payload?.data?.message);


            navigate(PATH.PRIVATE.CATEGORY_CHANGE_LIST)

        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
        }
    }



    return (<>


        {loading || loadingScrapDisposeEdit || loadingScrapRequest || loadingMaterialList || loadingBinCode || loadingCategories ? <Loading loading={true} /> : ""}


        <ThemeProvider theme={defaultTheme}>
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>
                
                <Typography component="h5" variant="h5" className='mb-3 scrap_header'>
                                        Category Change Request Form
                                    </Typography>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >
                    
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div style={{ cursor: mode === "view" ? "not-allowed" : "pointer" }}>
                            <div style={{ pointerEvents: mode === "view" ? "none" : "visible" }}>
                                <Box
                                    sx={{
                                        my: 4,
                                        mx: 4,
                                        display: 'flex',
                                        alignItems: 'center',
                                        marginTop: "20px",
                                        padding: "0 25vw"
                                    }}>
                                    <Grid container spacing={1} component="main">

                                        <Grid item md={12} lg={12} xs={12} style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                            <MyAutocomplete
                                                options={materialList.length ? materialList.map((value, index) => {
                                                    return { label: value.material_code, ...value }
                                                }) : []}
                                                label='Material Code *'
                                                {...register(`mcode`)}
                                                onChange={(e, value) => {
                                                    setValue(`mcode`, value);
                                                    setToggle(!toggle)
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 30,
                                                        material_code: value?.material_code
                                                    }
                                                    getShiftList(formData);
                                                }}
                                                onInputChange={(e, value) => {
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 10,
                                                        material_code: value
                                                    }
                                                    if (value != "undefined")
                                                        getMaterialList(formData)
                                                }}
                                                value={getValues()?.mcode ? getValues().mcode : null}
                                                error={errors?.mcode ? true : false}
                                                errormessage={errors?.mcode?.message}
                                            />

                                        </Grid>


                                        {(getValues(`mcode`)) && (<><Grid item xs={12} sm={12} md={12} >
                                            <ul className="scrapList">
                                                <ul>

                                                    <li>Existing Category</li>
                                                    <li>Quantity</li>
                                                    <li>New Category</li>
                                                </ul>

                                                {inventoryShiftList?.map((value, index) => {
                                                    return <ul>
                                                        <li>{value.category_name}</li>
                                                        <li>{value.quantity}</li>
                                                        <li>{(<><MySelect
                                                            required={true}
                                                            debugger
                                                            {...register(`shift_details.${index}.new_category`)}
                                                            label={'New Category'}
                                                            menuItems={allCategories}
                                                            selectors={{
                                                                label: "category",
                                                                value: "id"
                                                            }}
                                                            onChange={(e, value) => {
                                                                setValue(`shift_details.${index}.new_category`, value.props.value);
                                                                debugger
                                                                console.log("PPPP" + getValues(`shift_details.${index}.new_category`))
                                                                setToggle(!toggle)
                                                            }}
                                                            value={getValues(`shift_details.${index}.new_category`) ? getValues(`shift_details.${index}.new_category`) : ""}
                                                            error={errors?.shift_details?.[index]?.new_category ? errors.shift_details[index].new_category : false}
                                                            errormessage={errors?.shift_details?.[index]?.new_category?.message ? errors.shift_details[index].new_category.message : ""}
                                                        />

                                                        </>)}</li>
                                                    </ul>
                                                })}
                                            </ul>
                                        </Grid>
                                        </>)}



                                    </Grid>
                                </Box>



                            </div>
                        </div>

                        <Box sx={{
                            my: 4,
                            mx: 4,
                        }}>
                            <Grid container spacing={2}>
                                <Grid item md={12} sm={12} lg={12} style={{ display: "flex", justifyContent: "center", alignItems: "center", cursor: "pointer !important" }}>




                                    {(mode === "create" || mode === "edit") ? <MyButton type="submit" fullWidth={false} label={'Submit'}

                                    /> : ""}
                                </Grid>
                            </Grid>
                        </Box>
                    </form>
                    <DevTool control={control} />
                </Grid>




                <Dialog
                    className='dialogAlertStyle'
                    open={open}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">
                        <p className="dialog_title h3">
                            Material Deposit
                        </p>
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description" className='text-center'>
                            <b >
                                Your Material Deposit Form has been submitted successfully to your Reporting Manager for Approval,
                            </b>

                            <p className='h5 text-center mt-2'>
                                {`Request No : ${AddScrapInfoRef?.current?.request_no ? AddScrapInfoRef?.current?.request_no : ""}`}
                            </p>
                        </DialogContentText>
                    </DialogContent>

                    <DialogActions
                        className="dialogactions"
                    >
                        <Grid container style={{ marginTop: "-20px" }}>
                            <Grid item xs={5} sm={5} md={5} lg={5}>
                                <MyButton
                                    fullWidth={true}
                                    label='OK'
                                    onClick={(e) => {
                                        navigate(PATH.PRIVATE.DASHBOARD)
                                    }}
                                    style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} />
                            </Grid>
                        </Grid>
                    </DialogActions>
                </Dialog>


            </Grid>

        </ThemeProvider >

    </>
    );
}
export default CategoryChangeRequest;