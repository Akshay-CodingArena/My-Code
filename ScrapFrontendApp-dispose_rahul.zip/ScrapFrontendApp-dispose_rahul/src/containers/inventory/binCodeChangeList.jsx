import { useEffect, useRef, useState } from "react"
import { deleteDraftDisposeRequest, deleteDraftScrapRequest, departmentMasterList, dumpRequest, requestDisposeDrafts, requestScrapDrafts, viewScrapRequest, viewDisposalRequest } from "../../store/slices/list"
import { useDispatch } from "react-redux"
import Datatable from "../../components/Datatable"
import moment from "moment"
import { useAppSelector } from "../../store/hooks"
import { CONSTANTS } from "../../constants/constants"
import MyButton, { DeleteButton, EditButton, ViewButton } from "../../components/button"
import { ref } from "yup"
import useLocalStorage from "../../utils/localStorage"
import { PATH } from "../../paths/path"
import { useNavigate } from "react-router"
import { Container, Grid } from "@mui/material"
import { viewProfile } from "../../store/slices/users"
import DeleteIcon from "../../assets/images/icons/delete_icon.png"
import EditIcon from "../../assets/images/icons/edit.png";
import Loading from "../../components/backdrop";
import Pagination from "../../components/pagination"
import { showToast } from "../../components/toast";
import { getBincodeChangeExcel, requestChangeList } from "../../store/slices/inventory"
import DownloadIcon from "../../assets/images/images.png";


const OFFSET = 5;


const BinCodeChangeList = () => {
  let [page, setPage] = useState(1);
  const dispatch = useDispatch()
  const actionTaken = useRef(false)
  const navigate = useNavigate()
  const requestEdited = useRef("")
  const [list, setList] = useState([])
  let { departmentList, scrapRequestView, loadingDeleteDisposeDraft, loadingDisposeDraftList, totalCountDisposeDraftList, loadingScrapRequestView, tempRequestView } = useAppSelector(state => state.list)
  let { totalCountChangeList,loadingGetBincodeChangeExcel } = useAppSelector(state => state.inventory)
  // const list = [{
  //     id:12
  // },
  // {
  //     id:12
  // }]
  const getDraftsList = async (page) => {
    let result = await dispatch(requestChangeList({
      page_number: page - 1,
      offset: OFFSET
    }))
    let temp = result.payload.data.data.requestList;
    const final = temp?.map((row) => {
      return {
        ...row,
        created_on: moment(row['created_on']).format('DD/MM/YYYY HH:mm:ss'),
      }
    })
    // moment(row['created_on']).format('DD/MM/YYYY')
    setPage(page);
    setList(final)
  }


  useEffect(() => {
    getDraftsList(page)
  }, [])


  const downloadSheet = async () => {

    let response = await dispatch(getBincodeChangeExcel({}));
        let binCodeData = response?.payload?.data ? response.payload.data : {};


        if (binCodeData.status === 200) {
          window.open(binCodeData.data,"_blank");
        }else{
          showToast(
            "ERROR",
            binCodeData.message ?
            binCodeData.message :
                "Something went wrong"
        )
        }
  }

  const getStatus = (data) => {
    if (data.cnc_approval === 1) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (data.cnc_approval === 2) {
      return (
        <div >
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    } else if (data.cnc_approval === 0) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>
            PENDING
          </p>
        </div>
      );
    }
  };


  const columns = [
    {
      name: "Request No.",
      selector: "id",
      wrap: true,
      style: {
        minHeight: "100px"
      },
    },
    {
      name: "Date/Time",
      selector: "created_on",
      wrap: true,
    },
    {
      name: "Material Code",
      selector: "material_code",
      wrap: true,
    },
    {
      name: "Material Description",
      selector: "material_description",
      wrap: true,
      cell: (row) => {
        return row['material_description'] ? row['material_description'] : "N/A";
      },
    },
    {
      name: "From Location",
      selector: "from_location_name",
      wrap: true,
    },
    {
      name: "To Location",
      selector: "to_location_name",
      wrap: true,
    },
    {
      name: "Quantity",
      selector: "quantity",
      wrap: true,
    },
    {
      name: "C&C Approval",
      wrap: true,
      cell: (row) => {
        return getStatus(row);
      },
    }, {
      name: "Remarks",
      selector: "cnc_remarks",
      wrap: true,
    },
    // {
    //     name: "Date/ Time",
    //     selector: "",
    //     wrap: true,
    // },
  ]

  const handleCreateNew = () => {
    navigate(PATH.PRIVATE.BINCODE_CHANGE_REQUEST)
  }


  const handlePageChange = (e, value) => {
    getDraftsList(value)
  }

  return (
    <>
      {loadingDeleteDisposeDraft || loadingDisposeDraftList || loadingScrapRequestView || loadingGetBincodeChangeExcel ? <Loading loading={true} /> : ""}
      <Container fixed style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}>

        <Grid container style={{
          minWidth: "95vw",
        }}>
          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end",marginTop:"30px" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <MyButton label={"Create New Request"} onClick={handleCreateNew} />
          <Datatable columns={columns} data={list} />

          <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
            {list?.length ? <Pagination
              page={page}
              onChange={(event, value) => { handlePageChange(event, value) }}
              pageCount={Math.ceil(totalCountChangeList / OFFSET)}
            /> : ""}
          </Grid>
        </Grid>
      </Container>

    </>
  )

}

export default BinCodeChangeList