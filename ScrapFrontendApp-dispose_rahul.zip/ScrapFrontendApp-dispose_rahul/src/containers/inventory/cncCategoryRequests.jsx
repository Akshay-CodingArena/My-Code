import { Suspense, useEffect, useRef, useState } from "react"
import { deleteDraftDisposeRequest, deleteDraftScrapRequest, departmentMasterList, dumpRequest, requestDisposeDrafts, requestScrapDrafts, viewScrapRequest, viewDisposalRequest } from "../../store/slices/list"
import { useDispatch } from "react-redux"
import Datatable from "../../components/Datatable"
import moment from "moment"
import { useAppSelector } from "../../store/hooks"
import { CONSTANTS } from "../../constants/constants"
import MyButton, { DeleteButton, EditButton, ViewButton } from "../../components/button"
import { ref } from "yup"
import useLocalStorage from "../../utils/localStorage"
import { PATH } from "../../paths/path"
import { useNavigate } from "react-router"
import { Container, Dialog, DialogActions, DialogTitle, Grid } from "@mui/material"
import { viewProfile } from "../../store/slices/users"
import DeleteIcon from "../../assets/images/icons/delete_icon.png"
import EditIcon from "../../assets/images/icons/edit.png";
import Loading from "../../components/backdrop";
import Pagination from "../../components/pagination"
import { showToast } from "../../components/toast";
import { getBinCodeChangeApprovalCNC, getCategoryChangeApprovalCNC, requestCategoryChangeList, requestChangeList } from "../../store/slices/inventory"
import Input from "../../components/input"
import ConfirmDialog from "../../components/ConfirmDialog"
import { getPhysicalDisposeApprovalCNC } from "../../store/slices/dispose"
import { useForm } from "react-hook-form"
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup"
import CrossImage from "../../assets/images/cross.png";


const OFFSET = 5;


const CncCategortyRequests = () => {
  let [page, setPage] = useState(1);
  const dispatch = useDispatch()
  const actionTaken = useRef(false)
  const navigate = useNavigate()
  const requestEdited = useRef("")
  const [list, setList] = useState([])
  const confirmTaskRef = useRef();
  const dataRef = useRef();
  let [open, setOpen] = useState(false);
  let { departmentList, scrapRequestView, loadingDeleteDisposeDraft, loadingDisposeDraftList, totalCountDisposeDraftList, loadingScrapRequestView, tempRequestView } = useAppSelector(state => state.list)
  let { totalCountChangeList } = useAppSelector(state => state.inventory)
  const getDraftsList = async (page) => {
    let result = await dispatch(requestCategoryChangeList({
      page_number: page - 1,
      offset: OFFSET
    }))
    let temp = result.payload.data.data.requestList;
    const final = temp?.map((row) => {
      return {
        ...row,
        created_on: moment(row['created_on']).format('DD/MM/YYYY HH:mm:ss'),
      }
    })
    setPage(page);
    setList(final)
  }


  useEffect(() => {
    getDraftsList(page)
  }, [])
  const approveOrReject = (response) => {
    setOpen(true);
    dataRef.current = {
      userData: { ...dataRef.current.userData, response: response },
    };
  };

  const validationSchema = Yup.object().shape({
    remarks: Yup.string()
      .trim()
      .required("Remarks is required")
      .min(5, "Remarks must be atleast 5 characters long."),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    control,
    getValues,
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onConfirm = async () => {
    ///////////confirm//////

    confirmTaskRef.current.handleClose();
    approveOrReject(1);
  };

  const onDiscard = () => {
    //////////dis card////////
    confirmTaskRef.current.handleClose();
    approveOrReject(2);
  };
  const getStatus = (data) => {
    if (data.cnc_approval === 1) {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (data.cnc_approval === 2) {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    } else if (data.cnc_approval === 0) {
      return (
        <div
          style={{ cursor: "pointer" }}
          onClick={(e) => {
            confirmTaskRef.current.handleClickOpen();
            dataRef.current = {
              userData: data,
            };
          }}
        >
          <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>
            PENDING
          </p>
        </div>
      );
    }
  };


  const onSubmit = async (data) => {
    let inputData = dataRef.current.userData;

    let formData = {
      cnc_approval: inputData.response,
      cnc_remarks: data.remarks,
      shift_id: inputData.id
    };

    let response = await dispatch(getCategoryChangeApprovalCNC(formData));

    let responseData = response.payload.data ? response.payload.data : {};

    if (responseData.status === 200) {
      let tempData = list.map((value) => {
        if (
          value.material_code === inputData.material_code &&
          inputData.from_location === value.from_location
        ) {
          return {
            ...value,
            cnc_remarks: data.remarks,
            cnc_approval: inputData.response,
          };
        }
        return value;
      });
      showToast("SUCCESS", "Request submitted successfully");
      setList(tempData);
    } else {
      showToast("ERROR", responseData.status || "Some Error Occurred...");
    }
    setOpen(false);
  };

  const columns = [
    {
      name: "Request No.",
      selector: "id",
      wrap: true,
    },
    {
      name: "Date/Time",
      selector: "created_on",
      wrap: true,
    },
    {
      name: "Material Code",
      selector: "material_code",
      wrap: true,
    },
    {
      name: "From Location",
      selector: "from_location",
      wrap: true,
    },
    {
      name: "To Location",
      selector: "to_location",
      wrap: true,
    },
    {
      name: "Quantity",
      selector: "quantity",
      wrap: true,
    },
    {
      name: "C&C Approval",
      wrap: true,
      cell: (row) => {
        return getStatus(row);
      },
    },
    {
      name: "Remarks",
      selector: "cnc_remarks",
      wrap: true,
    },
    // {
    //     name: "Date/ Time",
    //     selector: "",
    //     wrap: true,
    // },
  ]



  const handlePageChange = (e, value) => {
    getDraftsList(value)
  }

  return (
    <>
      {loadingDeleteDisposeDraft || loadingDisposeDraftList || loadingScrapRequestView ? <Loading loading={true} /> : ""}
      <Container fixed style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        marginTop: "50px"
      }}>
        <Grid container style={{
          minWidth: "95vw",
        }}>
          <Datatable columns={columns} data={list} />

          <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
            {list?.length ? <Pagination
              page={page}
              onChange={(event, value) => { handlePageChange(event, value) }}
              pageCount={Math.ceil(totalCountChangeList / OFFSET)}
            /> : ""}
          </Grid>
        </Grid>
        <Suspense fallback={<Loading />}>
          <ConfirmDialog
            ref={confirmTaskRef}
            description={"Are you sure you want to Approve/Reject?"}
            title={""}
            confirm={"Approve"}
            discard={"Reject"}
            onConfirm={onConfirm}
            onDiscard={onDiscard}
          ></ConfirmDialog>
        </Suspense>

        <Suspense fallback={<Loading />}>
          <Dialog
            className="dialogAlertStyle"
            open={open}
            onClose={(e) => setOpen(false)}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
              <img onClick={(e) => {
                setOpen(false)
              }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
            </div>
            
            <DialogTitle id="alert-dialog-title">
              <p className="dialog_title h4">Remarks Section</p>
            </DialogTitle>

            <DialogActions className="dialogactions">
              <Grid container style={{ marginTop: "-20px", padding: "5px 0px" }}>
                <form onSubmit={handleSubmit(onSubmit)}>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={12}
                    lg={12}
                    style={{ minWidth: "400px" }}
                  >
                    <Input
                      style={{ width: "350px" }}
                      required={true}
                      multiline={true}
                      fullWidth={true}
                      autoFocus={true}
                      label="Remarks"
                      type="text"
                      autoComplete="on"
                      onChange={(e) => {
                        setValue("remarks", e.target.value);
                      }}
                      error={errors.remarks ? true : false}
                      errormessage={errors.remarks?.message}
                      minRows={3}
                    />
                  </Grid>

                  <Grid item xs={12} sm={12} md={12} lg={12}>
                    <MyButton
                      type="submit"
                      fullWidth={true}
                      label="Submit"
                      style={{
                        backgroundColor: CONSTANTS.COLORS.GREEN,
                      }}
                    />
                  </Grid>
                </form>
              </Grid>
            </DialogActions>
          </Dialog>
        </Suspense>
      </Container>

    </>
  )

}

export default CncCategortyRequests