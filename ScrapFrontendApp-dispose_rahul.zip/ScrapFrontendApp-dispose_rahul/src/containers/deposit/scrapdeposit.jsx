import React, { useEffect, useRef, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import { Button, InputAdornment } from "@mui/material";
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { createUser } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";

import { useForm, Controller, useFieldArray } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { materialMasterList, departmentMasterList } from '../../store/slices/list';
// import { getMaxListeners } from 'process';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S3';
import { editScrap, requestScrap } from '../../store/slices/requests';


// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();
let renderCount = 0
const ScrapDeposit = (props) => {
    const location = useLocation()
    console.log("props are", props, location.state)
    // const { scrapRequestView } = useAppSelector(state=>state.list)
    const [tempId, setTempId] = useState(false)
    const [toggle, setToggle] = useState(false)
    const [proceed, setProceed] = useState({})
    const [materialCount, setMaterialCount] = useState(1)
    let [open, setOpen] = useState(false);
    let [imagePreview, setImagePreview] = useState({})
    const navigate = useNavigate();
    const AddScrapInfoRef = useRef({});
    const saveRef = useRef(false)

    let dispatch = useAppDispatch();
    console.log("proceed state is", proceed)
    let [loading, setLoading] = useState(false);

    let { loadingMaterialList, materialList, departmentList, loadingDepartmentList, scrapRequestView } = useAppSelector(state => state.list);
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests)

    // const validationSchema = Yup.object().shape({
    //     material_code: Yup.object().required('Material Code is required.'),
    //     material_group: Yup.string().trim()
    //         .required('Material Group is required'),
    //     material_description: Yup.string().trim()
    //         .required('Material Description is required'),
    //     units: Yup.string().trim()
    //         .required('Units is required'),
    //     quantity: Yup.number()
    //         .typeError('Please enter a number')
    //         .positive('Quantity must be a positive')
    //         .required('Qunatity is a required.'),
    //     department: Yup.number()
    //         .required('Please select a department')
    //         .typeError('Please select a department'),
    //     comments: Yup.string().optional(),
    //     file: Yup.mixed().optional()
    // });

    const getMaterialList = async (formData) => {

        let response = await dispatch(materialMasterList(formData));
        if (response?.payload?.data?.status === 200) {


        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }


    const getDepartmentList = async () => {
        let responseData = await dispatch(departmentMasterList({}));
        if (responseData?.payload?.data?.status === 200) {
            let formData = {
                page_number: 0,
                count: 50,
                material_code: ''
            }
            getMaterialList(formData);

        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : "Some Error Occurred.")
        }
    }


    useEffect(() => {
        getDepartmentList();
    }, []);

    useEffect(() => {
        if (materialList.length) {
            console.log("Material list is", materialList)
            if (scrapRequestView.length && !getValues(`material_details.${0}.material_code`)) {
                setValue("department", scrapRequestView[0].department)
                setValue("company_name", scrapRequestView[0].company_name)
                scrapRequestView[0].material_details.map((item, index) => {
                    if (index > 0) {
                        handleAddMore()
                    }
                })
                scrapRequestView[0].material_details.map((item, index) => {
                    // if(index>0){
                    //     console.log("value before append",index, getValues().material_details)
                    //     handleAddMore()
                    // }
                    setValue(`material_details.${index}.material_code`, item.material_code ? { material_code: item.material_code, label: item.material_code }:"")
                    setValue(`material_details.${index}.comments`, item.comments)
                    setValue(`material_details.${index}.material_description`, item.material_description)
                    setValue(`material_details.${index}.material_group`, item.material_group)
                    setValue(`material_details.${index}.units`, item.unit)
                    setValue(`material_details.${index}.last_updated_price`, item.price)
                    setValue(`material_details.${index}.quantity`, item.quantity)
                    setValue(`material_details.${index}.image_url`, item.image_url)
                    setValue(`material_details.${index}.material_code_verification`, item.material_code_verification)
                    imagePreview[index] = item.image_url
                    console.log("values after setValues", index, getValues().material_details)
                })
                setToggle(!toggle)
                setImagePreview({ ...imagePreview })
                console.log("images are", imagePreview)
            }
        }
    }, [materialList])


    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control,
        getValues,
        setValue
    } = useForm({
        defaultValues: {
            company_name: "",
            department: "",
            material_details: [{
                material_code: "",
                material_group: "",
                material_description: "",
                units: "",
                quantity: "",
                comments: "",
                file: ""
            }]
        }
    });


    console.log("errors are", errors)
    let { fields, append, remove } = useFieldArray({
        name: "material_details",
        control
    })

    console.log("fields are", fields)
    const handleAddMore = () => {
        append({
            material_code: "",
            material_group: "",
            material_description: "",
            units: "",
            quantity: "",
            department: "",
            comments: "",
            file: "",
            material_code_verification: false
        })
    }

    const handleRemove = (index) => {
        remove(index)
    }
    console.log("Env is", process.env)

    const handleSave = () => {
        let userData = useLocalStorage.getItem("userData");
        let formData = {}
        formData["user_id"] = userData.id
        formData["isPermanent"] = 0
        let data = getValues();
        onSubmit(data, "SAVE")
    }


    const onSubmit = async (data) => {
        debugger
        let userData = useLocalStorage.getItem("userData");
        let formData = {}
        formData["user_id"] = userData.id;
        formData['department'] = data.department ? data.department : null;
        formData["company_name"] = data.company_name ? data.company_name : null;
        formData["isPermanent"] = 0;
        //  formData["isPermanent"] = location?.state?.isPermanent || 0
        let material_details = []
        let imageData = {}


        let isSubmit = false;

        data?.material_details?.forEach((material, index) => {
            debugger
            material_details.push({
                'key_index': index,
                'material_code': material?.material_code?.material_code ? data.material_details[index].material_code.label : null,
                'material_group': material.material_group ? material.material_group : null,
                'material_description': material.material_description ? material.material_description : null,
                "material_code_verification": material.material_code_verification ? 1 : 0,
                'quantity': material.quantity ? material.quantity : 0,
                'unit': material.units ? material.units : null,
                'comments': material.comments ? material.comments : null,
                "last_updated_price": material.last_updated_price ? material.last_updated_price : null
            })

            if (material?.file) {
                imageData[index] = material?.file;
                material_details[index]['image_url'] = "true";
            } else if (material.image_url) {
                material_details[index]['image_url'] = material.image_url;
            }

            if (data?.material_details?.[index]?.material_code.label) {
                isSubmit = true;
            }
        })
        formData["material_details"] = [...material_details]
        // if (data.comments) {
        //     formData.append('comments', data.material_details?.comments);
        // }
        // if (data.file) {
        //     formData.append('file', data.material_details?.file);
        // }


        if (!isSubmit) {
            showToast("ERROR", "Please fill atleast one material details.");
            return;
        }

        let responseData
        console.log("Image Data is", imageData)
        if (scrapRequestView.length || tempId) {
            if (location?.state?.isPermanent) {
                formData["permanent_scrap_id"] = location.state?.permanent_id
                formData["scrap_id"] = scrapRequestView[0]?.temp_scrap_id || scrapRequestView[0]?.requestNo
            } else if (scrapRequestView.length) {
                formData["scrap_id"] = scrapRequestView[0]?.requestNo
            } else {
                formData["scrap_id"] = tempId
            }

            let scrapId = scrapRequestView[0]?.requestNo || tempId
            responseData = await dispatch(editScrap(formData));
            console.log("response is", responseData, "Permanent Id", location.state?.permanent_id)
            uploadImage(imageData, responseData.payload?.data.data, navigate, saveRef.current, scrapId, 0, scrapRequestView[0]?.temp_scrap_id || scrapRequestView[0]?.requestNo, location.state?.permanent_id)
        } else {
            formData["scrap_reviewed"] = 0
            formData["temp_scrap_deposit_id"] = 0
            responseData = await dispatch(requestScrap(formData));
            if (responseData?.payload?.data?.status === 200) {
                // setOpen(true);
                let scrapId = responseData?.payload?.data?.data?.temp_scrap_deposit_id
                setTempId(scrapId)
                uploadImage(imageData, responseData?.payload?.data?.data?.material_data, navigate, saveRef.current, scrapId, location?.state?.isPermanent || 0)
                AddScrapInfoRef.current.request_no = responseData.payload.data.data?.request_id;
            } else {
                showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
            }
        }
    }

    const handleRemoveImage = (index) => {
        let temp = imagePreview
        temp[index] = false
        setValue(`material_details.${index}.file`, false);
        setImagePreview({ ...temp })
    }

    const showPreview = (file, index) => {
        let reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = ((result) => {
            imagePreview[index] = result.currentTarget.result
            setImagePreview({ ...imagePreview })
            console.log("image url is", result.currentTarget.result);
        })

    }

    console.log("renderCount", ++renderCount, errors, imagePreview)

    return (<>

        {loadingMaterialList || loadingDepartmentList || loading || loadingScrapRequest ? <Loading loading={true} /> : ""}


        <ThemeProvider theme={defaultTheme}>
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >
                    <Typography component="h1" variant="h5" className='mb-3 scrap_header'>
                        Material Deposit
                    </Typography>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Box
                            sx={{
                                my: 4,
                                mx: 4,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center'
                            }}
                        >


                            <Box key={`FieldStatic`} style={{ width: "100%" }}>

                                <Grid container spacing={2}>
                                    <Grid item md={4} lg={4} xs={12} id="company_name" >
                                        <MySelect
                                            {...register(`company_name`, { required: { value: true, message: "Please select your company name" } })}
                                            label={'Company *'}
                                            menuItems={COMAPANY}
                                            required={true}
                                            onChange={(e) => {
                                                setValue(`company_name`, e.target.value);
                                                setToggle(!toggle)
                                            }}
                                            value={getValues(`company_name`) ? getValues(`company_name`) : ""}
                                            error={errors.company_name ? true : false}
                                            errormessage={errors.company_name?.message}
                                        />

                                    </Grid>
                                    <Grid item md={4} lg={4} xs={12} id="department">
                                        <MySelect
                                            required={true}
                                            {...register(`department`, { required: { value: true, message: "Please select a department" } })}
                                            label={'Department *'}
                                            menuItems={departmentList}
                                            onChange={(e) => {
                                                setValue(`department`, e.target.value);
                                                setToggle(!toggle)
                                            }}
                                            value={getValues(`department`) ? getValues(`department`) : ""}
                                            error={errors.department ? true : false}
                                            errormessage={errors.department?.message}
                                        />

                                    </Grid>
                                </Grid>
                                <p><strong>Material {1}</strong></p>
                            </Box>

                            {fields.map((field, index) => (
                                <Box key={`Fiel${field.id}`}>
                                    <Grid container spacing={2}>
                                        {
                                            index > 0 ? <Grid item md={12} sm={12} lg={12} style={{ textAlign: "right" }}>
                                                <p style={{ position: "absolute", marginTop: "12px" }}><strong>Material {index + 1}</strong></p>
                                                <Button type={"button"} variant="contained" fullWidth={false} onClick={() => handleRemove(index)} style={{ backgroundColor: CONSTANTS.COLORS.RED }} >
                                                    Remove
                                                </Button>
                                            </Grid> : null}
                                        <Grid item md={4} lg={4} xs={12} id={`material_code_${field.id}`}>
                                            <MyAutocomplete
                                                options={materialList.length ? materialList.map((value, index) => {
                                                    return { label: value.material_code, ...value }
                                                }) : []}
                                                label='Material Code *'

                                                {...register(`material_details.${index}.material_code`, { required: { value: true, message: "Material Code is required" } })}
                                                onChange={(e, value) => {
                                                    console.log("values are", value, getValues())
                                                    setValue(`material_details.${index}.material_code`, value);
                                                    setValue(`material_details.${index}.material_group`, value.material_group);
                                                    setValue(`material_details.${index}.material_description`, value.material_description);
                                                    setValue(`material_details.${index}.units`, value.unit)
                                                    setValue(`material_details.${index}.last_updated_price`, value.price)
                                                    setToggle(!toggle)
                                                }}
                                                onInputChange={(e, value) => {
                                                    console.log("Input value is", value)
                                                    let formData = {
                                                        page_number: 0,
                                                        count: 50,
                                                        material_code: value
                                                    }
                                                    getMaterialList(formData)
                                                    // console.log("saawre",getValues(`material_details.${index}`),value)
                                                    // setValue(`material_details.${index}.material_code`, { label: value});
                                                }}
                                                value={getValues()?.material_details?.[index]?.material_code ? getValues().material_details[index].material_code : null}
                                                error={errors?.material_details?.[index]?.material_code ? true : false}
                                                errormessage={errors?.material_details?.[index]?.material_code?.message}
                                            />

                                        </Grid>

                                        <Grid item md={4} lg={4} xs={12} id={`material_group_${field.id}`}>
                                            <Input
                                                {...register(`material_details.${index}.material_group`)}
                                                required={true}
                                                fullWidth={true}
                                                autoFocus={true}
                                                label="Material Group"
                                                type="text"
                                                autoComplete='on'
                                                error={errors?.material_details?.[index]?.material_group ? true : false}
                                                errormessage={errors?.material_details?.[index]?.material_group?.message}
                                                value={getValues(`material_details.${index}.material_group`) ? getValues(`material_details.${index}.material_group`) : ""}
                                                onChange={(e) => {
                                                    setValue(`material_details.${index}.material_group`, e.target.value);
                                                }}
                                                disabled={true}
                                            />

                                        </Grid>
                                        <Grid item md={4} lg={4} xs={12} id={`material_description_${field.id}`}>
                                            <Input
                                                {...register(`material_details.${index}.material_description`)}
                                                required={true}
                                                multiline={true}
                                                fullWidth={true}
                                                autoFocus={true}
                                                label="Material Description"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.material_description ? true : false}
                                                errormessage={errors.material_description?.message}
                                                value={getValues(`material_details.${index}.material_description`) ? getValues(`material_details.${index}.material_description`) : ""}
                                                onChange={(e) => {
                                                    setValue(`material_details.${index}.material_description`, e.target.value);
                                                }}
                                                disabled={true}
                                            />
                                        </Grid>

                                        <Grid item md={12} lg={12} xs={12} style={{ marginTop: "-10px" }}>

                                            <input {...register(`material_details.${index}.material_code_verification`)} type="checkbox"
                                                checked={getValues(`material_details.${index}.material_code_verification`)}
                                                onChange={(e) => {
                                                    console.log("value", e.target.checked)
                                                    setValue(`material_details.${index}.material_code_verification`, e.target.checked)
                                                    proceed[index] = e.target.checked
                                                    // console.log(proceed)
                                                    setToggle(!toggle)
                                                    setProceed({ ...proceed })
                                                }}
                                            /> I confirm the verification of the Material Code in SAP

                                        </Grid>

                                        <Grid item md={4} lg={4} xs={6} id={`material_unit_${field.id}`}>

                                            <Input
                                                {...register(`material_details.${index}.units`)}
                                                required={true}
                                                fullWidth={true}
                                                autoFocus={true}
                                                label="Units"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.units ? true : false}
                                                errormessage={errors.units?.message}
                                                value={getValues(`material_details.${index}.units`) ? getValues(`material_details.${index}.units`) : ""}
                                                onChange={(e) => {
                                                    setValue(`material_details.${index}.units`, e.target.value);
                                                }}
                                                disabled={true}
                                            />

                                        </Grid>

                                        <Grid item md={4} lg={4} xs={6}>
                                            <Input
                                                // {...register(`material_details.${index}.quantity`, {validate:(value)=>{
                                                //     console.log("Lutgaye",value)
                                                //     if(value===""){
                                                //         return `Quantity is required`
                                                //     }else if(!parseInt(value) || parseInt(value)+"" != value){
                                                //         return `Quantity should be a number`
                                                //     }else if(value < 0){
                                                //         return `Quantity should be positive`
                                                //     }
                                                // }})}
                                                {...register(`material_details.${index}.last_updated_price`)}
                                                fullWidth={true}
                                                label="Last Updated Price*"
                                                type="text"
                                                autoComplete='on'
                                                disabled={true}
                                                // error={errors.material_details?.[index].quantity ? true : false}
                                                // errormessage={errors.material_details?.[index].quantity?.message}
                                                value={getValues(`material_details.${index}.last_updated_price`) ? getValues(`material_details.${index}.last_updated_price`) : ""}
                                            // onChange={(e) => {
                                            //     setValue(`material_details.${index}.last_updated_price`, e.target.value);
                                            //     setToggle(!toggle)
                                            // }}

                                            />

                                        </Grid>

                                        <Grid item md={4} lg={4} xs={6} className='scrapMarginDeposit'>

                                            <TextField
                                                InputProps={{ endAdornment: <InputAdornment position="end">{getValues(`material_details.${index}.units`)}</InputAdornment> }}
                                                {...register(`material_details.${index}.quantity`, {
                                                    validate: (value) => {
                                                        console.log("validating working", value)
                                                        if (value === "") {
                                                            return `Quantity is required`
                                                        } else if (!parseFloat(value) || parseFloat(value) + "" != value) {
                                                            return `Quantity should be a number`
                                                        } else if (value < 0) {
                                                            return `Quantity should be positive`
                                                        }
                                                    }
                                                })}
                                                fullWidth={true}
                                                label="Quantity*"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.material_details?.[index]?.quantity ? true : false}

                                                value={getValues(`material_details.${index}.quantity`) ? getValues(`material_details.${index}.quantity`) : ""}
                                                onChange={(e) => {
                                                    let regex = new RegExp(/^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/);
                                                    if (regex.test(e.target.value) || e.target.value.length === 0) {
                                                        setValue(`material_details.${index}.quantity`, e.target.value);

                                                    } else {
                                                        let str = e.target.value;
                                                        str = str.substring(0, str.length - 1);
                                                        setValue(`material_details.${index}.quantity`, str);
                                                    }
                                                    setToggle(!toggle)
                                                }}
                                            />
                                            <Typography variant="subtitle1" color="error" >
                                                {errors.material_details?.[index]?.quantity?.message ? errors.material_details?.[index]?.quantity.message : ""}
                                            </Typography>
                                        </Grid>



                                        <Grid item md={6} lg={6} xs={12}>
                                            <Input
                                                {...register(`material_details.${index}.comments`)}
                                                fullWidth={true}
                                                multiline={true}
                                                minRows={2}
                                                label="Short Text"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.comments ? true : false}
                                                onChange={(e) => {
                                                    console.log("Comment", e.target.value)
                                                    setValue(`material_details.${index}.comments`, e.target.value || '');
                                                    setToggle(!toggle)
                                                }}
                                                value={getValues(`material_details.${index}.comments`) ? getValues(`material_details.${index}.comments`) : ""}
                                                errormessage={errors.comments?.message}
                                            />
                                        </Grid>

                                        <Grid item md={3} sm={3} lg={8} style={{ display: "flex", gap: "20px" }}>
                                            {imagePreview[index] ? <>
                                                Image Preview
                                                <div style={{ position: "relative" }}>
                                                    <img className="previewImg" src={imagePreview[index]?.length < 1000 ? imagePreview[index] + "?" + Math.random() : imagePreview[index]} />
                                                    <div onClick={() => handleRemoveImage(index)} className="imageRemove">X</div>
                                                    {/* <MyButton style={{marginTop:"10px", backgroundColor:"green", height:"20px"}} label={"Uploaded Image"} onClick={()=>{
                                                    window.open(scrapRequestView?.[0]?.material_details[index]?.image_url, "_blank") }} />   */}
                                                </div></> :
                                                <InputFileUpload
                                                    onChange={(e) => {
                                                        setLoading(true)
                                                        showPreview(e.target.files[0], index)
                                                        setValue(`material_details.${index}.file`, e.target.files[0]);
                                                        setTimeout(() => {
                                                            setLoading(false);
                                                        }, 1500)
                                                    }}
                                                    value={getValues(`material_details.${index}.file`) ? getValues(`material_details.${index}.file`) : ""}
                                                    label={"Upload Image"}
                                                    optional={true}
                                                    errormessage={errors?.file?.message ? errors.file.message : ""}
                                                />}
                                        </Grid>

                                    </Grid>
                                </Box>
                            ))}
                            <Box style={{ width: "100%" }}>
                                <Grid container spacing={2}>
                                    <Grid item md={12} sm={12} lg={12} style={{ textAlign: "right" }}>
                                        <Button type={"button"} variant="contained" fullWidth={false} onClick={handleAddMore} style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} >
                                            Add More
                                        </Button>
                                    </Grid>
                                    <Grid item md={12} sm={12} lg={12}>
                                        <div style={{ display: "flex", justifyContent: "center", gap: "5px" }}>
                                            <Button fullWidth={false} type="button" variant="contained" sx={{ mt: 3, mb: 2 }} onClick={() => {
                                                saveRef.current = true;
                                                handleSave();
                                            }}>
                                                Save
                                            </Button>
                                            <MyButton disabled={(() => {
                                                let allTrue = true
                                                getValues('material_details').map(value => {
                                                    if (value.material_code_verification == false) {
                                                        allTrue = false
                                                    }
                                                })
                                                console.log("alltrue is", allTrue)
                                                return !allTrue
                                            })()}
                                                onClick={() => {
                                                    saveRef.current = false
                                                }}
                                                type="submit" fullWidth={false} label={'Proceed'} />
                                        </div>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Box>
                    </form>
                    <DevTool control={control} />
                </Grid>

                <Dialog
                    className='dialogAlertStyle'
                    open={open}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">
                        <p className="dialog_title h3">
                            Material Deposit
                        </p>
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description" className='text-center'>
                            <b >
                                Your Material Deposit Form has been submitted successfully to your Reporting Manager for Approval,
                            </b>

                            <p className='h5 text-center mt-2'>
                                {`Request No : ${AddScrapInfoRef?.current?.request_no ? AddScrapInfoRef?.current?.request_no : ""}`}
                            </p>
                        </DialogContentText>
                    </DialogContent>

                    <DialogActions
                        className="dialogactions"
                    >
                        <Grid container style={{ marginTop: "-20px" }}>
                            <Grid item xs={5} sm={5} md={5} lg={5}>
                                <MyButton
                                    fullWidth={true}
                                    label='OK'
                                    onClick={(e) => {
                                        navigate(PATH.PRIVATE.DASHBOARD)
                                    }}
                                    style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} />
                            </Grid>
                        </Grid>
                    </DialogActions>
                </Dialog>

            </Grid>

        </ThemeProvider >
    </>
    );
}
export default ScrapDeposit;