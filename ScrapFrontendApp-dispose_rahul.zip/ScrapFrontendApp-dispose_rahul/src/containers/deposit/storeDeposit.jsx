// import React, { useEffect, useRef, useState } from 'react';
// import { Button } from "@mui/material";
// import Typography from '@mui/material/Typography';
// import { createTheme, ThemeProvider } from '@mui/material/styles';
// import { useAppDispatch, useAppSelector } from '../../store/hooks';
// import Paper from '@mui/material/Paper';
// import Box from '@mui/material/Box';
// import Grid from '@mui/material/Grid';
// import { useLocation, useNavigate } from "react-router-dom";
// import { showToast } from '../../components/toast';
// import useLocalStorage from '../../utils/localStorage';
// import { materialMasterList, departmentMasterList, viewScrapRequest, getScrapListHOD, dumpRequestList } from '../../store/slices/list';

// // import { getMaxListeners } from 'process';
// import Filter from '../../components/autocomplete';
// import MyAutocomplete from '../../components/autocomplete';
// import InputFileUpload from '../../components/upload';
// import MySelect from '../../components/select';
// import Dialog from '@mui/material/Dialog';
// import DialogTitle from "@mui/material/DialogTitle";
// import DialogContent from "@mui/material/DialogContent";
// import DialogContentText from "@mui/material/DialogContentText";
// import DialogActions from "@mui/material/DialogActions";
// import { COMAPANY, CONSTANTS } from '../../constants/constants';
// import {DevTool} from "@hookform/devtools"
// import { uploadImage } from '../../components/S3/S3';
// import Input from '../../components/input';
// import { PATH } from '../../paths/path';
// import { useDispatch } from 'react-redux';
// import MyButton from '../../components/button';
// import Loading from '../../components/backdrop';
// import { editScrap, requestScrap } from '../../store/slices/requests';

// const defaultTheme = createTheme();
// const StoreDepositReview = ()=>{
//     const [isReviewed, setIsReviewed] = useState(false)
//     const navigate = useNavigate()
//     const remarks = useRef("")
//     const [toggle,setToggle] = useState(true)
//     const [state, setState]= useState()
//     const { departmentList, scrapRequestView, loadingScrapRequestView, loadingDepartmentList } = useAppSelector(state => state.list);
//     const {loadingScrapRequest} = useAppSelector(state=>state.scrapRequests)
//     const [mode,setMode]=useState("review")
//     const dispatch = useDispatch()
//     const location = useLocation()
//     const [open, setOpen] = useState(false)
//     const onSubmit = ()=>{
//         console.log("Yoo")
//     }

//     const getScrapRequest = async ()=>{
//         if(location.state?.scrapId){
//             const data = {
//                 scrap_id: location.state.tempId?location.state.tempId:location.state.scrapId,
//                 isPermanent: 0
//               //  isPermanent:location?.state?.isPermanent || 0
//             }
//             const list = await dispatch(viewScrapRequest(data))
//             setToggle(!toggle)
//         }
//     }

//     useEffect(()=>{
//         getScrapRequest()
//         dispatch(dumpRequestList())
//         console.log("List dept",departmentList)
//         if(window.location.pathname.split("/").slice(-1)[0] === 'view'){
//             setMode("view")
//         }
//     },[])

//     useEffect(()=>{
//         if(scrapRequestView.length){
//             if(scrapRequestView.length){
//                 let department = scrapRequestView[0].department
//                 let company_name = scrapRequestView[0].company_name
//                 let temp_scrap_deposit_id = scrapRequestView[0]?.requestNo
//                 console.log("Id is ",temp_scrap_deposit_id)
//                 let material_details = []
//                 console.log("scrapRequest",scrapRequestView)
//                 debugger
//                 scrapRequestView[0].material_details.map((item,index)=>{
//                    material_details.push({ 
//                     "material_code": item.material_code,
//                     "comments": item.comments,
//                     "material_description": item.material_description,
//                     "material_group": item.material_group,
//                     "unit": "TONS",
//                     "last_updated_price": item.price,
//                     "quantity":item.quantity,
//                     "image_url": item?.image_url,
//                     "key_index": index
//                     })
//                     console.log("values after setValues",index)
//                 })
//                 setState({
//                     department,
//                     company_name,
//                     temp_scrap_deposit_id,
//                     material_details
//                 })
//                 if(!departmentList.length){
//                     dispatch(departmentMasterList({}))
//                  //   console.log("runn")
//                 }
//                 //setToggle(!toggle)
//             }
//         }
//     },[scrapRequestView])

   
//     const handleSubmit= async ()=>{
//         console.log("Review process",isReviewed)
//         if(isReviewed && remarks.current.length>1){
//             let formData = {
//                 department: state.department,
//                 scrap_reviewed:1,
//                 // temp_scrap_deposit_id:state.temp_scrap_deposit_id,
//                 scrap_remarks:remarks.current,
//                 company_name:state.company_name,
//                 material_details:state.material_details,
//                 isPermanent:1
//             }
//             console.log("submitting",formData)
//             let responseData
//             if(location.state.isPermanent){
//                 formData["scrap_id"] = location.state.scrapId
//                 formData["temp_scrap_deposit_id"] = location.state.tempId
//                 responseData = await dispatch(editScrap(formData))
//             }else{
//                 formData["temp_scrap_deposit_id"] = state.temp_scrap_deposit_id
//                 responseData = await dispatch(requestScrap(formData));
//             }
//             if (responseData?.payload?.data?.status === 200) {
//                 showToast("SUCCESS", `Request is submitted successfully.`)
//             }
//             else{
//                 showToast("ERROR", responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...')
//             }
//             setTimeout(()=>{
//                 navigate(PATH.PRIVATE.SCRAP_DEPOSIT_LIST)
//             },1000)
//         }
//         else{
//             if(!isReviewed){
//                 showToast('ERROR', "Please verify that you have reviewed and cross verified the above details")
//             }
            
//         }

//     }

//     // console.log("scrap descript", departmentList)
//     return (
//         <ThemeProvider  theme={defaultTheme}>
//             {loadingScrapRequestView || loadingDepartmentList || loadingScrapRequest || loadingScrapRequestView ?<Loading  loading={true}  />:null}
//             <Grid className="scrapSection" container component="main" sx={{
//                 display: "flex",
//                 justifyContent: "center",
//                 alignItems: "center",
//                 marginTop: "20px",
//                 marginBottom: "10px"
//             }}>

//                 <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
//                 >

//                 <Typography  component="h1" variant="h5" className='scrap_header'>
//                               {mode==="view"?"Request Description":"Review Summary"}
//                 </Typography>
//                             <form onSubmit={onSubmit}>
//                         <Box
//                             sx={{
//                                 my: 2,
//                                 mx: 4,
//                                 display: 'flex',
//                                 flexDirection: 'column',
//                                 alignItems: 'center'
//                             }}
//                         >
//                         <Box key={`FieldStatic`} style={{width:"100%"}}>
//                         <Grid  container spacing={2}>
//                         <Grid item md={6} lg={6} xs={12}  id="company_name" >
//                         <p>Company Name  <b> : {state?.company_name ||""}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Company"
//                             type="text"
//                             disabled={true}
//                             value={state?.company_name || ""}
//                         /> */}
//                         {/* <Input
//                             fullWidth={true}
//                             multiline={true}
//                             minRows={2}
//                             label="Comments"
//                             type="text"
//                             autoComplete='on'
//                         /> */}

//                         </Grid>
//                         <Grid item md={6} lg={6} xs={12} >
//                             <p>Department <b>: {departmentList?.[state?.department -1]?.label || ""}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Department"
//                             type="text"
//                             disabled={true}
//                             value={departmentList?.[state?.department -1]?.label || ""}
//                         /> */}
//                         {/* <Input
//                             fullWidth={true}
//                             multiline={true}
//                             minRows={2}
//                             label="Comments"
//                             type="text"
//                             autoComplete='on' */}
                       

//                         </Grid>
//                         </Grid>
//                         <hr style={{marginTop:'-15px'}} />
//                         <Grid  container spacing={2} >
                            
//                         {state?.material_details.map((  
//                             material,index)=>(<Grid item md={6} lg={6} xl={6} xs={12} >
//                                 <Grid component={Paper} elevation={3} sx={{padding:"20px"}}>
//                         <div>
//                         <p><strong>Material {index+1}</strong></p>
//                         <Grid item md={8} lg={8} xs={8} >
//                         <p>Material Code <b>: {material.material_code}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Material Code"
//                             type="text"
//                             disabled={true}
//                             value={material.material_code}
//                         /> */}
//                         </Grid>
//                         <Grid item md={8} lg={8} xs={8} >
//                         <p>Material Group <b>: {material.material_group}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Material Group"
//                             type="text"
//                             disabled={true}
//                             value={material.material_group}
//                         /> */}
//                         </Grid>
//                         <Grid item md={8} lg={8} xs={8} >
//                         <p>Material Description <b>: {material.material_description}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Material Description"
//                             type="text"
//                             disabled={true}
//                             value={material.material_description}
//                         /> */}
//                         </Grid>
//                         <Grid item md={8} lg={8} xs={8} >
//                         <p>Unit<b>: {material.unit}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Unit"
//                             type="text"
//                             disabled={true}
//                             value={"TONS"}
//                         /> */}
//                         </Grid>
//                         <Grid item md={8} lg={8} xs={8} >
//                         <p>Quantity <b>: {material.quantity}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             label="Quantity"
//                             type="text"
//                             disabled={true}
//                             value={material.quantity}
//                         /> */}
//                         </Grid>
//                         <Grid item md={8} lg={8} xs={8} >
//                         <p>Short Text <b>: {material.comments}</b></p>
//                         {/* <Input
//                             fullWidth={true}
//                             multiline={true}
//                             minRows={2}
//                             label="Short Text"
//                             type="text"
//                             autoComplete='on'
//                             disabled={true}
//                             value={material.comments}
//                         /> */}
//                         </Grid>
                      
//                         {/* </Grid> */}
//                         {material.image_url?<div style={{display:"flex", gap:"10px", marginTop:"10px"}}>
//                             Image Preview <b>:</b> 
//                         <div style={{position:"relative"}}>
                            
//                         <img className="previewImg" src={material?.image_url+"?"+Math.random()}/>
//                         {/* <div className="imageRemove">X</div> */}
//                         {/* <MyButton label={"Uploaded Image"} onClick={()=>{
//                             console.log(material)
//                             window.open(material?.image_url, '_blank').focus()
//                         }}/> */}
//                         </div></div>
//                        :""}
//                        </div>
//                        </Grid>
//                         </Grid>))}
//                         {mode==="view"?null:<>
//                         <Grid item md={8} lg={7} xs={12} >
//                         <Input
//                             fullWidth={true}
//                             multiline={true}
//                             minRows={2}
//                             label="Remarks"
//                             type="text"
//                             autoComplete='on'
//                             onChange={(e)=>{
//                                 remarks.current = e.target.value
//                             }}
//                         />
//                         <div style={{marginTop:"10px", cursor:"pointer"}}>
//                             <input id="reviewed" type="checkbox" checked={isReviewed} value={isReviewed} onChange={(e)=>setIsReviewed(e.target.checked)}/> 
//                             <span id="reviewed" name="reviewed"  onClick={()=>setIsReviewed(!isReviewed)}> I have reviewed and cross verified the above details </span>
//                         </div>
//                         </Grid>
//                         <Grid item md={12} sm={12} lg={12}>
//                                     <div style={{display:"flex", justifyContent:"center", gap:"5px"}}>
//                                         <Button fullWidth={true} fullWidth={false} variant="contained"  sx={{ mt: 3, mb: 2 }} onClick={handleSubmit}>
//                                             Submit    
//                                         </Button>
//                                     </div>
//                         </Grid>
//                         </>}
//                         </Grid>
//                         </Box>

//                         </Box>
//                         </form>
//                         </Grid>
//                         </Grid>
//                         </ThemeProvider>
//     )
// }

// export default StoreDepositReview