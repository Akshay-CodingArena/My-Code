import React, { Suspense, useEffect, useRef, useState } from 'react';
import { Button, InputAdornment, InputLabel, OutlinedInput, TextField } from "@mui/material";
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { materialMasterList, departmentMasterList, viewScrapRequest, getScrapListHOD, dumpRequestList, listCategory, listBinCode } from '../../store/slices/list';

// import { getMaxListeners } from 'process';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S3';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import { useDispatch } from 'react-redux';
import MyButton from '../../components/button';
import Loading from '../../components/backdrop';
import { editScrap, requestScrap, storeManagerApproval } from '../../store/slices/requests';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import DownloadIcon from "../../assets/images/images.png";
import ImageDialog from '../../components/ImageModal';

const defaultTheme = createTheme();

const ScrapDepositStoreReview = () => {
    const {
        register,
        // handleSubmit,
        formState: { errors },
        reset,
        control,
        getValues,
        setValue
    } = useForm({
        defaultValues: {
            material_details: [{
                store_quantity_accepted: 0,
                bincode: "",
                store_weighment_slip: "",
                store_weighment_required: false,
                weighment_slip_no: "",
                store_quantity_variation: "",
                store_weighment_category: "",
                store_remarks: ""
            }]
        }
    });

    let { fields, append, remove } = useFieldArray({
        name: "material_details",
        control
    })

    const navigate = useNavigate()
    const remarks = useRef("")
    const [toggle, setToggle] = useState(false)
    const [state, setState] = useState()
    const { departmentList, scrapRequestView, loadingScrapRequestView, loadingDepartmentList, scrapCategories, loadingCategories, scrapBinCodes, loadingBinCode, tempRequestView } = useAppSelector(state => state.list);
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests)
    console.log("categories are", scrapCategories)
    const [mode, setMode] = useState("review")
    const dispatch = useDispatch()
    const location = useLocation()
    const [open, setOpen] = useState(false)
    const ImageRef = useRef();


    const onSubmit = () => {
        console.log("Yoo")
    }

    const getScrapRequest = async () => {
        if (location.state?.scrapId) {
            const data = {
                scrap_id: location.state.tempId ? location.state.tempId : location.state.scrapId,
                isPermanent: 1
            }
            const list = await dispatch(viewScrapRequest(data))
            setToggle(!toggle)
        }
    }

    useEffect(() => {
        getScrapRequest()
        if (scrapBinCodes.length === 0) {
            dispatch(listBinCode())
        }
        dispatch(listCategory())
        dispatch(dumpRequestList())
        console.log("List dept", departmentList)
        if (window.location.pathname.split("/").slice(-1)[0] === 'view') {
            setMode("view")
        }
    }, [])

    useEffect(() => {
        debugger
        if (scrapRequestView.length) {
            if (scrapRequestView.length) {

                debugger
                let created_on = scrapRequestView[0].created_on
                let department = scrapRequestView[0].department
                let company_name = scrapRequestView[0].company_name
                let temp_scrap_deposit_id = scrapRequestView[0]?.requestNo
                console.log("Id is ", temp_scrap_deposit_id)
                let material_details = []
                console.log("scrapRequest", scrapRequestView)
                scrapRequestView[0].material_details.map((item, index) => {
                    if (tempRequestView.length) {
                        material_details.push({
                            "material_code": item.material_code,
                            "comments": item.comments,
                            "material_description": item.material_description,
                            "material_group": item.material_group,
                            "unit": item.unit,
                            "last_updated_price": item.price,
                            "quantity": item.quantity,
                            "image_url": item?.image_url,
                            "key_index": index,
                            store_quantity_accepted: tempRequestView?.[index]?.store_quantity_accepted ?? 0,
                            store_quantity_variation: tempRequestView?.[index]?.store_quantity_variation ?? "",
                            bincode: tempRequestView?.[index]?.bincode ?? "",
                            store_weighment_slip: tempRequestView?.[index]?.store_weighment_slip ?? "",
                            store_weighment_required: tempRequestView?.[index]?.store_weighment_required ?? 0,
                            store_quantity_variation: tempRequestView?.[index]?.store_quantity_variation ?? 0,
                            store_weighment_category: tempRequestView?.[index]?.store_weighment_category,
                            store_remarks: tempRequestView?.[index]?.store_remarks
                        })
                        setValue(`material_details.${index}.bincode`, tempRequestView?.[index]?.bincode ?? 0)
                        setValue(`material_details.${index}.store_quantity_accepted`, tempRequestView?.[index]?.store_quantity_accepted ?? 0)
                        setValue(`material_details.${index}.store_weighment_required`, tempRequestView?.[index]?.store_weighment_required ?? 0)
                        setValue(`material_details.${index}.store_quantity_variation`, tempRequestView?.[index]?.store_quantity_variation ?? "")
                        setValue(`material_details.${index}.store_weighment_slip`, tempRequestView?.[index]?.store_weighment_slip ?? 0)
                        setValue(`material_details.${index}.store_weighment_category`, tempRequestView?.[index]?.store_weighment_category ?? 0)
                        setValue(`material_details.${index}.store_remarks`, tempRequestView?.[index]?.store_remarks ?? 0);

                        setToggle(!toggle);
                    } else {
                        material_details.push({
                            "material_code": item.material_code,
                            "comments": item.comments,
                            "material_description": item.material_description,
                            "material_group": item.material_group,
                            "unit": item.unit,
                            "last_updated_price": item.price,
                            "quantity": item.quantity,
                            "image_url": item?.image_url,
                            "key_index": index,
                            store_quantity_accepted: item?.store_quantity_accepted ?? 0,
                            store_quantity_variation: item?.store_quantity_variation ?? "",
                            bincode: item?.bincode ?? "",
                            store_weighment_slip: item?.store_weighment_slip ?? "",
                            store_weighment_required: item?.store_weighment_required ?? 0,
                            store_quantity_variation: item?.store_quantity_variation ?? "",
                            store_weighment_category: item?.store_weighment_category ?? "",
                            store_remarks: item?.store_remarks ?? ""
                        })
                    }
                })
                setState({
                    created_on,
                    department,
                    company_name,
                    temp_scrap_deposit_id,
                    material_details
                })
                if (!departmentList.length) {
                    dispatch(departmentMasterList({}))
                    //   console.log("runn")
                }
                //setToggle(!toggle)
            }
        }
    }, [scrapRequestView])

    const handleSubmit = async () => {
        const material_details = getValues(`material_details`)
        console.log("Field is", getValues(`material_details`))
        let formData = []
        getValues(`material_details`).map((material, index) => {
            formData.push({
                material_code: state?.material_details[index]?.material_code,
                key_index: index,
                store_quantity_accepted: material.store_quantity_accepted,
                store_quantity_variation: material.store_quantity_variation,
                bincode: material.bincode,
                store_weighment_slip: material.store_weighment_slip,
                weighment_slip_no: material.weighment_slip_no,
                store_quantity_variation: material.store_quantity_variation,
                store_weighment_category: material.store_weighment_category,
                store_remarks: material.store_remarks
            })

        })

        const result = await dispatch(storeManagerApproval({
            "scrap_id": location.state.tempId ? location.state.tempId : location.state.scrapId,
            "store_isPermanent": 1,
            "scrap_deposit_approval": 1,
            "role_id": 2,
            // store_material_details:formData
        }))

        if (result.payload.data.status == 200) {
            showToast("SUCCESS", "Materials Accepted Successfully")
            navigate("/Store-Manager/scrap-request-list-for-approval")
        } else {
            showToast("ERROR", "Some Error Occured")
        }
        console.log("result os", result.payload.data.status)
    }
    //     // console.log("Review process",isReviewed)
    //     if(remarks.current.length>1){
    //         let formData = {
    //             department: state.department,
    //             scrap_reviewed:1,
    //             // temp_scrap_deposit_id:state.temp_scrap_deposit_id,
    //             scrap_remarks:remarks.current,
    //             company_name:state.company_name,
    //             material_details:state.material_details,
    //             isPermanent:1
    //         }
    //         console.log("submitting",formData)
    //         let responseData
    //         if(location.state.isPermanent){
    //             formData["scrap_id"] = location.state.scrapId
    //             formData["temp_scrap_deposit_id"] = location.state.tempId
    //             responseData = await dispatch(editScrap(formData))
    //         }else{
    //             formData["temp_scrap_deposit_id"] = state.temp_scrap_deposit_id
    //             responseData = await dispatch(requestScrap(formData));
    //         }
    //         if (responseData?.payload?.data?.status === 200) {
    //             showToast("SUCCESS", `Request is submitted successfully.`)
    //         }
    //         else{
    //             showToast("ERROR", responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...')
    //         }
    //         setTimeout(()=>{
    //             navigate(PATH.PRIVATE.SCRAP_DEPOSIT_LIST)
    //         },1000)
    //     }
    //     else{
    //         if(!isReviewed){
    //             showToast('ERROR', "Please verify that you have reviewed and cross verified the above details")
    //         }

    //     }

    // }

    // console.log("scrap descript", departmentList)

    const downloadImage = async (imageUrl) => {
        try {
            // Fetch the image data
            const response = await fetch(imageUrl);
            const blob = await response.blob();
            // Create a temporary URL for the Blob
            const blobUrl = URL.createObjectURL(blob);
            // Create a link element
            const link = document.createElement('a');
            // Set the link's href to the Blob URL
            link.href = blobUrl;
            // Add the download attribute and specify the desired filename
            link.download = 'preview_image';
            // Append the link to the document body
            document.body.appendChild(link);
            // Trigger a click event on the link
            link.click();
            // Remove the link and revoke the Blob URL
            document.body.removeChild(link);
            URL.revokeObjectURL(blobUrl);
        } catch (error) {
            console.error('Error downloading image:', error);
        }
    }


    return (
        <ThemeProvider theme={defaultTheme}>
            {loadingBinCode || loadingScrapRequestView || loadingDepartmentList || loadingScrapRequest || loadingScrapRequestView ? <Loading loading={true} /> : null}
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >

                    <Typography component="h1" variant="h5" className='scrap_header'>
                        {mode === "view" ? "Request Description" : "Review Summary"}
                    </Typography>
                    <form onSubmit={onSubmit}>
                        <Box
                            sx={{
                                my: 2,
                                mx: 4,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center'
                            }}
                        >
                            <Box key={`FieldStatic`} style={{ width: "100%" }}>
                                <Grid style={{ position: "sticky", top: "65px", backgroundColor: "white", zIndex: "99" }} container spacing={2}>
                                    <Grid item md={3} lg={3} xs={12} id="request_number" >
                                        <p>Request Number  <b> : {state?.temp_scrap_deposit_id || ""}</b></p>
                                    </Grid>
                                    <Grid item md={3} lg={3} xs={12} id="request_date" >
                                        <p>Request Date  <b> : {state?.created_on || ""}</b></p>
                                    </Grid>
                                    <Grid item md={3} lg={3} xs={12} id="company_name" >
                                        <p>Company Name  <b> : {state?.company_name || ""}</b></p>

                                    </Grid>
                                    <Grid item md={3} lg={3} xs={12} >
                                        <p>Department <b>: {departmentList?.filter((value, index) => value.value === state?.department)?.[0]?.label || ""}</b></p>
                                    </Grid>
                                </Grid>
                                <hr style={{ marginTop: '-15px' }} />
                                <Grid container spacing={2} >

                                    {state?.material_details.map((
                                        material, index) => (<Grid item md={6} lg={6} xl={6} xs={12} >
                                            <Grid component={Paper} elevation={3} sx={{ padding: "20px" }}>
                                                <p><strong>Material {index + 1}</strong></p>
                                                <div style={{ display: "flex" }}>
                                                    <div>
                                                        <Grid item md={8} lg={8} xs={8} >
                                                            <p>Material Code <b>: {material.material_code}</b></p>
                                                            {/* <Input
                            fullWidth={true}
                            label="Material Code"
                            type="text"
                            disabled={true}
                            value={material.material_code}
                        /> */}
                                                        </Grid>
                                                        <Grid item md={8} lg={8} xs={8} >
                                                            <p>Material Group <b>: {material.material_group}</b></p>
                                                            {/* <Input
                            fullWidth={true}
                            label="Material Group"
                            type="text"
                            disabled={true}
                            value={material.material_group}
                        /> */}
                                                        </Grid>
                                                        <Grid item md={8} lg={8} xs={8} >
                                                            <p>Material Description <b>: {material.material_description}</b></p>
                                                            {/* <Input
                            fullWidth={true}
                            label="Material Description"
                            type="text"
                            disabled={true}
                            value={material.material_description}
                        /> */}
                                                        </Grid>
                                                        <Grid item md={8} lg={8} xs={8} >
                                                            <p>Unit<b>: {material.unit}</b></p>
                                                            {/* <Input
                            fullWidth={true}
                            label="Unit"
                            type="text"
                            disabled={true}
                            value={"TONS"}
                        /> */}
                                                        </Grid>
                                                        <Grid item md={8} lg={8} xs={8} >
                                                            <p>Quantity <b>: {material.quantity}</b></p>
                                                            {/* <Input
                            fullWidth={true}
                            label="Quantity"
                            type="text"
                            disabled={true}
                            value={material.quantity}
                        /> */}
                                                        </Grid>
                                                        <Grid item md={8} lg={8} xs={8} >
                                                            <p>Short Text <b>: {material.comments}</b></p>
                                                            {/* <Input
                            fullWidth={true}
                            multiline={true}
                            minRows={2}
                            label="Short Text"
                            type="text"
                            autoComplete='on'
                            disabled={true}
                            value={material.comments}
                        /> */}
                                                        </Grid>

                                                        {/* </Grid> */}
                                                        {material.image_url ? <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
                                                            Image Preview <b>:</b>
                                                            <div style={{ position: "relative" }}>

                                                                <img className="previewImg"
                                                                    onClick={() => {
                                                                        ImageRef.current.handleClickOpen(material?.image_url + "?" + Math.random());
                                                                    }}
                                                                    src={material?.image_url + "?" + Math.random()} />
                                                                {/* <div className="imageRemove">X</div> */}
                                                                {/* <MyButton label={"Uploaded Image"} onClick={()=>{
                            console.log(material)
                            window.open(material?.image_url, '_blank').focus()
                        }}/> */}
                                                            </div>
                                                            <b>
                                                                <img src={DownloadIcon}
                                                                    onClick={() => {
                                                                        downloadImage(material?.image_url + "?" + Math.random())
                                                                    }}
                                                                    style={{ height: "20px", width: "20px", cursor: "pointer" }}
                                                                />
                                                            </b>

                                                        </div>
                                                            : ""}
                                                    </div>
                                                    {/* </div> */}
                                                    {/* <br /> */}
                                                    {/* <hr /> */}
                                                    {/* <br /> */}
                                                    <div>
                                                        <p><strong>Accepted by Store Manager</strong></p>
                                                        <Grid lg={12} sm={12} xl={12}>
                                                            {/* <InputLabel htmlFor="outlined-adornment-amount">Amount</InputLabel> */}
                                                            <p>Quantity Accepted <b>: {material.store_quantity_accepted ? material.store_quantity_accepted : ""}</b></p>
                                                        </Grid>
                                                        <Grid lg={12} sm={12} xl={12}>
                                                            {/* <InputLabel htmlFor="outlined-adornment-amount">Amount</InputLabel> */}
                                                            <p>Variation in quantity <b>: {material.store_quantity_variation}</b></p>
                                                        </Grid>
                                                        <Grid lg={12} sm={12} xl={12}>
                                                            <p>Location Bincode <b>: {scrapBinCodes.length ? scrapBinCodes?.filter((bin) => bin.id == material?.bincode)[0]?.bincode : ""}</b></p>
                                                        </Grid>
                                                        <Grid lg={12} sm={12} xl={12} style={{ marginBottom: "10px" }}>
                                                            {/* <p>Weighment Required <b>: {material.store_weighment_required ? "YES":"NO"}</b></p> */}
                                                        </Grid>
                                                        {material.store_weighment_slip ? <Grid lg={12} sm={12} xl={12}>
                                                            <p>Weighment Slip No <b>: {material?.store_weighment_slip  ? material.store_weighment_slip : "N/A"}</b></p>
                                                        </Grid> : null
                                                        }
                                                        <Grid lg={12} sm={12} xl={12}>
                                                            <p>Weighment Category <b>: {scrapCategories.length ? scrapCategories?.filter((category) => category?.id == material?.store_weighment_category)?.[0]?.category : ""}</b></p>
                                                        </Grid>
                                                        <Grid lg={12} sm={12} xl={12} style={{ marginTop: "10px" }}>
                                                            <p>Remarks <b style={{ wordWrap: 'break-word' }}>: {material?.store_remarks}</b></p>
                                                        </Grid>
                                                    </div>
                                                </div>
                                            </Grid>
                                        </Grid>))}

                                </Grid>
                            </Box>
                        </Box>
                        <Grid lg={12} style={{ display: "flex", justifyContent: "center", gap: "20px" }}>
                            {!location.state.isPermanent ?
                                <MyButton onClick={handleSubmit} label={"Submit"} />
                                : null}
                        </Grid>
                    </form>
                    <DevTool control={control} />
                </Grid>
            </Grid>


            <Suspense fallback={<Loading />}>
                <ImageDialog
                    ref={ImageRef}
                ></ImageDialog>
            </Suspense>


        </ThemeProvider>
    )
}

export default ScrapDepositStoreReview