import React, { Suspense, useEffect, useRef, useState } from 'react';
import { Button, InputAdornment, InputLabel, OutlinedInput, TextField } from "@mui/material";
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { materialMasterList, departmentMasterList, viewScrapRequest, getScrapListHOD, dumpRequestList, listCategory, listBinCode } from '../../store/slices/list';

// import { getMaxListeners } from 'process';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S3';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import { useDispatch } from 'react-redux';
import MyButton from '../../components/button';
import Loading from '../../components/backdrop';
import { editScrap, requestScrap, storeManagerApproval } from '../../store/slices/requests';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import DownloadIcon from "../../assets/images/images.png";
import ImageDialog from '../../components/ImageModal';

const defaultTheme = createTheme();
const ScrapDepositStoreApproval = () => {
    const {
        register,
        unregister,
        handleSubmit,
        formState: { errors },
        reset,
        control,
        getValues,
        setValue,
        setError,
        clearErrors
    } = useForm({
        defaultValues: {
            material_details: [{
                store_quantity_accepted: 0,
                bincode: "",
                store_weighment_slip: "",
                store_weighment_required: 0,
                store_quantity_variation: "",
                store_weighment_category: "",
                store_remarks: ""
            }]
        }
    });
    let { fields, append, remove } = useFieldArray({
        name: "material_details",
        control
    })

    const navigate = useNavigate()
    const actionRef = useRef("")
    const [toggle, setToggle] = useState(false)
    const [state, setState] = useState()
    const { departmentList, scrapRequestView, tempRequestView, loadingScrapRequestView, loadingDepartmentList, scrapCategories, loadingCategories, scrapBinCodes, loadingBinCode } = useAppSelector(state => state.list);
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests)
    console.log("categories are", scrapCategories)
    const [mode, setMode] = useState("review")
    const dispatch = useDispatch()
    const location = useLocation()
    const [open, setOpen] = useState(false)
    const saveValidation = useRef();
    const ImageRef = useRef();


    const onSubmit = async (e) => {
        console.log(getValues('material_details'));

        // e.preventDefault()
        console.log("submitter is", actionRef.current, e)
        const result = await handleSave()
        if (result.payload.data.status == "200") {
            showToast("SUCCESS", "Details Saved Successfully")
            if (actionRef.current === "PROCEED") {
                navigate(PATH.PRIVATE.SCRAP_DEPOSIT_STORE_REVIEW, {
                    state: {
                        scrapId: location.state.tempId ?? location.state?.scrapId,
                        isPermanent: 0
                    }
                })
            }
        } else {
            showToast("ERROR", result.payload.data.message)
        }

        //  handlers[label](e); // <--proxy event to proper callback handler
    }

    const getScrapRequest = async () => {
        if (location.state?.scrapId) {
            const data = {
                scrap_id: location.state.tempId ? location.state.tempId : location.state.scrapId,
                isPermanent: 1
                //  isPermanent:location?.state?.isPermanent || 0
            }
            const list = await dispatch(viewScrapRequest(data))
            setToggle(!toggle)
        }
    }



    const saveInDraft = async () => {
        actionRef.current = "SAVE";
        debugger
        if (!Object.keys(errors).length) {
            const result = await handleSave();
            if (result.payload.data.status == "200") {
                showToast("SUCCESS", "Details Saved Successfully in Draft")
            } else {
                showToast("ERROR", result.payload.data.message)
            }
        } else {
            showToast("ERROR", "Invalid values in the form")
        }
    }


    useEffect(() => {
        getScrapRequest()
        dispatch(listBinCode())
        dispatch(listCategory())
        dispatch(dumpRequestList())
        console.log("List dept", departmentList)
        if (window.location.pathname.split("/").slice(-1)[0] === 'view') {
            setMode("view")
        }
    }, [])

    useEffect(() => {
        debugger

        if (scrapRequestView.length) {
            if (scrapRequestView.length) {
                debugger
                let created_on = scrapRequestView[0].created_on
                let department = scrapRequestView[0].department
                let company_name = scrapRequestView[0].company_name
                let temp_scrap_deposit_id = scrapRequestView[0]?.requestNo
                let remarks = scrapRequestView[0]?.remarks
                console.log("Id is ", temp_scrap_deposit_id)
                let material_details = []
                console.log("scrapRequest", scrapRequestView);
                // debugger
                scrapRequestView[0].material_details.map((item, index) => {
                    if (tempRequestView.length) {

                        // debugger

                        // console.log(typeof tempRequestView[index].store_weighment_required);

                        material_details.push({
                            "material_code": item.material_code,
                            "comments": item.comments,
                            "material_description": item.material_description,
                            "material_group": item.material_group,
                            "unit": item.unit,
                            "last_updated_price": item.price,
                            "quantity": item.quantity,
                            "image_url": item?.image_url,
                            "key_index": index,
                            store_quantity_accepted: tempRequestView?.[index]?.store_quantity_accepted ?? 0,
                            store_quantity_variation: tempRequestView?.[index]?.store_quantity_variation ?? 0,
                            bincode: tempRequestView?.[index]?.bincode ?? "",
                            store_weighment_slip: tempRequestView?.[index]?.store_weighment_slip ?? "",
                            store_weighment_required: tempRequestView?.[index]?.store_weighment_required ? tempRequestView[index].store_weighment_required : 0,
                            store_quantity_variation:
                                tempRequestView?.[index]?.store_quantity_variation ?
                                    tempRequestView?.[index]?.store_quantity_variation
                                    :
                                    tempRequestView?.[index]?.store_quantity_variation === 0 ?
                                        0 :
                                        item.quantity
                            ,
                            store_weighment_category: tempRequestView?.[index]?.store_weighment_category,
                            store_remarks: tempRequestView?.[index]?.store_remarks ? tempRequestView[index].store_remarks:""
                        })


                        console.log("---------TESTING----------");
                        console.log(tempRequestView?.[index]?.store_weighment_required);


                        setValue(`material_details.${index}.bincode`, tempRequestView?.[index]?.bincode ?? 0)
                        setValue(`material_details.${index}.store_quantity_accepted`, tempRequestView?.[index]?.store_quantity_accepted ?? 0)
                        setValue(`material_details.${index}.store_weighment_required`, tempRequestView?.[index]?.store_weighment_required ? tempRequestView[index].store_weighment_required : 0)
                        setValue(`material_details.${index}.store_quantity_variation`, tempRequestView?.[index]?.store_quantity_variation ?
                            tempRequestView?.[index]?.store_quantity_variation
                            :
                            tempRequestView?.[index]?.store_quantity_variation === 0 ?
                                0 :
                                item.quantity
                        )
                        setValue(`material_details.${index}.store_weighment_category`, tempRequestView?.[index]?.store_weighment_category ?? 0)
                        setValue(`material_details.${index}.store_weighment_slip`, tempRequestView?.[index]?.store_weighment_slip ?? 0)
                        setValue(`material_details.${index}.store_remarks`, tempRequestView?.[index]?.store_remarks ? tempRequestView[index].store_remarks: '')
                        setToggle(!toggle)




                    } else {

                        // debugger



                        material_details.push({
                            "material_code": item.material_code,
                            "comments": item.comments,
                            "material_description": item.material_description,
                            "material_group": item.material_group,
                            "unit": item.unit,
                            "last_updated_price": item.price,
                            "quantity": item.quantity,
                            "image_url": item?.image_url,
                            "key_index": index,
                            store_quantity_accepted: item?.store_quantity_accepted ?? 0,
                            store_quantity_variation: item?.store_quantity_variation ?? "",
                            bincode: item?.bincode ?? "",
                            store_weighment_slip: item?.store_weighment_slip ?? "",
                            store_weighment_required: item?.store_weighment_required ? item.store_weighment_required : 0,
                            store_quantity_variation:
                                item?.store_quantity_variation ?
                                    item.store_quantity_variation
                                    :
                                    item.store_quantity_variation === 0 ?
                                        0 :
                                        item.quantity,
                            store_weighment_category: item?.store_weighment_category ?? "",
                            store_remarks: item?.store_remarks ? item.store_remarks: ""
                        }
                        )
                        // console.log("..................//", typeof (item?.bincode))

                        setValue(`material_details.${index}.bincode`, item?.bincode ?? "")
                        setValue(`material_details.${index}.store_quantity_accepted`, item?.store_quantity_accepted ?? 0)
                        setValue(`material_details.${index}.store_weighment_required`, item?.store_weighment_required ? item.store_weighment_required : 0)
                        setValue(`material_details.${index}.store_quantity_variation`, item?.store_quantity_variation ?
                            item.store_quantity_variation
                            :
                            item.store_quantity_variation === 0 ?
                                0 :
                                item.quantity
                        )
                        setValue(`material_details.${index}.store_weighment_category`, item?.store_weighment_category ?? "")
                        setValue(`material_details.${index}.store_weighment_slip`, item?.store_weighment_slip ?? "")
                        setValue(`material_details.${index}.store_remarks`, item?.store_remarks ?? "")



                        setToggle(!toggle)
                    }

                    console.log("quantity acceped", `material_details.${index}.store_quantity_accepted`, tempRequestView?.[index]?.store_quantity_accepted ? tempRequestView?.[index].store_quantity_accepted : 0)
                    // setValue(`material_details.${index}.store_quantity_accepted`,tempRequestView?.[index]?.store_quantity_accepted ? tempRequestView?.[index].store_quantity_accepted:0)

                    console.log("values after setValues", index)
                    //  setValue(`material_details.${index}.store_quantity_variation`, item.store_quantity_variation??item?.quantity)     // To be check variation key
                })
                setState({
                    department,
                    company_name,
                    temp_scrap_deposit_id,
                    remarks,
                    created_on,
                    material_details
                })
                if (!departmentList.length) {
                    dispatch(departmentMasterList({}))
                    //   console.log("runn")
                }
                //setToggle(!toggle)
            }
        }
    }, [scrapRequestView])

    const handleSave = async () => {
        debugger
        console.log(state);
        // debugger
        const material_details = getValues(`material_details`)
        console.log("Field is", getValues(`material_details`))
        let store_material_details = []
        getValues(`material_details`).map((material, index) => {
            console.log("material is", material)
            store_material_details.push({
                material_code: state?.material_details[index]?.material_code,
                key_index: index,
                store_quantity_accepted: parseFloat(material.store_quantity_accepted) ? parseFloat(material.store_quantity_accepted) : 0,
                store_quantity_variation: material.store_quantity_variation ? material.store_quantity_variation : 0,
                bincode: material.bincode ? material.bincode : "",
                store_weighment_slip: material?.store_weighment_slip ? material?.store_weighment_slip : "",
                store_weighment_required: (material.store_weighment_required == "true" || material.store_weighment_required == 1) ? 1 : 0,
                store_weighment_category: material.store_weighment_category ? material.store_weighment_category : "",
                store_remarks: material.store_remarks ? material.store_remarks : "",
                test: material.quantity
            })
        })

        debugger

        let formData = {
            "scrap_id": scrapRequestView[0]?.requestNo,
            "store_isPermanent": 0,
            "scrap_deposit_approval": 1,
            "role_id": 2,
            store_material_details
        }

        let res = await dispatch(storeManagerApproval(formData))
        console.log("response for save", res)
        return res

    }






    //     // console.log("Review process",isReviewed)
    //     if(remarks.current.length>1){
    //         let formData = {
    //             department: state.department,
    //             scrap_reviewed:1,
    //             // temp_scrap_deposit_id:state.temp_scrap_deposit_id,
    //             scrap_remarks:remarks.current,
    //             company_name:state.company_name,
    //             material_details:state.material_details,
    //             isPermanent:1
    //         }
    //         console.log("submitting",formData)
    //         let responseData
    //         if(location.state.isPermanent){
    //             formData["scrap_id"] = location.state.scrapId
    //             formData["temp_scrap_deposit_id"] = location.state.tempId
    //             responseData = await dispatch(editScrap(formData))
    //         }else{
    //             formData["temp_scrap_deposit_id"] = state.temp_scrap_deposit_id
    //             responseData = await dispatch(requestScrap(formData));
    //         }
    //         if (responseData?.payload?.data?.status === 200) {
    //             showToast("SUCCESS", `Request is submitted successfully.`)
    //         }
    //         else{
    //             showToast("ERROR", responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...')
    //         }
    //         setTimeout(()=>{
    //             navigate(PATH.PRIVATE.SCRAP_DEPOSIT_LIST)
    //         },1000)
    //     }
    //     else{
    //         if(!isReviewed){
    //             showToast('ERROR', "Please verify that you have reviewed and cross verified the above details")
    //         }

    //     }

    // }

    // console.log("scrap descript", departmentList)

    const downloadImage = async (imageUrl) => {
        try {
            // Fetch the image data
            const response = await fetch(imageUrl);
            const blob = await response.blob();
            // Create a temporary URL for the Blob
            const blobUrl = URL.createObjectURL(blob);
            // Create a link element
            const link = document.createElement('a');
            // Set the link's href to the Blob URL
            link.href = blobUrl;
            // Add the download attribute and specify the desired filename
            link.download = 'preview_image';
            // Append the link to the document body
            document.body.appendChild(link);
            // Trigger a click event on the link
            link.click();
            // Remove the link and revoke the Blob URL
            document.body.removeChild(link);
            URL.revokeObjectURL(blobUrl);
        } catch (error) {
            console.error('Error downloading image:', error);
        }
    }

    return (
        <ThemeProvider theme={defaultTheme}>
            {loadingBinCode || loadingScrapRequestView || loadingDepartmentList || loadingScrapRequest || loadingScrapRequestView ? <Loading loading={true} /> : null}
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >

                    <Typography component="h1" variant="h5" className='scrap_header'>
                        {mode === "view" ? "Request Description" : "Store Record"}
                    </Typography>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Box
                            sx={{
                                my: 2,
                                mx: 4,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center'
                            }}
                        >
                            <Box key={`FieldStatic`} style={{ width: "100%" }}>
                                <Grid style={{ position: "sticky", top: "65px", backgroundColor: "white", zIndex: "999" }} container spacing={2}>
                                    <Grid item md={6} lg={6} xs={12} id="request_number" >
                                        <p>Request Number  <b> : {state?.temp_scrap_deposit_id || ""}</b></p>
                                    </Grid>
                                    <Grid item md={6} lg={6} xs={12} id="request_date" >
                                        <p>Request Date  <b> : {state?.created_on || ""}</b></p>
                                    </Grid>
                                    <Grid item md={6} lg={6} xs={12} id="company_name" >
                                        <p>Company Name  <b> : {state?.company_name || ""}</b></p>
                                        <p>User Remarks <b>: {state?.remarks}</b></p>
                                        {/* <Input
                            fullWidth={true}
                            label="Company"
                            type="text"
                            disabled={true}
                            value={state?.company_name || ""}
                        /> */}
                                        {/* <Input
                            fullWidth={true}
                            multiline={true}
                            minRows={2}
                            label="Comments"
                            type="text"
                            autoComplete='on'
                        /> */}

                                    </Grid>
                                    <Grid item md={6} lg={6} xs={12} >
                                        <p>Department <b>: {departmentList?.filter((value, index) => value.value === state?.department)?.[0]?.label || ""}</b></p>
                                        {/* <Input
                            fullWidth={true}
                            label="Department"
                            type="text"
                            disabled={true}
                            value={departmentList?.[state?.department -1]?.label || ""}
                        /> */}
                                        {/* <Input
                            fullWidth={true}
                            multiline={true}
                            minRows={2}
                            label="Comments"
                            type="text"
                            autoComplete='on' */}
                                    </Grid>
                                </Grid>
                                <hr style={{ marginTop: '-15px' }} />
                                <Grid container spacing={2} >

                                    {state?.material_details.map((
                                        material, index) => (<Grid item md={6} lg={6} xl={6} xs={12} >
                                            <Grid component={Paper} elevation={3} sx={{ padding: "20px" }}>
                                                <div>
                                                    <p><strong>Material {index + 1}</strong></p>
                                                    <Grid item md={8} lg={8} xs={8} >
                                                        <p>Material Code <b>: {material.material_code}</b></p>
                                                        {/* <Input
                            fullWidth={true}
                            label="Material Code"
                            type="text"
                            disabled={true}
                            value={material.material_code}
                        /> */}
                                                    </Grid>
                                                    <Grid item md={8} lg={8} xs={8} >
                                                        <p>Material Group <b>: {material.material_group}</b></p>
                                                        {/* <Input
                            fullWidth={true}
                            label="Material Group"
                            type="text"
                            disabled={true}
                            value={material.material_group}
                        /> */}
                                                    </Grid>
                                                    <Grid item md={8} lg={8} xs={8} >
                                                        <p>Material Description <b>: {material.material_description}</b></p>
                                                        {/* <Input
                            fullWidth={true}
                            label="Material Description"
                            type="text"
                            disabled={true}
                            value={material.material_description}
                        /> */}
                                                    </Grid>
                                                    <Grid item md={8} lg={8} xs={8} >
                                                        <p>Unit<b>: {material.unit}</b></p>
                                                        {/* <Input
                            fullWidth={true}
                            label="Unit"
                            type="text"
                            disabled={true}
                            value={"TONS"}
                        /> */}
                                                    </Grid>
                                                    <Grid item md={8} lg={8} xs={8} >
                                                        <p>Quantity <b>: {material.quantity}</b></p>
                                                        {/* <Input
                            fullWidth={true}
                            label="Quantity"
                            type="text"
                            disabled={true}
                            value={material.quantity}
                        /> */}
                                                    </Grid>
                                                    <Grid item md={8} lg={8} xs={8} >
                                                        <p>Short Text <b>: {material.comments}</b></p>
                                                        {/* <Input
                            fullWidth={true}
                            multiline={true}
                            minRows={2}
                            label="Short Text"
                            type="text"
                            autoComplete='on'
                            disabled={true}
                            value={material.comments}
                        /> */}
                                                    </Grid>

                                                    {/* </Grid> */}
                                                    {material.image_url ? <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
                                                        Image Preview <b>:</b>
                                                        <div style={{ position: "relative" }}>

                                                            <img className="previewImg"
                                                                onClick={() => {
                                                                    ImageRef.current.handleClickOpen(material?.image_url + "?" + Math.random());
                                                                }}
                                                                src={material?.image_url + "?" + Math.random()} />
                                                            {/* <div className="imageRemove">X</div> */}
                                                            {/* <MyButton label={"Uploaded Image"} onClick={()=>{
                            console.log(material)
                            window.open(material?.image_url, '_blank').focus()
                        }}/> */}
                                                        </div>

                                                        <b>
                                                            <img src={DownloadIcon}
                                                                onClick={() => {
                                                                    downloadImage(material?.image_url + "?" + Math.random())
                                                                }}
                                                                style={{ height: "20px", width: "20px", cursor: "pointer" }}
                                                            />
                                                        </b>

                                                    </div>
                                                        : ""}
                                                </div>
                                                <br />
                                                <Grid lg={12} sm={12} xl={12}>
                                                    {/* <InputLabel htmlFor="outlined-adornment-amount">Amount</InputLabel> */}
                                                    <TextField
                                                        id="outlined-adornment-amount"
                                                        InputProps={{ endAdornment: <InputAdornment position="end">{material.unit}</InputAdornment> }}
                                                        label="Accepted Quantity*"
                                                        style={{ width: '100%', marginBottom: "10px" }}
                                                        defaultValue={""}
                                                        type={"text"}
                                                        disabled={location.state?.storeApproved}

                                                        // value={getValues(`material_details.${index}.store_quantity_accepted`)?getValues(`material_details.${index}.store_quantity_accepted`):""}
                                                        {...register(`material_details.${index}.store_quantity_accepted`, {
                                                            required: { value: true, message: "Accepted quantity is required" },
                                                            max: { value: material.quantity, message: `Maximum Quantity is ${material.quantity}` },
                                                            min: { value: 0, message: `Minimum Quantity is 0` },
                                                            validate: (value) => {
                                                                if (parseFloat(value) > material.quantity) {
                                                                    return "Accepted quantity cannot be greater than requested quantity"
                                                                }
                                                            },
                                                            onChange: (e) => {
                                                                // debugger
                                                                clearErrors(`material_details[${index}].store_quantity_accepted`);
                                                                if (e.target.value < 0) {
                                                                    setError(`material_details[${index}].store_quantity_accepted`, {
                                                                        type: 'manual',
                                                                        message: 'Accepted Quantity must be positive.',
                                                                    });
                                                                }
                                                                if (e.target.value > material.quantity) {
                                                                    setError(`material_details[${index}].store_quantity_accepted`, {
                                                                        type: 'manual',
                                                                        message: 'Accepted Quantity should not be greater than available quantity.',
                                                                    });
                                                                }
                                                                // let regex = new RegExp(/^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$/);

                                                                // if (regex.test(e.target.value) || e.target.value.length === 0) {
                                                                setValue(`material_details.${index}.store_quantity_accepted`, (e.target.value))
                                                                setValue(`material_details.${index}.store_quantity_variation`, parseFloat(material.quantity) - parseFloat(e.target.value ? e.target.value : 0))
                                                                setToggle(!toggle)
                                                                // } else {
                                                                //     let str = e.target.value;
                                                                //     str = str.substring(0, str.length - 1);
                                                                //     setValue(`material_details.${index}.store_quantity_accepted`, (str));
                                                                // }
                                                            }
                                                        })}

                                                        error={errors.material_details?.[index]?.store_quantity_accepted ?
                                                            true : false
                                                        }
                                                        errormessage={errors.material_details?.[index]?.store_quantity_accepted?.message ? errors.material_details?.[index]?.store_quantity_accepted?.message : saveValidation?.current?.errormsg ? saveValidation.current.errormsg : ""}
                                                    />
                                                    <Typography variant="subtitle1" color="error" >
                                                        {errors.material_details?.[index]?.store_quantity_accepted?.message ? errors.material_details?.[index]?.store_quantity_accepted?.message : ""}
                                                    </Typography>
                                                    {/* <Input isQuantity={true} required={true} label={"Accepted Quantity"} /> */}
                                                    <p {...register(`material_details.${index}.store_quantity_variation`, { required: { value: true, message: "Accepted quantity is required" } })}>Variation in quantity <b>{getValues(`material_details.${index}.store_quantity_variation`) + " " + `${material.unit}`}</b></p>
                                                </Grid>
                                                <Grid lg={12} sm={12} xl={12}>
                                                    <MySelect
                                                        required={true}
                                                        {...register(`material_details.${index}.bincode`, {
                                                            required: { value: true, message: "Location Bin Code is required" },
                                                        })}
                                                        // {...register(`department`,  {required:{value:true, message:"Please select a department"}})}   
                                                        label={'Location Bin Code*'}
                                                        menuItems={scrapBinCodes}

                                                        selectors={{
                                                            label: "bincode",
                                                            value: "id"
                                                        }}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.bincode`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.bincode`) ?? ""}
                                                        error={errors.material_details?.[index]?.bincode ? true : false}
                                                        errormessage={errors.material_details?.[index]?.bincode?.message}
                                                    // value={getValues(`department`) ? getValues(`department`) : ""}
                                                    // error={errors.department ? true : false}
                                                    // errormessage={errors.department?.message}
                                                    />
                                                    {/* <Input required={true} label={"Location (Bin Code)"}
                            {...register(`material_details.${index}.bincode`,  {required:{value:true, message:"Location Bin Code is required"},
                            }) }
                            onChange={(e)=>{
                                setValue(`material_details.${index}.bincode`, e.target.value)
                                setToggle(!toggle)
                            }}
                            value={getValues(`material_details.${index}.bincode`)??""}
                            error={errors.material_details?.[index]?.bincode ? true : false}
                            errormessage={errors.material_details?.[index]?.bincode?.message}
                            /> */}
                                                </Grid>
                                                <Grid lg={12} sm={12} xl={12} style={{ marginBottom: "10px", marginTop: "10px" }}>
                                                    <label>Weighment Required<span className='text-danger'>*</span></label>
                                                    <span style={{ marginLeft: "10px" }}><input checked={material.store_weighment_required ? true : false} name={`YES${index}`} id={`YES${index}`} value={true} type={"radio"}
                                                        {...register(`material_details.${index}.store_weighment_required`, { required: { value: true, message: "Accepted quantity is required" } })}
                                                        onClick={() => {
                                                            // debugger
                                                            let newList = state.material_details
                                                            newList[index].store_weighment_required = true
                                                            setValue(`material_details.${index}.store_weighment_required`, true)
                                                            console.log(getValues(`material_details.${index}`))
                                                            setState({ ...state, material_details: [...newList] })
                                                        }} /> <label htmlFor="YES"> Yes</label>
                                                    </span>
                                                    <span style={{ marginLeft: "10px" }}><input checked={!material.store_weighment_required ? true : false} name={`NO${index}`} id={`NO${index}`} value={false} type={"radio"}
                                                        {...register(`material_details.${index}.store_weighment_required`, { required: { value: true, message: "Accepted quantity is required" } })}
                                                        onClick={() => {
                                                            // debugger
                                                            let newList = state.material_details
                                                            newList[index].store_weighment_required = false
                                                            unregister(`material_details.${index}.store_weighment_slip`)
                                                            setValue(`material_details.${index}.store_weighment_required`, false)
                                                            console.log(getValues(`material_details.${index}`))
                                                            setState({ ...state, material_details: [...newList] })
                                                        }} /> <label htmlFor="NO"> No</label></span>
                                                </Grid>
                                                {material.store_weighment_required ? <Grid lg={12} sm={12} xl={12}>
                                                    <Input label={"Weighment Slip No*"} {...register(`material_details.${index}.store_weighment_slip`, {
                                                        required: { value: true, message: "Weighment slip no. is required" },
                                                        onChange: (e) => {
                                                            setValue(`material_details.${index}.store_weighment_slip`, e.target.value)
                                                            setToggle(!toggle)
                                                        }
                                                    })}
                                                        type={"number"}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.store_weighment_slip`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.store_weighment_slip`) ?? ""}
                                                        error={errors.material_details?.[index]?.store_weighment_slip ? true : false}
                                                        errormessage={errors.material_details?.[index]?.store_weighment_slip?.message}
                                                    />
                                                </Grid> : null
                                                }
                                                <Grid lg={12} sm={12} xl={12}>
                                                    <MySelect
                                                        required={true}
                                                        {...register(`material_details.${index}.store_weighment_category`, { required: { value: true, message: "Weighment category is required" } })}
                                                        // {...register(`department`,  {required:{value:true, message:"Please select a department"}})}   
                                                        label={'Category*'}
                                                        menuItems={scrapCategories}

                                                        selectors={{
                                                            label: "category",
                                                            value: "id"
                                                        }}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.store_weighment_category`, e.target.value);
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.store_weighment_category`) ?? ""}
                                                        error={errors.material_details?.[index]?.store_weighment_category ? true : false}
                                                        errormessage={errors.material_details?.[index]?.store_weighment_category?.message}
                                                    // value={getValues(`department`) ? getValues(`department`) : ""}
                                                    // error={errors.department ? true : false}
                                                    // errormessage={errors.department?.message}
                                                    />
                                                    {/* <Input label={"Category"} /> */}
                                                </Grid>
                                                <Grid lg={12} sm={12} xl={12} style={{ marginTop: "10px" }}>
                                                    <Input label={"Remarks*"}
                                                        isRequired={true}
                                                        {...register(`material_details.${index}.store_remarks`, { required: { value: true, message: "Remarks is required" } })}
                                                        onChange={(e) => {
                                                            setValue(`material_details.${index}.store_remarks`, e.target.value)
                                                            setToggle(!toggle)
                                                        }}
                                                        value={getValues(`material_details.${index}.store_remarks`) ?? ""}
                                                        error={errors.material_details?.[index]?.store_remarks ? true : false}
                                                        errormessage={errors.material_details?.[index]?.store_remarks?.message}
                                                    />
                                                </Grid>
                                            </Grid>
                                        </Grid>))}

                                </Grid>
                            </Box>
                        </Box>
                        <Grid lg={12} style={{ display: "flex", justifyContent: "center", gap: "20px" }}>
                            <MyButton type="button" onClick={saveInDraft} label={"SAVE"} style={{ backgroundColor: CONSTANTS.COLORS.BLUE }} />
                            <MyButton type="submit" label={"Proceed"} onClick={() => actionRef.current = "PROCEED"} />
                        </Grid>
                    </form>
                    <DevTool control={control} />
                </Grid>
            </Grid>

            <Suspense fallback={<Loading />}>
                <ImageDialog
                    ref={ImageRef}
                ></ImageDialog>
            </Suspense>


        </ThemeProvider>
    )
}

export default ScrapDepositStoreApproval