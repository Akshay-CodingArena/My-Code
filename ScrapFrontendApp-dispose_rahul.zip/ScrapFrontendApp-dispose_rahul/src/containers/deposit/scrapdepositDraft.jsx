import { useEffect, useRef, useState } from "react"
import { deleteDraftScrapRequest, departmentMasterList, dumpRequest, requestScrapDrafts, viewScrapRequest } from "../../store/slices/list"
import { useDispatch } from "react-redux"
import Datatable from "../../components/Datatable"
import moment from "moment"
import { useAppSelector } from "../../store/hooks"
import { CONSTANTS } from "../../constants/constants"
import MyButton, { DeleteButton, EditButton } from "../../components/button"
import { ref } from "yup"
import useLocalStorage from "../../utils/localStorage"
import { PATH } from "../../paths/path"
import { useNavigate } from "react-router"
import { Container, Grid } from "@mui/material"
import { viewProfile } from "../../store/slices/users"
import DeleteIcon from "../../assets/images/icons/delete_icon.png"
import EditIcon from "../../assets/images/icons/edit.png"
import Pagination from "../../components/pagination"

const ScrapDepositDraftList = () => {
    const dispatch = useDispatch()
    const actionTaken = useRef(false)
    const navigate = useNavigate()
    const requestEdited = useRef("")
    const [list, setList] = useState([])
    let { departmentList, scrapRequestView } = useAppSelector(state => state.list);
    let [page, setPage] = useState(1);
    let [totalCount, setTotalCount] = useState(0);
    // const list = [{
    //     id:12
    // },
    // {
    //     id:12
    // }]

    const OFFSET = 10;

    const getDraftsList = async (page) => {
        let data = useLocalStorage.getItem("userData");
        let result = await dispatch(requestScrapDrafts({
            user_id: data.id,
            page_number: page - 1,
            offset: OFFSET
        }))
        let temp = result.payload.data.data.getListData;
        
        const final = temp?.map((row) => {
            let department_no = departmentList.filter((value, index) => value.value === row.department);
            return {
                request_no: row.requestNo,
                department_no: department_no.length ? department_no[0].label : "N/A",
                company_name: row.company_name,
                created_on: moment(row['created_on']).format('DD/MM/YYYY'),
                permanent_deposit_id: row.permanent_deposit_id
            }
        })

        // moment(row['created_on']).format('DD/MM/YYYY')

        setList(final ? final : [])
        setTotalCount(result.payload.data.data.scrap_request_count)
        setPage(page);
    }

    const getDepartmentList = async () => {
        let responseData = await dispatch(departmentMasterList({}));
        if (responseData?.payload?.data?.status === 200) {
            // getDraftsList()

        } else {
            //  showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : "Some Error Occurred.")
        }
    }

    useEffect(() => {
        debugger
        getDepartmentList()
    }, [])

    useEffect(() => {
        if (departmentList.length) {
            getDraftsList(page)
        }
    }, [departmentList])

    useEffect(() => {
        console.log("Scrap Request is", scrapRequestView)
        if (actionTaken.current) {
            console.log("Scrap Request is captured", scrapRequestView)
            useLocalStorage.setItem("scrapRequest", JSON.stringify(scrapRequestView[0]))
            actionTaken.current = false
            let permanent_id = requestEdited.current
            console.log("id permanent", permanent_id)
            navigate(PATH.PRIVATE.SCRAP_DEPOSIT, { state: { isPermanent: permanent_id ? 1 : 0, permanent_id } })
        }
    }, [scrapRequestView])

    const TableIcons = ({ rowData }) => {
        console.log("rowData is ", rowData)
        const data = {
            scrap_id: rowData.request_no,
            isPermanent: 0
        }
        // const handleOpenConfirmDialog = () => {
        //     dataRef.current = {
        //         scrapData: rowData.row
        //     };
        //     confirmTaskRef.current.handleClickOpen()
        // }

        return (
            <>
                <div style={{ display: "flex", gap: "15px" }}>
                    <EditButton
                        onClick={() => {
                            dispatch(viewScrapRequest(data))
                            actionTaken.current = true
                            requestEdited.current = rowData.permanent_deposit_id
                        }}
                    />
                    <DeleteButton
                        label={'Delete'}
                        onClick={async () => {
                            const resp = await dispatch(deleteDraftScrapRequest({ scrap_id: rowData.request_no }));
                            getDraftsList(1)
                        }}
                    />
                </div>

            </>
        )
    }


    const columns = [
        {
            name: "Request No.",
            selector: "request_no",
            style: {
                minHeight: "70px"
            },
            wrap: true,
        }, {
            name: "Created Date",
            selector: "created_on",
            style: {
                minHeight: "70px"
            },
            wrap: true,
        },
        {
            name: "Company Name",
            selector: "company_name",
            style: {
                minHeight: "70px"
            },
            wrap: true,
            cell: (row) => {
                return row['company_name'] ? row['company_name'] : "N/A"
            }
        },
        {
            name: "Department",
            selector: "department_no",
            style: {
                minHeight: "70px"
            },
            wrap: true,
            cell: (row) => {
                return row['department_no'] ? row['department_no'] : "N/A"
            }
        },
        {
            name: "Action",
            selector: "action",
            style: {
                minHeight: "70px"
            },
            wrap: true,
            cell: (row) => {
                return <TableIcons rowData={row} />
            }
        }
    ]

    const handleCreateNew = () => {
        localStorage.removeItem("scrapRequest")
        if (scrapRequestView.length) {
            // window.location.href = window.location.origin +PATH.PRIVATE.SCRAP_DEPOSIT
            dispatch(dumpRequest())
            navigate(PATH.PRIVATE.SCRAP_DEPOSIT)
        } else {
            navigate(PATH.PRIVATE.SCRAP_DEPOSIT)
        }
        // scrapRequestView = []
        // navigate(PATH.PRIVATE.SCRAP_DEPOSIT)
    }


    const handlePageChange = (e, value) => {
        getDraftsList(value)
    }

    return (
        <>
            <Container fixed style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px"
            }}>
                <Grid container style={{
                    minWidth: "95vw",
                }}>
                    <MyButton label={"Create New"} onClick={handleCreateNew} />
                    <Datatable columns={columns} data={list} />

                    <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                        {list.length ? <Pagination
                            page={page}
                            onChange={(event, value) => { handlePageChange(event, value) }}
                            pageCount={Math.ceil(totalCount / OFFSET)}
                        /> : ""}
                    </Grid>
                </Grid>
            </Container>
        </>
    )

}

export default ScrapDepositDraftList