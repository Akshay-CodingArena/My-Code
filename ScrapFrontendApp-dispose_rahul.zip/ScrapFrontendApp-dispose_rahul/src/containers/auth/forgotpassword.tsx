import React, { useEffect, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { forgotPassword } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";

import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { showToast } from '../../components/toast';
import OtpModal from './forgotpasswordmodal';
import useLocalStorage from '../../utils/localStorage';


// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

const Forgotpassword = () => {

    const dispatch = useAppDispatch();
    const { loadingForgotPassword } = useAppSelector(state => state.auth);

    let [open, setOpen] = useState(false);


    const validationSchema = Yup.object().shape({
        email: Yup.string().trim()
            .required('Email is required')
            .email('Email format is invalid')
            .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only')
    });

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset
    } = useForm({
        resolver: yupResolver(validationSchema)
    });


    useEffect(() => {
        useLocalStorage.clear();
    }, []);

    
    const onSubmit = async (data: any) => {
        let formData = {
            email: data.email
        }
        let response = await dispatch(forgotPassword(formData));

        let forgotPasswordData = response?.payload?.data ? response?.payload?.data : {};

        if (forgotPasswordData.status === 200) {
            setOpen(true);
        } else {
            showToast('ERROR', forgotPasswordData.message || 'Some Error Occurred...');
        }
    }

    return (<>
        {loadingForgotPassword ? <Loading loading={true} /> : ""}

        <ThemeProvider theme={defaultTheme}>
            <Grid container component="main" sx={{ minHeight: '100vh', overflowY: "hidden" }}>
                <CssBaseline />
                <Grid
                    className="grey-scale"
                    item
                    xs={false}
                    sm={4}
                    md={8}
                    sx={{
                        backgroundImage: `url(${PlantImage})`,
                        backgroundRepeat: 'no-repeat',
                        backgroundColor: (t) =>
                            t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                    }}
                />
                <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square sx={{ maxHeight: '100vh', overflowY: "scroll" }}>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Box
                            sx={{
                                my: 8,
                                mx: 4,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                            }}
                        >
                            <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                                <LockOutlinedIcon />
                            </Avatar>
                            <Typography component="h1" variant="h5">
                                Forgot Password
                            </Typography>
                            <Box >
                                <Grid container>
                                    <Grid item md={12} lg={12} xs={12}>
                                        <Input
                                            required={true}
                                            fullWidth={true}
                                            autoFocus={true}
                                            {...register('email')}
                                            label="Office Email"
                                            type="text"
                                            autoComplete='on'
                                            error={errors.email ? true : false}
                                            onChange={(e: any) => {
                                                setValue('email', e.target.value);
                                            }}
                                            errormessage={errors.email?.message}
                                        />
                                    </Grid>

                                    <Grid item md={12} lg={12} xs={12}>
                                        <MyButton type="submit" fullWidth={true} label={'Submit'} />
                                    </Grid>

                                    <Grid item xs >
                                        <Link path={PATH.PUBLIC.SIGN_IN} label="Sign in" />
                                    </Grid>

                                    <Grid item xs style={{ display: "flex", justifyContent: "end" }}>
                                        <Link path={PATH.PUBLIC.SIGN_UP} label="Sign up" />
                                    </Grid>
                                </Grid>
                            </Box>
                        </Box>
                    </form>
                </Grid>
            </Grid>

            <OtpModal open={open} setOpen={setOpen} />
        </ThemeProvider>
    </>
    );
}
export default Forgotpassword;