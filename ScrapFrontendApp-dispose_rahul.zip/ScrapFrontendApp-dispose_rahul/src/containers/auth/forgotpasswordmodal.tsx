import * as React from 'react';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import MyOtpInput from '../../components/otpInput';
import { Grid } from '@mui/material';
import Button from '../../components/button';

import { useForm, Controller } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { CONSTANTS } from '../../constants/constants';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import Loading from '../../components/backdrop';
import { forgotPassword, verifyOtp } from '../../store/slices/auth';
import { useNavigate } from "react-router-dom";
import { PATH } from '../../paths/path';
import { showToast } from '../../components/toast';
import CrossImage from "../../assets/images/cross.png";

const OtpModal = (props: any) => {

  let { open, setOpen } = props;

  const dispatch = useAppDispatch();

  const { loadingForgotPassword, forgotPasswordData, loadingVerifyOtp } = useAppSelector(state => state.auth);

  const navigate = useNavigate();

  const handleClose = () => {
    setOpen(false);
  };

  const validationSchema = Yup.object().shape({
    otp: Yup.string()
      .required("This field is required")
      .matches(/^[0-9]+$/, "OTP must be digits only.")
      .min(4, 'Must be exactly 4 digits')
      .max(4, 'Must be exactly 4 digits')
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    control
  }: any = useForm({
    resolver: yupResolver(validationSchema)
  });

  React.useEffect(() => {

    reset({
      otp: ""
    })

  }, [])

  const onSubmit = async (data: any) => {
    ////////////////send encrypted id//////////
    let formData = {
      email: forgotPasswordData.email,
      otp: data.otp
    }
    let response = await dispatch(verifyOtp(formData));

    let verifyOTPData = response?.payload?.data ? response.payload.data : {};

    if (verifyOTPData?.status === 200) {
      showToast('SUCCESS', verifyOTPData.message);
      navigate(`${PATH.PUBLIC.CONFIRM_PASSWORD}?user_email=${forgotPasswordData.email}`)
    } else {
      showToast('ERROR', verifyOTPData.message);
    }
    setOpen(true)
  }


  const resendOtp = async () => {
    setOpen(false);
    let formData = {
      email: forgotPasswordData.email
    }
    let response = await dispatch(forgotPassword(formData));

    let responseData = response?.payload?.data ? response?.payload?.data : {};

    if (responseData.status === 200) {
      showToast('SUCCESS', responseData.message);
      reset({ otp: "" })
      setOpen(true)
    } else {
      showToast('ERROR', forgotPasswordData.message || 'Some Error Occurred...');
    }

  }

  return (
    <div>
      {loadingForgotPassword || loadingVerifyOtp ? <Loading loading={true} /> : ""}

      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
          <img onClick={(e: any) => {
            setOpen(false)
          }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
        </div>

        <DialogTitle id="alert-dialog-title" >
          {'Enter Verification Code'}
        </DialogTitle>

        <form onSubmit={handleSubmit(onSubmit)}>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              <Grid container >
                <Grid item xs={12} md={12} lg={12} style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                  <Controller
                    name="otp"
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      <MyOtpInput
                        onChange={onChange}
                        value={value}
                        error={errors.otp ? true : false}
                        errormessage={errors.otp?.message}
                      />
                    )}
                  />
                </Grid>

                <Grid item xs={12} md={12} lg={12} style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                  <p>If you don't receive a code.<span onClick={resendOtp} style={{ color: CONSTANTS.COLORS.GREEN, cursor: "pointer", textDecoration: "underline" }}>Resend</span></p>
                </Grid>

                <Grid item xs={12} md={12} lg={12}>
                  <Button type="submit" fullWidth={true} label={'Confirm'} />
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
        </form>
      </Dialog>
    </div>
  );
}

export default OtpModal;