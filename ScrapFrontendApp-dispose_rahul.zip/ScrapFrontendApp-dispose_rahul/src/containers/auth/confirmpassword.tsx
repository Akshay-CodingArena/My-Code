import React, { useEffect, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import CssBaseline from '@mui/material/CssBaseline';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { createUser, updatePassword } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

const ConfirmPassword = () => {


    const navigate = useNavigate();

    const [searchParams, setSearchParams] = useSearchParams();


    const dispatch = useAppDispatch();
    const { loading } = useAppSelector(state => state.auth);

    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);


    useEffect(() => {
        console.log(searchParams.get("id"))
    }, [])

    const validationSchema = Yup.object().shape({
        password: Yup.string().trim()
            .required('Password is required')
            .max(20, 'Password must not exceed 20 characters')
            .matches(
                /^.*(?=.{8,})((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/,
                "Password must contain at least 8 characters,one uppercase,one number and one special case character"
            ),
        confirm_password: Yup.string().trim()
            .required('This field is required')
            .oneOf([Yup.ref('password')], 'Passwords must match.'),
    });

    useEffect(() => {
        useLocalStorage.clear();
        reset({
            password: "",
            confirm_password: ""
        })
    }, [])

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset
    } = useForm({
        resolver: yupResolver(validationSchema)
    });

    const onSubmit = async (data: any) => {

        let user_email = searchParams.get("user_email") ? searchParams.get("user_email") : "";

        let formData = {
            email: user_email,
            password: data.password
        }

        let response = await dispatch(updatePassword(formData))

        let updatePasswordData = response?.payload?.data ? response?.payload?.data : {};

        if (updatePasswordData.status === 200) {
            showToast('SUCCESS', updatePasswordData.message);
            navigate(PATH.PUBLIC.SIGN_IN)
        } else {
            showToast('ERROR', updatePasswordData.message || 'Some Error Occurred...');
        }
    }

    return (<>
        {loading ? <Loading loading={loading} /> : ""}

        <ThemeProvider theme={defaultTheme}>
            <Grid container component="main" sx={{ minHeight: '100vh', overflowY: "hidden" }}>
                <CssBaseline />
                <Grid
                    className="grey-scale"
                    item
                    xs={false}
                    sm={4}
                    md={8}
                    sx={{
                        backgroundImage: `url(${PlantImage})`,
                        backgroundRepeat: 'no-repeat',
                        backgroundColor: (t) =>
                            t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                    }}
                />
                <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square sx={{ maxHeight: '100vh', overflowY: "scroll" }}>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Box
                            sx={{
                                my: 8,
                                mx: 4,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                            }}
                        >
                            <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                                <LockOutlinedIcon />
                            </Avatar>
                            <Typography component="h1" variant="h5">
                                Confirm Password
                            </Typography>
                            <Box >
                                <Grid container>
                                    <Grid item md={12} lg={12} xs={12}>
                                        <Input
                                            required={true}
                                            fullWidth={true}
                                            {...register('password')}
                                            label="Password"
                                            autoComplete='off'
                                            error={errors.password ? true : false}
                                            onChange={(e: any) => {
                                                setValue('password', e.target.value);
                                            }}
                                            errormessage={errors.password?.message}
                                            type={showPassword ? "text" : "password"}
                                            isPassword={true}
                                            showPassword={showPassword}
                                            setShowPassword={() => {
                                                setShowPassword(!showPassword)
                                            }} />
                                    </Grid>

                                    <Grid item md={12} lg={12} xs={12}>
                                        <Input
                                            required={true}
                                            fullWidth={true}
                                            {...register('confirm_password')}
                                            label="Confirm Password"
                                            autoComplete='off'
                                            error={errors.confirm_password ? true : false}
                                            onChange={(e: any) => {
                                                setValue('confirm_password', e.target.value);
                                            }}
                                            errormessage={errors.confirm_password?.message}
                                            type={showConfirmPassword ? "text" : "password"}
                                            isPassword={true}
                                            showPassword={showConfirmPassword}
                                            setShowPassword={() => {
                                                setShowConfirmPassword(!showConfirmPassword)
                                            }} />
                                    </Grid>
                                </Grid>

                                <MyButton type="submit" fullWidth={true} label={'Submit'} />


                            </Box>
                        </Box>
                    </form>
                </Grid>
            </Grid>
        </ThemeProvider>
    </>
    );
}
export default ConfirmPassword;