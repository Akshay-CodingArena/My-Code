import React, { useEffect, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { loginUser } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useNavigate } from "react-router-dom";
import { CONSTANTS } from '../../constants/constants';
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';


// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

const SignIn = () => {

  const navigate = useNavigate();

  const dispatch = useAppDispatch();
  const { loadingLoginUser } = useAppSelector(state => state.auth);

  const [showPassword, setShowPassword] = useState(false);


  const validationSchema = Yup.object().shape({
    email: Yup.string().trim()
      .required('Email is required')
      .email('Email format is invalid')
      .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only')
    , password: Yup.string().trim()
      .required('Password is required')
      .max(20, 'Password must not exceed 20 characters')
      .matches(
        /^.*(?=.{8,})((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/,
        "Password must contain at least 8 characters,one uppercase,one number and one special case character"
      )
  });

  useEffect(() => {
    useLocalStorage.clear();
}, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset
  } = useForm({
    resolver: yupResolver(validationSchema)
  });

  const onSubmit = async (data: any) => {
    let formData: any = {
      email: data.email,
      password: data.password
    }
    let response: any = await dispatch(loginUser(formData));

    let loginUserData = response?.payload?.data ? response.payload.data:{};

    if (loginUserData.status === 200) {
      navigate(PATH.PRIVATE.DASHBOARD)
    }
    else {
      showToast('ERROR', loginUserData.message || 'Some Error Occurred...');
    }
  }


  return (<>
    {loadingLoginUser ? <Loading loading={true} /> : ""}

    <ThemeProvider theme={defaultTheme}>
      <Grid container component="main" sx={{ height: '100vh' }}>
        <CssBaseline />
        <Grid
         className="grey-scale"
          item
          xs={false}
          sm={4}
          md={8}
          sx={{
            backgroundImage: `url(${PlantImage})`,
            backgroundRepeat: 'no-repeat',
            backgroundColor: (t) =>
              t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />

        <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square>
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                my: 8,
                mx: 4,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <p style={{fontSize:"21px"}}>Material Management</p>
              <Avatar sx={{ m: 1, bgcolor: 'green' }}>
                <LockOutlinedIcon />
              </Avatar>
              <Typography component="h1" variant="h5">
                Sign in
              </Typography>
              <Box sx={{ mt: 1 }}>
                <Grid container>
                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      autoFocus={true}
                      {...register('email')}
                      label="Office Email"
                      type="text"
                      autoComplete='on'
                      error={errors.email ? true : false}
                      onChange={(e: any) => {
                        setValue('email', e.target.value);
                      }}
                      errormessage={errors.email?.message}
                    />
                  </Grid>

                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      {...register('password')}
                      label="Password"
                      autoComplete='off'
                      error={errors.password ? true : false}
                      onChange={(e: any) => {
                        setValue('password', e.target.value);
                      }}
                      errormessage={errors.password?.message}
                      type={showPassword ? "text" : "password"}
                      isPassword={true}
                      showPassword={showPassword}
                      setShowPassword={() => {
                        setShowPassword(!showPassword)
                      }}
                    />
                  </Grid>
                </Grid>

                <MyButton type="submit" fullWidth={true} label={'Sign In'} />

                <Grid container>
                  <Grid item xs style={{ display: "flex" }}>
                    Are you a new user? <Link path={PATH.PUBLIC.SIGN_UP} label=" Sign up" />
                  </Grid>
                  <Grid item>
                    <Link path={PATH.PUBLIC.FORGOT_PASSWORD} label="Forgot Password?" />
                  </Grid>
                </Grid>
              </Box>
            </Box>
          </form>
        </Grid>
      </Grid>
    </ThemeProvider>
  </>
  );
}
export default SignIn;