import React, { useEffect, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { createUser } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";
import { DevTool } from "@hookform/devtools"

import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import MySelect from '../../components/select';
import { departmentMasterList } from '../../store/slices/list';
// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

const SignUp = () => {

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [toggle, setToggle] = useState(false)

  const { loading } = useAppSelector(state => state.auth);

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);


  const getDepartmentList = async () => {
    let responseData = await dispatch(departmentMasterList({}));
  }

  useEffect(() => {
    useLocalStorage.clear();
    getDepartmentList()
  }, []);




  const validationSchema = Yup.object().shape({
    first_name: Yup.string().required('Name is required'),
    last_name: Yup.string().required('Last Name is required'),
    designation: Yup.string().required('Designation is required'),
    department: Yup.number().required('Department is required'),
    email: Yup.string().trim()
      .required('Email is required')
      .email('Email format is invalid')
      .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only'),
    rm_email: Yup.string().trim()
      .required('Reporting Manager Email is required')
      .email('Email format is invalid')
      .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only'),
    emp_id: Yup.string()
      .required('Employee ID is required.')
      .matches(
        /(?=.*?\d)^\$?(([1-9]\d{0,2}(,\d{3})*)|\d+)?(\.\d{1,2})?$/,
        "Enter a valid Employee ID"
      ),

    password: Yup.string().trim()
      .required('Password is required')
      .max(20, 'Password must not exceed 20 characters')
      .matches(
        /^.*(?=.{8,})((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/,
        "Password must contain at least 8 characters,one uppercase,one number and one special case character"
      ),
    confirm_password: Yup.string().trim()
      .required('This field is required')
      .oneOf([Yup.ref('password')], 'Passwords must match.'),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
    reset,
    control
  } = useForm({
    resolver: yupResolver(validationSchema)
  });


  const { departmentList }: any = useAppSelector(state => state.list)


  const onSubmit = async (data: any) => {
    let formData = {
      first_name: data.first_name,
      last_name: data.last_name,
      designation: data.designation,
      department_id: data.department,
      email: data.email,
      password: data.password,
      employee_id: data.emp_id,
      manager_email: data.rm_email,
      role_id: "1"
    }
    let response = await dispatch(createUser(formData));

    let signupUserData = response?.payload?.data ? response.payload.data : {};

    if (signupUserData.status === 200) {
      showToast('SUCCESS', signupUserData.message);
      navigate(PATH.PUBLIC.SIGN_IN)
    }
    else {
      showToast('ERROR', signupUserData.message || 'Some Error Occurred...');
    }
  }

  return (<>
    {loading ? <Loading loading={loading} /> : ""}

    <ThemeProvider theme={defaultTheme}>
      <Grid container component="main" sx={{ maxHeight: '100vh', overflowY: "hidden" }}>
        <CssBaseline />
        <Grid
          className="grey-scale"
          item
          xs={false}
          sm={4}
          md={8}
          sx={{
            backgroundImage: `url(${PlantImage})`,
            backgroundRepeat: 'no-repeat',
            backgroundColor: (t) =>
              t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square sx={{ maxHeight: '100vh', overflowY: "scroll" }}>
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box
              sx={{
                my: 8,
                mx: 4,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                <LockOutlinedIcon />
              </Avatar>
              <Typography component="h1" variant="h5">
                Sign up
              </Typography>
              <Box >
                <Grid sx={{ marginTop: "10px" }} container spacing={1}>
                  <Grid item md={6} lg={6} xs={6}>
                    <Input
                      required={true}
                      fullWidth={true}
                      autoFocus={true}
                      {...register('first_name')}
                      label="First Name"
                      type="text"
                      autoComplete='on'
                      error={errors.first_name ? true : false}
                      value={getValues('first_name')}
                      onChange={(e: any) => {
                        setValue('first_name', e.target.value.replace(
                          /([^a-z ]+)/gi,
                          ""
                        ))
                        setToggle(!toggle)
                      }}
                      errormessage={errors.first_name?.message}
                    />
                  </Grid>

                  <Grid item md={6} lg={6} xs={6}>
                    <Input
                      required={true}
                      fullWidth={true}
                      autoFocus={true}
                      {...register('last_name')}
                      label="Last Name"
                      type="text"
                      autoComplete='on'
                      error={errors.first_name ? true : false}
                      value={getValues('last_name')}
                      onChange={(e: any) => {
                        setValue('last_name', e.target.value.replace(
                          /([^a-z ]+)/gi,
                          ""
                        ))
                        setToggle(!toggle)
                      }}
                      errormessage={errors.last_name?.message}
                    />
                  </Grid>

                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      autoFocus={true}
                      {...register('designation')}
                      label="Designation"
                      type="text"
                      autoComplete='on'
                      error={errors.designation ? true : false}
                      onChange={(e: any) => {
                        setValue('designation', e.target.value);
                      }}
                      errormessage={errors.designation?.message}
                    />
                  </Grid>

                  <Grid item md={12} lg={12} xs={12}>
                    <MySelect
                      {...register(`department`, { required: { value: true, message: "Please select a department" } })}
                      label={'Department'}
                      menuItems={departmentList || []}
                      onChange={(e: any) => {
                        setValue(`department`, e.target.value);
                      }}
                      value={getValues('department')}
                      error={errors.department ? true : false}
                      errormessage={errors.department?.message}
                    />
                  </Grid>

                  <Grid sx={{ marginTop: "5px" }} item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      autoFocus={true}
                      {...register('email')}
                      label="Office Email"
                      type="text"
                      autoComplete='on'
                      error={errors.email ? true : false}
                      onChange={(e: any) => {
                        setValue('email', e.target.value);
                      }}
                      errormessage={errors.email?.message}
                    />
                  </Grid>


                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      {...register('rm_email')}
                      label="Reporting Manager Office Email"
                      type="text"
                      autoComplete='on'
                      error={errors.rm_email ? true : false}
                      onChange={(e: any) => {
                        setValue('rm_email', e.target.value);
                      }}
                      errormessage={errors.rm_email?.message}
                    />
                  </Grid>


                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      {...register('emp_id')}
                      label="Employee Id"
                      type="text"
                      autoComplete='on'
                      error={errors.emp_id ? true : false}
                      onChange={(e: any) => {
                        setValue('emp_id', e.target.value);
                      }}
                      errormessage={errors.emp_id?.message}
                    />
                  </Grid>

                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      {...register('password')}
                      label="Password"
                      autoComplete='off'
                      error={errors.password ? true : false}
                      onChange={(e: any) => {
                        setValue('password', e.target.value);
                      }}
                      errormessage={errors.password?.message}
                      type={showPassword ? "text" : "password"}
                      isPassword={true}
                      showPassword={showPassword}
                      setShowPassword={() => {
                        setShowPassword(!showPassword)
                      }} />
                  </Grid>

                  <Grid item md={12} lg={12} xs={12}>
                    <Input
                      required={true}
                      fullWidth={true}
                      {...register('confirm_password')}
                      label="Confirm Password"
                      autoComplete='off'
                      error={errors.confirm_password ? true : false}
                      onChange={(e: any) => {
                        setValue('confirm_password', e.target.value);
                      }}
                      errormessage={errors.confirm_password?.message}
                      type={showConfirmPassword ? "text" : "password"}
                      isPassword={true}
                      showPassword={showConfirmPassword}
                      setShowPassword={() => {
                        setShowConfirmPassword(!showConfirmPassword)
                      }} />
                  </Grid>


                </Grid>

                <MyButton type="submit" fullWidth={true} label={'Sign Up'} />

                <Grid container>
                  <Grid item xs style={{ display: "flex" }}>
                    Already a user?<Link path={PATH.PUBLIC.SIGN_IN} label="Sign in" />
                  </Grid>
                  <Grid item>
                    <Link path={PATH.PUBLIC.FORGOT_PASSWORD} label="Forgot Password?" />
                  </Grid>
                </Grid>
              </Box>
            </Box>
          </form>
        </Grid>
        <DevTool control={control} />
      </Grid>
    </ThemeProvider>
  </>
  );
}
export default SignUp;