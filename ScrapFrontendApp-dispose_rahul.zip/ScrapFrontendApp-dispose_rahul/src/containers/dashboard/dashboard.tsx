import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import AdbIcon from "@mui/icons-material/Adb";
import { CONSTANTS } from "../../constants/constants";
import PlantImage from "../../assets/images/rtnpower.svg";
import { redirect, useLocation, useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import useLocalStorage from "../../utils/localStorage";
import { logout } from "../../store/slices/auth";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { Grid } from "@mui/material";
// import { showToast } from "../../toast";
// import BackButton from "../../BackButton";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { CardActionArea, CardActions } from "@mui/material";
import NextIcon from "../../assets/images/icons/next.svg";
const pages = [
  { name: 'Material Deposit', path: PATH.PRIVATE.SCRAP_DEPOSIT_DRAFTS, roles: [1] },
  { name: 'Material Requests', path: PATH.PRIVATE.SCRAP_DEPOSIT_LIST, roles: [1] },
  { name: 'Material Approvals (R.M.)', path: PATH.PRIVATE.SCRAP_LIST, roles: [1] },
  { name: 'Material Approvals (H.O.D/MANAGER)', path: PATH.PRIVATE.SCRAP_LIST_HOD_MANAGER, roles: [3] },
  { name: 'Material Approvals (H.O.D)', path: PATH.PRIVATE.SCRAP_LIST_HOD, roles: [3] },
  { name: 'Material Approvals (S.M.)', path: PATH.PRIVATE.SCRAP_LIST_STORE_MANAGER, roles: [2] },
  { name: 'Material Dispose (S.M.)', path: PATH.PRIVATE.SCRAP_DISPOSE_DRAFT, roles: [2] },
  { name: 'Material Approvals (C&C Head)', path: PATH.PRIVATE.SCRAP_LIST_CNC_HEAD, roles: [4] },
  { name: 'Create Account', path: PATH.PRIVATE.ADMIN_CREATE_USER, roles: [7] },
  { name: 'Scrap Dispose Requests for Approval', path: PATH.PRIVATE.SCRAP_DISPOSE_REQUESTS_FOR_APPROVAL_CNC, roles: [4] },
  { name: 'Physical Dispose Requests for Approval', path: PATH.PRIVATE.PHYSICAL_DISPOSE_REQUESTS_FOR_APPROVAL_CNC, roles: [4] },
  { name: 'Accounts', path: PATH.PRIVATE.ADMIN_USER_LIST, roles: [7] },
  { name: 'Accounts List', path: PATH.PRIVATE.AUDIT_USER_LIST, roles: [6] },
  { name: 'Upload Files', path: PATH.PRIVATE.ADMIN_UPLOAD_FILES, roles: [7] },
  { name: 'Deposit Material Logs', path: PATH.PRIVATE.ADMIN_SCRAP_LIST, roles: [7] },
  { name: 'Provisional Material Movement Requests', path: PATH.PRIVATE.SCRAP_DISPOSE_REQUESTS_LIST, roles: [2] },
  { name: 'Physical Movement (S.M.)', path: PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE, roles: [2] },
  
  { name: "Dispose Requests for Approval", path: PATH.PRIVATE.APPROVE_REJECT_COMMITTEE_MEMBERS, roles: [1, 3, 5] },
  {name: "Material Inventory", path:PATH.PRIVATE.MATERIAL_INVENTORY,  roles:[2, 4 ,6 ,7]},
  {name: "Logs of Material Deposit", path:PATH.PRIVATE.MATERIAL_DEPOSIT_LOGS,  roles:[6]},
  {name: "Logs of Material Dispose", path:PATH.PRIVATE.MATERIAL_DISPOSE_LOGS,  roles:[6]},
  {name: "Logs of Physical Material Movement", path:PATH.PRIVATE.AUDIT_MOVEMENT_LIST,  roles:[6]},
  {name: "Transaction Logs of Material Deposit", path:PATH.PRIVATE.TRANSACTION_DEPOSIT_LOGS,  roles:[6]},
  {name: "Transaction Logs of Material Dispose", path:PATH.PRIVATE.TRANSACTION_DISPOSE_LOGS,  roles:[6]},
  
  { name: 'Bin Code Change (S.M.)', path: PATH.PRIVATE.BINCODE_CHANGE_LIST, roles: [2] },
  { name: 'Category Change (S.M.)', path: PATH.PRIVATE.CATEGORY_CHANGE_LIST, roles: [2] },
  { name: 'Bin Code Requests for Approval', path: PATH.PRIVATE.APPROVE_BINCODE_CHANGE, roles: [4] },
  { name: 'Category Change Requests for Approval', path: PATH.PRIVATE.APPROVE_CATEGORY_CHANGE, roles: [4] },
  {name:"Deposit/Dispose Report",path: PATH.PRIVATE.DEPOSIT_DISPOSE_REPORT,roles:[2,7,6,4]}
];
const settings = [
  { name: "Profile", path: PATH.PRIVATE.UPDATE_PROFILE },
  { name: "User Approval List", path: PATH.PRIVATE.USER_PROFILE_LIST },
  { name: "Logout", path: "" },
];

function ResponsiveAppBar() {
  const settings: any =
    useLocalStorage.getItem("userData").role_id === 7
      ? [{ name: "Logout", path: "" }]
      : [
          { name: "Profile", path: PATH.PRIVATE.UPDATE_PROFILE },
          { name: "User Approval List", path: PATH.PRIVATE.USER_PROFILE_LIST },
          { name: "Logout", path: "" },
        ];

  const dispatch = useAppDispatch();
  const location = useLocation();

  let userData = useLocalStorage.getItem("userData");
  const navigate = useNavigate();
  const [anchorElNav, setAnchorElNav] = React.useState<null | HTMLElement>(
    null
  );
  const [anchorElUser, setAnchorElUser] = React.useState<null | HTMLElement>(
    null
  );

  const handleOpenNavMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  //   const handleCloseUserMenu = async (setting: any) => {
  //     if (!setting.path && setting.name === "Logout") {
  //       let responseData = await dispatch(logout({}));
  //       if (responseData?.payload?.status === 200) {
  //         showToast(
  //           "SUCCESS",
  //           responseData?.payload?.data?.message
  //             ? responseData.payload.data.message
  //             : "Some Error Occurred."
  //         );
  //         navigate(PATH.PUBLIC.SIGN_IN);
  //       } else {
  //         showToast(
  //           "ERROR",
  //           responseData?.payload?.data?.message
  //             ? responseData.payload.data.message
  //             : "Some Error Occurred."
  //         );
  //       }
  //     } else {
  //       switch (setting.name) {
  //         case "Profile":
  //           navigate(PATH.PRIVATE.UPDATE_PROFILE);
  //           break;
  //         case "User Approval List":
  //           navigate(PATH.PRIVATE.USER_PROFILE_LIST);
  //       }
  //     }

  //     setAnchorElUser(null);
  //   };

  const redirect = (page: any) => {
    navigate(page.path);
  };

  return (
    <Box component="section" className="dashboardSection">
      <Container maxWidth="xl">
        <h1>Dashboard</h1>

        {/* <AdbIcon sx={{ display: { xs: 'none', md: 'flex' }, mr: 1 }} /> */}

        {/* <BackButton /> */}
        {/* 
     <Typography
       variant="h6"
       noWrap
       component="a"
       onClick={() => {
         navigate(PATH.PRIVATE.DASHBOARD);
       }}
       sx={{
         mr: 2,
         display: { xs: "flex", md: "flex" },
         fontFamily: "monospace",
         fontWeight: 700,
         letterSpacing: ".3rem",
         color: "inherit",
         textDecoration: "none",
       }}
     >
       <Box
         component="img"
         sx={{ height: 54 }}
         alt="Logo"
         src={PlantImage}
       />
     </Typography> */}

        <Grid container spacing={2} className="dashboard_section">
          {pages.map((page: any) =>
            page?.roles?.indexOf(userData.role_id) > -1 ? (
              <Grid item md={3} lg={3} xs={12}>
                <Card
                  className="dashboard_list"
                  key={page.name}
                  onClick={(e: any) => {
                    redirect(page);
                  }}
                >
                  <CardContent className="TextBox">
                    <Typography
                      gutterBottom
                      variant="h5"
                      component="div"
                      className="navText"
                    >
                      {page.name}
                    </Typography>
                    {/* <Typography variant="body2" color="text.secondary">
                        500
                      </Typography> */}
                  </CardContent>

                  <CardActions className="btnBox">
                    <Button size="small" color="primary">
                      <img src={NextIcon} style={{ width: "30px" }} />
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            ) : (
              ""
            )
          )}
        </Grid>
      </Container>
    </Box>
  );
}
export default ResponsiveAppBar;
