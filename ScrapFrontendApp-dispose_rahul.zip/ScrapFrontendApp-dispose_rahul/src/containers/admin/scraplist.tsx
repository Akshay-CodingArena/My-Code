import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import {
  getScrapDepositList,
  scrapListSheetDownload,
} from "../../store/slices/admin";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import { departmentMasterList } from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton from "../../components/button";

const OFFSET = 5;

const ScrapList = () => {
  const navigate = useNavigate();

  let [page, setPage]: any = useState(1);

  let [ScrapList, setScrapList]: any = useState([]);

  // new Date('1970-01-1')
  let [dateRange, setDateRange]: any = useState([
    dayjs(moment().startOf("month").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [department, setDepartment] = useState();
  let [requestNo, setRequestNo] = useState();

  const { departmentList, loadingDepartmentList } = useAppSelector(
    (state) => state.list
  );
  const { loadingScrapListSheet } = useAppSelector((state) => state.admin);

  const dispatch = useAppDispatch();
  const { loadingScrapList, totalScrapCount, scrapList } = useAppSelector(
    (state) => state.admin
  );

  const getStatus = (status: any) => {
    if (status === "Approved") {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (status === "Rejected") {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    } else {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>
            PENDING
          </p>
        </div>
      );
    }
  };

  const downloadMRN = (url: any) => {
    const pdfUrl = url;
    const link = document.createElement("a");
    link.href = pdfUrl;
    link.target = "_blank";
    link.download = "user_data.pdf";
    link.click();
  };

  const columns: any = [
    {
      name: "Request No.",
      selector: "requestNo",
      wrap: true,
      width: "130px",
      style: {
        minHeight: "100px",
      },
    },
    {
      name: "",
      wrap: true,
      cell: (row: any) => {
        return (
          <div className="text-center">
            <b
              style={{ color: CONSTANTS.COLORS.INFO, cursor: "pointer" }}
              onClick={(e) => {
                navigate(PATH.PRIVATE.SCRAP_DEPOSIT_STORE_REVIEW, {
                  state: {
                    isPermanent: 1,
                    scrapId: row["requestNo"],
                  },
                });
              }}
            >
              View Details
            </b>
          </div>
        );
      },
    },
    {
      name: "Created By",
      wrap: true,
      selector: "user_name",
      width: "200px",
      cell: (row: any) => {
        return <div>{row.user_name ? row.user_name : "N/A"}</div>;
      },
    },
    {
      name: "Creation Date/Time",
      selector: "created_on",
      wrap: true,
      width: "200px",
      cell: (row: any) => {
        return (
          <div>{moment(row["created_on"]).format("DD/MM/YYYY HH:mm:ss")}</div>
        );
      },
    },
    {
      name: "RM Name",
      wrap: true,
      selector: "manager_name",
      cell: (row: any) => {
        return <div>{row.manager_name ? row.manager_name : "N/A"}</div>;
      },
    },
    {
      name: "Status RM",
      selector: "ApprovalFromManager",
      wrap: true,
      width: "110px",
      cell: (row: any) => {
        return getStatus(row["ApprovalFromManager"]);
      },
    },
    {
      name: "Date/Time",
      selector: "UpdatedDateByManager",
      wrap: true,
      width: "200px",
      cell: (row: any) => {
        return (
          <div>
            {moment(row["UpdatedDateByManager"]).format("DD/MM/YYYY HH:mm:ss")}
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "RemarksByManager",
      wrap: true,
    },
    {
      name: "HOD Name",
      selector: "hod_name",
      wrap: true,
      cell: (row: any) => {
        return <div>{row.hod_name ? row.hod_name : "N/A"}</div>;
      },
    },
    {
      name: "Status HOD",
      selector: "ApprovalFromHOD",
      wrap: true,
      width: "110px",
      cell: (row: any) => {
        return getStatus(row["ApprovalFromHOD"]);
      },
    },
    {
      name: "Date/Time",
      selector: "UpdatedDateByHOD",
      wrap: true,
      width: "200px",
      cell: (row: any) => {
        return (
          <div className="text-center">
            {moment(row["UpdatedDateByHOD"]).format("DD/MM/YYYY HH:mm:ss")}
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "RemarksByHOD",
      wrap: true,
    },
    {
      name: "SM Name",
      selector: "store_name",
      wrap: true,
      width: "150px",
      cell: (row: any) => {
        return <div>{row.store_name ? row.store_name : "N/A"}</div>;
      },
    },

    {
      name: "Status SM",
      selector: "ApprovalFromStoreManager",
      wrap: true,
      width: "110px",
      cell: (row: any) => {
        return getStatus(row["ApprovalFromStoreManager"]);
      },
    },
    {
      name: "Date/Time",
      selector: "UpdatedDateByStore",
      wrap: true,
      width: "150px",
      cell: (row: any) => {
        return (
          <div>
            {row["UpdatedDateByStore"]
              ? moment(row["UpdatedDateByStore"]).format("DD/MM/YYYY HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },

    {
      name: "C&C Head Name",
      selector: "cnc_name",
      wrap: true,
      width: "150px",
      cell: (row: any) => {
        return <div>{row.cnc_name ? row.cnc_name : "N/A"}</div>;
      },
    },
    {
      name: "Status C&C Head",
      selector: "ApprovalFromCNCHead",
      width: "110px",
      wrap: true,
      cell: (row: any) => {
        return getStatus(row["ApprovalFromCNCHead"]);
      },
    },
    {
      name: "Date/Time",
      selector: "UpdatedDateByCNCHead",
      wrap: true,
      cell: (row: any) => {
        return (
          <div>
            {row["UpdatedDateByCNCHead"]
              ? moment(row["UpdatedDateByCNCHead"]).format(
                  "DD/MM/YYYY HH:mm:ss"
                )
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "RemarkByCNCHead",
      wrap: true,
    },

    {
      name: "Download MRN",
      wrap: true,
      cell: (row: any) => {
        return (
          <div style={{ textAlign: "center" }}>
            {row["DownloadMRN"] ? (
              <img
                src={DownloadIcon}
                onClick={() => {
                  downloadMRN(row["DownloadMRN"]);
                }}
                alt=""
                style={{
                  height: "25px",
                  width: "25px",
                  border: "1px solid black",
                  marginBottom: "5px",
                  cursor: "pointer",
                }}
              />
            ) : (
              "N/A"
            )}
          </div>
        );
      },
    },
  ];

  const getList = async (page: number) => {
    let formData: any = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }
    if (department) {
      formData["department_params"] = department;
    }

    if (requestNo) {
      formData["scrap_id_params"] = requestNo;
    }

    let response = await dispatch(getScrapDepositList(formData));
    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  const getDepartmentList = async () => {
    let response = await dispatch(departmentMasterList({}));
    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    setScrapList(scrapList);
  }, [scrapList]);

  useEffect(() => {
    getList(page);
    getDepartmentList();
  }, []);

  const handlePageChange = (e: any, value: any) => {
    getList(value);
  };

  const downloadSheet = async () => {
    let formData = {
      department_params: department,
      scrap_id_params: requestNo,
      start_date: moment(dateRange[0]["$d"]).format("YYYY/MM/DD"),
      end_date: moment(dateRange[1]["$d"]).format("YYYY/MM/DD"),
    };

    let response = await dispatch(scrapListSheetDownload(formData));

    let sheetData = response?.payload?.data ? response.payload.data : {};

    if (sheetData.status === 200) {
      const pdfUrl = sheetData.data.file;
      const link = document.createElement("a");
      link.href = pdfUrl;
      link.target = "_blank";
      link.download = "scrap_list_data.pdf";
      link.click();
    } else {
      showToast("ERROR", sheetData.message || "Some Error Occurred...");
    }
  };
  return (
    <React.Fragment>
      {loadingScrapList || loadingDepartmentList || loadingScrapListSheet ? (
        <Loading loading={true} />
      ) : (
        ""
      )}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      >
        <Grid container spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">Logs of Material Deposit</h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue: any) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <MySelect
              label={"Department"}
              menuItems={
                [{ label: "None", value: "" }, ...departmentList] || []
              }
              onChange={(e: any) => {
                setDepartment(e.target.value);
              }}
              value={department}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6} className="mb-3 scrapMarginZero">
            <Input
              label="Request No."
              type="text"
              value={requestNo}
              onChange={(e: any) => {
                setRequestNo(e.target.value);
              }}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "25px" }}
          >
            <MyButton
              label={"Search"}
              type="button"
              onClick={() => getList(1)}
            />
          </Grid>

          <Grid item xs={12} lg={12} sm={12}>
            <Datatable columns={columns} data={ScrapList} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {ScrapList.length ? (
              <Pagination
                page={page}
                onChange={(event: any, value: any) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalScrapCount / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>
    </React.Fragment>
  );
};

export default ScrapList;
