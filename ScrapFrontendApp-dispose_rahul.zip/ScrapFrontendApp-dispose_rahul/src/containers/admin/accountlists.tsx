import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";

/////////////////ICONS///////////////////////////
import MyButton from "../../components/button";
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import { getAccounts, downloadUsersSheet, enableOrDisableUser } from "../../store/slices/admin";
import DownloadIcon from "../../assets/images/images.png";
import Input from "../../components/input";



const OFFSET = 15;

const AccountsList = () => {

    const confirmTaskRef: any = useRef();
    let [page, setPage]: any = useState(1);
    const dataRef: any = useRef();
    let [requestNo, setRequestNo]: any = useState("");


    let [AccountsList, setAccountsList]: any = useState([])

    const dispatch = useAppDispatch();
    const { loadingGetAccounts, accounts, total_accounts, loadingDownloadSheet, loadingEnableOrDisableUser } = useAppSelector(state => state.admin);

    const getList = async (page: number) => {

        let formData = {
            page_number: page - 1,
            offset: OFFSET,
            search_name: requestNo
        }

        let response = await dispatch(getAccounts(formData));
        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {
            setPage(page)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    useEffect(() => {
        setAccountsList(accounts)
    }, [accounts])


    const handlePageChange = (e: any, value: any) => {
        getList(value);
    }

    useEffect(() => {
        getList(page);
    }, [])



    const onConfirm = async () => {
        ///////////confirm///////
        confirmTaskRef.current.handleClose();

        let data = dataRef.current.userData;
        let formData = {
            "is_deleted": data.is_deleted === 0 ? 2 : 0,
            "type": data.role_name.toLowerCase() === "hod" ? "HOD" : "user",
            "id": data.user_id,
            "role_id": data.role_id
        }

        let response = await dispatch(enableOrDisableUser(formData));

        let sheetData = response?.payload?.data ? response.payload.data : {};

        if (sheetData.status === 200) {
            let newData: any = AccountsList.map((value: any) => {
                return value.user_id === data.user_id ?
                    {
                        ...value,
                        "is_deleted": formData.is_deleted
                    } : { ...value }
            })


            setAccountsList([...newData])
            showToast('SUCCESS', sheetData.message);
        }
        else {
            showToast('ERROR', sheetData.message || 'Some Error Occurred...');
        }
    }

    const onDiscard = () => {
        //////////dis card////////
        confirmTaskRef.current.handleClose();
    }




    const columns: any = [

        {
            name: "User Type",
            selector: "role_name",
            wrap: true,
        },

        {
            name: "Name",
            selector: "name",

            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.name ? row.name : "N/A"}
                </div>
            }
        },

        {
            name: "Designation",
            selector: "designation",

            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.designation ? row.designation : "N/A"}
                </div>
            }
        },
        {
            name: "Department",
            selector: "current_department",

            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.current_department ? row.current_department : "N/A"}
                </div>
            }
        },
        {
            name: "Email",
            selector: "email",
            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.email ? row.email : "N/A"}
                </div>
            }

        },
        {
            name: "Employee Id",
            selector: "employee_id",
            wrap: true,
            cell: (row: any) => {
                return <div >
                    {row.employee_id ? row.employee_id : "N/A"}
                </div>
            }
        },
        {
            name: "RM_Email",
            selector: "manager_email",
            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.manager_email ? row.manager_email : "N/A"}
                </div>
            },

        },
        {
            name: "Actions",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center">
                    <MyButton type="button" onClick={() => {
                        EnableOrDisable(row)
                    }} style={{ backgroundColor: row['is_deleted'] === 2 ? CONSTANTS.COLORS.GREEN : CONSTANTS.COLORS.RED }} label={row['is_deleted'] === 2 ? 'Enable' : 'Disable'} />
                </div>
            },
        },

    ]

    const EnableOrDisable = (data: any) => {
        confirmTaskRef.current.handleClickOpen();
        dataRef.current = { userData: { ...data } };
    }

    const downloadSheet = async () => {
        let response = await dispatch(downloadUsersSheet({}));
        let listData = response.payload.data ? response.payload.data : {};


        if (listData.status === 200) {
            const pdfUrl = listData.data.file;
            const link = document.createElement('a');
            link.href = pdfUrl;
            link.target = "_blank";
            link.download = 'user_data.pdf';
            link.click();
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    return <React.Fragment>

        {loadingGetAccounts || loadingDownloadSheet || loadingEnableOrDisableUser ? <Loading loading={true} /> : ""}

        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}>
            <Grid container style={{
                minWidth: "95vw",
            }}>

                <Grid item xs={12} lg={12} sm={12}>
                    <h3 className="text-center pb-3">Accounts List</h3>
                </Grid>


                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end" }}>
                    <b className="mr-3" style={{ marginRight: "5px" }} >Sheet</b>
                    <img src={DownloadIcon}
                        onClick={downloadSheet}
                        alt="" style={{
                            height: "25px",
                            width: "25px",
                            border: "1px solid black",
                            marginBottom: "5px",
                            cursor: "pointer"
                        }} />
                </Grid>
                <Grid item xs={12} lg={3} sm={6} className="mb-3 scrapMarginZero" style={{ marginTop: "-20px" }}>
                    <Input
                        label="Search"
                        type="text"
                        value={requestNo}
                        onChange={(e: any) => {
                            setRequestNo(e.target.value);
                        }}
                        size="small"
                    />
                </Grid>


                <Grid item xs={12} lg={3} sm={6} className="mb-3" style={{ marginLeft: "10px", marginTop: "15px" }}>
                    <MyButton label={'Search'} type="button" onClick={() => getList(1)} />
                </Grid>

                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={AccountsList}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {AccountsList.length ? <Pagination
                        page={page}
                        onChange={(event: any, value: any) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(total_accounts / OFFSET)}
                    /> : ""}
                </Grid>

            </Grid>
        </Container>


        <Suspense fallback={<Loading />}>
            <ConfirmDialog
                ref={confirmTaskRef}
                description={"Are you sure you want to Enable/Disable?"}
                title={""}
                confirm={"Confirm"}
                discard={"Cancel"}
                onConfirm={onConfirm}
                onDiscard={onDiscard}
            ></ConfirmDialog>
        </Suspense>
    </React.Fragment>


}

export default AccountsList;