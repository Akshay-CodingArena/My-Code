import { yupResolver } from "@hookform/resolvers/yup";
import { Grid, Paper } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import * as Yup from 'yup';
import MyButton from "../../../components/button";
import Input from "../../../components/input";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import Loading from "../../../components/backdrop";
import { uploadMaterialCategory } from "../../../store/slices/admin";
import { showToast } from "../../../components/toast";
import RemoveIcon from "../../../assets/images/icons/delete.png";
import { listCategory } from "../../../store/slices/list";
import { Value } from "sass";


const MaterialCatergory = (props: any) => {

    const dispatch = useAppDispatch();
    let [categories, setCategories]: any = useState([]);

    const { loadingMaterialCategory } = useAppSelector(state => state.admin);

    const { loadingCategories } = useAppSelector(state => state.list);

    // ---------------validation schema-----------------
    const validationSchema = Yup.object().shape({

        material: Yup.array().of(
            Yup.object().shape({
                name: Yup.string().required("This field is required"),
            })
        )
    })


    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        control,
        watch,
        getValues
    } = useForm({
        resolver: yupResolver(validationSchema)
    });

    const { fields, append, prepend, remove, swap, move, insert } = useFieldArray({
        control,
        name: "material",
    });

    useEffect(() => {
        append({ name: "" })
    }, []);


    const getCategories = async () => {
        let response = await dispatch(listCategory({}));
        let categoriesData = response.payload.data.data;
        setCategories(categoriesData);
    }

    useEffect(() => {
        getCategories();
    }, []);

    const onSubmit = async (data: any) => {

        let formData = {
            material_category: data.material.map((value: any) => {
                return value.name
            })
        }

        let response = await dispatch(uploadMaterialCategory(formData));

        let sheetData = response?.payload?.data ? response.payload.data : {};

        if (sheetData.status === 200) {
            showToast('SUCCESS', sheetData.message);

            let newCategories: any = [...categories];

            data.material.map((value: any, index: any) => {
                newCategories.push({ category: value.name })
            })
            setCategories([...newCategories]);
            reset({ material: [{ name: "" }] });
        }
        else {
            showToast('ERROR', sheetData.message || 'Some Error Occurred...');
        }
    }

    return <>

        {loadingMaterialCategory || loadingCategories ? <Loading loading={true} /> : ""}

        <form onSubmit={handleSubmit(onSubmit)}>
            <Grid container component="main"
                spacing={1}
                sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    marginTop: "20px",
                    padding: "0 20vw"
                }}>

                <Grid item xs={12} sm={12} md={12} >
                    <p className="display-6 text-center">Material Category Addition</p>
                </Grid>

                <Grid item xs={12} sm={12} md={12} >
                    <h5>Material Categories</h5>
                    <ul className="scrapList">
                        {categories.map((value: any, index: any) => {
                            return <li>{value.category}</li>
                        })}
                    </ul>
                </Grid>



                <Grid item xs={12} sm={12} md={12} style={{ display: "flex", flexDirection: "row-reverse", marginTop: "-20px" }}>
                    <Grid md={1}>
                        <MyButton type="button" onClick={(e: any) => {
                            append({ name: "" })
                        }} fullWidth={true} label={'Add'} />
                    </Grid>
                </Grid>

                {fields.map((field: any, index: number) => (
                    <>
                        <Grid item xs={12} sm={12} md={12} lg={5} spacing={1}>
                            <Controller
                                control={control}
                                name={`material.${index}.name`}
                                render={({ field: any }) => (
                                    <Input
                                        control={control}
                                        fullWidth={true}
                                        {...register(`material.${index}.name`)}
                                        label="Material Category Name"
                                        type="text"
                                        autoComplete='on'
                                        error={errors?.material?.[index]?.name ? true : false}
                                        value={getValues(`material.${index}.name`) ? getValues(`material.${index}.name`) : ""}
                                        onChange={(e: any) => {
                                        
                                            setValue(`material.${index}.name`, e.target.value);
                                        }}
                                        errormessage={errors?.material?.[index]?.name ? errors.material?.[index]?.name?.message : ""}
                                    />)}
                            />
                        </Grid>

                        <Grid lg={1}>
                            {index > 0 ? <img src={RemoveIcon} style={{ marginLeft: "5px", height: "25px", width: "25px", cursor: "pointer",marginTop:"15px" }}
                                onClick={() => {
                                    remove(index);
                                }
                                } /> : ""}
                        </Grid>
                    </>

                ))}





                <Grid container item >
                    <MyButton type="submit" fullWidth={true} label={'Submit'} />
                </Grid>

            </Grid>
        </form>
    </>
}

export default MaterialCatergory;