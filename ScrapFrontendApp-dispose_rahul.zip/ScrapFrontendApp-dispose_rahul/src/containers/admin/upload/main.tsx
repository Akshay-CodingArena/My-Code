import React, { useState } from "react";
import BincodeAddition from "./bincodeaddition";
import classnames from "classnames"
import MaterialCatergory from "./materialcategory";

const Main = () => {

    const [tabNo, setTabNo] = useState(1);

    return <>

        <ul className="nav justify-content-center mt-3">
            <li className="nav-item">
                <a className={classnames("nav-link", tabNo === 1 ? "fw-bold" : "")} aria-current="page" href="javascript:void(0);" onClick={(e) => setTabNo(1)}>Bin Code Addition</a>
            </li>
            <li className="nav-item">
                <a className={classnames("nav-link", tabNo === 2 ? "fw-bold" : "")} href="javascript:void(0);" onClick={(e) => setTabNo(2)}>Material Code Addition</a>
            </li>
            <li className="nav-item">
                <a className={classnames("nav-link", tabNo === 3 ? "fw-bold" : "")} href="javascript:void(0);" onClick={(e) => setTabNo(3)}>Material Category Addition</a>
            </li>
        </ul>


        {
            tabNo === 1 ? <BincodeAddition title="Bin Code Addition" sheet="BINCODE" /> : ""

        }

        {
            tabNo === 2 ? <BincodeAddition title="Material Code Addition" sheet="MATERIALCODE" /> : ""

        }
        
        {
            tabNo === 3 ? <MaterialCatergory /> : ""
        }






    </>
}
export default Main;