import { Grid, Paper } from "@mui/material";
import React, { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import MyButton from "../../../components/button";
import Loading from "../../../components/backdrop";
import Input from "../../../components/input";
import DownloadIcon from "../../../assets/images/images.png";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { showToast } from "../../../components/toast";
import { uploadMaterialCodeSheet, uploadBincodeSheet } from "../../../store/slices/admin";

const BincodeAddition = (props: any) => {
    const [file, setFile]: any = useState({});
    let [error, setError]: any = useState("");
    let [loading, setloading]: any = useState(false);


    const dispatch = useAppDispatch();

    const { loadingBincodeSheet, loadingMaterialcodeSheet } = useAppSelector(state => state.admin);

    const onDrop = useCallback((acceptedFiles: any) => {
        setloading(true)
        // Do something with the files

        // Checking if the file type is allowed or not
        const allowedTypes: any = ["xlsx", "xls"];
      
        if (!allowedTypes.includes(acceptedFiles[0].path.split(".")[1])) {
            setError("Only Excel files are allowed")
            setTimeout(() => {
                setloading(false)
            }, 1500)

        } else {
            setError("");
            setFile(acceptedFiles[0]);
            setTimeout(() => {
                setloading(false)
            }, 1500)
        }
    }, [])
    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop })


    const uploadFile = async () => {


        console.log(file);
    
        if (!Object.keys(file).length) {
            setError("Please select a file");
            return;
        }




        const formData = new FormData()
        formData.append("file",file);

      
      

        let response: any;

        if (props.sheet === "BINCODE") {
            response = await dispatch(uploadBincodeSheet(formData));
        } else {
            response = await dispatch(uploadMaterialCodeSheet(formData));
        }

        let sheetData = response?.payload?.data ? response.payload.data : {};

        if (sheetData.status === 200) {
            showToast('SUCCESS', sheetData.message);
        }
        else {
            showToast('ERROR', sheetData.message || 'Some Error Occurred...');
        }
    }


    const downloadSheet = () => {
        let materialSheet = "https://cust-documents-public.s3.ap-south-1.amazonaws.com/Scrap/sample_sheets/material_sample_sheet%20%281%29.xlsx"
        let binCodeSheet = "https://cust-documents-public.s3.ap-south-1.amazonaws.com/Scrap/sample_sheets/bincode_sample_sheet.xlsx";

        let sheetUrl = props.sheet === "BINCODE" ? binCodeSheet : materialSheet;

        const pdfUrl = sheetUrl;
        const link = document.createElement('a');
        link.href = pdfUrl;
        link.target = "_blank";
        link.download = 'sample_sheet.pdf';
        link.click();
    }

    return (<>

        {loading || loadingBincodeSheet || loadingMaterialcodeSheet ? <Loading loading={true} /> : ""}

        <Grid container component="main" sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
            marginBottom: "10px"
        }}>

            <Grid item xs={12} sm={12} md={12} >
                <p className="display-6 text-center mb-3">{props.title}</p>
            </Grid>



            <Grid item xs={12} sm={6} md={4}>

                <div style={{ display: "flex", justifyContent: "end" }}>

                    <b >Sample Format</b>

                    <img src={DownloadIcon}
                        onClick={downloadSheet}
                        alt="" style={{
                            height: "25px",
                            width: "25px",
                            border: "1px solid black",
                            marginBottom: "5px",
                            cursor: "pointer",
                            float: "right",
                            marginLeft: "5px"
                        }} />
                </div>

                <div
                    style={{

                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        width: "100%",
                        border: "4px dotted green",
                        height: "150px",
                        cursor:"pointer"
                    }}
                    {...getRootProps()}>
                    <input type="file" {...getInputProps()} accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
                    {
                        isDragActive ?
                            <p>Drop the files here ...</p> :
                            <p>Drag 'n' drop a file here, or click to select file<span className="text-danger">(.xls or .xlsx)</span></p>
                    }
                </div>

                <p className="text-success mt-3 text-center">{file.path ? file.path : ""}</p>

                <p className="text-danger mt-3 text-center">{error ? error : ""}</p>


                <MyButton type="button" onClick={uploadFile} fullWidth={true} label={'Submit'} />


            </Grid>
        </Grid>

    </>
    );
}
export default BincodeAddition;