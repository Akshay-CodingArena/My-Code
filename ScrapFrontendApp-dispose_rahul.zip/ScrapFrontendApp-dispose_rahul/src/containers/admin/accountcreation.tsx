import React, { useEffect, useState } from 'react';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import Loading from '../../components/backdrop';
import MySelect from '../../components/select';
import { useForm, Controller } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import MyButton from '../../components/button';
import { useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { departmentMasterList } from '../../store/slices/list';
import { DevTool } from '@hookform/devtools';
import { createUser } from '../../store/slices/admin';
import { CONSTANTS } from '../../constants';




// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

const AccountUpdate = () => {

    const navigate = useNavigate();
    const dispatch = useAppDispatch();

    const { loadingCreateUser } = useAppSelector(state => state.admin);
    const { departmentList, loadingDepartmentList } = useAppSelector(state => state.list)

    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Name is required'),
        department: Yup.number().required('Department is required'),
        role_id: Yup.string().required('This field is required.'),
        designation: Yup.string().required('Designation is required'),
        email: Yup.string().trim()
            .required('Email is required')
            .email('Email format is invalid')
            .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only'),
        rm_email: Yup.string().trim()
            .required('Reporting Manager Email is required')
            .email('Email format is invalid')
            .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only'),
        emp_id: Yup.string()
            .required('Employee ID is required.')
            .matches(
                /(?=.*?\d)^\$?(([1-9]\d{0,2}(,\d{3})*)|\d+)?(\.\d{1,2})?$/,
                "Enter a valid Employee ID"
            ),
    });

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        control,
        getValues
    } = useForm({
        resolver: yupResolver(validationSchema),
    });


    useEffect(() => {
        dispatch(departmentMasterList({}))
    }, [])

    const onSubmit = async (data: any) => {

        let userData = useLocalStorage.getItem("userData");

        let formData =
        {
            "name": data.name,
            "email": data.email,
            "designation": data.designation,
            "employee_id": data.emp_id,
            "manager_email": data.rm_email,
            "role_id": data.role_id,
            "department": data.role_id === "3" ?
                departmentList.filter((t, index) => {
                    return t.value.toString() === data.department.toString()
                })[0].label : data.department.toString()
        }
        debugger
        
        let response = await dispatch(createUser(formData));

        let createUserData = response?.payload?.data ? response.payload.data : {};
        if (createUserData.status === 200) {
            showToast('SUCCESS', "Login ID has been successfully created and password has been sent over email.");
        }

        else {
            showToast('ERROR', createUserData.message || 'Some Error Occurred...');
        }
    }

    return (<>
        {loadingDepartmentList || loadingCreateUser ? <Loading loading={true} /> : ""}

        <Grid container component="main" sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
            marginBottom: "10px"
        }}>

            <Grid item xs={12} sm={6} md={4} component={Paper} elevation={2} square >
                <form onSubmit={handleSubmit(onSubmit)}>
                    <Box
                        sx={{
                            my: 1,
                            mx: 4,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                        }}
                    >
                        <Typography component="h1" variant="h5">
                            Create Account
                        </Typography>
                        <Box >
                            <Grid container>
                                <Grid item md={12} lg={12} xs={12}>
                                    <Controller
                                        control={control}
                                        name={`name`}
                                        render={({ field: any }) => (
                                            <Input
                                                control={control}
                                                fullWidth={true}
                                                autoFocus={true}
                                                label="Name*"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.name ? true : false}
                                                value={getValues('name') ? getValues('name') : ""}
                                                onChange={(e: any) => {
                                                    var regex = new RegExp("^[a-zA-Z ]+$");
                                                    if (e.target.value.length && regex.test(e.target.value)) {
                                                        setValue("name", e.target.value);
                                                    } else if (!e.target.value.trim().length) {
                                                        setValue("name", "");
                                                    }
                                                }}
                                                errormessage={errors.name?.message}
                                            />
                                        )}
                                    />
                                </Grid>


                                <Grid item md={12} lg={12} xs={12} style={{ marginBottom: "10px" }}>
                                    <Controller
                                        control={control}
                                        name={`role_id`}
                                        render={({ field: any }) => (
                                            <MySelect
                                                {...register(`role_id`, { required: { value: true, message: "Please select a department" } })}
                                                label={'Account Creation for*'}
                                                menuItems={CONSTANTS.ADMIN_ACCOUNT_CREATION_FOR}
                                                onChange={(e: any) => {
                                                    setValue(`role_id`, e.target.value);
                                                }}
                                                value={getValues('role_id') ? getValues('role_id') : ""}
                                                error={errors.role_id ? true : false}
                                                errormessage={errors.role_id?.message}
                                            />)} />
                                </Grid>

                                <Grid item md={12} lg={12} xs={12}>
                                    <Controller
                                        control={control}
                                        name={`designation`}
                                        render={({ field: any }) => (
                                            <Input
                                                control={control}
                                                fullWidth={true}
                                                autoFocus={false}
                                                {...register('designation')}
                                                label="Designation*"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.designation ? true : false}
                                                value={getValues('designation') ? getValues('designation') : ""}
                                                onChange={(e: any) => {
                                                    setValue('designation', e.target.value);
                                                }}
                                                errormessage={errors.designation?.message}
                                            />)}
                                    />
                                </Grid>
                                <Grid item md={12} lg={12} xs={12}>
                                    <Controller
                                        control={control}
                                        name={`department`}
                                        render={({ field: any }) => (
                                            <MySelect
                                                {...register(`department`, { required: { value: true, message: "Please select a department" } })}
                                                label={'Department*'}
                                                menuItems={departmentList || []}
                                                onChange={(e: any) => {
                                                    console.log("department changing", e.target.value)
                                                    setValue(`department`, e.target.value);

                                                }}
                                                value={getValues('department') ? getValues('department') : ""}
                                                error={errors.department ? true : false}
                                                errormessage={errors.department?.message}
                                            />)} />
                                </Grid>
                                <Grid sx={{ marginTop: "10px" }} item md={12} lg={12} xs={12}>

                                    <Controller
                                        control={control}
                                        name={`email`}
                                        render={({ field: any }) => (
                                            <Input
                                                fullWidth={true}
                                                autoFocus={false}
                                                label="Office Email*"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.email ? true : false}
                                                errormessage={errors.email?.message}
                                                value={getValues('email') ? getValues('email') : ""}
                                                onChange={(e: any) => {
                                                    setValue('email', e.target.value);
                                                }}

                                            />
                                        )}
                                    />
                                </Grid>


                                <Grid item md={12} lg={12} xs={12}>

                                    <Controller
                                        control={control}
                                        name={`rm_email`}
                                        render={({ field: any }) => (
                                            <Input
                                                fullWidth={true}
                                                autoFocus={false}
                                                label="Reporting Manager Email*"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.rm_email ? true : false}
                                                errormessage={errors.rm_email?.message}
                                                value={getValues('rm_email') ? getValues('rm_email') : ""}
                                                onChange={(e: any) => {
                                                    setValue('rm_email', e.target.value);
                                                }}
                                            />
                                        )}
                                    />




                                </Grid>


                                <Grid item md={12} lg={12} xs={12}>

                                    <Controller
                                        control={control}
                                        name={`emp_id`}
                                        render={({ field: any }) => (
                                            <Input
                                                fullWidth={true}
                                                autoFocus={false}
                                                label="Employee Id*"
                                                type="text"
                                                autoComplete='on'
                                                error={errors.emp_id ? true : false}
                                                errormessage={errors.emp_id?.message}
                                                // disabled={true}
                                                value={getValues('emp_id') ? getValues('emp_id') : ""}
                                                onChange={(e: any) => {
                                                    setValue('emp_id', e.target.value)
                                                }}
                                            />
                                        )}
                                    />
                                </Grid>
                            </Grid>
                            <MyButton type="submit" fullWidth={true} label={'Create Account'} />
                        </Box>
                    </Box>
                </form>

            </Grid>
        </Grid>

    </>
    );
}
export default AccountUpdate;