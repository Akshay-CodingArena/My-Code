import { useState } from "react";
import classnames from "classnames";
import DepositReport from "./depositreport";
import DisposeReport from "./disposereport";

const Main = () => {

    const [tabNo, setTabNo] = useState(1);

    return <>

        <ul className="nav justify-content-center mt-3">
            <li className="nav-item">
                <a className={classnames("nav-link", tabNo === 1 ? "fw-bold" : "")} aria-current="page" href="javascript:void(0);" onClick={(e) => setTabNo(1)}>Deposit</a>
            </li>
            <li className="nav-item">
                <a className={classnames("nav-link", tabNo === 2 ? "fw-bold" : "")} href="javascript:void(0);" onClick={(e) => setTabNo(2)}>Dispose</a>
            </li>
        </ul>


        {
            tabNo === 1 ? <DepositReport/> : null
        }

        {
            tabNo === 2 ? <DisposeReport/> : null 

        }
    </>
}
export default Main;