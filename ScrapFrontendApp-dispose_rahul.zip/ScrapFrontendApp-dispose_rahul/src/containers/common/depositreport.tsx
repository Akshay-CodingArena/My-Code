import { Container, Grid, sliderClasses } from "@mui/material";
import React, { Suspense, useEffect, useRef, useState } from "react";
import MyButton, { ViewButton } from "../../components/button";
import DownloadIcon from "../../assets/images/images.png";
import dayjs, { Dayjs } from 'dayjs';
import Input from "../../components/input";
import DateRange from "../../components/daterange";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { departmentMasterList, listBinCode, listCategory, materialDepositList, materialMasterList } from "../../store/slices/list";
import MultiSelect from "../../components/mutilselect";
import MyDatePicker from "../../components/date";
import MyAutocomplete from "../../components/autocomplete";
import { showToast } from "../../components/toast";
import Loading from "../../components/backdrop";
import MySelect from '../../components/select';
import moment from "moment";
import Pagination from "../../components/pagination";
import Datatable from "../../components/Datatable";
import { CONSTANTS } from "../../constants/constants";
import ImageDialog from "../../components/ImageModal";

const OFFSET = 15;

const DepositReport = (props: any) => {

    const dispatch = useAppDispatch();
    const ImageRef: any = useRef();
    let [dateRange, setDateRange]: any = useState([null, null])
    let [department, setDepartment]: any = useState([]);
    let [requestDate, setRequestDate] = useState([null, null]);
    let [material, setMaterial]: any = useState(null);
    let [bincode, setBincode]: any = useState([]);
    let [category, setCategory] = useState(null);
    let [materialCodesPaste, setMaterialCodePaste]: any = useState('');
    let [binCodesPaste, setBincodesPaste]: any = useState('');
    let [requestsPaste, setRequestsPaste]: any = useState('');


    let [page, setPage]: any = useState(1);

    let [listData, setListData]: any = useState({
        data: [],
        count: 0
    })

    let { loadingMaterialDepositList, loadingBinCode, scrapBinCodes, scrapCategories, loadingCategories, loadingMaterialList, materialList, departmentList, loadingDepartmentList } = useAppSelector(state => state.list);


    const getDepartmentList = async () => {
        let responseData = await dispatch(departmentMasterList({}));
        if (responseData?.payload?.data?.status === 200) {
            let formData = {
                page_number: 0,
                count: 50,
                material_code: ''
            }
            getMaterialList(formData);
            dispatch(listBinCode({}));
            dispatch(listCategory({}));
        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : "Some Error Occurred.")
        }
    }


    const getMaterialList = async (formData: any) => {

        let response = await dispatch(materialMasterList(formData));

        if (response?.payload?.data?.status === 200) {
            // setMaterial({material_code:formData.material_code});
        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }


    const getData = async (page: any) => {

        if (bincode?.length && binCodesPaste.length) {
            showToast('ERROR', 'Please select bincode data from one field only');
            return;
        }


        if (material?.length && materialCodesPaste.length) {
            showToast('ERROR', 'Please select material data from one field only');
            return;
        }

        let formData: any = {
            page_number: page - 1,
            count: OFFSET,
        }
        if (dateRange?.[0]?.['$d'] && dateRange?.[1]?.['$d']) {
            formData['start_date'] = moment(dateRange[0]['$d']).format('YYYY/MM/DD')
            formData['end_date'] = moment(dateRange[1]['$d']).format('YYYY/MM/DD')
        }
        if (requestDate?.[0]?.['$d'] && requestDate?.[1]?.['$d']) {
            formData['requested_start_date'] = moment(requestDate[0]['$d']).format('YYYY/MM/DD')
            formData['requested_end_date'] = moment(requestDate[1]['$d']).format('YYYY/MM/DD')
        }
        if (material) {
            formData['material_code_params'] = [material.material_code];
        }

        if (materialCodesPaste.length) {
            formData['material_code_params'] = materialCodesPaste.split(",").slice(0, materialCodesPaste.split(",").length - 1);
        }

        if (bincode.length) {
            let bincodes: any = []
            for (let i = 0; i < bincode.length; ++i) {
                bincodes.push(bincode[i].value)
            }
            formData['bincode_params'] = bincodes;
        }

        if (binCodesPaste.length) {
            let arr = binCodesPaste.split(",").slice(0, binCodesPaste.split(",").length - 1);
            let tempArr: any = [];
            let Obj = {};

            for (let i = 0; i < arr.length; ++i) {
                let data: any = scrapBinCodes.filter((data: any) => {
                    return arr[i] === data.bincode;
                })

                if (data && tempArr.indexOf(data[0].id) === -1) {
                    tempArr.push(data[0].id)
                }
            }
            formData['bincode_params'] = tempArr;

        }

        if (category) {
            formData['category_params'] = category
        }

        if (department.length) {
            let departments: any = []
            for (let i = 0; i < department.length; ++i) {
                departments.push(department[i].value)
            }
            formData['department_params'] = departments;
        }


        if (requestsPaste.length) {
            let arr = requestsPaste.split(",").slice(0, requestsPaste.split(",").length - 1);
            formData['material_id_params'] = arr;
        }


        let response = await dispatch(materialDepositList(formData));
        let materialData = response?.payload?.data ? response.payload.data : {};

        if (materialData.status === 200) {
            setPage(page);
            setListData({
                count: materialData.data.count ? materialData.data.count : 0,
                data: materialData.data.materialData ? materialData.data.materialData : []
            })
        }
        else {
            showToast(
                "ERROR",
                materialData.message ?
                    materialData.message :
                    "Something went wrong"
            )
        }
    }

    useEffect(() => {
        getDepartmentList();
    }, [])


    useEffect(() => {
        getData(page);
    }, [])

    const clearFilters = async () => {
        setDateRange([null, null]);
        setDepartment([]);
        setRequestDate([null, null]);
        setMaterial(null);
        setBincode([]);
        setCategory(null);
        setMaterialCodePaste('');
        setBincodesPaste('');
        setRequestsPaste('');
        setPage(1);


        let formData: any = {
            page_number: 0,
            count: OFFSET,
        }


        let response = await dispatch(materialDepositList(formData));
        let materialData = response?.payload?.data ? response.payload.data : {};

        if (materialData.status === 200) {
            setListData({
                count: materialData.data.count ? materialData.data.count : 0,
                data: materialData.data.materialData ? materialData.data.materialData : []
            })
        }
        else {
            showToast(
                "ERROR",
                materialData.message ?
                    materialData.message :
                    "Something went wrong"
            )
        }
    }

    const downloadSheet = async () => {

        if (bincode?.length && binCodesPaste.length) {
            showToast('ERROR', 'Please select bincode data from one field only');
            return;
        }

        if (material?.length && materialCodesPaste.length) {
            showToast('ERROR', 'Please select material data from one field only');
            return;
        }

        let formData: any = {
            isDownload: true
        }
        if (dateRange?.[0]?.['$d'] && dateRange?.[1]?.['$d']) {
            formData['start_date'] = moment(dateRange[0]['$d']).format('YYYY/MM/DD')
            formData['end_date'] = moment(dateRange[1]['$d']).format('YYYY/MM/DD')
        }

        if (requestDate?.[0]?.['$d'] && requestDate?.[1]?.['$d']) {
            formData['requested_start_date'] = moment(requestDate[0]['$d']).format('YYYY/MM/DD')
            formData['requested_end_date'] = moment(requestDate[1]['$d']).format('YYYY/MM/DD')
        }

        if (material) {
            formData['material_code_params'] = [material.material_code];
        }

        if (materialCodesPaste.length) {
            formData['material_code_params'] = materialCodesPaste.split(",").slice(0, materialCodesPaste.split(",").length - 1);
        }


        if (bincode.length) {
            let bincodes: any = []
            for (let i = 0; i < bincode.length; ++i) {
                bincodes.push(bincode[i].value)
            }
            formData['bincode_params'] = bincodes;
        }

        if (binCodesPaste.length) {
            let arr = binCodesPaste.split(",").slice(0, binCodesPaste.split(",").length - 1);
            let tempArr: any = [];
            let Obj = {};

            for (let i = 0; i < arr.length; ++i) {
                let data: any = scrapBinCodes.filter((data: any) => {
                    return arr[i] === data.bincode;
                })

                if (data && tempArr.indexOf(data[0].id) === -1) {
                    tempArr.push(data[0].id)
                }
            }
            formData['bincode_params'] = tempArr;

        }


        if (category) {
            formData['category_params'] = category
        }

        if (department.length) {
            let departments: any = []
            for (let i = 0; i < department.length; ++i) {
                departments.push(department[i].value)
            }
            formData['department_params'] = departments;
        }

        let response = await dispatch(materialDepositList(formData));
        let materialData = response?.payload?.data ? response.payload.data : {};

        if (materialData.status === 200) {
            window.open(materialData.data, "_blank")
        }
        else {
            showToast(
                "ERROR",
                materialData.message ?
                    materialData.message :
                    "Something went wrong"
            )
        }
    }

    const handlePageChange = (event: any, page: any) => {
        getData(page);
    }


    const getStatus = (status: any) => {

        if (status === "Approved") {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>APPROVED</p>
            </div>

        }
        else if (status === "Rejected") {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>REJECTED</p>
            </div>
        } else {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>PENDING</p>
            </div>

        }
    }


    const columns: any = [
        {
            name: "S.No.",
            selector: "material_code",
            cell: (row: any,index:any) => {
                return <div className="text-center" >
                    {(page-1)*OFFSET + (index+1)}
                </div>
            }
        },
        {
            name: "Material Code",
            selector: "material_code",
            wrap: true
        },
        {
            name: "Request No.",
            selector: "request_no",
            wrap: true,
            style: {
                minHeight: "70px"
            }
        },
        {
            name: "Request Date|Time",
            selector: "request_no",
            wrap: true,
            cell: (row: any) => {
                return row['created_on'] ?
                    moment(row['created_on']).format('DD/MM/YYYY') + " | " + moment.utc(row['created_on']).format('HH:mm:ss')
                    :
                    "N/A"
            }
        },
        {
            name: "Material Group",
            selector: "material_group",
            wrap: true
        },
        {
            name: "Material Description",
            selector: "material_description",
            wrap: true
        },
        {
            name: "Department",
            selector: "department",
            wrap: true
        },
        {
            name: "Category",
            selector: "category",
            wrap: true
        },
        {
            name: "Request Deposited By",
            selector: "created_by",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['created_by'] ? row['created_by'] : "N/A"}
                </div>
            }
        },
        {
            name: "Requested Quantity",
            selector: "requested_quantity",
            wrap: false,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['requested_quantity'] + " " + row['unit']}
                </div>
            }
        },
        {
            name: "Approved By Manager",
            selector: "requested_quantity",
            minWidth:"250px",
            cell: (row: any) => {
                return <div className="text-center" >
                {row['manager_email']?row['manager_email']:"N/A"}
            </div>
            },
        },
        {
            name: "Approved By HOD",
            selector: "requested_quantity",
            minWidth:"250px",
            cell: (row: any) => {
                return <div className="text-center" >
                {row['hod_email']?row['hod_email']:"N/A"}
            </div>
            }
        },
        {
            name: "HOD Approval Date|Time",
            selector: "requested_quantity",
            wrap: true,
            cell: (row: any) => {
                return row['hod_approval_date'] ?
                    moment(row['hod_approval_date']).format('DD/MM/YYYY') + " | " + moment.utc(row['hod_approval_date']).format('HH:mm:ss')
                    :
                    "N/A"
            }
        },
        {
            name: "Deposit Quantity",
            selector: "deposit_quantity",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['deposit_quantity'] + " " + row['unit']}
                </div>
            }
        },
        {
            name: "Deposit Date|Time",
            selector: "requested_quantity",
            wrap: true,
            cell: (row: any) => {
                return row['store_approval_date'] ?
                    moment(row['store_approval_date']).format('DD/MM/YYYY') + " | " + moment.utc(row['store_approval_date']).format('HH:mm:ss')
                    :
                    "N/A"
            }
        }, {
            name: "Bin Code",
            selector: "bincode",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['bincode'] ? row['bincode'] : "N/A"}
                </div>
            }
        }, {
            name: "Weighment Slip No.",
            selector: "created_by",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['store_weighment_slip'] ? row['store_weighment_slip'] : "N/A"}
                </div>
            }
        }, {
            name: "Image",
            selector: "created_by",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['image_url'] ?
                        <ViewButton label={"View"}
                            style={{ height: "10px", width: "10px" }}
                            onClick={() => {
                                ImageRef.current.handleClickOpen(row['image_url']);
                            }} />
                        : "N/A"}
                </div>
            }
        },
        {
            name: "MRN",
            selector: "mrn_sheet_link",
            wrap: true,
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['mrn_sheet_link'] ?
                        <img src={DownloadIcon}
                            onClick={(e: any) => {
                                window.open(row['mrn_sheet_link'], "_blank")
                            }}
                            alt="" style={{
                                height: "25px",
                                width: "25px",
                                border: "1px solid black",
                                marginBottom: "5px",
                                cursor: "pointer",
                                marginLeft: "5px"
                            }} /> : "N/A"}
                </div>
            }
        }

    ];


    return <React.Fragment>
        {(loadingMaterialDepositList || loadingMaterialList || loadingDepartmentList || loadingBinCode || loadingCategories) ? <Loading loading={true} /> : ""}
        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
        }}><Grid container style={{
            minWidth: "95vw",
        }} spacing={1}>

                <Grid item xs={12} lg={12} sm={12} >
                    <h3 className="text-center pb-3">Deposit Report</h3>
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end" }}>
                    <b>Sheet</b>
                    <img src={DownloadIcon}
                        onClick={downloadSheet}
                        alt="" style={{
                            height: "25px",
                            width: "25px",
                            border: "1px solid black",
                            marginBottom: "5px",
                            cursor: "pointer",
                            marginLeft: "5px"
                        }} />
                </Grid>


                <Grid item xs={12} lg={4} sm={6} >
                    <DateRange
                        onChange={(newValue: any) => {
                            setDateRange(newValue);
                        }}
                        label={'Deposit Date Range'}
                        value={dateRange}
                    />
                </Grid>

                <Grid item xs={12} lg={4} sm={6} className="mb-3" style={{ marginTop: "35px" }}>
                    <MultiSelect
                        options={departmentList}
                        onChange={(e: any, value: any) => {
                            setDepartment(value)
                        }}
                        value={department}
                        label={'Department'}
                        placeholder={'Select department'}
                    />
                </Grid>

                <Grid item xs={12} lg={4} sm={6} >
                    <DateRange
                        onChange={(newValue: any) => {
                            setRequestDate(newValue);
                        }}
                        label={'Requested Date Range'}
                        value={requestDate}
                    />
                </Grid>


                <Grid item xs={12} lg={4} sm={6} className="mb-3">
                    <MyAutocomplete
                        options={materialList.length ? materialList.map((value, index) => {
                            return { label: value.material_code, ...value }
                        }) : []}
                        label='Material Code'
                        onChange={(e: any, value: any) => {
                            setMaterial(value)
                        }}
                        onInputChange={(e: any, value: any) => {
                            let formData = {
                                page_number: 0,
                                count: 50,
                                material_code: value
                            }
                            getMaterialList(formData)
                        }}
                        value={material}
                        disableClearable={false}
                    />
                </Grid>
                <Grid item xs={12} lg={4} sm={6}>

                    <MultiSelect
                        options={scrapBinCodes.map((data: any) => {
                            return { label: data.bincode, value: data.id }
                        })}
                        onChange={(e: any, value: any) => {

                            setBincode(value)
                        }}
                        value={bincode}
                        label={'Bincode'}
                        placeholder={'Select Bincode'}
                    />
                </Grid>


                <Grid item xs={12} lg={4} sm={6}>
                    <MySelect
                        label={'Categories'}
                        menuItems={[{ label: "None", value: null }, ...scrapCategories.map((data: any) => {
                            return { value: data.id, label: data.category }
                        })]}
                        onChange={(e: any) => {
                            setCategory(e.target.value)
                        }}
                        value={category}
                    />
                </Grid>



                <Grid item xs={12} lg={12} sm={12}>
                    <h6><span className="text-danger">*</span>Use Paste Options(Copy and Paste from excel sheet)</h6>
                </Grid>

                <Grid item xs={12} lg={4} sm={12}>
                    <Input

                        multiline={true}
                        fullWidth={true}
                        label="Material Codes"
                        type="text"
                        value={materialCodesPaste}
                        autoComplete='on'
                        onPaste={(e: any) => {
                            // Access clipboard data
                            const clipboardData = e.clipboardData;

                            // Get plain text data from clipboard
                            const pastedText = clipboardData.getData('text');
                            console.log(pastedText.split('\r\n'));

                            setMaterialCodePaste(materialCodesPaste + "" + pastedText.split('\r\n').join(","))
                        }}

                        minRows={2}
                    />


                </Grid>




                <Grid item xs={12} lg={4} sm={12}>
                    <Input
                        multiline={true}
                        fullWidth={true}
                        label="Bincodes Codes"
                        type="text"
                        value={binCodesPaste}
                        autoComplete='on'
                        onPaste={(e: any) => {
                            // Access clipboard data
                            const clipboardData = e.clipboardData;

                            // Get plain text data from clipboard
                            const pastedText: any = clipboardData.getData('text');

                            setBincodesPaste(binCodesPaste + "" + pastedText.split("\r\n").join(","))
                        }}

                        minRows={2}
                    />
                </Grid>

                <Grid item xs={12} lg={4} sm={12}>
                    <Input
                        multiline={true}
                        fullWidth={true}
                        label="Request Numbers"
                        type="text"
                        value={requestsPaste}
                        autoComplete='on'
                        onPaste={(e: any) => {
                            // Access clipboard data
                            const clipboardData = e.clipboardData;

                            // Get plain text data from clipboard
                            const pastedText: any = clipboardData.getData('text');

                            setRequestsPaste(requestsPaste + "" + pastedText.split("\r\n").join(","))
                        }}

                        minRows={2}
                    />
                </Grid>


                <Grid item xs={12} lg={4} sm={12}>
                    <MyButton label={'Clear'} type="button"
                        style={{ backgroundColor: "red", marginTop: "-10px" }}
                        onClick={(e: any) => {
                            setMaterialCodePaste('');
                        }} />
                </Grid>


                <Grid item xs={12} lg={4} sm={12}>
                    <MyButton label={'Clear'} type="button"
                        style={{ backgroundColor: "red", marginTop: "-10px" }}
                        onClick={(e: any) => {
                            setBincodesPaste('');
                        }} />
                </Grid>

                <Grid item xs={12} lg={4} sm={12}>
                    <MyButton label={'Clear'} type="button"
                        style={{ backgroundColor: "red", marginTop: "-10px" }}
                        onClick={(e: any) => {
                            setRequestsPaste('');
                        }} />
                </Grid>



                <Grid item xs={12} lg={12} sm={6} className="mb-3 d-flex justify-content-center" style={{ marginTop: "-20px" }}>
                    <MyButton label={'Search'} type="button"
                        style={{ padding: "10px 30px" }}
                        onClick={(e: any) => {
                            handlePageChange(e, 1)
                        }} />

                    <MyButton label={'Clear Filters'} type="button"
                        style={{ marginLeft: "10px", backgroundColor: "red" }}
                        onClick={clearFilters} />
                </Grid>


                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", flexDirection: "column" }}>
                    <Datatable
                        columns={columns}
                        data={listData.data}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {listData.data.length ? <Pagination
                        page={page}
                        onChange={(event: any, value: any) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(listData.count / OFFSET)}
                    /> : ""}
                </Grid>

            </Grid>
        </Container>


        <Suspense fallback={<Loading />}>
            <ImageDialog
                ref={ImageRef}
            ></ImageDialog>
        </Suspense>

    </React.Fragment>
}
export default DepositReport