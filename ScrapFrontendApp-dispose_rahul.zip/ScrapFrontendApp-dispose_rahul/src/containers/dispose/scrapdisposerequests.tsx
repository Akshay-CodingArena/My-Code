import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom"
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from 'dayjs';
import { departmentMasterList, downloadScrapDisposalList, listBinCode, listCategory } from "../../store/slices/list";
import MySelect from '../../components/select';
import Input from "../../components/input";
import MyButton, { EditButton, ViewButton } from "../../components/button";
import { getScrapDisposeRequestView, getScrapDisposeRequestsList } from "../../store/slices/dispose";

const OFFSET = 5;

const ScrapDisposeRequests = () => {

    const navigate = useNavigate();
    let [page, setPage]: any = useState(1);

    let [disposeRequestsList, setDisposeRequestsList]: any = useState([])
    let [dateRange, setDateRange]: any = useState([
        dayjs(moment().startOf('year').format('YYYY-MM-DD')),
        dayjs(new Date())])
    let [requestNo, setRequestNo] = useState();

    const { loadingScrapDisposeRequestView, loadingScrapDisposeRequestsList, scrapDisposeRequestsList, totalDisposeRequestsCount } = useAppSelector(state => state.dispose);
    const { loadingBinCode, loadingCategories, scrapCategories, scrapBinCodes, loadingScrapDisposalListSheet } = useAppSelector(state => state.list);

    const dispatch = useAppDispatch();


    const getScrapDisposeData = async (id: any) => {

        let formData =
        {
            scrap_disposal_id: id,
            is_permanent: 1,
        }


        let response = await dispatch(getScrapDisposeRequestView(formData));
        let listData = response.payload.data ? response.payload.data : {};


        if (listData.status === 200) {
            let editData = { ...listData.data.disposalDetails[0] };
            editData['committee_members'] = [...editData.committee];
            delete editData['committee'];

            editData['material_details'] = editData['material_details'].map((value: any) => {

                return {
                    ...value,
                    'bincode': scrapBinCodes.filter((item: any, index: any) => item.bincode === value.bincode)[0].id.toString(),
                    'category': scrapCategories.filter((item: any, index: any) => item.category === value.category)[0].id.toString(),
                }
            })

            useLocalStorage.setItem("scrapDisposeRequest", JSON.stringify(editData))
            navigate(PATH.PRIVATE.SCRAP_DISPOSAL_STORE_REQUEST,
                { state: { mode: "edit", isPermanentRequest: true } })
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    const getStatus = (status: any) => {

        if (status === 1) {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>APPROVED</p>
            </div>

        }
        else if (status === 2) {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>REJECTED</p>
            </div>
        } else {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>PENDING</p>
            </div>

        }
    }


    const columns: any = [
        {
            name: "Request No.",
            selector: "id",
            wrap: true,
            width: "120px",
            style: {
                minHeight: "70px"
            }
        },
        {
            name: "View Details",
            wrap: true,

            width: "150px",

            cell: (row: any) => {
                return <ViewButton label={"View"} onClick={() => {
                    navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                        state: {
                            "isPermanent": 1,
                            "scrap_disposal_id": row['id']
                        }
                    })
                }} />

            }
        },
        {
            name: "Edit Details",
            wrap: true,



            cell: (row: any) => {
                return <div className="text-center">
                    <div style={{ cursor: !(row['cnc_approved'] === 2 || row['committee_approval'] === 2) ? "not-allowed" : "pointer" }}>
                        <div style={{ pointerEvents: !(row['cnc_approved'] === 2 || row['committee_approval'] === 2) ? "none" : "visible" }}>
                            <EditButton
                                onClick={() => {
                                    getScrapDisposeData(row['id'])
                                }}
                                disabled={!(row['cnc_approved'] === 2 || row['committee_approval'] === 2)}
                            />
                        </div>
                    </div>
                </div>
            }
        },
        {
            name: "C&C Approval",
            selector: "cnc_approved",
            wrap: true,
            width: "170px",
            cell: (row: any) => {
                return getStatus(row['cnc_approved'])
            }
        },
        {
            name: "C&C Approval Date",
            selector: "cnc_approval_date",
            wrap: true,
            width: "200px",
            cell: (row: any) => {
                return row['cnc_approval_date'] ?
                    moment(row['cnc_approval_date']).format('DD/MM/YYYY') + " | " + moment.utc(row['cnc_approval_date']).format('HH:mm:ss')
                    :
                    "N/A"
            }
        },
        {
            name: "C&C Remarks",
            selector: "cnc_remarks",
            wrap: true,
            width: "200px",
            cell: (row: any) => {
                return row['cnc_remarks'] ?
                    <div className="text-center">{row['cnc_remarks']}</div> : "N/A"
            }
        },
        {
            name: "Approval from all committee members",
            wrap: true,
            width: "300px",
            cell: (row: any) => {
                return getStatus(row['committee_approval'])
            }
        },

        {
            name: "Version Details",
            wrap: true,
            width: "200px",
            cell: (row: any) => {

                return <div style={{ display: "flex", flexDirection: "column" }}>{row['version_data']?.length ?
                    row['version_data'].map((value: any, index: any) => {
                        return <p className="text-danger" style={{ fontWeight: "600", textDecoration: "underline", cursor: "pointer" }}
                            onClick={(e: any) => {

                                if (index === 0) {
                                    navigate(
                                        PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                                        state: {
                                            "version_data": JSON.parse(value.dispose_data)
                                        }
                                    })
                                } else {
                                    /////////////go to compare JSONS screen///////////////

                                    let oldData = { ...JSON.parse(row['version_data'][index - 1].dispose_data) }.material_details;
                                    let newData = { ...JSON.parse(row['version_data'][index].dispose_data) }.material_details;
                        
                                    oldData = oldData.map((value: any, index: any) => {
                                        return {
                                            material_code: value.material_code,
                                            quantity: value.quantity,
                                            unit: value.unit,
                                            image_url: value.image_url,
                                            comments: value.comments,
                                            bincode: scrapBinCodes.filter((data:any,index:any)=> value.bincode == data.id)[0].bincode ,
                                            category:scrapCategories.filter((data:any,index:any)=> value.category == data.id)[0].category,
                                            available_quantity: value.available_quantity,
                                            material_group: value.material_group,
                                            material_description: value.material_description
                                        }
                                    })

                                    console.log(scrapBinCodes);
                                    console.log(scrapCategories);
                                    debugger

                                    newData = newData.map((value: any, index: any) => {
                                        return {
                                            material_code: value.material_code,
                                            quantity: value.quantity,
                                            unit: value.unit,
                                            image_url: value.image_url,
                                            comments: value.comments,
                                            bincode: scrapBinCodes.filter((data:any,index:any)=> value.bincode == data.id)[0].bincode ,
                                            category:scrapCategories.filter((data:any,index:any)=> value.category == data.id)[0].category,
                                            material_group: value.material_group,
                                            available_quantity: value.available_quantity,
                                            material_description: value.material_description
                                        }
                                    })

                                    navigate(
                                        PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                                        state: {
                                            "version_data": { ...JSON.parse(row['version_data'][index].dispose_data) },
                                            "version_details":{
                                                "new_data":newData,
                                                "old_data":oldData
                                            },
                                            "is_version_comparision": true
                                        }
                                    })
                                }
                            }}>{'Version ' + (index + 1)}</p>
                    }) : "N/A"}
                </div>
            }

        },
        {
            name: "Details of approval from all committee members",
            wrap: true,
            width: "370px",
            cell: (row: any) => {
                return <div className="text-center">
                    {row['committee_data']?.length ? <b style={{ color: CONSTANTS.COLORS.INFO, cursor: "pointer" }} onClick={(e) => {

                        navigate(
                            PATH.PRIVATE.VIEW_COMMITTEE_MEMBERS_LIST,
                            {
                                state: {
                                    data: row
                                }
                            }
                        )

                    }}>View Details</b> : "N/A"}
                </div>
            }
        }


    ];


    const getList = async (page: number) => {

        let formData: any =
        {
            page_number: page - 1,
            count: OFFSET,
        }

        /////////////////set if statements////////////

        if (dateRange) {
            formData['start_date'] = moment(dateRange[0]['$d']).format('YYYY/MM/DD');
            formData['end_date'] = moment(dateRange[1]['$d']).format('YYYY/MM/DD');
        }


        if (requestNo) {

            formData['scrap_disposal_id_params'] = requestNo;
        }

        let response = await dispatch(getScrapDisposeRequestsList(formData));

        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {

            setPage(page)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }

    useEffect(() => {
        setDisposeRequestsList(scrapDisposeRequestsList)
    }, [scrapDisposeRequestsList])





    useEffect(() => {
        dispatch(listBinCode({}));
        dispatch(listCategory({}));
        getList(page);
    }, [])

    const handlePageChange = (e: any, value: any) => {
        getList(value);
    }


    const downloadSheet = async () => {
        // alert("Pending")
        let formData: any =
        {
        }
        if (dateRange) {
            formData['start_date'] = moment(dateRange[0]['$d']).format('YYYY/MM/DD');
            formData['end_date'] = moment(dateRange[1]['$d']).format('YYYY/MM/DD');
        }

        if (requestNo) {

            formData['scrap_disposal_id_params'] = requestNo;
        }
        let response = await dispatch(downloadScrapDisposalList(formData))

        if (response.payload.data.data) {
            var iframe = document.createElement('iframe');
            iframe.id = "1";
            iframe.style.display = 'none';
            document.body.appendChild(iframe);
            iframe.src = response.payload.data.data
        }
        console.log("data log")

    }


    return <React.Fragment>

        {(loadingScrapDisposeRequestView || loadingScrapDisposeRequestsList || loadingBinCode || loadingCategories || loadingScrapDisposalListSheet) ? <Loading loading={true} /> : ""}

        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
        }}><Grid container style={{
            minWidth: "95vw",
        }} spacing={1}>

                <Grid item xs={12} lg={12} sm={12} >
                    <h3 className="text-center pb-3">Provisional Material Movement Requests</h3>
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end" }}>
                    <b>Sheet</b>
                    <img src={DownloadIcon}
                        onClick={downloadSheet}
                        alt="" style={{
                            height: "25px",
                            width: "25px",
                            border: "1px solid black",
                            marginBottom: "5px",
                            cursor: "pointer",
                            marginLeft: "5px"
                        }} />
                </Grid>


                <Grid item xs={12} lg={3} sm={6} >
                    <DateRange
                        onChange={(newValue: any) => {
                            setDateRange(newValue);
                        }}
                        value={dateRange}
                    />
                </Grid>

                <Grid item xs={12} lg={3} sm={6} className="mb-3" style={{ marginTop: "20px" }}>

                    <Input

                        label="Request Number"
                        type="text"
                        value={requestNo}
                        onChange={(e: any) => {
                            setRequestNo(e.target.value);
                        }}
                    />
                </Grid>


                <Grid item xs={12} lg={3} sm={6} className="mb-3" style={{ marginTop: "25px" }}>
                    <MyButton label={'Search'} type="button" onClick={() => {
                        getList(1)
                    }
                    } />
                </Grid>


                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", flexDirection: "column" }}>
                    <Datatable
                        columns={columns}
                        data={disposeRequestsList}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {disposeRequestsList?.length ? <Pagination
                        page={page}
                        onChange={(event: any, value: any) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(totalDisposeRequestsCount / OFFSET)}
                    /> : ""}
                </Grid>

            </Grid>
        </Container>



    </React.Fragment>


}

export default ScrapDisposeRequests;