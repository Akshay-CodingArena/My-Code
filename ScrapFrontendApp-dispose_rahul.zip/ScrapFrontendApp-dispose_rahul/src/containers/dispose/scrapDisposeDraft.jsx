import { useEffect, useRef, useState } from "react"
import { deleteDraftDisposeRequest, deleteDraftScrapRequest, departmentMasterList, dumpRequest, requestDisposeDrafts, requestScrapDrafts, viewScrapRequest, viewDisposalRequest } from "../../store/slices/list"
import { useDispatch } from "react-redux"
import Datatable from "../../components/Datatable"
import moment from "moment"
import { useAppSelector } from "../../store/hooks"
import { CONSTANTS } from "../../constants/constants"
import MyButton, { DeleteButton, EditButton, ViewButton } from "../../components/button"
import { ref } from "yup"
import useLocalStorage from "../../utils/localStorage"
import { PATH } from "../../paths/path"
import { useNavigate } from "react-router"
import { Container, Grid } from "@mui/material"
import { viewProfile } from "../../store/slices/users"
import DeleteIcon from "../../assets/images/icons/delete_icon.png"
import EditIcon from "../../assets/images/icons/edit.png";
import Loading from "../../components/backdrop";
import Pagination from "../../components/pagination"
import { showToast } from "../../components/toast";



const OFFSET = 5;


const ScrapDisposeDraftList = () => {
    let [page, setPage] = useState(1);
    const dispatch = useDispatch()
    const actionTaken = useRef(false)
    const navigate = useNavigate()
    const requestEdited = useRef("")
    const [list, setList] = useState([])
    let { departmentList, scrapRequestView, loadingDeleteDisposeDraft, loadingDisposeDraftList, totalCountDisposeDraftList, loadingScrapRequestView, tempRequestView } = useAppSelector(state => state.list)
    // const list = [{
    //     id:12
    // },
    // {
    //     id:12
    // }]
    const getDraftsList = async (page) => {
        let data = useLocalStorage.getItem("userData");
        let result = await dispatch(requestDisposeDrafts({
            user_id: data.id,
            page_number: page - 1,
            offset: OFFSET
        }))
        let temp = result.payload.data.data.getListData;
        const final = temp?.map((row) => {
            return {
                ...row,
                created_on: moment(row['created_on']).format('DD/MM/YYYY HH:mm:ss'),
            }
        })
        // moment(row['created_on']).format('DD/MM/YYYY')
        setPage(page);
        setList(final)
    }

    const getDepartmentList = async () => {
        let responseData = await dispatch(departmentMasterList({}));
        if (responseData?.payload?.data?.status === 200) {
            // getDraftsList()

        } else {
            //  showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : "Some Error Occurred.")
        }
    }

    useEffect(() => {
        getDraftsList(page)
    }, [])

    // useEffect(() => {
    //     if (actionTaken.current) {
    //         debugger
    //         useLocalStorage.setItem("scrapRequest", JSON.stringify(tempRequestView[0]))
    //         actionTaken.current = false
    //         navigate(PATH.PRIVATE.SCRAP_DISPOSAL_STORE_REQUEST,
    //              { state: { mode :"edit" } })
    //     }
    // }, [tempRequestView])

    const TableIcons = ({ rowData }) => {
        console.log("rowData is ", rowData)
        const data = {
            scrap_id: rowData.requestNo,
            isPermanent: 0
        }
        // const handleOpenConfirmDialog = () => {
        //     dataRef.current = {
        //         scrapData: rowData.row
        //     };
        //     confirmTaskRef.current.handleClickOpen()
        // }

        return (
            <>
                <div style={{ display: "flex", gap: "15px" }}>
                    <EditButton
                        onClick={() => {
                            useLocalStorage.setItem("scrapDisposeRequest",
                                JSON.stringify({
                                    ...rowData,
                                    temp_scrap_disposal_id: rowData.requestNo,
                                    disposal_id: rowData.permanent_disposal_id
                                }))
                            navigate(PATH.PRIVATE.SCRAP_DISPOSAL_STORE_REQUEST,
                                { state: { mode: "edit" } })
                        }}
                    />
                    <DeleteButton
                        label={'Delete'}
                        onClick={async () => {
                            const respose = await dispatch(deleteDraftDisposeRequest({ scrap_disposal_id: rowData.requestNo }));
                            showToast("SUCCESS", "Data deleted successfully")
                            getDraftsList(1)
                        }}
                    />
                </div>

            </>
        )
    }


    const columns = [
        {
            name: "Request No.",
            selector: "requestNo",
            wrap: true,
        }, {
            name: "View Details",
            wrap: true,
            cell: (row) => {
                return <div className="text-center">
                    <ViewButton onClick={(e) => {
                        navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                            state: {
                                "isPermanent": 0,
                                "scrap_disposal_id": row['requestNo']
                            }
                        })
                    }} />
                </div>
            }
        },
        {
            name: "Created Date | Time",
            selector: "created_on",
            wrap: true,
        },
        {
            name: "Actions",
            selector: "action",
            style: {
                minHeight: "70px"
            },
            wrap: true,
            cell: (row) => {
                return <TableIcons rowData={row} />
            }
        }
    ]

    const handleCreateNew = () => {
        localStorage.removeItem("scrapRequest")
        if (scrapRequestView.length) {
            // window.location.href = window.location.origin +PATH.PRIVATE.SCRAP_DEPOSIT
            dispatch(dumpRequest())
            navigate(PATH.PRIVATE.SCRAP_DISPOSAL_STORE_REQUEST)
        } else {
            navigate(PATH.PRIVATE.SCRAP_DISPOSAL_STORE_REQUEST)
        }
        // scrapRequestView = []
        // navigate(PATH.PRIVATE.SCRAP_DEPOSIT)
    }


    const handlePageChange = (e, value) => {
        getDraftsList(value)
    }

    return (
        <>
            {loadingDeleteDisposeDraft || loadingDisposeDraftList || loadingScrapRequestView ? <Loading loading={true} /> : ""}
            <Container fixed style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
            }}>
                <Grid container style={{
                    minWidth: "95vw",
                }}>
                    <MyButton label={"Create New"} onClick={handleCreateNew} />
                    <Datatable columns={columns} data={list} />

                    <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                        {list?.length ? <Pagination
                            page={page}
                            onChange={(event, value) => { handlePageChange(event, value) }}
                            pageCount={Math.ceil(totalCountDisposeDraftList / OFFSET)}
                        /> : ""}
                    </Grid>
                </Grid>
            </Container>

        </>
    )

}

export default ScrapDisposeDraftList