
import { useEffect } from 'react';
import React from "react";
// import { diffString, diff } from 'json-diff';

const CompareJSONS=(props)=>
{

    useEffect(()=>
    {
        console.log("COMPARE JSONS")
        // console.log(props.location.state);
        debugger
    },[])

    return <React.Fragment>

    </React.Fragment>
}

export default CompareJSONS;