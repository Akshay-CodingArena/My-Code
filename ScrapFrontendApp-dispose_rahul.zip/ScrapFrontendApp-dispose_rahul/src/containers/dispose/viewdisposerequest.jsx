
import React, { useEffect, useState } from "react";
import Loading from "../../components/backdrop";
import { Box, Grid, Paper, Typography } from "@mui/material";
import { ScrapDisposeRequestEdit, getScrapDisposeRequestView } from "../../store/slices/dispose";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from "../../components/toast";
import moment from "moment";
import MyButton from "../../components/button";
import { requestDispose } from "../../store/slices/requests";
import { PATH } from "../../paths/path";
import { listBinCode, listCategory } from "../../store/slices/list";
import ReactJsonViewCompare from 'react-json-view-compare';


///////////get list of all bincode and material code///////



const ViewScrapDisposeRequest = () => {

    const { state } = useLocation();
    const navigate = useNavigate();

    const [disposeData, setDisposeData] = useState({});

    let [committee, setCommittee] = useState("");


    ///////////////////////////////////////////////////////////////
    const dispatch = useAppDispatch()


    const { loadingScrapDisposeRequestView, scrapDisposeRequestData, loadingScrapDisposeEdit } = useAppSelector(state => state.dispose);

    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests);

    const { loadingBinCode, loadingCategories, scrapCategories, scrapBinCodes } = useAppSelector(state => state.list);

    const scrapDisposeData = async () => {
        let data = state;

        let formData =
        {
            scrap_disposal_id: data.scrap_disposal_id,
            is_permanent: data.isPermanent,
        }

        let response = await dispatch(getScrapDisposeRequestView(formData));
        let listData = response.payload.data ? response.payload.data : {};
        if (listData.status === 200) {
            let str = "";
            listData.data.disposalDetails?.[0]?.committee?.map((value, index) => {
                str += (index + 1) + "." + (value.user_email) + " ";
            })
            setCommittee(str);
            let data = JSON.parse(JSON.stringify(listData.data.disposalDetails[0]));

            if (state?.disposal_id) {
                data['disposal_id'] = state.disposal_id;
            }
            setDisposeData(data)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }



    useEffect(() => {
        dispatch(listBinCode({}));
        dispatch(listCategory({}));
        let data = state;
        if (state.version_data) {
            let str = "";

            state.version_data?.committee?.map((value, index) => {
                str += (index + 1) + "." + (value.user_email) + " ";
            })
            setCommittee(str);
            setDisposeData(state.version_data)

        } else {
            scrapDisposeData();
        }
    }, [])

    const savePermanently = async () => {

        let data = disposeData;
        let formData = {};

        const fDate = moment(data.schedule_inspection_date).format('YYYY-MM-DD');
        const fTime = data.schedule_inspection_time;

        formData['schedule_inspection_date'] = fDate;
        formData['schedule_inspection_time'] = fTime;
        formData["isPermanent"] = 1;

        let material_details = []
        let imageData = {}
        let committee = []

        data?.committee?.forEach((member, index) => {
            committee.push(
                member?.user_email ? member.user_email : "",
            )
        })

        formData["committee"] = [...committee]
        data?.material_details?.forEach((material, index) => {
            material_details.push({
                'key_index': index,
                'material_code': material.material_code,
                'bincode': scrapBinCodes.filter((value, index) => value.bincode === material.bincode)[0].id,
                'category': scrapCategories.filter((value, index) => value.category === material.category)[0].id,
                'comments': material?.comments,
                'material_description': material?.material_description,
                'material_group': material?.material_group,
                'unit': material?.unit,
                'quantity': material?.quantity,
                'available_quantity': material.available_quantity,
                "image_url": material.image_url ? material.image_url : ""
            })
        })

        formData["material_details"] = [...material_details];

        if (data.temp_scrap_disposal_id) {
            formData['temp_scrap_disposal_id'] = data.temp_scrap_disposal_id;
        }

        if (data.disposal_id) {
            delete formData['temp_scrap_disposal_id'];
            formData["scrap_disposal_id"] = data.disposal_id;
            formData["permanent_scrap_id"] = data.temp_scrap_disposal_id;
        }

        let responseData;

        responseData = (formData["permanent_scrap_id"]) ?
            await dispatch(ScrapDisposeRequestEdit(formData))
            : await dispatch(requestDispose(formData));

        if (responseData?.payload?.data?.status === 200) {
            showToast('SUCCESS', responseData?.payload?.data?.message);
            navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUESTS_LIST)
        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
        }

    }


    return <React.Fragment>

        {loadingScrapDisposeRequestView || loadingScrapRequest || loadingScrapDisposeEdit || loadingBinCode || loadingCategories ? <Loading loading={true} /> : null}


        <Grid className="scrapSection" container component="main" sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
            marginBottom: "10px"
        }}>

            <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
            >
                <h4 className="text-center mt-3">
                    Review Summary
                </h4>

                <Box
                    sx={{
                        my: 2,
                        mx: 4,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center'
                    }}
                >
                    <Box key={`FieldStatic`} style={{ width: "100%" }}>
                        {/* <Grid container > */}

                        <Grid style={{ position: "sticky", top: "65px", backgroundColor: "white", zIndex: "99" }} container spacing={2}>
                            <Grid item md={6} lg={6} xs={12} id="company_name" >
                                <p>Request No <b> : {disposeData.disposal_id ? disposeData.disposal_id : disposeData.temp_scrap_disposal_id}</b></p>
                            </Grid>
                            <Grid item md={6} lg={6} xs={12} >
                                <p>Submitted By<b>: {disposeData.submitted_by ? disposeData.submitted_by : "N/A"}</b></p>
                            </Grid>
                            <Grid item md={6} lg={6} xs={12} >
                                <p>Created Date | Time<b>: {moment(disposeData.created_on).format('DD/MM/YYYY') + " | " + moment(disposeData.created_on).format('HH:mm:ss')}</b></p>
                            </Grid>

                            <Grid item md={6} lg={6} xs={12} >
                                <p>Scheduled Inspection Date | Time<b>: {moment(disposeData.schedule_inspection_date).format('DD/MM/YYYY') + " | " + disposeData.schedule_inspection_time}</b></p>
                            </Grid>

                            <Grid item md={12} lg={12} xs={12} >
                                <p>Committee Members<b>: {committee ? committee : "N/A"}</b></p>
                            </Grid>

                        </Grid>
                        <hr />

                        <Grid container spacing={2} >

                            {!state.is_version_comparision && disposeData?.material_details && disposeData?.material_details?.map((material, index) => (<Grid item md={6} lg={6} xl={6} xs={12} >
                                <Grid component={Paper} elevation={3} sx={{ padding: "20px" }}>
                                    <div>
                                        <p><strong>Material {index + 1}</strong></p>
                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Material Code <b>: {material.material_code ? material.material_code : "N/A"}</b></p>

                                        </Grid>
                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Material Group <b>: {material.material_group ? material.material_group : "N/A"}</b></p>

                                        </Grid>
                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Material Description <b>: {material.material_description ? material.material_description : "N/A"}</b></p>

                                        </Grid>

                                        <Grid lg={12} sm={12} xl={12}>
                                            <p>Category <b>: {material.category ? material.category : "N/A"}</b></p>
                                        </Grid>

                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Unit Of Measurement(UOM)<b>: {material.unit ? material.unit : "N/A"}</b></p>

                                        </Grid>

                                        <Grid lg={12} sm={12} xl={12}>
                                            <p>Bincode <b>: {material.bincode ? material.bincode : "N/A"}</b></p>
                                        </Grid>


                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Available Quantity <b>: {material.available_quantity ? material.available_quantity : "N/A"}</b></p>

                                        </Grid>

                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Requested Quantity <b>: {material.quantity ? material.quantity : "N/A"}</b></p>

                                        </Grid>

                                        <Grid item md={8} lg={8} xs={8} >
                                            <p>Comments <b>: {material.comments}</b></p>
                                        </Grid>


                                        {material.image_url ? <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
                                            Image Preview <b>:</b>
                                            <div style={{ position: "relative" }}>
                                                <img className="previewImg" src={material?.image_url + "?" + Math.random()} />
                                            </div></div>
                                            : ""}
                                    </div>
                                </Grid>
                            </Grid>))}


                            {state.is_version_comparision ?
                                <ReactJsonViewCompare oldData={state.version_details.old_data} newData={state.version_details.new_data} /> :
                                null
                            }

                            {state?.is_submit_enable ? <Grid item md={6} lg={12} xl={12} xs={12} style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                                <MyButton type="button" label="Submit" onClick={savePermanently} />

                            </Grid> : ""}

                        </Grid>

                    </Box>
                </Box>
            </Grid>




        </Grid>

    </React.Fragment>
}

export default ViewScrapDisposeRequest;