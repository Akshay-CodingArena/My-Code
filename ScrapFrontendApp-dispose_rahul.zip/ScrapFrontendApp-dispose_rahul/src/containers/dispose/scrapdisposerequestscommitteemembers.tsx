import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Dialog, DialogActions, DialogTitle, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useLocation, useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from 'dayjs';
import { departmentMasterList, listBinCode, listCategory } from "../../store/slices/list";
import MySelect from '../../components/select';
import Input from "../../components/input";
import MyButton, { ViewButton } from "../../components/button";
import { getScrapDisposeCommitteeApproval, getScrapDisposeRequestsList } from "../../store/slices/dispose";
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import DateTimePicker from "../../components/datetime";
import CrossImage from "../../assets/images/cross.png";

const OFFSET = 5;

const CommitteMembersScrapDisposeRequestsList = () => {

    const { state } = useLocation();

    const navigate = useNavigate();

    const [userData, setUserData]: any = useState([]);

    const confirmTaskRef: any = useRef();
    const dataRef: any = useRef();

    let [page, setPage]: any = useState(1);

    let [open, setOpen]: any = useState(false);

    const { loadingScrapDisposeCommitteeApproval, loadingScrapDisposeRequestsList, totalDisposeRequestsCount } = useAppSelector(state => state.dispose);
    const { loadingBinCode, loadingCategories, scrapCategories, scrapBinCodes } = useAppSelector(state => state.list);


    const dispatch = useAppDispatch();

    const getAllDisposeRequests = async (page: any) => {

        let formData = {
            page_number: page - 1,
            count: OFFSET
        }


        let response = await dispatch(getScrapDisposeRequestsList(formData));

        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {

            setUserData(listData.data.dispose_list);
            setPage(page)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }


    }

    useEffect(() => {
        /////get all user data////
        dispatch(listBinCode({}));
        dispatch(listCategory({}));
        getAllDisposeRequests(1)
    }, [])



    const validationSchema = Yup.object().shape({
        remarks: Yup.string().trim()
            .required('Remarks is required')
            .min(5, 'Remarks must be atleast 5 characters long.'),
        date_time: Yup.object()
            .required('Date|Time is required')

    });

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        control,
        getValues
    } = useForm({
        resolver: yupResolver(validationSchema),
    });


    const getStatus = (data: any) => {

        if (data.approval_status === 1) {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>APPROVED</p>
            </div>

        }
        else if (data.approval_status === 2) {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>REJECTED</p>
            </div>
        } else if (data.approval_status === 0) {
            return <div style={{ cursor: "pointer" }} onClick={(e: any) => {
                confirmTaskRef.current.handleClickOpen();
                dataRef.current = {
                    userData: data
                }
            }}>
                <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>PENDING</p>
            </div>

        }
    }




    const approveOrReject = (response: any) => {
        setOpen(true);
        dataRef.current = {
            userData: { ...dataRef.current.userData, response: response }
        }
        setValue("date_time", dayjs(new Date()));
    }

    const onConfirm = async () => {
        ///////////confirm//////

        confirmTaskRef.current.handleClose();
        approveOrReject(1);
    }



    const onDiscard = () => {
        //////////dis card////////
        confirmTaskRef.current.handleClose();
        approveOrReject(2);
    }

    const columns: any = [
        {
            name: "Request No.",
            selector: "disposal_id",
            wrap: true,
            style: {
                minHeight: "70px"
            }
        },
        {
            name: "View Details",
            wrap: true,


            cell: (row: any) => {
                return <ViewButton label={"View"} onClick={() => {
                    navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                        state: {
                            "isPermanent": 1,
                            "scrap_disposal_id": row['disposal_id']
                        }
                    })
                }} />

            }
        },
        {
            name: "Remarks",
            selector: "remarks",
            wrap: true,
            cell: (row: any) => {
                return row['remarks'] ? row['remarks'] : "N/A"
            }
        },
        {
            name: "Date | Time",
            selector: "committee_date_time",
            wrap: true,
            cell: (row: any) => {
                return row['actual_inspection_date'] ?
                    moment(row['actual_inspection_date']).format('DD/MM/YYYY') + " | " + row['actual_inspection_time']
                    : "N/A"
            }
        }, {
            name: "Version Details",
            wrap: true,
            width: "200px",
            cell: (row: any) => {

                return <div style={{ display: "flex", flexDirection: "column" }}>{row['version_data']?.length ?
                    row['version_data'].map((value: any, index: any) => {
                        return <p className="text-danger" style={{ fontWeight: "600", textDecoration: "underline", cursor: "pointer" }}
                            onClick={(e: any) => {
                                if (index === 0) {
                                    navigate(
                                        PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                                        state: {
                                            "version_data": JSON.parse(value.dispose_data)
                                        }
                                    })
                                } else {
                                    /////////////go to compare JSONS screen///////////////

                                    let oldData = { ...JSON.parse(row['version_data'][index - 1].dispose_data) }.material_details;
                                    let newData = { ...JSON.parse(row['version_data'][index].dispose_data) }.material_details;

                                    oldData = oldData.map((value: any, index: any) => {
                                        return {
                                            material_code: value.material_code,
                                            quantity: value.quantity,
                                            unit: value.unit,
                                            image_url: value.image_url,
                                            comments: value.comments,
                                            available_quantity: value.available_quantity,
                                            material_group: value.material_group,
                                            bincode: scrapBinCodes.filter((data:any,index:any)=> value.bincode == data.id)[0].bincode ,
                                            category:scrapCategories.filter((data:any,index:any)=> value.category == data.id)[0].category,
                                            material_description: value.material_description
                                        }
                                    })


                                    newData = newData.map((value: any, index: any) => {
                                        return {
                                            material_code: value.material_code,
                                            quantity: value.quantity,
                                            unit: value.unit,
                                            image_url: value.image_url,
                                            comments: value.comments,
                                            available_quantity: value.available_quantity,
                                            material_group: value.material_group,
                                            bincode: scrapBinCodes.filter((data:any,index:any)=> value.bincode == data.id)[0].bincode ,
                                            category:scrapCategories.filter((data:any,index:any)=> value.category == data.id)[0].category,
                                            material_description: value.material_description
                                        }
                                    })

                                    navigate(
                                        PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                                        state: {
                                            "version_data": { ...JSON.parse(row['version_data'][index].dispose_data) },
                                            "version_details": {
                                                "new_data": newData,
                                                "old_data": oldData
                                            },
                                            "is_version_comparision": true
                                        }
                                    })
                                }

                            }}>{'Version ' + (index + 1)}</p>
                    }) : "N/A"}
                </div>
            }

        },
        {
            name: "Approval Status",
            selector: "approval_status",
            wrap: true,
            cell: (row: any) => {
                return getStatus(row)
            }
        }


    ];


    const onSubmit = async (data: any) => {
        let inputData = dataRef.current.userData;
        let formData = {
            "scrap_disposal_id": inputData.disposal_id,
            "user_email": inputData.user_email,
            "scrap_disposal_approval": inputData.response,
            "remarks": data.remarks,
            "actual_inspection_date": moment(data.date_time['$d']).format('YYYY/MM/DD'),
            "actual_inspection_time": moment(data.date_time['$d']).format('HH:mm:ss')
        }



        let response = await dispatch(getScrapDisposeCommitteeApproval(formData));

        let responseData = response.payload.data ? response.payload.data : {};



        if (responseData.status === 200) {
            let tempData: any = userData;
            tempData = tempData.map((value: any) => {
                if (value.disposal_id === inputData.disposal_id) {
                    return {
                        ...value,
                        remarks: data.remarks,
                        approval_status: inputData.response,
                        actual_inspection_date: formData.actual_inspection_date,
                        actual_inspection_time: formData.actual_inspection_time
                    }
                }
                return value;
            })
            showToast('SUCCESS', 'Request submitted successfully');
            setUserData(tempData);
            localStorage.setItem("committee_data", JSON.stringify(tempData));
        } else {
            showToast('ERROR', responseData.status || 'Some Error Occurred...');
        }
        setOpen(false);
    }

    const handlePageChange = (e: any, value: any) => {
        getAllDisposeRequests(value);
    }


    return <React.Fragment>

        {loadingScrapDisposeCommitteeApproval || loadingScrapDisposeRequestsList || loadingBinCode || loadingCategories ? <Loading loading={true} /> : ""}
 
        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}><Grid container style={{
            minWidth: "95vw",
        }} spacing={1}>

                <Grid item xs={12} lg={12} sm={12} >
                    <h3 className="text-center pb-3">Scrap Dispose requests for Approval</h3>
                </Grid>

                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={userData}
                    />
                </Grid>


                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {userData.length ? <Pagination
                        page={page}
                        onChange={(event: any, value: any) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(totalDisposeRequestsCount / OFFSET)}
                    /> : ""}
                </Grid>


            </Grid>
        </Container>


        <Suspense fallback={<Loading />}>
            <ConfirmDialog
                ref={confirmTaskRef}
                description={"Are you sure you want to Approve/Reject?"}
                title={""}
                confirm={"Approve"}
                discard={"Reject"}
                onConfirm={onConfirm}
                onDiscard={onDiscard}
            ></ConfirmDialog>
        </Suspense>

        <Suspense fallback={<Loading />}>
            <Dialog
                className='dialogAlertStyle'
                open={open}
                onClose={(e) => setOpen(false)}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >

                <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
                    <img onClick={(e: any) => {
                        setOpen(false)
                    }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
                </div>

                <DialogTitle id="alert-dialog-title">
                    <p className="dialog_title h4">
                        Remarks Section
                    </p>
                </DialogTitle>


                <DialogActions
                    className="dialogactions"
                >
                    <Grid container style={{ marginTop: "-20px", padding: "5px 0px" }}>

                        <form onSubmit={handleSubmit(onSubmit)}>



                            <Grid item xs={12} sm={12} md={12} lg={12} style={{ minWidth: "400px", marginBottom: "10px" }}>

                                <DateTimePicker
                                    label="Enter Actual Date/Time"
                                    value={getValues("date_time")}
                                    onChange={(value: any) => setValue('date_time', value)}
                                />

                            </Grid>


                            <Grid item xs={12} sm={12} md={12} lg={12} style={{ minWidth: "400px" }}>


                                <Input
                                    style={{ width: "350px" }}
                                    required={true}
                                    multiline={true}
                                    fullWidth={true}
                                    autoFocus={true}
                                    label="Remarks"
                                    type="text"
                                    autoComplete='on'
                                    onChange={(e: any) => {
                                        setValue('remarks', e.target.value);
                                    }}
                                    error={errors.remarks ? true : false}
                                    errormessage={errors.remarks?.message}
                                    minRows={3}
                                />


                            </Grid>



                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                <MyButton type="submit"
                                    fullWidth={true}
                                    label="Submit" style={{
                                        backgroundColor: CONSTANTS.COLORS.GREEN
                                    }} />
                            </Grid>



                        </form>



                    </Grid>
                </DialogActions>
            </Dialog>

        </Suspense>



    </React.Fragment>


}

export default CommitteMembersScrapDisposeRequestsList;