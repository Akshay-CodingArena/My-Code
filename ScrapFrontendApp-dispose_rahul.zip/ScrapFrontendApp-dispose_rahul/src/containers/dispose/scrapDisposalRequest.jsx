import React, { useEffect, useRef, useState } from 'react';
import Avatar from '@mui/material/Avatar';
import { Button, InputAdornment } from "@mui/material";
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { createUser } from '../../store/slices/auth';
import Loading from '../../components/backdrop';
import Link from "../../components/link";

import { useForm, Controller, useFieldArray } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/input';
import { PATH } from '../../paths/path';
import PlantImage from "../../assets/images/land.png"
import MyButton from '../../components/button';
import { useLocation, useNavigate } from "react-router-dom";
import { showToast } from '../../components/toast';
import useLocalStorage from '../../utils/localStorage';
import { departmentMasterList, listBinCode, listCategory, disposeMaterialList, disposeListBinCode, disposeListCategory } from '../../store/slices/list';
import Filter from '../../components/autocomplete';
import MyAutocomplete from '../../components/autocomplete';
import InputFileUpload from '../../components/upload';
import MySelect from '../../components/select';
import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import { COMAPANY, CONSTANTS } from '../../constants/constants';
import { DevTool } from "@hookform/devtools"
import { uploadImage } from '../../components/S3/S33';
import BasicDatePicker from '../../components/basicDatePicker';
import BasicTimePicker from '../../components/timePicker';
import DateTimePickerValue from "../../components/dateTimePicker";
import { editDispose, editScrap, getAvailableQuantity, requestDispose, requestScrap } from '../../store/slices/requests';
import moment from 'moment';
import { DateTimePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';

import RemoveIcon from "../../assets/images/icons/delete.png";
import { ScrapDisposeRequestEdit } from '../../store/slices/dispose';

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();
let renderCount = 0
const ScrapDisposalRequest = (props) => {

    const location = useLocation()
    const [tempId, setTempId] = useState(false)
    const currentDateTime = new Date();
    const [toggle, setToggle] = useState(false)
    const [proceed, setProceed] = useState({})
    const [materialCount, setMaterialCount] = useState(1)
    const AddScrapInfoRef = useRef({});
    let [open, setOpen] = useState(false);
    let [imagePreview, setImagePreview] = useState({})
    const navigate = useNavigate();
    const saveRef = useRef(false);
    let [state, setState] = useState({});
    const disposalIds = useRef();
    const saveValidation = useRef();




    //1.create mode 2.view 3.edit

    //create ---> view --->
    let [mode, setMode] = useState("create")

    let dispatch = useAppDispatch();
    let [loading, setLoading] = useState(false);

    let { loadingMaterialList, materialList, departmentList, loadingDepartmentList, scrapRequestView, scrapBinCodes, scrapCategories, loadingBinCode, loadingCategories } = useAppSelector(state => state.list);
    const { loadingScrapRequest } = useAppSelector(state => state.scrapRequests);
    const { loadingScrapDisposeEdit } = useAppSelector(state => state.dispose);

    const validationSchema = Yup.object().shape({

        committee: Yup.array().of(
            Yup.object().shape({
                email_id: Yup.string().trim()
                    .required('Email is required')
                    .email('Email format is invalid')
                    .matches(/\@rattanindia.com$/, 'Use RattanIndia email ID\'s only')
            })
        ),
        material_details: Yup.array().of(
            Yup.object().shape({
                material_code: Yup.object().required('Material Code is required.'),
                material_group: Yup.string().trim()
                    .required('Material Group is required'),
                material_description: Yup.string().trim()
                    .required('Material Description is required'),
                bincode: Yup.string().trim()
                    .required('Bincode is required'),
                category: Yup.string().trim()
                    .required('Category is required'),
                units: Yup.string().trim()
                    .required('Units is required'),
                total_quantity: Yup.number()
                    .typeError('Please enter a number')
                    .positive('Total quantity must be a positive')
                    .required('Total quantity is a required.'),
                quantity: Yup.number()
                    .typeError('Please enter a number')
                    .positive('Quantity must be a positive')
                    .required('Quantity is a required.'),
                comments: Yup.string().optional(),
                file: Yup.mixed().optional()
            })
        )
    });

    const getMaterialList = async (formData) => {
        let response = await dispatch(disposeMaterialList(formData));
        if (response?.payload?.data?.status === 200) { } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }

    const getBinCodeList = async (formData) => {
        let response = await dispatch(disposeListBinCode(formData));
        if (response?.payload?.data?.status === 200) {


        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }

    const getCategoryList = async (formData) => {
        let response = await dispatch(disposeListCategory(formData));
        if (response?.payload?.data?.status === 200) {


        } else {
            showToast('ERROR', response?.payload?.data?.message ? response.payload.data.message : "Some Error Occurred.")
        }
    }


    useEffect(() => {
        let formData = {
            page_number: 0
        }

        getMaterialList(formData)
        setValue(`inspection_datetime`, dayjs(new Date()));
    }, []);


    useEffect(() => {

        let { state } = location;
        if (state?.mode === "edit") {

            setLoading(true)

            let scrapDisposeData = JSON.parse(useLocalStorage.getItem("scrapDisposeRequest"));

            ///////////////is scrap has temporary id//////////////
            if (scrapDisposeData.temp_scrap_disposal_id) {
                disposalIds.current = {
                    scrap_disposal_id: scrapDisposeData.temp_scrap_disposal_id
                }
            }

            if (scrapDisposeData.disposal_id) {
                disposalIds.current = {
                    ...disposalIds.current,
                    disposal_id: scrapDisposeData.disposal_id
                }
            }



            setValue("inspection_datetime", dayjs(new Date(`${scrapDisposeData.schedule_inspection_date.split(" ")[0]} ${scrapDisposeData.schedule_inspection_time}`)))



            scrapDisposeData.committee_members.map((item, index) => {
                if (index > 0) {
                    handleAddMember()
                }
            })
            scrapDisposeData.committee_members.map((item, index) => {
                setValue(`committee.${index}.email_id`, item.user_email)
            })
            scrapDisposeData.material_details.map((item, index) => {
                if (index > 0) {
                    handleAddMore()
                }
            })
            scrapDisposeData.material_details.map(async (item, index) => {
                setValue(`material_details.${index}.material_code`,
                    { label: item.material_code, material_code: item.material_code }
                )
                setValue(`material_details.${index}.comments`, item.comments);
                setValue(`material_details.${index}.material_description`, item.material_description)
                setValue(`material_details.${index}.material_group`, item.material_group)
                setValue(`material_details.${index}.units`, item.unit);
                setValue(`material_details.${index}.total_quantity`, item.available_quantity ? item.available_quantity : 0);
                setValue(`material_details.${index}.quantity`, item.quantity ? item.quantity : 0);
                setValue(`material_details.${index}.image_url`, item?.image_url ? item.image_url : "");

                let formData1 = {
                    material_code: item.material_code,
                    index
                };

                let response1 = await dispatch(disposeListBinCode(formData1))

                let binarr = response1.payload.data.data;


                let temp1 = binarr.filter((object) => {
                    return object.bincode == item.bincode;
                })



                setValue(`material_details.${index}.bincode`, temp1?.[0]?.bincode ? temp1[0].bincode : "");

                let formdata2 = {
                    material_code: item.material_code,
                    bincode: getValues(`material_details.${index}.bincode`),
                    index
                }

                let response2 = await dispatch(disposeListCategory(formdata2));

                let catarr = response2.payload.data.data;



                let temp2 = catarr.filter((object) => {
                    return object.category == item.category;
                })

                setTimeout(() => {
                    setLoading(false)
                }, 1000);


                setValue(`material_details.${index}.category`, temp2?.[0]?.category ? temp2[0].category : "")
                imagePreview[index] = item.image_url;


                setImagePreview({ ...imagePreview })
            })

            setMode("edit")
        }
    }, [])

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control,
        getValues,
        setValue,
        setError,
        clearErrors
    } = useForm({
        mode: 'onChange',
        resolver: yupResolver(validationSchema),
        defaultValues: {
            inspection_datetime: "",
            committee: [{
                email_id: "",
            }],
            material_details: [{
                material_code: null,
                bincode: "",
                category: "",
                material_group: "",
                material_description: "",
                units: "",
                total_quantity: "",
                quantity: 0,
                comments: "",
                file: ""
            }]
        }
    });

    let { fields, append, remove } = useFieldArray({
        name: "material_details",
        control
    })

    let { fields: member_fields, append: member_append, remove: member_remove } = useFieldArray({
        name: "committee",
        control
    })


    const handleAddMember = () => {
        member_append({
            email_id: "",
        })
    }

    const handleAddMore = () => {
        append({
            material_code: "",
            material_group: "",
            material_description: "",
            units: "",
            quantity: "",
            comments: "",
            file: "",
            material_code_verification: false
        })
    }

    const handleRemove = (index) => {
        remove(index)
    }

    const handleRemoveMember = (index) => {
        member_remove(index)
    }



    const saveInDraft = async () => {
        const data = getValues();

        if (data.inspection_datetime['$d'] < currentDateTime) {
            setError(`inspection_datetime`, {
                type: 'manual',
                message: 'Inspection datetime should be in the future, after the created date time of request',
            });
            showToast('ERROR', 'Inspection datetime should be in the future, after the created date time of request');
            return;
        }


        let isQuantityError = false;

        data.material_details.map((item, index) => {
            if (item.quantity > item.total_quantity) {
                setError(`material_details[${index}].quantity`, {
                    type: 'manual',
                    message: 'Accepted Quantity should not be greater than available quantity.',
                });
                isQuantityError = true;
            }
        })

        if (isQuantityError) {
            showToast('ERROR', 'Error in quantity.Please check.');
            return;
        }



        let userData = useLocalStorage.getItem("userData");
        let formData = {}
        const momentObject = moment(data.inspection_datetime['$d']);
        const fDate = momentObject.format('YYYY-MM-DD');
        const fTime = momentObject.format('HH:mm:ss');

        formData['schedule_inspection_date'] = fDate;
        formData['schedule_inspection_time'] = fTime;
        formData["isPermanent"] = 0;
        let material_details = []
        let imageData = {}
        let committee = [];

        data?.committee?.forEach((member, index) => {
            committee.push(
                member?.email_id ? member.email_id : "",
            )
        });

        formData["committee"] = [...committee];

        data?.material_details?.forEach((material, index) => {
            material_details.push({
                'key_index': index,
                'material_code': material.material_code.material_code ?? data.material_details[index].material_code.material_code,
                'bincode': material.bincode ? material.bincode : "",
                'category': material.category ? material.category : "",
                'comments': material.comments ? material.comments : "",
                'material_description': material.material_description ? material.material_description : "",
                'material_group': material.material_group ? material.material_group : "",
                'unit': material.units ? material.units : "",
                'quantity': material.quantity ? material.quantity : 0,
                'available_quantity': material.total_quantity ? material.total_quantity : ""
            })
            if (material?.file) {
                imageData[index] = material?.file
                material_details[index]['image_url'] = "true"
            } else if (material.image_url) {
                material_details[index]['image_url'] = material.image_url
            }
        })
        formData["material_details"] = [...material_details];

        if (disposalIds?.current?.scrap_disposal_id) {
            formData["scrap_disposal_id"] = disposalIds.current.scrap_disposal_id;
        }

        if (disposalIds?.current?.disposal_id) {
            formData["permanent_scrap_id"] = disposalIds.current.disposal_id;
        }

        let responseData;

        responseData = formData["scrap_disposal_id"] ?
            await dispatch(ScrapDisposeRequestEdit(formData))
            : await dispatch(requestDispose(formData));


        if (responseData?.payload?.data?.status === 200) {

            showToast('SUCCESS', responseData?.payload?.data?.message);

            let scrapId = responseData?.payload?.data?.data?.temp_scrap_disposal_id;

            if (scrapId) {
                disposalIds.current = {
                    scrap_disposal_id: scrapId
                }
            }

            if (formData["scrap_disposal_id"])
                uploadImage(imageData, responseData?.payload?.data?.data);
            else
                uploadImage(imageData, responseData?.payload?.data?.data?.material_data);
        } else {
            formData["temp_scrap_disposal_id"] = 0
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
        }
    }

    const onSubmit = async (data) => {


        if (data.inspection_datetime['$d'] < currentDateTime) {
            setError(`inspection_datetime`, {
                type: 'manual',
                message: 'Inspection datetime should be in the future, after the created date time of request',
            });
            showToast('ERROR', 'Inspection datetime should be in the future, after the created date time of request');

            return;
        }

        let isQuantityError = false;

        data.material_details.map((item, index) => {
            if (item.quantity > item.total_quantity) {
                setError(`material_details[${index}].quantity`, {
                    type: 'manual',
                    message: 'Accepted Quantity should not be greater than available quantity.',
                });
                isQuantityError = true;
            }
        })

        if (isQuantityError) {
            showToast('ERROR', 'Error in quantity.Please check.');
            return;
        }

        let userData = useLocalStorage.getItem("userData");
        let formData = {};



        const momentObject = moment(data.inspection_datetime['$d']);
        const fDate = momentObject.format('YYYY-MM-DD');
        const fTime = momentObject.format('HH:mm:ss');



        formData['schedule_inspection_date'] = fDate;
        formData['schedule_inspection_time'] = fTime;
        formData["isPermanent"] = 0;
        let material_details = []
        let imageData = {}
        let committee = []
        data?.committee?.forEach((member, index) => {
            committee.push(
                member?.email_id ? member.email_id : "",
            )
        })

        formData["committee"] = [...committee]
        data?.material_details?.forEach((material, index) => {
            material_details.push({
                'key_index': index,
                'material_code': material.material_code.material_code ?? data.material_details[index].material_code.material_code,
                'bincode': material?.bincode,
                'category': material?.category,
                'comments': material?.comments,
                'material_description': material?.material_description,
                'material_group': material?.material_group,
                'unit': material?.units,
                'quantity': material?.quantity,
                'available_quantity': material.total_quantity
            })
            if (material?.file) {
                imageData[index] = material?.file
                material_details[index]['image_url'] = "true"
            } else if (material.image_url) {
                material_details[index]['image_url'] = material.image_url
            }
        })

        formData["material_details"] = [...material_details];

        if (disposalIds?.current?.scrap_disposal_id) {
            formData['scrap_disposal_id'] = disposalIds.current.scrap_disposal_id;
        }

        if (disposalIds?.current?.disposal_id) {
            formData["permanent_scrap_id"] = disposalIds.current.disposal_id;
        }

        let responseData;

        responseData = (disposalIds?.current?.scrap_disposal_id) ?
            await dispatch(ScrapDisposeRequestEdit(formData))
            : await dispatch(requestDispose(formData));
        if (responseData?.payload?.data?.status === 200) {

            showToast('SUCCESS', responseData?.payload?.data?.message);

            let scrapId =
                responseData?.payload?.data?.data?.temp_scrap_disposal_id
                    ?
                    responseData.payload?.data?.data?.temp_scrap_disposal_id
                    :
                    disposalIds?.current?.scrap_disposal_id
                ;


            uploadImage(imageData, responseData?.payload?.data?.data?.material_data);

            //    setLoading(true);


            //    setTimeout(()=>{

            //     setLoading(false);

            navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                state: {
                    "isPermanent": 0,
                    "scrap_disposal_id": scrapId,
                    "is_submit_enable": true,
                    "disposal_id": disposalIds?.current?.disposal_id
                }
            })
            //    },1500)
        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : 'Some Error Occurred...');
        }
    }

    const handleRemoveImage = (index) => {
        let temp = imagePreview
        temp[index] = false
        setValue(`material_details.${index}.file`, false);
        setValue(`material_details.${index}.image_url`, "");
        setImagePreview({ ...temp })
    }

    const showPreview = (file, index) => {
        let reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = ((result) => {
            imagePreview[index] = result.currentTarget.result
            setImagePreview({ ...imagePreview })
        })

    }

    console.log(errors, getValues());

    return (<>


        {loading || loadingScrapDisposeEdit || loadingScrapRequest || loadingMaterialList || loadingBinCode || loadingCategories ? <Loading loading={true} /> : ""}


        <ThemeProvider theme={defaultTheme}>
            <Grid className="scrapSection" container component="main" sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "20px",
                marginBottom: "10px"
            }}>

                <Grid item xs={12} sm={12} md={12} component={Paper} elevation={6} square
                >
                    <Typography component="h1" variant="h5" className='mb-3 scrap_header'>
                        Material Dispose
                    </Typography>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div style={{ cursor: mode === "view" ? "not-allowed" : "pointer" }}>
                            <div style={{ pointerEvents: mode === "view" ? "none" : "visible" }}>

                                <Box
                                    sx={{
                                        my: 4,
                                        mx: 4,
                                        display: 'flex',
                                        flexDirection: 'column',

                                    }}
                                >


                                    <Box key={`FieldStatic`} style={{ width: "100%", marginBottom: "10px" }}>
                                        <Grid item md={4} lg={4} xs={12} id="ins_date" >
                                            <Controller
                                                control={control}
                                                name={`inspection_datetime`}
                                                render={({ field: any }) => (
                                                    <DateTimePickerValue
                                                        {...register(`inspection_datetime`, { required: { value: true, message: "Please enter inspection time" } })}
                                                        label={'Inspection Date Time'}
                                                        required={true}
                                                        control={control}
                                                        onChange={(e) => {
                                                            clearErrors(`inspection_datetime`);
                                                            setValue(`inspection_datetime`, e);
                                                        }}
                                                        value={getValues(`inspection_datetime`) ? getValues(`inspection_datetime`) : ""}
                                                        error={errors.inspection_datetime ? true : false}
                                                        errormessage={errors.inspection_datetime?.message}
                                                    />)}
                                            />
                                        </Grid>
                                    </Box >

                                    {member_fields.map((field, index) => (
                                        <Box key={`Fiel${field.id}`}>
                                            <Grid container spacing={2}>
                                                <Grid item md={4} lg={4} sm={4} xs={12} id={`committee_${field.id}`}>
                                                    <p><strong>Committe Member {index + 1}</strong></p>

                                                    <Controller
                                                        control={control}
                                                        name={`committee.${index}.email_id`}
                                                        render={({ field: any }) => (
                                                            <Input
                                                                fullWidth={true}
                                                                label="Committee Member Email"
                                                                type="email"

                                                                onChange={(e, value) => {
                                                                    setValue(`committee.${index}.email_id`, e.target.value);
                                                                }}
                                                                value={getValues()?.committee?.[index]?.email_id ? getValues().committee[index].email_id : null}
                                                                error={errors?.committee?.[index]?.email_id ? true : false}
                                                                errormessage={errors?.committee?.[index]?.email_id?.message}
                                                                ///////disabled members in case of Permanent Request///////
                                                                disabled={location?.state?.isPermanentRequest}
                                                            />
                                                        )}
                                                    />
                                                </Grid>

                                                {index > 0 ? <Grid item md={2} sm={2} lg={2} >
                                                    {location?.state?.isPermanentRequest ?
                                                        "" :
                                                        <img src={RemoveIcon} style={{ height: "25px", width: "25px", marginTop: "50px", cursor: "pointer" }}
                                                            onClick={() => {
                                                                handleRemoveMember(index);
                                                            }} />}
                                                </Grid> : null}
                                            </Grid>
                                        </Box>
                                    ))}


                                    {location?.state?.isPermanentRequest ? "" : <Grid item md={2} sm={2} lg={2}>
                                        <Button
                                            type={"button"}
                                            variant="contained" fullWidth={false} onClick={handleAddMember} style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} >
                                            Add Commitee Member
                                        </Button>
                                    </Grid>}
                                </Box>

                                {fields.map((field, index) => (
                                    <Box key={`Fiel${field.id}`}
                                        sx={{
                                            my: 4,
                                            mx: 4,
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center'
                                        }}>
                                        <Grid container spacing={2}>
                                            
                                            {
                                                getValues('material_details').length > 1 ? <Grid item md={12} sm={12} lg={12} style={{ textAlign: "right" }}>
                                                    <p style={{ position: "absolute", marginTop: "12px" }}><strong>Material {index + 1}</strong></p>
                                                    <Button type={"button"} variant="contained" fullWidth={false} onClick={() => handleRemove(index)} style={{ backgroundColor: CONSTANTS.COLORS.RED }} >
                                                        Remove
                                                    </Button>
                                                </Grid> : null
                                            }

                                            <Grid item md={4} lg={4} xs={12}>
                                                <MyAutocomplete
                                                    options={materialList.length ? materialList.map((value, index) => {
                                                        return { label: value.material_code, ...value }
                                                    }) : []}
                                                    label='Material Code *'
                                                    {...register(`material_details.${index}.material_code`)}
                                                    onChange={(e, value) => {

                                                        setValue(`material_details.${index}.bincode`, "")
                                                        setValue(`material_details.${index}.category`, "")


                                                        setValue(`material_details.${index}.material_code`, value);
                                                        setValue(`material_details.${index}.material_group`, value?.material_group ? value.material_group : "N/A");
                                                        setValue(`material_details.${index}.material_description`, value?.material_description ? value.material_description : "N/A");
                                                        setValue(`material_details.${index}.units`, value?.unit)
                                                        setValue(`material_details.${index}.total_quantity`, value?.total_quantity ? value?.total_quantity : 0);


                                                        setToggle(!toggle)
                                                        let formData = {
                                                            material_code: value?.material_code,
                                                            index
                                                        }
                                                        getBinCodeList(formData)
                                                    }}
                                                    onInputChange={(e, value) => {

                                                        let formData = {
                                                            page_number: 0,
                                                            count: 10,
                                                            material_code: value
                                                        }

                                                        getMaterialList(formData)
                                                    }}
                                                    value={getValues()?.material_details?.[index]?.material_code ? getValues().material_details[index].material_code : null}
                                                    error={errors?.material_details?.[index]?.material_code ? true : false}
                                                    errormessage={errors?.material_details?.[index]?.material_code?.message}
                                                />

                                            </Grid>
                                            <Grid item md={4} lg={4} xs={12}>
                                                <MySelect
                                                    required={true}
                                                    {...register(`material_details.${index}.bincode`)}
                                                    label={'Location Bin Code'}
                                                    menuItems={scrapBinCodes?.[index]}
                                                    selectors={{
                                                        label: "bincode_name",
                                                        value: "bincode"
                                                    }}
                                                    onChange={(e, value) => {
                                                        setValue(`material_details.${index}.bincode`, value.props.value);
                                                        let temp = scrapBinCodes[index].filter((object) => {
                                                            return object.bincode == getValues(`material_details.${index}.bincode`);
                                                        })

                                                        setValue(`material_details.${index}.total_quantity`, temp[0]?.total_quantity ? temp[0].total_quantity : 0);
                                                        setToggle(!toggle)
                                                        let formdata = {
                                                            material_code: getValues(`material_details.${index}.material_code.material_code`),
                                                            bincode: getValues(`material_details.${index}.bincode`),
                                                            index
                                                        }
                                                        getCategoryList(formdata);
                                                    }}
                                                    value={getValues(`material_details.${index}.bincode`) ?? ""}
                                                    error={errors.material_details?.[index]?.bincode ? true : false}
                                                    errormessage={errors.material_details?.[index]?.bincode?.message}
                                                />


                                            </Grid>


                                            <Grid item md={4} lg={4} xs={12}>
                                                <MySelect
                                                    required={true}
                                                    {...register(`material_details.${index}.category`)}
                                                    label={'Category'}
                                                    menuItems={scrapCategories[index]}

                                                    selectors={{
                                                        label: "category_name",
                                                        value: "category"
                                                    }}
                                                    onChange={(e, value) => {
                                                        setValue(`material_details.${index}.category`, value.props.value);
                                                        let temp = scrapCategories[index].filter((object) => {
                                                            return object.category == getValues(`material_details.${index}.category`);
                                                        })

                                                        setValue(`material_details.${index}.total_quantity`, temp[0]?.total_quantity ? temp[0].total_quantity : 0);

                                                        setValue(`material_details.${index}.category`, e.target.value);
                                                        setToggle(!toggle)
                                                    }}
                                                    value={getValues(`material_details.${index}.category`) ?? ""}
                                                    error={errors.material_details?.[index]?.category ? true : false}
                                                    errormessage={errors.material_details?.[index]?.category?.message}
                                                />
                                            </Grid>
                                            <Grid item md={4} lg={4} xs={12} id={`material_group_${field.id}`}>
                                                <Input
                                                    {...register(`material_details.${index}.material_group`)}
                                                    required={true}
                                                    fullWidth={true}
                                                    autoFocus={true}
                                                    label="Material Group"
                                                    type="text"
                                                    autoComplete='on'
                                                    error={errors?.material_details?.[index]?.material_group ? true : false}
                                                    errormessage={errors?.material_details?.[index]?.material_group?.message}
                                                    value={getValues(`material_details.${index}.material_group`) ? getValues(`material_details.${index}.material_group`) : ""}
                                                    onChange={(e) => {
                                                        setValue(`material_details.${index}.material_group`, e.target.value);
                                                    }}
                                                    disabled={true}
                                                />

                                            </Grid>
                                            <Grid item md={4} lg={4} xs={12} id={`material_description_${field.id}`}>
                                                <Input
                                                    {...register(`material_details.${index}.material_description`)}
                                                    required={true}
                                                    multiline={true}
                                                    fullWidth={true}
                                                    autoFocus={true}
                                                    label="Material Description"
                                                    type="text"
                                                    autoComplete='on'
                                                    error={errors?.material_details?.[index]?.material_description ? true : false}
                                                    errormessage={errors?.material_details?.[index]?.material_description?.message}
                                                    value={getValues(`material_details.${index}.material_description`) ? getValues(`material_details.${index}.material_description`) : ""}
                                                    onChange={(e) => {
                                                        setValue(`material_details.${index}.material_description`, e.target.value);
                                                    }}
                                                    disabled={true}
                                                />
                                            </Grid>
                                            <Grid item md={4} lg={4} xs={6} id={`material_unit_${field.id}`}>

                                                <Input
                                                    {...register(`material_details.${index}.units`)}
                                                    required={true}
                                                    fullWidth={true}
                                                    autoFocus={true}
                                                    label="Units"
                                                    type="text"
                                                    autoComplete='on'
                                                    error={errors?.material_details?.[index]?.units ? true : false}
                                                    errormessage={errors?.material_details?.[index]?.units?.message}
                                                    value={getValues(`material_details.${index}.units`) ? getValues(`material_details.${index}.units`) : ""}
                                                    onChange={(e) => {
                                                        setValue(`material_details.${index}.units`, e.target.value);
                                                    }}
                                                    disabled={true}
                                                />

                                            </Grid>
                                            <Grid item md={4} lg={4} xs={12} id={`material_quantity_${field.id}`}>
                                                <Input
                                                    {...register(`material_details.${index}.total_quantity`)}
                                                    required={true}
                                                    fullWidth={true}
                                                    autoFocus={true}
                                                    label="Available Quantity"
                                                    type="text"
                                                    autoComplete='on'
                                                    error={errors?.material_details?.[index]?.total_quantity ? true : false}
                                                    errormessage={errors?.material_details?.[index]?.total_quantity?.message}
                                                    value={getValues(`material_details.${index}.total_quantity`) ? getValues(`material_details.${index}.total_quantity`) : 0}
                                                    onChange={(e) => {
                                                        setValue(`material_details.${index}.total_quantity`, e.target.value);
                                                    }}
                                                    disabled={true}
                                                />

                                            </Grid>

                                            <Grid item md={4} lg={4} xs={6}>
                                                <Input
                                                    InputProps={{ endAdornment: <InputAdornment position="end">{getValues(`material_details.${index}.units`)}</InputAdornment> }}
                                                    {...register(`material_details.${index}.quantity`)}
                                                    fullWidth={true}
                                                    label="Quantity"
                                                    type="text"
                                                    autoComplete='on'
                                                    error={errors.material_details?.[index]?.quantity ? true : saveValidation?.current?.error ? saveValidation.current.error : false}
                                                    errormessage={errors.material_details?.[index]?.quantity?.message ? errors.material_details?.[index]?.quantity?.message : saveValidation?.current?.errormsg ? saveValidation.current.errormsg : ""}
                                                    value={getValues(`material_details.${index}.quantity`) ? getValues(`material_details.${index}.quantity`) : ""}
                                                    onChange={(e) => {
                                                        // saveValidation.current = {};
                                                        // if (e.target.value < 0) {
                                                        //     saveValidation.current = {
                                                        //         error: true,
                                                        //         errormsg: "Value should be positive"
                                                        //     }

                                                        // }
                                                        // if (e.target.value > getValues(`material_details.${index}.total_quantity`)) {
                                                        //     saveValidation.current = {
                                                        //         error: true,
                                                        //         errormsg: "Value can not be greater than available quantity"
                                                        //     }
                                                        // }
                                                        clearErrors(`material_details[${index}].quantity`);
                                                        if (e.target.value < 0) {
                                                            setError(`material_details[${index}].quantity`, {
                                                                type: 'manual',
                                                                message: 'Quantity must be positive.',
                                                            });
                                                        }
                                                        if (e.target.value > getValues(`material_details.${index}.total_quantity`)) {
                                                            setError(`material_details[${index}].quantity`, {
                                                                type: 'manual',
                                                                message: 'Accepted Quantity should not be greater than available quantity.',
                                                            });
                                                        }
                                                        setValue(`material_details.${index}.quantity`, e.target.value);
                                                        setToggle(!toggle)
                                                    }}
                                                    disabled={mode === "view" ? true : false}
                                                />
                                            </Grid>



                                            <Grid item md={6} lg={6} xs={12}>
                                                <Input
                                                    {...register(`material_details.${index}.comments`)}
                                                    fullWidth={true}
                                                    multiline={true}
                                                    minRows={2}
                                                    label="Short Text"
                                                    type="text"
                                                    autoComplete='on'
                                                    error={errors.material_details?.[index]?.comments ? true : false}
                                                    onChange={(e) => {
                                                        setValue(`material_details.${index}.comments`, e.target.value || '');
                                                        setToggle(!toggle)
                                                    }}
                                                    value={getValues(`material_details.${index}.comments`) ? getValues(`material_details.${index}.comments`) : ""}
                                                    errormessage={errors.material_details?.[index]?.message}
                                                    disabled={mode === "view" ? true : false}
                                                />
                                            </Grid>

                                            <Grid item md={3} sm={3} lg={8} style={{ display: "flex", gap: "20px" }}>
                                                {imagePreview[index] ? <>
                                                    Image Preview
                                                    <div style={{ position: "relative" }}>
                                                        <img className="previewImg" src={imagePreview[index]?.length < 1000 ? imagePreview[index] + "?" + Math.random() : imagePreview[index]} />
                                                        <div onClick={() => handleRemoveImage(index)} className="imageRemove">X</div>

                                                    </div></> :
                                                    <InputFileUpload
                                                        onChange={(e) => {
                                                            setLoading(true)
                                                            showPreview(e.target.files[0], index)
                                                            setValue(`material_details.${index}.file`, e.target.files[0]);
                                                            setTimeout(() => {
                                                                setLoading(false);
                                                            }, 1500)
                                                        }}
                                                        value={getValues(`material_details.${index}.file`) ? getValues(`material_details.${index}.file`) : ""}
                                                        label={"Upload Image"}
                                                        optional={true}
                                                        errormessage={errors?.file?.message ? errors.file.message : ""}
                                                    />}
                                            </Grid>



                                        </Grid>
                                    </Box>
                                ))}



                                <Box sx={{
                                    my: 4,
                                    mx: 4,
                                }}>
                                    <Grid container spacing={2}>

                                        <Grid item md={12} sm={12} lg={12}>
                                            <Button type={"button"} variant="contained" fullWidth={false} onClick={handleAddMore} style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} >
                                                Add Material
                                            </Button>
                                        </Grid>


                                    </Grid>
                                </Box>
                            </div>
                        </div>

                        <Box sx={{
                            my: 4,
                            mx: 4,
                        }}>
                            <Grid container spacing={2}>
                                <Grid item md={12} sm={12} lg={12} style={{ display: "flex", justifyContent: "center", alignItems: "center", cursor: "pointer !important" }}>

                                    {(mode === "create" || mode === "edit") ?
                                        <MyButton type="button" fullWidth={false} label={"Save"}
                                            onClick={saveInDraft}
                                            style={{
                                                backgroundColor: CONSTANTS.COLORS.PRIMARY,
                                                marginRight: "10px"
                                            }} /> :
                                        ""}


                                    {(mode === "create" || mode === "edit") ? <MyButton type="submit" fullWidth={false} label={'Proceed'}

                                    /> : ""}
                                </Grid>
                            </Grid>
                        </Box>
                    </form>
                    <DevTool control={control} />
                </Grid>




                <Dialog
                    className='dialogAlertStyle'
                    open={open}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">
                        <p className="dialog_title h3">
                            Material Deposit
                        </p>
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description" className='text-center'>
                            <b >
                                Your Material Deposit Form has been submitted successfully to your Reporting Manager for Approval,
                            </b>

                            <p className='h5 text-center mt-2'>
                                {`Request No : ${AddScrapInfoRef?.current?.request_no ? AddScrapInfoRef?.current?.request_no : ""}`}
                            </p>
                        </DialogContentText>
                    </DialogContent>

                    <DialogActions
                        className="dialogactions"
                    >
                        <Grid container style={{ marginTop: "-20px" }}>
                            <Grid item xs={5} sm={5} md={5} lg={5}>
                                <MyButton
                                    fullWidth={true}
                                    label='OK'
                                    onClick={(e) => {
                                        navigate(PATH.PRIVATE.DASHBOARD)
                                    }}
                                    style={{ backgroundColor: CONSTANTS.COLORS.GREEN }} />
                            </Grid>
                        </Grid>
                    </DialogActions>
                </Dialog>


            </Grid>

        </ThemeProvider >

    </>
    );
}
export default ScrapDisposalRequest;