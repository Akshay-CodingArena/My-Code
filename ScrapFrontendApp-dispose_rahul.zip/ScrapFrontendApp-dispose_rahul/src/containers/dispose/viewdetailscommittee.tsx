import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Dialog, DialogActions, DialogTitle, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useLocation, useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from 'dayjs';
import { departmentMasterList } from "../../store/slices/list";
import MySelect from '../../components/select';
import Input from "../../components/input";
import MyButton from "../../components/button";
import { getScrapDisposeCommitteeApproval, getScrapDisposeRequestsList } from "../../store/slices/dispose";
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import DateTimePicker from "../../components/datetime";


const OFFSET = 5;

const CommitteMembersList = () => {

    const { state } = useLocation();

    const [userData, setUserData]: any = useState([]);

    useEffect(() => {
        let data: any = state.data.committee_data;
        console.log(data);
        if (localStorage.getItem('committee_data')) {
            let t: any = localStorage.getItem('committee_data');
            setUserData(JSON.parse(t));
        } else {
            localStorage.setItem("committee_data", JSON.stringify(data));
            setUserData(data);
        }
        return () => {
            localStorage.removeItem("committee_data");
        }
    }, [])

    const validationSchema = Yup.object().shape({
        remarks: Yup.string().trim()
            .required('Remarks is required')
            .min(5, 'Remarks must be atleast 5 characters long.'),
        date_time: Yup.object()
            .required('Date|Time is required')

    });

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        control,
        getValues
    } = useForm({
        resolver: yupResolver(validationSchema),
    });




    const getStatus = (data: any) => {

        if (data.approval_status === 1) {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>APPROVED</p>
            </div>

        }
        else if (data.approval_status === 2) {
            return <div style={{ cursor: "not-allowed" }}>
                <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>REJECTED</p>
            </div>
        } else if (data.approval_status === 0) {
            return <div style={{ cursor: "not-allowed" }} >
                <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>PENDING</p>
            </div>
        }
    }

    const columns: any = [
        {
            name: "Email",
            selector: "user_email",
            wrap: true,
            style: {
                minHeight: "70px"
            }
        },
        {
            name: "Approval Status",
            selector: "approval_status",
            wrap: true,
            cell: (row: any) => {
                return getStatus(row)
            }
        }


    ];


 

    return <React.Fragment>

        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}>
            <Grid container spacing={1}>

                <Grid item xs={12} lg={12} sm={12} >
                    <h3 className="text-center pb-3">Committee Members List</h3>
                </Grid>


                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={userData}
                    />
                </Grid>
            </Grid>
        </Container>
    </React.Fragment>


}

export default CommitteMembersList;