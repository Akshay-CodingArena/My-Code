import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import {
  Container,
  Dialog,
  DialogActions,
  DialogTitle,
  Grid,
} from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import {
  departmentMasterList,
  downloadScrapDisposalList,
  listBinCode,
  listCategory,
} from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton, { ViewButton } from "../../components/button";
import {
  getScrapDisposeApprovalCNC,
  getScrapDisposeRequestsList,
} from "../../store/slices/dispose";

import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import CrossImage from "../../assets/images/cross.png";



const OFFSET = 5;

const ScrapDisposeRequestsCNC = () => {
  const navigate = useNavigate();
  let [page, setPage]: any = useState(1);

  const confirmTaskRef: any = useRef();
  const dataRef: any = useRef();
  let [open, setOpen]: any = useState(false);
  const [userData, setUserData]: any = useState([]);

  let [disposeRequestsList, setDisposeRequestsList]: any = useState([]);
  let [dateRange, setDateRange]: any = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [requestNo, setRequestNo] = useState();

  const {
    loadingScrapDisposeRequestsList,
    scrapDisposeRequestsList,
    totalDisposeRequestsCount,
    loadingScrapDisposeApprovalCNC,
  } = useAppSelector((state) => state.dispose);

  const { loadingBinCode, loadingCategories, scrapCategories, scrapBinCodes } = useAppSelector(state => state.list);

  const dispatch = useAppDispatch();

  const approveOrReject = (response: any) => {
    setOpen(true);
    dataRef.current = {
      userData: { ...dataRef.current.userData, response: response },
    };
  };

  const validationSchema = Yup.object().shape({
    remarks: Yup.string()
      .trim()
      .required("Remarks is required")
      .min(5, "Remarks must be atleast 5 characters long."),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    control,
    getValues,
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onConfirm = async () => {
    ///////////confirm//////

    confirmTaskRef.current.handleClose();
    approveOrReject(1);
  };

  const onDiscard = () => {
    //////////dis card////////
    confirmTaskRef.current.handleClose();
    approveOrReject(2);
  };

  const getStatus = (data: any) => {
    if (data.cnc_approved === 1) {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (data.cnc_approved === 2) {
      return (
        <div style={{ cursor: "not-allowed" }}>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    } else if (data.cnc_approved === 0) {
      return (
        <div
          style={{ cursor: "pointer" }}
          onClick={(e: any) => {
            confirmTaskRef.current.handleClickOpen();
            dataRef.current = {
              userData: data,
            };
          }}
        >
          <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>
            PENDING
          </p>
        </div>
      );
    }
  };

  const onSubmit = async (data: any) => {
    let inputData: any = dataRef.current.userData;
    let formData = {
      scrap_disposal_id: inputData.id,
      scrap_disposal_approval: inputData.response,
      remarks: data.remarks,
    };

    let response = await dispatch(getScrapDisposeApprovalCNC(formData));

    let responseData = response.payload.data ? response.payload.data : {};

    if (responseData.status === 200) {
      let tempData: any = disposeRequestsList.map((value: any) => {
        if (value.id === inputData.id) {
          return {
            ...value,
            cnc_remarks: data.remarks,
            cnc_approved: inputData.response,
          };
        }
        return value;
      });
      showToast("SUCCESS", "Request submitted successfully");
      setDisposeRequestsList(tempData);
      localStorage.setItem("committee_data", JSON.stringify(tempData));
    } else {
      showToast("ERROR", responseData.status || "Some Error Occurred...");
    }
    setOpen(false);
  };

  const columns: any = [
    {
      name: "Request No.",
      selector: "id",
      wrap: true,
      width: "120px",
      style: {
        minHeight: "70px",
      },
    },
    {
      name: "View Details",
      wrap: true,
      cell: (row: any) => {
        return (<div className="text-center">
          <ViewButton onClick={() => {
            navigate(PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
              state: {
                isPermanent: 1,
                scrap_disposal_id: row["id"],
              },
            });
          }} />
        </div>);
      }
    },
    {
      name: "C&C Remarks",
      selector: "cnc_remarks",
      wrap: true,
      cell: (row: any) => {
        return row["cnc_remarks"] ? (
          <div className="text-center">{row["cnc_remarks"]}</div>
        ) : (
          "N/A"
        );
      },
    },
    {
      name: "C&C Approval",
      wrap: true,
      cell: (row: any) => {
        return getStatus(row);
      },
    },
    {
      name: "Version Details",
      wrap: true,
      width: "200px",
      cell: (row: any) => {

          return <div style={{ display: "flex", flexDirection: "column" }}>{row['version_data']?.length ?
              row['version_data'].map((value: any, index: any) => {
                  return <p className="text-danger" style={{ fontWeight: "600", textDecoration: "underline", cursor: "pointer" }}
                      onClick={(e: any) => {
                        if (index === 0) {
                          navigate(
                              PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                              state: {
                                  "version_data": JSON.parse(value.dispose_data)
                              }
                          })
                      } else {
                          /////////////go to compare JSONS screen///////////////

                          let oldData = { ...JSON.parse(row['version_data'][index - 1].dispose_data) }.material_details;
                          let newData = { ...JSON.parse(row['version_data'][index].dispose_data) }.material_details;
              
                          oldData = oldData.map((value: any, index: any) => {
                              return {
                                  material_code: value.material_code,
                                  quantity: value.quantity,
                                  unit: value.unit,
                                  image_url: value.image_url,
                                  comments: value.comments,
                                  available_quantity: value.available_quantity,
                                  material_group: value.material_group,
                                  bincode: scrapBinCodes.filter((data:any,index:any)=> value.bincode == data.id)[0].bincode ,
                                  category:scrapCategories.filter((data:any,index:any)=> value.category == data.id)[0].category,
                                  material_description: value.material_description
                              }
                          })


                          newData = newData.map((value: any, index: any) => {
                              return {
                                  material_code: value.material_code,
                                  quantity: value.quantity,
                                  unit: value.unit,
                                  image_url: value.image_url,
                                  comments: value.comments,
                                  available_quantity: value.available_quantity,
                                  material_group: value.material_group,
                                  bincode: scrapBinCodes.filter((data:any,index:any)=> value.bincode == data.id)[0].bincode ,
                                  category:scrapCategories.filter((data:any,index:any)=> value.category == data.id)[0].category,
                                  material_description: value.material_description
                              }
                          })

                          navigate(
                              PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW, {
                              state: {
                                  "version_data": { ...JSON.parse(row['version_data'][index].dispose_data) },
                                  "version_details":{
                                      "new_data":newData,
                                      "old_data":oldData
                                  },
                                  "is_version_comparision": true
                              }
                          })
                      }
                      }}>{'Version ' + (index + 1)}</p>
              }) : "N/A"}
          </div>
      }

  }
  ];

  const getList = async (page: number) => {
    let formData: any = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (requestNo) {
      formData["scrap_disposal_id_params"] = requestNo;
    }

    let response = await dispatch(getScrapDisposeRequestsList(formData));

    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setDisposeRequestsList(listData.data.dispose_list);
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    setDisposeRequestsList(scrapDisposeRequestsList);
  }, [scrapDisposeRequestsList]);

  useEffect(() => {
    dispatch(listBinCode({}));
    dispatch(listCategory({}));
    getList(page);
  }, []);

  const handlePageChange = (e: any, value: any) => {
    getList(value);
  };

  const downloadSheet = async () => {
    let formData: any = {};
    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }


    if (requestNo) {
      formData["scrap_disposal_id_params"] = requestNo;
    }


    let response = await dispatch(downloadScrapDisposalList(formData));

    if (response.payload.data.data) {
      var iframe = document.createElement("iframe");
      iframe.id = "1";
      iframe.style.display = "none";
      document.body.appendChild(iframe);
      iframe.src = response.payload.data.data;
    }
    console.log("data log");
  };

  return (
    <React.Fragment>
      {loadingScrapDisposeRequestsList || loadingScrapDisposeApprovalCNC || loadingBinCode || loadingCategories ? (
        <Loading loading={true} />
      ) : (
        ""
      )}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      ><Grid container style={{
        minWidth: "95vw",
      }} spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">
              Scrap Dispose Requests for Approval
            </h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue: any) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Request Number"
              type="text"
              value={requestNo}
              onChange={(e: any) => {
                setRequestNo(e.target.value);
              }}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "25px" }}
          >
            <MyButton
              label={"Search"}
              type="button"
              onClick={() => {
                getList(1);
              }}
            />
          </Grid>

          <Grid item xs={12} lg={12} sm={12} style={{ marginLeft: "5px", marginRight: "5px" }}>
            <Datatable columns={columns} data={disposeRequestsList} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {disposeRequestsList.length ? (
              <Pagination
                page={page}
                onChange={(event: any, value: any) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalDisposeRequestsCount / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>

      <Suspense fallback={<Loading />}>
        <ConfirmDialog
          ref={confirmTaskRef}
          description={"Are you sure you want to Approve/Reject?"}
          title={""}
          confirm={"Approve"}
          discard={"Reject"}
          onConfirm={onConfirm}
          onDiscard={onDiscard}
        ></ConfirmDialog>
      </Suspense>

      <Suspense fallback={<Loading />}>
        <Dialog
          className="dialogAlertStyle"
          open={open}
          onClose={(e) => setOpen(false)}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
            <img onClick={(e) => {
              setOpen(false)
            }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
          </div>
          <DialogTitle id="alert-dialog-title">
            <p className="dialog_title h4">Remarks Section</p>
          </DialogTitle>

          <DialogActions className="dialogactions">
            <Grid container style={{ marginTop: "-20px", padding: "5px 0px" }}>
              <form onSubmit={handleSubmit(onSubmit)}>
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  lg={12}
                  style={{ minWidth: "400px" }}
                >
                  <Input
                    style={{ width: "350px" }}
                    required={true}
                    multiline={true}
                    fullWidth={true}
                    autoFocus={true}
                    label="Remarks"
                    type="text"
                    autoComplete="on"
                    onChange={(e: any) => {
                      setValue("remarks", e.target.value);
                    }}
                    error={errors.remarks ? true : false}
                    errormessage={errors.remarks?.message}
                    minRows={3}
                  />
                </Grid>

                <Grid item xs={12} sm={12} md={12} lg={12}>
                  <MyButton
                    type="submit"
                    fullWidth={true}
                    label="Submit"
                    style={{
                      backgroundColor: CONSTANTS.COLORS.GREEN,
                    }}
                  />
                </Grid>
              </form>
            </Grid>
          </DialogActions>
        </Dialog>
      </Suspense>
    </React.Fragment>
  );
};

export default ScrapDisposeRequestsCNC;
