import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import {
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  Paper,
} from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import { departmentMasterList } from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton from "../../components/button";
import {
  getCNCPhysicalDisposeView,
  getPhysicalDisposeApprovalCNC,
  getPhysicalDisposeRequestsList,
  getScrapDisposeApprovalCNC,
  getScrapDisposeRequestsList,
  getScrapPhysicalDisposeView,
} from "../../store/slices/dispose";

import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  getMaterialDepositTransactionLogs,
  getMaterialDisposeTransactionLogs,
  getMovementList,
} from "../../store/slices/inventory";

const OFFSET = 5;

const TransactionLogsDispose = () => {
  const navigate = useNavigate();
  let [page, setPage] = useState(1);

  const confirmTaskRef = useRef();
  const dataRef = useRef();
  const [userData, setUserData] = useState([]);

  let [transactionLogs, setTransactionLogs] = useState([]);
  let [dateRange, setDateRange] = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [requestNo, setRequestNo] = useState();
  let [materialCode, setMaterialCode] = useState();

  const { totalMaterialDisposeTransactionLogs, loadingMovementList } =
    useAppSelector((state) => state.inventory);

  const dispatch = useAppDispatch();

  const columns = [
    {
      name: "Created Date & Time",
      wrap: true,
      width: "230px",
      cell: (row) => {
        return (
          <div>
            {row["created_on"]
              ? moment(row["created_on"]).format("DD/MM/YYYY") +
                " | " +
                moment(row["created_on"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Request No.",
      selector: "id",
      wrap: true,
      width: "170px",
    },
    {
      name: "Disposal Id",
      selector: "scrap_disposal_id",
      wrap: true,
      width: "170px",
    },
    {
      name: "User Type",
      selector: "role_name",
      wrap: true,
      width: "170px",
    },
    // {
    //   name: "Name",
    //   selector: "user_name",
    //   wrap: true,
    //   width: "170px",
    // },
    // {
    //   name: "UOM",
    //   selector: "remarks",
    //   wrap: true,
    //   width: "170px",
    // },
    {
      name: "Remarks",
      selector: "remarks",
      wrap: true,
      width: "170px",
    },
    {
      name: "Approval Action",
      selector: "approval_action",
      wrap: true,
      width: "170px",
    },
    // {
    //   name: "Quantity Moved",
    //   selector: "bincode",
    //   wrap: true,
    //   width: "170px",
    // },
    // {
    //   name: "Location (Bin Code)",
    //   selector: "store_weighment_required",
    //   wrap: true,
    //   width: "170px",
    // },
    // {
    //   name: "Weighment Required",
    //   selector: "store_weighment_category",
    //   wrap: true,
    //   width: "170px",
    // },
    // {
    //   name: "Weighment Slip No.",
    //   selector: "bincode_name",
    //   wrap: true,
    //   width: "170px",
    // },
    
  ];

  const getList = async (page) => {
    let formData = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (requestNo) {
      formData["disposal_id"] = requestNo;
    }
    if (materialCode) {
      formData["material_code"] = materialCode;
    }

    let response = await dispatch(getMaterialDisposeTransactionLogs(formData));

    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setTransactionLogs(listData.data.disposalApprovalLogs);
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    getList(page);
  }, []);

  useEffect(() => {
    getList(1);
  }, [materialCode, dateRange, requestNo]);

  const handlePageChange = (e, value) => {
    getList(value);
  };

  let id1, id2;

  const downloadSheet = () => {
    alert("Pending");
  };

  return (
    <React.Fragment>
      {loadingMovementList ? <Loading loading={true} /> : ""}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      ><Grid container style={{
        minWidth: "95vw",
    }}spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">
              Transaction Logs of Material Dispose
            </h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Request Number"
              type="text"
              value={requestNo}
              onChange={(e) => {
                if(/^(0|[1-9][0-9]*)$/g.test(e.target.value)){
                  setRequestNo(e.target.value);
                }else{
                  setRequestNo(e.target.value.replace(/[^0-9]/g, ''))
                }
              }}
            />
          </Grid>
          {/* <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Material Code"
              type="text"
              onChange={(e) => {
                clearTimeout(id2);
                id2 = setTimeout(() => setMaterialCode(e.target.value), 1000);
              }}
            />
          </Grid> */}

          <Grid item xs={12} lg={12} sm={12}>
            <Datatable columns={columns} data={transactionLogs} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {transactionLogs?.length ? (
              <Pagination
                page={page}
                onChange={(event, value) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(
                  totalMaterialDisposeTransactionLogs / OFFSET
                )}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>
    </React.Fragment>
  );
};

export default TransactionLogsDispose;
