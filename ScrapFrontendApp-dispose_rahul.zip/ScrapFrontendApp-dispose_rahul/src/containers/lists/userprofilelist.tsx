import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { managerUserList } from "../../store/slices/list";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";

/////////////////ICONS///////////////////////////
import MyButton from "../../components/button";
import { CONSTANTS } from "../../constants/constants";
import { approveProfile, approveSignup } from "../../store/slices/users";
///////////////////////////////////////////////


const OFFSET = 5;

const UserProfileLists = () => {
    const confirmTaskRef: any = useRef();
    const dataRef: any = useRef();
    let [page, setPage]: any = useState(1);

    const [list, setList]: Array<any> = useState([]);

    const dispatch = useAppDispatch();
    const { loadingManagerUserList, managerUsersListData, managerUsersListTotalCount } = useAppSelector(state => state.list);
    const { loadingApproveProfile, loadingApproveSignup } = useAppSelector(state => state.user);


    const getList = async (page: number) => {

        let userData = useLocalStorage.getItem("userData");

        let formData = {
            page_number: page - 1,
            offset: OFFSET,
            list_type: 1,
            user_id: userData.id
        }

        let response = await dispatch(managerUserList(formData));

        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {
            setPage(page)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    const handlePageChange = (e: any, value: any) => {
        getList(value);
    }


    useEffect(() => {
        getList(page);
    }, [])


    useEffect(() => {
        setList(managerUsersListData);
    }, [managerUsersListData])

    const approveOrReject = async (action: number) => {

        //////////1:Approve
        //////////2:Reject

        confirmTaskRef.current.handleClose();

        let userData = dataRef.current;


        let responseData: any = {};
        if (userData.type === "2") {
            let formData = {
                id: userData.data.user_id,
                profile_approval: action
            }
            responseData = await dispatch(approveProfile(formData));
        } else {
            let formData = {
                user_id: userData.data.user_id,
                signup_approval: action
            }
            responseData = await dispatch(approveSignup(formData));
        }
        if (responseData?.payload?.data?.status === 200) {

            let type = dataRef.current.type;
            let user_id = dataRef.current.data.user_id;

            let newList = list.map((value: any) => {
                if (value.user_id === user_id && type === "1") {
                    return { ...value, signup_approved: action }
                }
                else if (value.user_id === user_id && type === "2") {
                    return { ...value, profile_approved: action }
                }
                return value;
            })
            setList(newList)
        } else {
            showToast('ERROR', responseData?.payload?.data?.message ? responseData.payload.data.message : "Some Error Occurred")
        }
    }

    const onConfirm = () => {
        approveOrReject(1);
    }

    const onDiscard = () => {
        approveOrReject(2);
    }


    const TableIcons = (props: any) => {

        let rowData = props.row;
        let type = props.type;


        let requestType = 0;


        if (type == "1") {
            requestType = rowData.signup_approved;
        } else {
            requestType = rowData.profile_approved;
        }

        const handleOpen = (type:number ) => {
          //  console.log("data is .....",type, rowData)
            dataRef.current = {
                type: type,
                data: rowData
            }
            confirmTaskRef.current.handleClickOpen();
        }

        return (
            <>
                {requestType === 3 && <div>
                    <MyButton style={{ backgroundColor: CONSTANTS.COLORS.INFO }}
                        label={'Pending'}
                        onClick={()=>handleOpen(type)} />
                </div>}

                {requestType === 1 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        <MyButton style={{ backgroundColor: CONSTANTS.COLORS.GREEN, pointerEvents: "none" }}
                            label={'Approved'}

                        />
                    </div>
                </div>}

                {requestType === 2 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        <MyButton style={{ backgroundColor: CONSTANTS.COLORS.RED, pointerEvents: "none" }}
                            label={'Rejected'}

                        />
                    </div>
                </div>}

                {requestType === 0 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        <MyButton style={{ backgroundColor: CONSTANTS.COLORS.PRIMARY, pointerEvents: "none" }}
                            label={'No Actions'}
                        />
                    </div>
                </div>}

            </>
        )
    }


    const columns: any = [
        {
            name: "Employee Id",
            selector: "employee_id",
            wrap: true,
        },
        {
            name: "Employee Email",
            selector: "user_email",
            wrap: true,
        },
        {
            name: "Authentication Status",
            selector: "signup_approved",
            wrap: true,
            cell: (row: any) => <TableIcons row={row} type="1" />
        },
        {
            name: "Modification Status",
            selector: "profile_approved",
            wrap: true,
            cell: (row: any) => <TableIcons row={row} type="2" />
        },
    ];

    return <React.Fragment>
        {loadingManagerUserList || loadingApproveProfile || loadingApproveSignup ? <Loading loading={true} /> : ""}
        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}>
            <Grid container style={{
                minWidth: "95vw",
            }}>

                <Grid item xs={12} lg={12} sm={12}>
                    <h3 className="text-center pb-3">Request for Approval List:</h3>
                </Grid>

                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={list}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                  { list?.length ? <Pagination
                        page={page}
                        onChange={(event: any, value: any) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(managerUsersListTotalCount / OFFSET)}
                    />:""}
                </Grid>

            </Grid>
        </Container>





        <Suspense fallback={<Loading />}>
            <ConfirmDialog
                ref={confirmTaskRef}
                description={"Are you sure you want to Approve/Reject?"}
                title={""}
                confirm={"Approve"}
                discard={"Reject"}
                onConfirm={onConfirm}
                onDiscard={onDiscard}
            ></ConfirmDialog>
        </Suspense>
    </React.Fragment>




}

export default UserProfileLists;