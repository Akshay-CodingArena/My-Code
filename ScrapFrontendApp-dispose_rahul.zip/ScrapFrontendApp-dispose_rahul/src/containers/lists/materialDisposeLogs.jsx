import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import {
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  Paper,
} from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import { departmentMasterList } from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton from "../../components/button";
import {
  getCNCPhysicalDisposeView,
  getPhysicalDisposeApprovalCNC,
  getPhysicalDisposeRequestsList,
  getScrapDisposeApprovalCNC,
  getScrapDisposeRequestsList,
  getScrapPhysicalDisposeView,
} from "../../store/slices/dispose";

import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  getBinCodesByMcode,
  getInventoryList,
  getMaterialDisposeLogs,
} from "../../store/slices/inventory";
import { scrapListSheetDownload } from "../../store/slices/admin";

const OFFSET = 5;

const MaterialDisposeLogs = () => {
  const navigate = useNavigate();
  let [page, setPage] = useState(1);

  const confirmTaskRef = useRef();
  const dataRef = useRef();
  let [open, setOpen] = useState(false);
  const [userData, setUserData] = useState([]);

  let [materialDisposeLogs, setMaterialDisposeLogs] = useState([]);
  let [committeeDetails, setCommitteeDetails] = useState([]);
  let [dateRange, setDateRange] = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [requestNo, setRequestNo] = useState();

  const {
    loadingScrapDisposeRequestsList,
    scrapDisposeRequestsList,
    totalDisposeRequestsCount,
    loadingScrapDisposeApprovalCNC,
  } = useAppSelector((state) => state.dispose);
  const { totalMaterialDisposeLogs } = useAppSelector(
    (state) => state.inventory
  );

  const dispatch = useAppDispatch();

  const getStatus = (status) => {
    if (status === 1) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>
            APPROVED
          </p>
        </div>
      );
    } else if (status === 2) {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>
            REJECTED
          </p>
        </div>
      );
    } else {
      return (
        <div>
          <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>
            PENDING
          </p>
        </div>
      );
    }
  };
  const committee_columns = [
    {
      name: "",
      selector: "user_email",
      wrap: true,
      width: "225px",
    },
    {
      name: "Remarks ",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div>
            {row["committee_remarks"] ? row["committee_remarks"] : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Approval Status",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return getStatus(row.approval_status);
      },
    },
  ];
  const columns = [
    {
      name: "Request No.",
      selector: "id",
      wrap: true,
      width: "170px",
    },
    {
      name: "View Details",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div className="text-center">
            <b
              style={{ color: CONSTANTS.COLORS.INFO, cursor: "pointer" }}
              onClick={(e) => {
                navigate(PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_REVIEW, {
                  state: {
                    scrapId: row["id"],
                    mode: "view",
                  },
                });
              }}
            >
              View Details
            </b>
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "cnc_remarks",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return <div>{row["cnc_remarks"] ? row["cnc_remarks"] : "N/A"}</div>;
      },
    },
    {
      name: "C&C Head Approval",
      selector: "cnc_approved",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return getStatus(row.cnc_approved);
      },
    },
    {
      name: "Date/ Time",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div>
            {row["cnc_approval_date"]
              ? moment(row["cnc_approval_date"]).format("DD/MM/YYYY") +
                " | " +
                moment(row["cnc_approval_date"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Actual date of inspection",
      selector: "",
      wrap: true,
      width: "280px",
      cell: (row) => {
        return (
          <div>
            {row["actual_inspection_date"]
              ? moment(row["actual_inspection_date"]).format("DD/MM/YYYY") +
                " | " +
                row['actual_inspection_time']
              : "N/A"}
          </div>
        );
      },

    },
    {
      name: "Approval from all committee members",
      wrap: true,
      width: "300px",
      cell: (row) => {
        return getStatus(row.committee_approval);
      },
    },
    {
      name: "Details of approval from all committe members",
      wrap: true,
      width: "350px",
      cell: (row) => {
        return (
          <div className="text-center">
            <b
              style={{ color: CONSTANTS.COLORS.INFO, cursor: "pointer" }}
              onClick={(e) => {
                setOpen(true);
                setCommitteeDetails(row["committee_data"]);
              }}
            >
              View Details
            </b>
          </div>
        );
      },
    },
  ];

  const getList = async (page) => {
    let formData = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (requestNo) {
      formData["disposal_id"] = requestNo;
    }

    let response = await dispatch(getMaterialDisposeLogs(formData));

    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setMaterialDisposeLogs(listData.data.dispose_list);
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    setMaterialDisposeLogs(scrapDisposeRequestsList);
  }, [scrapDisposeRequestsList]);

  useEffect(() => {
    getList(page);
  }, []);

  useEffect(() => {
    getList(1);
  }, [dateRange, requestNo]);

  const handlePageChange = (e, value) => {
    getList(value);
  };

  const downloadSheet = () => {
    alert("Pending");
  };

  return (
    <React.Fragment>
      {loadingScrapDisposeRequestsList || loadingScrapDisposeApprovalCNC ? (
        <Loading loading={true} />
      ) : (
        ""
      )}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      ><Grid container style={{
        minWidth: "95vw",
    }}spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">Logs of Material Dispose</h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Request No."
              type="text"
              value={requestNo}
              onChange={(e) => {
                if(/^(0|[1-9][0-9]*)$/g.test(e.target.value)){
                  setRequestNo(e.target.value);
                }else{
                  setRequestNo(e.target.value.replace(/[^0-9]/g, ''))
                }
              }}
            />
          </Grid>

          {/* <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "25px" }}
          >
            <MyButton
              label={"Search"}
              type="button"
              onClick={() => {
                getList(1);
              }}
            />
          </Grid> */}

          <Grid item xs={12} lg={12} sm={12}>
            <Datatable columns={columns} data={materialDisposeLogs} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {materialDisposeLogs.length ? (
              <Pagination
                page={page}
                onChange={(event, value) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalMaterialDisposeLogs / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>

      <Suspense fallback={<Loading />}>
        <Dialog
          className="dialogAlertStyle"
          open={open}
          onClose={(e) => setOpen(false)}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            <p className="dialog_title h3">Committee Details</p>
          </DialogTitle>
          <DialogContent>
            <DialogContentText
              id="alert-dialog-description"
              className="text-center"
            >
              <Grid item xs={12} lg={12} sm={12}>
                <Datatable
                  columns={committee_columns}
                  data={committeeDetails}
                />
              </Grid>
            </DialogContentText>
          </DialogContent>
        </Dialog>
      </Suspense>
    </React.Fragment>
  );
};

export default MaterialDisposeLogs;
