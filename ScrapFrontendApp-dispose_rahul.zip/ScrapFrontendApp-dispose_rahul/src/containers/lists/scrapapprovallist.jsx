import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";

/////////////////ICONS///////////////////////////
import MyButton, { ViewButton } from "../../components/button";
import { CONSTANTS } from "../../constants/constants";
import { approveProfile, approveSignup } from "../../store/slices/users";
import { getRequestScrapList, scrapApproval, viewScrapRequest } from "../../store/slices/list";
///////////////////////////////////////////////

import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import Input from "../../components/input";
import moment from "moment";
import { useForm, Controller } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import Filters from "../../components/filters";
import { generateMRNSheet } from "../../store/slices/requests";
import DownloadButton from "../../components/downloadButton";
import CrossImage from "../../assets/images/cross.png";

const OFFSET = 5;

const RequestScrapList = () => {
    // const [state, setState] = 
    const [state, setState] = useState({
        date: [
            moment().startOf('month').format('YYYY/MM/DD'),
            moment(new Date()).format('YYYY/MM/DD')
        ]
    })
    const confirmTaskRef = useRef();
    const navigate = useNavigate()
    const dataRef = useRef();
    const [open, setOpen] = useState(false);
    const actionTaken = useRef("")
    let [page, setPage] = useState(1);
    const [remarks, setRemarks] = useState("")
    const [list, setList] = useState([]);
    const dispatch = useAppDispatch();

    const { loadingScrapList, scrapRequestlist, scrapListTotalCount, loadingScrapApproval, scrapRequestView } = useAppSelector(state => state.list);
    const { loadingGenerateMRN } = useAppSelector(state => state.scrapRequests);

    const validationSchema = Yup.object().shape({
        remarks: Yup.string().trim()
            .required('Remarks is required')
            .min(10, 'Remarks must be atleast 10 characters long.'),
    });

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        control,
        getValues
    } = useForm({
        resolver: yupResolver(validationSchema),
    });



    useEffect(() => {
        setList(scrapRequestlist)
    }, [scrapRequestlist])


    const getList = async (page) => {

        let userData = useLocalStorage.getItem("userData");
        let formData = {
            page_number: page - 1,
            offset: OFFSET,
            list_type: 2,
            user_id: userData.id
        }

        let response = await dispatch(getRequestScrapList(formData));

        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {
            setPage(page)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    const handlePageChange = (e, value) => {
        setPage(value);
    }


    const approveOrReject = async (action) => {
        //////////1:Approve
        //////////2:Reject
        dataRef.current = { ...dataRef.current, actionType: action };
        console.log(dataRef.current);
        confirmTaskRef.current.handleClose();
        setOpen(true)
    }

    const onConfirm = () => {
        approveOrReject(1);
    }

    const onDiscard = () => {
        approveOrReject(2);
    }

    useEffect(() => {
        console.log("Scrap Request is", scrapRequestView)
        if (actionTaken.current) {
            console.log("Scrap Request is captured", scrapRequestView)
            useLocalStorage.setItem("scrapRequest", JSON.stringify(scrapRequestView[0]))
            if (actionTaken.current === "EDIT") {
                navigate(PATH.PRIVATE.SCRAP_DEPOSIT, { state: { isPermanent: 1 } })
            } else {
                navigate(PATH.PRIVATE.SCRAP_DEPOSIT_VIEW)
            }
            //      navigate(PATH.PRIVATE.SCRAP_DEPOSIT, {state:{action:actionTaken.current}})
            actionTaken.current = ""
        }
    }, [scrapRequestView]);

    const generateMRN = async (scrap_id) => {
        let result = await dispatch(generateMRNSheet({ scrap_id }));
        if (result.payload.data.status === 200) {
            window.open(result.payload.data.data, "_blank")
        } else {
            showToast("ERROR", result.payload.data.message)
        }
    }

    const TableIcons = (rowData) => {
        let role = rowData.role
        let requestType

        if (role === "MANAGER") {
            requestType = rowData.row.ApprovalFromManager
        }
        else if (role === "HOD") {
            requestType = rowData.row.ApprovalFromHOD
        }
        else if (role === "CNCHead") {
            requestType = rowData.row.ApprovalFromCNCHead
        } else if (role === "StoreManager") {
            requestType = rowData.row.store_approved
        }

        const handleOpenConfirmDialog = () => {
            dataRef.current = {
                scrapData: rowData.row
            };
            confirmTaskRef.current.handleClickOpen()
        }

        return (
            <>
                {requestType === 1 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        {/* <MyButton style={{ backgroundColor: CONSTANTS.COLORS.GREEN, pointerEvents: "none" }}
                            label={'Approved'}

                        /> */}
                        <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>APPROVED</p>
                    </div>
                </div>}

                {requestType === 2 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        {/* <MyButton style={{ backgroundColor: CONSTANTS.COLORS.RED, pointerEvents: "none" }}
                            label={'Rejected'}

                        /> */}
                        <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>REJECTED</p>
                    </div>
                </div>}

                {requestType === 0 && <div>
                    {rowData.enableAction ?
                        <div>
                            <MyButton style={{ backgroundColor: CONSTANTS.COLORS.INFO }}
                                onClick={handleOpenConfirmDialog}
                                label={'Pending'}
                            />
                        </div> :
                        <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>PENDING</p>
                    }
                </div>}

            </>
        )
    }


    const columns = [
        {
            name: "Request No.",
            selector: "requestNo",
            width: '150px',
            style: {
                minHeight: "120px"
            },
            wrap: true,
        },
        {
            name: "Date | Time",
            selector: "created_on",
            width: '200px',
            wrap: true,
            cell: (row) => {
                return <div className="text-center" >
                    {row['created_on'] ? moment(row['created_on']).format('DD/MM/YYYY') + " | " + moment.utc(row['created_on']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "Description",
            selector: "requestNo",
            wrap: true,

            width: '200px',
            cell: (row) => {
                return <ViewButton label={"View"} onClick={() => {
                    dispatch(viewScrapRequest({ scrap_id: row.requestNo, isPermanent: "1" }))
                    actionTaken.current = "VIEW"
                }} />
            }

        },
        {
            name: "Edit",
            selector: "created_on",
            wrap: true,
            cell: (row) => {
                return <MyButton disabled={true} style={{ backgroundColor: "grey", color: "white" }} label={"Edit"} onClick={() => {
                    dispatch(viewScrapRequest({ scrap_id: row.requestNo, isPermanent: "1" }))
                    actionTaken.current = "EDIT"
                }} />
            }

        },

        {
            name: "Request Submitted By",
            selector: "employee_id",
            wrap: true,

            width: '200px',
            cell: (row) => {
                return <div className="text-center">
                    {`${row.first_name ?? ""} ${row.last_name ?? ""} ${row.last_name ? "(" : ""}${row.employee_id}${row.last_name ? ')' : ''}` ?? "N/A"}
                </div>
            }
        },

        {
            name: "Updated Date by Manager",
            selector: "UpdatedDateByManager",
            minWidth: "200px",
            wrap: true,
            cell: (row) => {
                return <div className="text-center" >
                    {row['UpdatedDateByManager'] ? row['UpdatedDateByManager'] === "NOW" ? "Just Now" : moment(row['UpdatedDateByManager']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByManager']).format('HH:mm:ss') : "N/A"}
                </div>
            }
        },

        {
            name: "Actions",
            selector: "ApprovalFromManager",
            minWidth: "175px",
            wrap: true,
            cell: (row) => {
                return <TableIcons row={row} role={"MANAGER"} enableAction={true} />
            }
        },
        {
            name: "Manager Remarks",
            selector: "RemarksByManager",
            minWidth: "150px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarksByManager ? row.RemarksByManager : "N/A"}
                </div>
            }
        },

        {
            name: "Updated Date by HOD",
            selector: "UpdatedDateByHOD",
            wrap: true,

            width: '200px',
            cell: (row) => {
                return <div className="text-center" >
                    {row['UpdatedDateByHOD'] ? moment(row['UpdatedDateByHOD']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByHOD']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "Approval by HOD",
            selector: "ApprovalFromHOD",
            wrap: true,

            width: '200px',
            cell: (row) => {
                return <TableIcons row={row} role={"HOD"} />
            }

        },
        {
            name: "HOD Remarks",
            selector: "RemarksByHOD",
            minWidth: "150px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarksByHOD ? row.RemarksByHOD : "N/A"}
                </div>
            }
        },

        {
            name: "Approval from Store Manager",
            selector: "store_approved",
            minWidth: "220px",
            wrap: true,
            cell: (row) => {
                return <TableIcons row={row} role={"StoreManager"} />
            }
        },

        {
            name: "Updated Date by Store Manager",
            selector: "store_approval_date",
            wrap: true,

            width: '250px',
            cell: (row) => {
                return <div className="text-center" >
                    {row['store_approval_date'] ? moment(row['store_approval_date']).format('DD/MM/YYYY') + " | " + moment(row['store_approval_date']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        // {
        //     name: "Store Manager Remarks",
        //     selector: "RemarksByStoreManager",
        //     minWidth: "150px",
        //     wrap: true,
        //     cell: (row) => {
        //         return <div>
        //             {row.RemarksByStoreManager ? row.RemarksByStoreManager : "N/A"}
        //         </div>
        //     }
        // },


        {
            name: "Approval from C&C HEAD",
            selector: "ApprovalFromCNCHead",
            minWidth: "200px",
            wrap: true,
            cell: (row) => {
                return <TableIcons row={row} role={"CNCHead"} />
            }
        },

        {
            name: "Updated Date by C&C HEAD",
            selector: "UpdatedDateByCNCHead",
            wrap: true,

            width: '220px',
            cell: (row) => {
                return <div className="text-center" >
                    {row['UpdatedDateByCNCHead'] ? moment(row['UpdatedDateByCNCHead']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByCNCHead']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "C&C HEAD Remarks",
            selector: "RemarkByCNCHead",
            minWidth: "200px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarkByCNCHead ? row.RemarkByCNCHead : "N/A"}
                </div>
            }
        },
        {
            name: "MRN Sheet",
            selector: "DownloadMRN",
            minWidth: "175px",
            wrap: true,
            cell: (row) => {
                return <DownloadButton enable={row.ApprovalFromHOD == 1 ? true : false} onClick={() =>
                    row.ApprovalFromHOD == 1 ? generateMRN(row.requestNo) : ""
                } />
            }
        },
    ]

    // let userData = useLocalStorage.getItem("userData");
    // const roleId = userData.role_id

    // if(roleId === "3" || roleId === "4"){
    //     columns.push( {
    //         name: "Remarks",
    //         selector: "RemarksByHOD",
    //         minWidth: "350px",
    //         wrap: true,
    //         cell: (row) => {
    //             return <div>
    //                {row.RemarksByHOD? row.RemarksByHOD :"N/A"}
    //             </div>
    //         }
    //     })
    //     columns.push(    
    //     {
    //         name: "Actions",
    //         selector: "ApprovalFromHOD",
    //         minWidth: "175px",
    //         wrap: true,
    //         cell: (row) => {
    //             return <TableIcons row={row} role={"HOD"} />
    //         }
    //     })
    // } 

    // if(roleId === "4"){
    //     columns.push( {
    //         name: "Remarks",
    //         selector: "RemarkByCNCHead",
    //         minWidth: "350px",
    //         wrap: true,
    //         cell: (row) => {
    //             return <div>
    //                {row.RemarksByHOD? row.RemarksByHOD :"N/A"}
    //             </div>
    //         }
    //     })
    //     columns.push(    
    //     {
    //         name: "Actions",
    //         selector: "ApprovalFromCNCHead",
    //         minWidth: "175px",
    //         wrap: true,
    //         cell: (row) => {
    //             return <TableIcons row={row} role={"CNCHead"}/>
    //         }
    //     })
    // }


    const onSubmit = async (data) => {

        let scrapData = dataRef.current.scrapData;
        let userData = useLocalStorage.getItem("userData");

        let formData = {
            scrap_id: scrapData.requestNo,
            scrap_deposit_approval: dataRef.current.actionType.toString(),
            role_id: userData.role_id,
            remarks: data.remarks
        }

        let responseData = await dispatch(scrapApproval(formData));


        if (responseData?.payload?.data?.status === 200) {
            let newList = list.map((value) => {
                if (value.requestNo === scrapData.requestNo) {
                    return { ...value, ApprovalFromManager: dataRef.current.actionType, RemarksByManager: data.remarks, UpdatedDateByManager: "NOW" }
                }
                return value

            })


            setList(newList);
        } else {
            showToast('ERROR', responseData?.payload?.data?.message || 'Some Error Occurred...');
        }
        setOpen(false);
    }

    return <React.Fragment>
        {loadingScrapList || loadingScrapApproval || loadingGenerateMRN ? <Loading loading={true} /> : ""}
        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}>
            <Grid container style={{
                minWidth: "95vw",
            }}>

                <Grid item xs={12} lg={12} sm={12}>
                    <h3 className="text-center pb-3">Material Request's List:</h3>
                </Grid>
                <Filters page={page} state={state} setPage={setPage} setState={setState} listType={2} listCategory={"MANAGER"} />

                {/* <Filters page={page} setPage={setPage} state={state} setState={setState} /> */}

                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={list}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {list?.length ? <Pagination
                        page={page}
                        onChange={(event, value) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(scrapListTotalCount / OFFSET)}
                    /> : ""}
                </Grid>

            </Grid>
        </Container>



        <Suspense fallback={<Loading />}>
            <Dialog
                className='dialogAlertStyle'
                open={open}
                onClose={(e) => setOpen(false)}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
                    <img onClick={(e) => {
                        setOpen(false)
                    }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
                </div>

                <DialogTitle id="alert-dialog-title">
                    <p className="dialog_title h4">
                        Remarks Section
                    </p>
                </DialogTitle>


                <DialogActions
                    className="dialogactions"
                >
                    <Grid container style={{ marginTop: "-20px", padding: "5px 0px" }}>
                        <form onSubmit={handleSubmit(onSubmit)}>

                            <Grid item xs={12} sm={12} md={12} lg={12} style={{ minWidth: "400px" }}>


                                <Input
                                    style={{ width: "350px" }}
                                    required={true}
                                    multiline={true}
                                    fullWidth={true}
                                    autoFocus={true}
                                    label="Remarks"
                                    type="text"
                                    autoComplete='on'
                                    onChange={(e) => {
                                        setValue('remarks', e.target.value);
                                    }}
                                    error={errors.remarks ? true : false}
                                    errormessage={errors.remarks?.message}
                                    minRows={3}
                                />


                            </Grid>

                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                <MyButton type="submit"
                                    fullWidth={true}
                                    label="Submit" style={{
                                        backgroundColor: CONSTANTS.COLORS.GREEN
                                    }} />
                            </Grid>
                        </form>


                    </Grid>
                </DialogActions>
            </Dialog>

        </Suspense>


        <Suspense fallback={<Loading />}>
            <ConfirmDialog
                ref={confirmTaskRef}
                description={"Are you sure you want to Approve/Reject?"}
                title={""}
                confirm={"Approve"}
                discard={"Reject"}
                onConfirm={onConfirm}
                onDiscard={onDiscard}
            ></ConfirmDialog>
        </Suspense>
    </React.Fragment>


}

export default RequestScrapList;