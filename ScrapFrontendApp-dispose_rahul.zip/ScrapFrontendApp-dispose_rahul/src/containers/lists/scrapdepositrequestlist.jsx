import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import MyButton, { EditButton, ViewButton } from "../../components/button";
import { CONSTANTS } from "../../constants/constants";
import { approveProfile, approveSignup } from "../../store/slices/users";
import { getRequestScrapList, viewScrapRequest } from "../../store/slices/list";
///////////////////////////////////////////////
import moment from "moment";
import { useNavigate } from "react-router";
import { PATH } from "../../paths/path";
import DateRange from "../../components/filters/DateRange";
import DepartmentFilter from "../../components/filters/Department";
import Searchbar from "../../components/filters/Searchbar";
import Filters from "../../components/filters";
import { useLocation } from "react-router-dom";
import EditIcon from "../../assets/images/icons/edit.png"
import { generateMRNSheet } from "../../store/slices/requests";
import DownloadIcon from "../../assets/images/icons/MRN_Download.png"
import DownloadButton from "../../components/downloadButton";
import ImageDialog from "../../components/ImageModal";

const OFFSET = 5;

const ScrapDepositRequestList = () => {
    const [state, setState] = useState({
        date: [
            moment().startOf('month').format('YYYY/MM/DD'),
            moment(new Date()).format('YYYY/MM/DD')
        ]
    })
    const dataRef = useRef();
    const { search } = useLocation();
    let [page, setPage] = useState(1);
    const dispatch = useAppDispatch();
    const navigate = useNavigate()
    const actionTaken = useRef("")
    const requestEdited = useRef("")
    const req_num = useRef("")
    const req_date = useRef("")
    const [filterList, setFilterList] = useState({})

    const ImageRef  = useRef();

    const { loadingScrapList, scrapRequestlist, scrapListTotalCount, scrapRequestView } = useAppSelector(state => state.list);
    const { loadingGenerateMRN } = useAppSelector(state => state.scrapRequests);

    const getList = async (page) => {

        let userData = useLocalStorage.getItem("userData");

        let formData =
        {
            page_number: page - 1,
            offset: OFFSET,
            list_type: 1,
            user_id: userData.id
        }

        let response = await dispatch(getRequestScrapList(formData));

        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {
            setPage(page)
            // window.location.href+= "?page="+page
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    const handlePageChange = (e, value) => {
        setPage(value)
    }


    useEffect(() => {
        console.log("Scrap Request is", scrapRequestView)
        if (actionTaken.current) {
            console.log("Scrap Request is captured", scrapRequestView)
            useLocalStorage.setItem("scrapRequest", JSON.stringify(scrapRequestView[0]))
            let permanent_id = requestEdited.current
            let r_num = req_num.current
            let r_date = req_date.current
            if (actionTaken.current === "EDIT") {
                navigate(PATH.PRIVATE.SCRAP_DEPOSIT, { state: { isPermanent: 1, permanent_id: requestEdited.current } })
            } else {
                console.log("VIEWWWWDEPOSIT")
                console.log(permanent_id);
                console.log(r_num);
                console.log(r_date);
                // debugger;
                navigate(PATH.PRIVATE.SCRAP_DEPOSIT_VIEW, { state: { isPermanent: permanent_id ? 1 : 0, permanent_id, r_num: r_num, r_date: r_date } })
            }
            //      navigate(PATH.PRIVATE.SCRAP_DEPOSIT, {state:{action:actionTaken.current}})
            actionTaken.current = ""
        }
    }, [scrapRequestView])

    const generateMRN = async (scrap_id) => {
        let result = await dispatch(generateMRNSheet({ scrap_id }));
        if (result.payload.data.status === 200) {
            window.open(result.payload.data.data, "_blank")
        } else {
            showToast("ERROR", result.payload.data.message)
        }
    }

    const TableIcons = (data) => {
        return (
            <>
                <div>
                    <div style={{ cursor: "not-allowed" }}>
                        <p style={{
                            fontWeight: "bold",
                            color: data.requestType === 1 ? CONSTANTS.COLORS.GREEN : data.requestType === 2 ? CONSTANTS.COLORS.RED : CONSTANTS.COLORS.INFO,
                            pointerEvents: "none"
                        }}>
                            {data.requestType === 1 ? 'Approved' : data.requestType === 2 ? 'Rejected' : 'Pending'}
                        </p>
                    </div>
                </div>
            </>
        )
    }

    const columns = [
        {
            name: "Request No.",
            selector: "requestNo",
            style: {
                minHeight: "120px"
            },
            wrap: true,
        },
        {
            name: "Date | Time",
            selector: "created_on",
            width: "150px",
            style: {

                maxWidth: "500px !important",
                textWrap: "nowrap",
            },
            cell: (row) => {
                return <div className="text-center" >
                    {row['created_on'] ? moment(row['created_on']).format('DD/MM/YYYY') + " | " + moment.utc(row['created_on']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "Description",
            selector: "created_on",
            width: "150px",
            wrap: true,
            cell: (row) => {
                return <ViewButton label={"View"} onClick={() => {
                    dispatch(viewScrapRequest({ scrap_id: row.requestNo, isPermanent: "1" }))
                    actionTaken.current = "VIEW"
                    req_num.current = row.requestNo
                    req_date.current = row.created_on
                }} />
            }

        },
        {
            name: "Edit",
            selector: "created_on",
            wrap: true,
            cell: (row) => {
                return <>
                    {row.ApprovalFromManager == 2 || row.ApprovalFromHOD == 2 ?
                        <EditButton
                            onClick={() => {
                                dispatch(viewScrapRequest({ scrap_id: row.requestNo, isPermanent: "1" }))
                                actionTaken.current = "EDIT"
                                requestEdited.current = row.requestNo
                            }} />
                        :
                        <EditButton disabled={true} />
                    }
                </>
                //     return <>{row.ApprovalFromManager == 2 || row.ApprovalFromHOD == 2?<div style={{  height:"25px" }}
                //     label={'Edit'}
                //     onClick={()=>{
                //         dispatch(viewScrapRequest({scrap_id:row.requestNo, isPermanent:"1"}))
                //         actionTaken.current = "EDIT"
                //     }}
                // >
                //     <img src={EditIcon} style={{width:"30px", cursor:"pointer"}}/>
                // </div>:<div style={{  height:"25px", opacity:"0.4" }}
                //     label={'Edit'}
                //     disabled={true}
                //     onClick={()=>{
                //         dispatch(viewScrapRequest({scrap_id:row.requestNo, isPermanent:"1"}))
                //         actionTaken.current = "EDIT"
                //     }}
                // >
                //     <img src={EditIcon} style={{width:"30px", cursor:"not-allowed"}}/>
                // </div>}</>

            }

        },
        // {
        //     name: "Material Code",
        //     selector: "material_code",
        //     wrap: true,
        //     cell: (row: any) => {
        //         return <div className="text-center" >
        //             {row['material_code'] ? row['material_code'] : "N/A"}
        //         </div>
        //     }
        // },
        // {
        //     name: "Material Group",
        //     selector: "material_group",
        //     wrap: true,
        //     cell: (row: any) => {
        //         return <div className="text-center" >
        //             {row['material_group'] ? row['material_group'] : "N/A"}
        //         </div>
        //     }
        // },
        // {
        //     name: "Material Description",
        //     selector: "material_description",
        //     minWidth: "150px",
        //     wrap: true,
        //     cell: (row: any) => {
        //         return <div>
        //             {row['material_description'] ? row['material_description'] : "N/A"}
        //         </div>
        //     }
        // },
        // {
        //     name: "Quantity",
        //     selector: "quantity",
        //     wrap: true,
        // },
        // {
        //     name: "Units",
        //     selector: "units",
        //     wrap: true,
        // },
        // {
        //     name: "Scrap Image",
        //     selector: "image_url",
        //     wrap: true,
        //     cell: (row: any) => {
        //         return <div className="text-center" >
        //             {row.image_url ? <a href={row.image_url} target="_blank">View</a> : "N/A"}
        //         </div>
        //     }
        // },

        {
            name: "Request Submitted By",
            selector: "employee_id",
            wrap: false,

            width: '200px',
            cell: (row) => {
                return <div className="text-center">
                    {`${row.first_name ?? ""} ${row.last_name ?? ""} ${row.last_name ? "(" : ""}${row.employee_id}${row.last_name ? ')' : ''}` ?? "N/A"}
                </div>
            }
        },
        // {
        //     name: "User Comments",
        //     selector: "comment",
        //     minWidth: "150px",
        //     wrap: true,
        //     cell: (row: any) => {
        //         return <div>
        //             {row.comment ? row.comment : "N/A"}
        //         </div>
        //     }
        // },
        {
            name: "Approval from Manager",
            selector: "ApprovalFromManager",
            minWidth: "200px",
            wrap: true,
            cell: (row) => {
                return <TableIcons requestType={row.ApprovalFromManager} />
            }
        },

        {
            name: "Updated Date by Manager",
            selector: "UpdatedDateByManager",

            width: '200px',
            wrap: true,
            cell: (row) => {
                return <div className="text-center" >
                    {row['UpdatedDateByManager'] ? moment(row['UpdatedDateByManager']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByManager']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "Manager Remarks",
            selector: "RemarksByManager",
            minWidth: "150px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarksByManager ? row.RemarksByManager : "N/A"}
                </div>
            }
        },

        {
            name: "Approval from HOD",
            selector: "ApprovalFromHOD",
            minWidth: "175px",
            wrap: true,
            cell: (row) => {
                return <TableIcons requestType={row.ApprovalFromHOD} />
            }
        },

        {
            name: "Updated Date by HOD",
            selector: "UpdatedDateByHOD",

            width: '200px',
            wrap: true,
            cell: (row) => {
                return <div className="text-center" >
                    {row['UpdatedDateByHOD'] ? moment(row['UpdatedDateByHOD']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByHOD']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "HOD Remarks",
            selector: "RemarksByHOD",
            minWidth: "150px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarksByHOD ? row.RemarksByHOD : "N/A"}
                </div>
            }
        },

        {
            name: "Approval from Store Manager",
            selector: "ApprovalFromStore",
            minWidth: "220px",
            wrap: true,
            cell: (row) => {
                return <TableIcons requestType={row.store_approved} />
            }
        },

        {
            name: "Updated Date by Store Manager",
            selector: "store_approval_date",
            wrap: true,

            width: '250px',
            cell: (row) => {
                return <div className="text-center" >

                    {row['store_approval_date'] ? moment(row['store_approval_date']).format('DD/MM/YYYY') + " | " + moment(row['store_approval_date']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "Store Manager Remarks",
            selector: "RemarksByStoreManager",
            minWidth: "200px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarksByStoreManager ? row.RemarksByStoreManager : "N/A"}
                </div>
            }
        },


        {
            name: "Approval from C&C HEAD",
            selector: "ApprovalFromCNCHead",
            minWidth: "200px",
            wrap: true,
            cell: (row) => {
                return <TableIcons requestType={row.ApprovalFromCNCHead} />
            }
        },

        {
            name: "Updated Date by C&C HEAD",
            selector: "UpdatedDateByCNCHead",

            width: '220px',
            wrap: true,
            cell: (row) => {
                return <div className="text-center" >
                    {row['UpdatedDateByCNCHead'] ? moment(row['UpdatedDateByCNCHead']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByCNCHead']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "C&C HEAD Remarks",
            selector: "RemarkByCNCHead",
            minWidth: "170px",
            wrap: true,
            cell: (row) => {
                return <div>
                    {row.RemarkByCNCHead ? row.RemarkByCNCHead : "N/A"}
                </div>
            }
        },
        {
            name: "MRN Sheet",
            selector: "DownloadMRN",
            minWidth: "175px",
            wrap: true,
            cell: (row) => {
                return <DownloadButton enable={row.ApprovalFromHOD == 1 ? true : false} onClick={() =>
                        generateMRN(row.requestNo) 
                } />
            }
        },

    ];


    return <React.Fragment>
        {loadingScrapList || loadingGenerateMRN ? <Loading loading={true} /> : ""}
        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}>
            <Grid container style={{
                minWidth: "95vw",
            }}>

                <Grid item xs={12} lg={12} sm={12}>
                    <h3 className="text-center pb-3">Material Deposit Submitted Requests:</h3>
                </Grid>
                <Filters page={page} state={state} setPage={setPage} setState={setState} listType={1} listCategory={"MANAGER"} />
                {/* <Grid item xs={12} lg={8} sm={12}>
                <div className="scrapFilters">
                    <DateRange />
                    <DepartmentFilter />
                    <div style={{color:"white", backgroundColor:"green", border:"none", padding:"5px 20px", fontSize:"12px", borderRadius:'5px', cursor:"pointer"}}>Filter</div>
                </div>
                </Grid>
                <Grid lg={4}>
                <div className="scrapFilters">
                    <Searchbar />
                </div>
                </Grid> */}
                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={scrapRequestlist}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {scrapListTotalCount ? <Pagination
                        page={page}
                        onChange={(event, value) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(scrapListTotalCount / OFFSET)}
                    /> : ""}
                </Grid>

            </Grid>
        </Container>

        <Suspense fallback={<Loading />}>
            <ImageDialog
                ref={ImageRef}
            ></ImageDialog>
        </Suspense>

    </React.Fragment>


}

export default ScrapDepositRequestList;