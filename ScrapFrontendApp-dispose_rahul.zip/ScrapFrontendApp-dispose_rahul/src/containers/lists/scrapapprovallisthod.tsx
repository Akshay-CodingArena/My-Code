import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import { Container, Grid } from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";

/////////////////ICONS///////////////////////////
import MyButton, { ViewButton } from "../../components/button";
import { CONSTANTS } from "../../constants/constants";
import { approveProfile, approveSignup } from "../../store/slices/users";
import { getRequestScrapList, getScrapListHOD, scrapApproval, viewScrapRequest } from "../../store/slices/list";
///////////////////////////////////////////////

import Dialog from '@mui/material/Dialog';
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import Input from "../../components/input";
import moment from "moment";
import { useForm, Controller } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { PATH } from "../../paths/path";
import { useNavigate } from "react-router-dom";
import Filters from "../../components/filters";
import { generateMRNSheet } from "../../store/slices/requests";
import DownloadButton from "../../components/downloadButton";
import CrossImage from "../../assets/images/cross.png";


const OFFSET = 5;

const RequestScrapListHOD = () => {
    const actionTaken = useRef("")
    const confirmTaskRef: any = useRef();
    const navigate = useNavigate()
    const [state, setState] = useState({
        date: [
            moment().startOf('month').format('YYYY/MM/DD'),
            moment(new Date()).format('YYYY/MM/DD')
        ]
    })

    const dataRef: any = useRef();


    const [open, setOpen]: any = useState(false);

    let [page, setPage]: any = useState(1);
    const [list, setList]: Array<any> = useState([]);
    const dispatch = useAppDispatch();
    const { loadingScrapListHOD, scrapListHOD, scrapListCountHOD, loadingScrapApproval, scrapRequestView } = useAppSelector(state => state.list);
    const { loadingGenerateMRN } = useAppSelector(state => state.scrapRequests);

    const validationSchema = Yup.object().shape({
        remarks: Yup.string().trim()
            .required('Remarks is required')
            .min(10, 'Remarks must be atleast 10 characters long.'),
    });

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        control,
        getValues
    } = useForm({
        resolver: yupResolver(validationSchema),
    });



    useEffect(() => {
        setList(scrapListHOD)
    }, [scrapListHOD])

    useEffect(() => {
        console.log("Scrap Request is", scrapRequestView)
        if (actionTaken.current) {
            console.log("Scrap Request is captured", scrapRequestView)
            useLocalStorage.setItem("scrapRequest", JSON.stringify(scrapRequestView[0]))
            navigate(PATH.PRIVATE.SCRAP_DEPOSIT_VIEW)

            //      navigate(PATH.PRIVATE.SCRAP_DEPOSIT, {state:{action:actionTaken.current}})
            actionTaken.current = ""
        }
    }, [scrapRequestView])


    const getList = async (page: number) => {

        let userData = useLocalStorage.getItem("userData");

        let formData = {
            page_number: page - 1,
            offset: OFFSET,
            list_type: 2,
            hod_id: userData.id
        }

        let response = await dispatch(getScrapListHOD(formData));

        let listData = response.payload.data ? response.payload.data : {};

        if (listData.status === 200) {
            setPage(page)
        } else {
            showToast('ERROR', listData.message || 'Some Error Occurred...');
        }
    }


    const handlePageChange = (e: any, value: any) => {
        setPage(value);
    }



    const approveOrReject = async (action: number) => {
        //////////1:Approve
        //////////2:Reject
        dataRef.current = { ...dataRef.current, actionType: action };
        console.log(dataRef.current);
        confirmTaskRef.current.handleClose();
        setOpen(true)
    }

    const onConfirm = () => {
        approveOrReject(1);

    }

    const onDiscard = () => {
        approveOrReject(2);
    }

    const generateMRN = async (scrap_id: any) => {
        let result = await dispatch(generateMRNSheet({ scrap_id }));
        if (result.payload.data.status === 200) {
            window.open(result.payload.data.data, "_blank")
        } else {
            showToast("ERROR", result.payload.data.message)
        }
    }


    const TableIcons = (rowData: any) => {
        let role = rowData.role
        let requestType

        if (role === "MANAGER") {
            requestType = rowData.row.manager_approved
        }
        else if (role === "HOD") {
            requestType = rowData.row.hod_approved
        }
        else if (role === "CNCHead") {
            requestType = rowData.row.ApprovalFromCNCHead
        } else if (role === "StoreManager") {
            requestType = rowData.row.store_approved
        }

        const handleOpenConfirmDialog = () => {
            dataRef.current = {
                scrapData: rowData.row
            };
            confirmTaskRef.current.handleClickOpen()
        }

        return (
            <>
                {requestType === 1 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        {/* <MyButton className="approved-status" style={{ backgroundColor: CONSTANTS.COLORS.GREEN, pointerEvents: "none" }}
                            label={'Approved'}

                        /> */}
                        <p style={{ color: CONSTANTS.COLORS.GREEN, fontWeight: "bolder" }}>APPROVED</p>
                    </div>
                </div>}

                {requestType === 2 && <div>
                    <div style={{ cursor: "not-allowed" }}>
                        {/* <MyButton style={{ backgroundColor: CONSTANTS.COLORS.RED, pointerEvents: "none" }}
                            label={'Rejected'}

                        /> */}
                        <p style={{ color: CONSTANTS.COLORS.RED, fontWeight: "bolder" }}>REJECTED</p>
                    </div>
                </div>}

                {requestType === 0 && <div>
                    {rowData.enableAction ?
                        <div>
                            <MyButton style={{ backgroundColor: CONSTANTS.COLORS.INFO }}
                                onClick={handleOpenConfirmDialog}
                                label={'Pending'}
                            />
                        </div> :
                        <p style={{ color: CONSTANTS.COLORS.INFO, fontWeight: "bolder" }}>PENDING</p>
                    }
                </div>}

            </>
        )
    }


    const columns: any = [
        {
            name: "Request No.",

            width: '120px',
            selector: "requestNo",
            style: {
                minHeight: "120px"
            },
            wrap: true,
        },
        {
            name: "Date | Time",
            selector: "created_on",
            width: "200px",
            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row['created_on'] ? moment(row['created_on']).format('DD/MM/YYYY') + " | " + moment.utc(row['created_on']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "Description",
            selector: "requestNo",
            wrap: true,
            cell: (row: any) => {
                return <ViewButton label={"View"} onClick={() => {
                    dispatch(viewScrapRequest({ scrap_id: row.requestNo, isPermanent: "1" }))
                    actionTaken.current = "VIEW"
                }} />
            }

        },
        {
            name: "Request Submitted By",
            selector: "employee_id",
            wrap: true,
            minWidth: "200px",
            cell: (row: any) => {
                return <div className="text-center">
                    {`${row.first_name ?? ""} ${row.last_name ?? ""} ${row.last_name ? "(" : ""}${row.employee_id}${row.last_name ? ')' : ''}` ?? "N/A"}
                </div>
            }
        },
        // {
        //     name: "Comments",
        //     selector: "comment",
        //     minWidth: "150px",
        //     wrap: true,
        //     cell: (row: any) => {
        //         return <div className="text-center">
        //             {row.comment ? row.comment:"N/A" }
        //         </div>
        //     }
        // },
        {
            name: "Manager Approval Date",
            selector: "manager_approval_date",
            wrap: true,
            minWidth: "200px",
            cell: (row: any) => {
                return <div>
                    {row['manager_approval_date'] ? moment(row['manager_approval_date']).format('DD/MM/YYYY') + " | " + moment(row['manager_approval_date']).format('HH:mm:ss') : "N/A"}
                </div>
            }
        },

        {
            name: "Manager Remarks",
            selector: "manager_remarks",
            minWidth: "200px",
            wrap: true,
            cell: (row: any) => {
                return <div >
                    {row.manager_remarks ? row.manager_remarks : "N/A"}
                </div>
            }
        },

        {
            name: "HOD Approval Date",
            selector: "hod_approval_date",
            wrap: true,
            minWidth: "200px",
            cell: (row: any) => {
                return <div>
                    {row.hod_approval_date ? row.hod_approval_date == "NOW" ? "Just Now" : moment(row['hod_approval_date']).format('DD/MM/YYYY') + " | " + moment(row['hod_approval_date']).format('HH:mm:ss') : "N/A"}
                </div>
            }
        },
        {
            name: "Action",
            selector: "hod_approved",
            minWidth: "175px",
            wrap: true,
            cell: (row: any) => {
                return <TableIcons row={row} role={"HOD"} enableAction={true} />
            }
        },
        {
            name: "HOD Remarks",
            selector: "hod_remarks",
            minWidth: "200px",
            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.hod_remarks ? row.hod_remarks : "N/A"}
                </div>
            }
        },
        {
            name: "Approval from Store Manager",
            selector: "store_approved",
            minWidth: "220px",
            wrap: true,
            cell: (row: any) => {
                return <TableIcons row={row} role={"StoreManager"} />
            }
        },

        {
            name: "Updated Date by Store Manager",
            selector: "UpdatedDateByStoreManager",
            wrap: true,
            minWidth: "250px",
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['store_approval_date'] ? moment(row['store_approval_date']).format('DD/MM/YYYY') + " | " + moment(row['store_approval_date']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        // {
        //     name: "Store Manager Remarks",
        //     selector: "RemarksByStoreManager",
        //     minWidth: "150px",
        //     wrap: true,
        //     cell: (row) => {
        //         return <div>
        //             {row.RemarksByStoreManager ? row.RemarksByStoreManager : "N/A"}
        //         </div>
        //     }
        // },


        {
            name: "Approval from C&C HEAD",
            selector: "ApprovalFromCNCHead",
            minWidth: "200px",
            wrap: true,
            cell: (row: any) => {
                return <TableIcons row={row} role={"CNCHead"} />
            }
        },

        {
            name: "Updated Date by C&C HEAD",
            selector: "UpdatedDateByCNCHead",
            wrap: true,

            width: '220px',
            cell: (row: any) => {
                return <div className="text-center" >
                    {row['UpdatedDateByCNCHead'] ? moment(row['UpdatedDateByCNCHead']).format('DD/MM/YYYY') + " | " + moment(row['UpdatedDateByCNCHead']).format('HH:mm:ss') : "N/A"}
                </div>
            }

        },
        {
            name: "C&C HEAD Remarks",
            selector: "RemarkByCNCHead",
            minWidth: "200px",
            wrap: true,
            cell: (row: any) => {
                return <div>
                    {row.RemarkByCNCHead ? row.RemarkByCNCHead : "N/A"}
                </div>
            }
        },
        {
            name: "MRN Sheet",
            selector: "download_mrn",
            minWidth: "175px",
            wrap: true,
            cell: (row: any) => {
                return <DownloadButton enable={row.hod_approved == 1 ? true : false} onClick={() =>
                    generateMRN(row.requestNo)
                } />
            }
        },
    ];

    const onSubmit = async (data: any) => {

        let scrapData = dataRef.current.scrapData;
        let userData = useLocalStorage.getItem("userData");

        let formData = {
            scrap_id: scrapData.requestNo,
            scrap_deposit_approval: dataRef.current.actionType,
            role_id: userData.role_id,
            remarks: data.remarks
        }

        let responseData = await dispatch(scrapApproval(formData));


        if (responseData?.payload?.data?.status === 200) {
            let newList = list.map((value: any) => {
                if (value.requestNo === scrapData.requestNo) {
                    return { ...value, hod_approved: dataRef.current.actionType, hod_remarks: data.remarks, hod_approval_date: "NOW" }
                }
                return value

            })
            console.log("New list is", newList)
            setList([...newList]);
        } else {
            showToast('ERROR', responseData?.payload?.data?.message || 'Some Error Occurred...');
        }
        setOpen(false);
    }

    return <React.Fragment>
        {loadingScrapListHOD || loadingScrapApproval || loadingGenerateMRN ? <Loading loading={true} /> : ""}
        <Container fixed style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px"
        }}>
            <Grid container style={{
                minWidth: "95vw",
            }}>

                <Grid item xs={12} lg={12} sm={12}>
                    <h3 className="text-center pb-3">Material Request's List(HOD)</h3>
                </Grid>
                <Filters page={page} state={state} setPage={setPage} setState={setState} listType={2} listCategory={"HOD"} />
                <Grid item xs={12} lg={12} sm={12}>
                    <Datatable
                        columns={columns}
                        data={list}
                    />
                </Grid>

                <Grid item xs={12} lg={12} sm={12} style={{ display: "flex", justifyContent: "end", marginTop: "20px" }}>
                    {list?.length ? <Pagination
                        page={page}
                        onChange={(event: any, value: any) => { handlePageChange(event, value) }}
                        pageCount={Math.ceil(scrapListCountHOD / OFFSET)}
                    /> : ""}
                </Grid>

            </Grid>
        </Container>

        <Suspense fallback={<Loading />}>
            <Dialog
                className='dialogAlertStyle'
                open={open}
                onClose={(e: any) => setOpen(false)}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <div className='mt-3 mr-3 w-100 d-flex justify-content-end'>
                    <img onClick={(e) => {
                        setOpen(false)
                    }} src={CrossImage} style={{ height: "23px", width: "25px", cursor: "pointer", marginRight: "20px" }} />
                </div>

                <DialogTitle id="alert-dialog-title">
                    <p className="dialog_title h4">
                        Remarks Section
                    </p>
                </DialogTitle>
                <DialogActions
                    className="dialogactions"
                >
                    <Grid container style={{ marginTop: "-20px", padding: "5px 0px" }}>
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <Grid item xs={12} sm={12} md={12} lg={12} style={{ minWidth: "400px" }}>
                                <Input
                                    style={{ width: "350px" }}
                                    required={true}
                                    multiline={true}
                                    fullWidth={true}
                                    autoFocus={true}
                                    label="Remarks"
                                    type="text"
                                    autoComplete='on'
                                    onChange={(e: any) => {
                                        setValue('remarks', e.target.value);
                                    }}
                                    error={errors.remarks ? true : false}
                                    errormessage={errors.remarks?.message}
                                    minRows={3}
                                />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                <MyButton type="submit"
                                    fullWidth={true}
                                    label="Submit" style={{
                                        backgroundColor: CONSTANTS.COLORS.GREEN
                                    }} />
                            </Grid>
                        </form>


                    </Grid>
                </DialogActions>
            </Dialog>

        </Suspense>


        <Suspense fallback={<Loading />}>
            <ConfirmDialog
                ref={confirmTaskRef}
                description={"Are you sure you want to Approve/Reject?"}
                title={""}
                confirm={"Approve"}
                discard={"Reject"}
                onConfirm={onConfirm}
                onDiscard={onDiscard}
            ></ConfirmDialog>
        </Suspense>
    </React.Fragment>


}

export default RequestScrapListHOD;