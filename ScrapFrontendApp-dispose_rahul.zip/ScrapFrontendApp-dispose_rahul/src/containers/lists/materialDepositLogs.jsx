import React, { Suspense, useEffect, useRef, useState } from "react";
import Loading from "../../components/backdrop";
import ConfirmDialog from "../../components/ConfirmDialog";
import {
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  Paper,
} from "@mui/material";
import Datatable from "../../components/Datatable";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import Pagination from "../../components/pagination";
import useLocalStorage from "../../utils/localStorage";
import { showToast } from "../../components/toast";
/////////////////ICONS///////////////////////////
import { CONSTANTS } from "../../constants/constants";
import { useNavigate } from "react-router-dom";
import { PATH } from "../../paths/path";
import DownloadIcon from "../../assets/images/images.png";
import moment from "moment";
import DateRange from "../../components/daterange";

import { generateMRNSheet } from "../../store/slices/requests";
import { Controller, useForm } from "react-hook-form";
import dayjs, { Dayjs } from "dayjs";
import {
  departmentMasterList,
  viewScrapRequest,
} from "../../store/slices/list";
import MySelect from "../../components/select";
import Input from "../../components/input";
import MyButton, { ViewButton } from "../../components/button";
import {
  getCNCPhysicalDisposeView,
  getPhysicalDisposeApprovalCNC,
  getPhysicalDisposeRequestsList,
  getScrapDisposeApprovalCNC,
  getScrapDisposeRequestsList,
  getScrapPhysicalDisposeView,
} from "../../store/slices/dispose";

import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  getMaterialDepositLogs,
  getMovementList,
} from "../../store/slices/inventory";
import DownloadButton from "../../components/downloadButton";
import { scrapListSheetDownload } from "../../store/slices/admin";

const OFFSET = 5;

const MaterialDepositLogs = () => {
  const navigate = useNavigate();
  let [page, setPage] = useState(1);

  const confirmTaskRef = useRef();
  const dataRef = useRef();
  const [userData, setUserData] = useState([]);

  const actionTaken = useRef("");
  const requestEdited = useRef("");
  const req_num = useRef("");
  const req_date = useRef("");

  let [depositList, setDepositList] = useState([]);
  let [dept, setDept] = useState();
  let [dateRange, setDateRange] = useState([
    dayjs(moment().startOf("year").format("YYYY-MM-DD")),
    dayjs(new Date()),
  ]);
  let [requestNo, setRequestNo] = useState();
  let [materialCode, setMaterialCode] = useState();

  const {
    loadingScrapList,
    scrapRequestlist,
    scrapListTotalCount,
    scrapRequestView,
  } = useAppSelector((state) => state.list);
  const { loadingGenerateMRN } = useAppSelector((state) => state.scrapRequests);
  useEffect(() => {
    console.log("Scrap Request is", scrapRequestView);
    if (actionTaken.current) {
      console.log("Scrap Request is captured", scrapRequestView);
      useLocalStorage.setItem(
        "scrapRequest",
        JSON.stringify(scrapRequestView[0])
      );
      let permanent_id = requestEdited.current;
      let r_num = req_num.current;
      let r_date = req_date.current;
      if (actionTaken.current === "EDIT") {
        navigate(PATH.PRIVATE.SCRAP_DEPOSIT, {
          state: { isPermanent: 1, permanent_id: requestEdited.current },
        });
      } else {
        console.log("VIEWWWWDEPOSIT");
        console.log(permanent_id);
        console.log(r_num);
        console.log(r_date);
        // debugger;
        navigate(PATH.PRIVATE.SCRAP_DEPOSIT_VIEW, {
          state: {
            isPermanent: permanent_id ? 1 : 0,
            permanent_id,
            r_num: r_num,
            r_date: r_date,
          },
        });
      }
      //      navigate(PATH.PRIVATE.SCRAP_DEPOSIT, {state:{action:actionTaken.current}})
      actionTaken.current = "";
    }
  }, [scrapRequestView]);

  const generateMRN = async (scrap_id) => {
    let result = await dispatch(generateMRNSheet({ scrap_id }));
    if (result.payload.data.status === 200) {
      window.open(result.payload.data.data, "_blank");
      console.log("HUEHUE");
    } else {
      showToast("ERROR", result.payload.data.message);
    }
  };

  const { loadingMovementList, totalMaterialDepositLogs } = useAppSelector(
    (state) => state.inventory
  );

  const dispatch = useAppDispatch();

  const columns = [
    {
      name: "Request No.",
      selector: "requestNo",
      wrap: true,
      width: "170px",
    },
    {
      name: "View Details",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <ViewButton
            label={"View"}
            onClick={() => {
              dispatch(
                viewScrapRequest({ scrap_id: row.requestNo, isPermanent: "1" })
              );
              actionTaken.current = "VIEW";
              req_num.current = row.requestNo;
              req_date.current = row.created_on;
            }}
          />
        );
      },
    },
    {
      name: "Created By",
      selector: "user_name",
      wrap: true,
      width: "150px",
    },
    {
      name: "Created Date & Time",
      wrap: true,
      width: "200px",
      cell: (row) => {
        return (
          <div>
            {row["created_on"]
              ? moment(row["created_on"]).format("DD/MM/YYYY") +
                " | " +
                moment(row["created_on"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Reporting Manager",
      selector: "manager_name",
      wrap: true,
      width: "170px",
    },
    {
      name: "Status-Reporting Manager",
      selector: "ApprovalFromManager",
      wrap: true,
      width: "230px",
    },
    {
      name: "Date/Time",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div>
            {row["UpdatedDateByManager"]
              ? moment(row["UpdatedDateByManager"]).format("DD/MM/YYYY") +
                " | " +
                moment(row["UpdatedDateByManager"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "RemarksByManager",
      wrap: true,
      width: "200px",
    },
    {
      name: "HOD Name",
      selector: "hod_name",
      wrap: true,
      width: "170px",
    },
    {
      name: "Status-HOD",
      selector: "ApprovalFromHOD",
      wrap: true,
      width: "230px",
    },
    {
      name: "Date/Time",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div>
            {row["UpdatedDateByHOD"]
              ? moment(row["created_on"]).format("DD/MM/YYYY") +
                " | " +
                moment(row["UpdatedDateByHOD"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "RemarksByHOD",
      wrap: true,
      width: "230px",
    },
    {
      name: "C&C Head Name",
      selector: "cnc_name",
      wrap: true,
      width: "170px",
    },
    {
      name: "Status C&C Head",
      selector: "ApprovalFromCNCHead",
      wrap: true,
      width: "230px",
    },
    {
      name: "Date/Time",
      wrap: true,
      width: "170px",
      cell: (row) => {
        return (
          <div>
            {row["UpdatedDateByCNCHead"]
              ? moment(row["created_on"]).format("DD/MM/YYYY") +
                " | " +
                moment(row["UpdatedDateByCNCHead"]).format("HH:mm:ss")
              : "N/A"}
          </div>
        );
      },
    },
    {
      name: "Remarks",
      selector: "RemarkByCNCHead",
      wrap: true,
      width: "200px",
    },
    {
      name: "Download MRN",
      selector: "DownloadMRN",
      wrap: true,
      width: "230px",
      cell: (row) => {
        return (
          <DownloadButton
            enable={row.ApprovalFromHOD == "Approved" ? true : false}
            onClick={() => generateMRN(row.requestNo)}
          />
        );
      },
    },
  ];

  const getList = async (page) => {
    let formData = {
      page_number: page - 1,
      count: OFFSET,
    };

    /////////////////set if statements////////////

    if (dateRange) {
      formData["start_date"] = moment(dateRange[0]["$d"]).format("YYYY/MM/DD");
      formData["end_date"] = moment(dateRange[1]["$d"]).format("YYYY/MM/DD");
    }

    if (requestNo) {
      formData["scrap_id"] = requestNo;
    }
    if (materialCode) {
      formData["material_code"] = materialCode;
    }
    if (dept) {
      formData["department"] = dept;
    }

    let response = await dispatch(getMaterialDepositLogs(formData));

    let listData = response.payload.data ? response.payload.data : {};

    if (listData.status === 200) {
      setDepositList(listData.data.getAllScrapListData);
      setPage(page);
    } else {
      showToast("ERROR", listData.message || "Some Error Occurred...");
    }
  };

  useEffect(() => {
    getList(page);
  }, []);

  useEffect(() => {
    getList(1);
  }, [dateRange, materialCode, requestNo, dept]);

  const handlePageChange = (e, value) => {
    getList(value);
  };

  let id1, id2;

  const downloadSheet = async () => {
    const resp =  await dispatch(scrapListSheetDownload({
      start_date:moment(dateRange[0]["$d"]).format("YYYY/MM/DD"),
      end_date:moment(dateRange[1]["$d"]).format("YYYY/MM/DD"),
      department_params:dept,
      scrap_id_params: requestNo
    }))
    try{
      console.log("My response",resp, resp.payload.data.data.file)
      window.location.href = resp.payload.data.data.file
    }catch{
      showToast(
        "ERROR",
       "Some Error Occurred."
      );
    }
  };

  return (
    <React.Fragment>
      {loadingMovementList ? <Loading loading={true} /> : ""}

      <Container
        fixed
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginTop: "20px",
        }}
      >
        <Grid container style={{
                minWidth: "95vw",
            }}spacing={1}>
          <Grid item xs={12} lg={12} sm={12}>
            <h3 className="text-center pb-3">Logs of Material Deposit</h3>
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{ display: "flex", justifyContent: "end" }}
          >
            <b>Sheet</b>
            <img
              src={DownloadIcon}
              onClick={downloadSheet}
              alt=""
              style={{
                height: "25px",
                width: "25px",
                border: "1px solid black",
                marginBottom: "5px",
                cursor: "pointer",
                marginLeft: "5px",
              }}
            />
          </Grid>

          <Grid item xs={12} lg={3} sm={6}>
            <DateRange
              onChange={(newValue) => {
                setDateRange(newValue);
              }}
              value={dateRange}
            />
          </Grid>

          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Request Number"
              type="text"
              value={requestNo}
              onChange={(e) => {
                
                // clearTimeout(id1);
                if(/^(0|[1-9][0-9]*)$/g.test(e.target.value)){
                  setRequestNo(e.target.value);
                }else{
                  setRequestNo(e.target.value.replace(/[^0-9]/g, ''))
                }
              }}
              // onChange={(e) => {
              //   clearTimeout(id1);
              //   id1 = setTimeout(() => setRequestNo(e.target.value), 1000);
              // }}
            />
          </Grid>
          {/* <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Material Code"
              type="text"
              onChange={(e) => {
                clearTimeout(id2);
                id2 = setTimeout(() => setMaterialCode(e.target.value), 1000);
              }}
            />
          </Grid> */}
          <Grid
            item
            xs={12}
            lg={3}
            sm={6}
            className="mb-3"
            style={{ marginTop: "20px" }}
          >
            <Input
              label="Department"
              type="text"
              onChange={(e) => {
                clearTimeout(id2);
                id2 = setTimeout(() => setDept(e.target.value), 1000);
              }}
            />
          </Grid>

          <Grid item xs={12} lg={12} sm={12}>
            <Datatable columns={columns} data={depositList} />
          </Grid>

          <Grid
            item
            xs={12}
            lg={12}
            sm={12}
            style={{
              display: "flex",
              justifyContent: "end",
              marginTop: "20px",
            }}
          >
            {depositList.length ? (
              <Pagination
                page={page}
                onChange={(event, value) => {
                  handlePageChange(event, value);
                }}
                pageCount={Math.ceil(totalMaterialDepositLogs / OFFSET)}
              />
            ) : (
              ""
            )}
          </Grid>
        </Grid>
      </Container>
    </React.Fragment>
  );
};

export default MaterialDepositLogs;
