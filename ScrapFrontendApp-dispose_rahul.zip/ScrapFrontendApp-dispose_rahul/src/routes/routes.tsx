import React, { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route, Link, Navigate, useLocation } from "react-router-dom";
import { PATH } from "../paths/path";
import Loading from "../components/backdrop";
const CncCategortyRequests = lazy(() => import('../containers/inventory/cncCategoryRequests'));
const CategoryChangeRequest = lazy(() => import('../containers/inventory/categoryChangeRequest'));
const CategoryChangeList = lazy(() => import('../containers/inventory/categoryChangeList'));
const CncBinCodeRequests = lazy(() => import('../containers/inventory/cncBinCodeRequests'));
const TransactionLogsDispose = lazy(() => import('../containers/lists/transactionLogsDispose'));
const TransactionLogsDeposit = lazy(() => import('../containers/lists/transactionLogsDeposit'));
const MaterialDepositLogs = lazy(() => import('../containers/lists/materialDepositLogs'));
const AuditAccountsList = lazy(() => import('../containers/lists/auditAccountsList'));
const AuditMovementList = lazy(() => import('../containers/lists/auditMovementList'));
const MaterialDisposeLogs = lazy(() => import('../containers/lists/materialDisposeLogs'));
const Error404 = lazy(() => import('../containers/auth/error404'));
const InventoryList = lazy(() => import('../containers/inventory/inventoryList'));
const BinCodeChangeList = lazy(() => import('../containers/inventory/binCodeChangeList'));
const BinCodeChangeRequest = lazy(() => import('../containers/inventory/binCodeChangeRequest'));
const CNCViewPhysicalDisposeRequest = lazy(() => import('../containers/physical_dispose/cncViewPhysicalDisposeRequest'));
const ScrapPhysicalDisposalRequest = lazy(() => import('../containers/physical_dispose/scrapPhysicalDisposeRequest'));
const PhysicalDisposeRequestsCNC = lazy(() => import('../containers/physical_dispose/cncPhysicalDisposeRequests'));
const ViewPhysicalDisposeRequest = lazy(() => import('../containers/physical_dispose/viewPhysicalDisposeRequest'));
const ScrapPhysicalDisposeList = lazy(() => import('../containers/physical_dispose/scrapPhysicalDisposalList'));
const CommitteMembersScrapDisposeRequestsList = lazy(() => import('../containers/dispose/scrapdisposerequestscommitteemembers'));
const ScrapDisposeRequests = lazy(() => import('../containers/dispose/scrapdisposerequests'));
const ViewScrapDisposeRequest = lazy(() => import('../containers/dispose/viewdisposerequest'));
const CommitteMembersList = lazy(() => import('../containers/dispose/viewdetailscommittee'));
const ScrapDisposeRequestsCNC = lazy(() => import('../containers/dispose/cncscrapdisposerequests'));
const SignInSide = lazy(() => import('../containers/auth/singin'));
const SignUpSide = lazy(() => import('../containers/auth/signup'));
const Forgotpassword = lazy(() => import('../containers/auth/forgotpassword'));
const AppBar = lazy(() => import('../components/appbar'));
const Dashboard = lazy(() => import('../containers/dashboard/dashboard'));
const Toast = lazy(() => import('../components/toast'));
const AccountUpdate = lazy(() => import('../containers/auth/accountupdate'));
const ConfirmPassword = lazy(() => import('../containers/auth/confirmpassword'));
const UserProfileLists = lazy(() => import('../containers/lists/userprofilelist'));
const ScrapDeposit = lazy(() => import('../containers/deposit/scrapdeposit'));
const RequestScrapList = lazy(() => import('../containers/lists/scrapapprovallist'));
const ProtectedRoute = lazy(() => import('./protectedRoute'));
const RequestScrapListHOD = lazy(() => import('../containers/lists/scrapapprovallisthod'));
const RequestScrapListHODManager = lazy(() => import('../containers/lists/scrapapprovallisthodmanager'));
const RequestScrapListStoreManager = lazy(() => import('../containers/lists/scrapapprovalliststoremanager'));
const ScrapDepositRequestList = lazy(() => import('../containers/lists/scrapdepositrequestlist'));
const ScrapDepositReview = lazy(() => import('../containers/deposit/scrapdepositReview'));
const ScrapDepositDraftList = lazy(() => import('../containers/deposit/scrapdepositDraft'));
const ScrapDepositStoreApproval = lazy(() => import('../containers/deposit/scrapdepositStoreApproval'))
const ScrapDepositStoreReview = lazy(() => import('../containers/deposit/scrapdepositStoreReview'))
const RequestScrapListCNCHead = lazy(() => import('../containers/lists/scrapapprovallistcnchead'))
const AccountsList = lazy(() => import('../containers/admin/accountlists'));
const AccountCreation = lazy(() => import('../containers/admin/accountcreation'));
const Main = lazy(() => import('../containers/admin/upload/main'))
const ScrapList = lazy(() => import('../containers/admin/scraplist'));
const ScrapDisposeDraftList = lazy(() => import('../containers/dispose/scrapDisposeDraft'));
const ScrapDisposalRequest = lazy(() => import('../containers/dispose/scrapDisposalRequest'));
const CompareJsons = lazy(() => import('../containers/dispose/compareJsons'));

//////////////////////////////////////////////////////////////////////////////
const Deposit_Dispose_Report = lazy(() => import('../containers/common/main'));
/////////////////////////////////////////////////////////////////////////////

const exclusionArray = [
    PATH.PUBLIC.SIGN_IN,
    PATH.PUBLIC.SIGN_UP,
    PATH.PUBLIC.FORGOT_PASSWORD,
    PATH.PUBLIC.CONFIRM_PASSWORD
];

const ProjectRoutes: React.FC = (): JSX.Element => {
    //////////////////////////////////
    const location = useLocation();
    const isHeaderSidemenuVisible = exclusionArray.indexOf(location.pathname) < 0;
    ////////////SET UP LAZY LOADING LATER ON////////////
    return (
        <Suspense fallback={<Loading loading={true} />}>
            <React.Fragment>
                {isHeaderSidemenuVisible ? <AppBar /> : null}
                <Routes>
                    <Route path={PATH.PUBLIC.SIGN_IN} element={<SignInSide />} />
                    <Route path={PATH.PUBLIC.SIGN_UP} element={<SignUpSide />} />
                    <Route path={PATH.PUBLIC.ERROR_404} element={<Error404 />} />
                    <Route path={PATH.PUBLIC.FORGOT_PASSWORD} element={<Forgotpassword />} />
                    <Route path={PATH.PUBLIC.CONFIRM_PASSWORD} element={<ConfirmPassword />} />





                    {/* ////////////////////DISPOSE//////////////////////// */}

                    <Route path={PATH.PRIVATE.APPROVE_REJECT_COMMITTEE_MEMBERS} element={
                        <ProtectedRoute >
                            <CommitteMembersScrapDisposeRequestsList />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_DISPOSE_REQUESTS_LIST} element={
                        <ProtectedRoute >
                            <ScrapDisposeRequests />
                        </ProtectedRoute>}


                    />

                    <Route path={PATH.PRIVATE.SCRAP_DISPOSE_REQUEST_VIEW} element={
                        <ProtectedRoute >
                            <ViewScrapDisposeRequest />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.VIEW_COMMITTEE_MEMBERS_LIST} element={
                        <ProtectedRoute >
                            <CommitteMembersList />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.SCRAP_DISPOSE_REQUESTS_FOR_APPROVAL_CNC} element={
                        <ProtectedRoute >
                            <ScrapDisposeRequestsCNC />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.PHYSICAL_DISPOSE_REQUESTS_FOR_APPROVAL_CNC} element={
                        <ProtectedRoute >
                            <PhysicalDisposeRequestsCNC />
                        </ProtectedRoute>}
                    />
                    {/* /////////////////////////DISPOSE END/////////////////////// */}

                    <Route path={PATH.PRIVATE.DEPOSIT_DISPOSE_REPORT} element={
                        <ProtectedRoute >
                            <Deposit_Dispose_Report/>
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.COMPARE_VERSION} element={
                        <ProtectedRoute >
                            <CompareJsons />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.ADMIN_UPLOAD_FILES} element={
                        <ProtectedRoute >
                            <Main />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.ADMIN_SCRAP_LIST} element={
                        <ProtectedRoute >
                            <ScrapList />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.ADMIN_CREATE_USER} element={
                        <ProtectedRoute >
                            <AccountCreation />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.ADMIN_USER_LIST} element={
                        <ProtectedRoute >
                            <AccountsList />
                        </ProtectedRoute>}
                    />

<Route path={PATH.PRIVATE.AUDIT_USER_LIST} element={
                        <ProtectedRoute >
                            <AuditAccountsList />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.DASHBOARD} element={
                        <ProtectedRoute >
                            <Dashboard />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.UPDATE_PROFILE} element={
                        <ProtectedRoute >
                            <AccountUpdate />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.USER_PROFILE_LIST} element={
                        <ProtectedRoute >
                            <UserProfileLists />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.USER_PROFILE_LIST} element={
                        <ProtectedRoute >
                            <AccountUpdate />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT_DRAFTS} element={
                        <ProtectedRoute >
                            <ScrapDepositDraftList />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT} element={
                        <ProtectedRoute >
                            <ScrapDeposit />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT_REVIEW} element={
                        <ProtectedRoute >
                            <ScrapDepositReview />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT_VIEW} element={
                        <ProtectedRoute >
                            <ScrapDepositReview />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_LIST} element={
                        <ProtectedRoute >
                            <RequestScrapList />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.SCRAP_LIST_HOD} element={
                        <ProtectedRoute >
                            <RequestScrapListHOD />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_LIST_HOD_MANAGER} element={
                        <ProtectedRoute >
                            <RequestScrapListHODManager />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.SCRAP_LIST_STORE_MANAGER} element={
                        <ProtectedRoute >
                            <RequestScrapListStoreManager />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_LIST_CNC_HEAD} element={
                        <ProtectedRoute >
                            <RequestScrapListCNCHead />
                        </ProtectedRoute>}
                    />


                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT_STORE_APPROVAL}
                        element={
                            <ProtectedRoute>
                                <ScrapDepositStoreApproval />
                            </ProtectedRoute>
                        }
                    />

                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT_STORE_REVIEW}
                        element={
                            <ProtectedRoute>
                                <ScrapDepositStoreReview />
                            </ProtectedRoute>
                        }
                    />

                    <Route path={PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_REVIEW}
                        element={
                            <ProtectedRoute>
                                <ViewPhysicalDisposeRequest />
                            </ProtectedRoute>
                        }
                    />

                    {/* <Route path={PATH.PRIVATE.SCRAP_DISPOSAL_STORE_LIST}
                element={
                    <ProtectedRoute>
                        <ScrapDisposalStoreList />
                    </ProtectedRoute>
                }
            /> */}

                    <Route path={PATH.PRIVATE.SCRAP_DISPOSAL_STORE_REQUEST}
                        element={
                            <ProtectedRoute>
                                <ScrapDisposalRequest />
                            </ProtectedRoute>
                        }
                    />
                    <Route path={PATH.PRIVATE.SCRAP_DISPOSE_DRAFT} element={
                        <ProtectedRoute >
                            <ScrapDisposeDraftList />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE} element={
                        <ProtectedRoute >
                            <ScrapPhysicalDisposeList />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_REQUEST} element={
                        <ProtectedRoute >
                            <ScrapPhysicalDisposalRequest />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_DEPOSIT_LIST} element={
                        <ProtectedRoute >
                            <ScrapDepositRequestList />
                        </ProtectedRoute>}
                    />

                    <Route path={PATH.PRIVATE.SCRAP_PHYSICAL_DISPOSE_VIEW_CNC} element={
                        <ProtectedRoute >
                            <CNCViewPhysicalDisposeRequest />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.MATERIAL_INVENTORY} element={
                        <ProtectedRoute >
                            <InventoryList />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.BINCODE_CHANGE_LIST} element={
                        <ProtectedRoute >
                            <BinCodeChangeList />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.BINCODE_CHANGE_REQUEST} element={
                        <ProtectedRoute >
                            <BinCodeChangeRequest />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.CATEGORY_CHANGE_REQUEST} element={
                        <ProtectedRoute >
                            <CategoryChangeRequest />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.MATERIAL_DISPOSE_LOGS} element={
                        <ProtectedRoute >
                            <MaterialDisposeLogs />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.MATERIAL_DEPOSIT_LOGS} element={
                        <ProtectedRoute >
                            <MaterialDepositLogs />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.AUDIT_MOVEMENT_LIST} element={
                        <ProtectedRoute >
                            <AuditMovementList />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.TRANSACTION_DEPOSIT_LOGS} element={
                        <ProtectedRoute >
                            <TransactionLogsDeposit />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.TRANSACTION_DISPOSE_LOGS} element={
                        <ProtectedRoute >
                            <TransactionLogsDispose />
                        </ProtectedRoute>}
                    />
                    
                    <Route path={PATH.PRIVATE.APPROVE_BINCODE_CHANGE} element={
                        <ProtectedRoute >
                            <CncBinCodeRequests />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.CATEGORY_CHANGE_LIST} element={
                        <ProtectedRoute >
                            <CategoryChangeList />
                        </ProtectedRoute>}
                    />
                    <Route path={PATH.PRIVATE.APPROVE_CATEGORY_CHANGE} element={
                        <ProtectedRoute >
                            <CncCategortyRequests />
                        </ProtectedRoute>}
                    />
                    <Route path="*" element={<Navigate to={PATH.PUBLIC.SIGN_IN} />} />
                    {/* <Route path="*" element={<Navigate to={PATH.PUBLIC.ERROR_404} />} /> */}
                </Routes>
                <Toast />
            </React.Fragment >
        </Suspense>)
}

export default ProjectRoutes;