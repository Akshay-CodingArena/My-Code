import React from 'react'
import { useSelector } from "react-redux"
import { Navigate, useLocation } from "react-router-dom"
import useLocalStorage from '../utils/localStorage';
import { PATH } from '../paths/path';

const ProtectedRoute = ({ children }: any) => {

    const token = useLocalStorage.getItem("accessToken")

    let location = useLocation();


    if (!token) {
        return <Navigate to={PATH.PUBLIC.SIGN_IN} state={{ from: location }} replace />
    }

    return children;

};

export default ProtectedRoute;