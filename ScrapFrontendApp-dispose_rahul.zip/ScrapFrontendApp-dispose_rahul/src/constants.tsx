export const CONSTANTS: any = {
    ADMIN_ACCOUNT_CREATION_FOR:
        [

            {
                value: "2",
                label: "Store Manager"
            },
            {
                value: "4",
                label: "C&C Head"
            },
            {
                value: "3",
                label: "HOD"
            },
            {
                value: "6",
                label: "Audit"
            }
        ]
}