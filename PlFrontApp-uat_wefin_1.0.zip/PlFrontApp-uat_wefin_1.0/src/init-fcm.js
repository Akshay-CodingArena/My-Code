import * as firebase from "firebase/app";
import { getMessaging, getToken } from "firebase/messaging";
// import { initializeApp } from "firebase/app";
import { getAnalytics, logEvent } from "firebase/analytics";
import CONSTANTS from "./constants/Constants";

// const firebaseConfig = {
//   apiKey: "AIzaSyAaVcKhdNHvCSHGKEuJaowtYP7a6ybyZEk",
//   authDomain: "neo-loan-db3e4.firebaseapp.com",
//   databaseURL: "https://rattanindia.firebaseio.com",
//   projectId: "neo-loan-db3e4",
//   storageBucket: "neo-loan-db3e4.appspot.com",
//   messagingSenderId: "719146948971",
//   appId: "1:719146948971:web:d7ffb3a8759446eca1542e",
//   measurementId: "G-T6CRM36BLT",
// };

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  // apiKey: "AIzaSyAaVcKhdNHvCSHGKEuJaowtYP7a6ybyZEk",
  // authDomain: "neo-loan-db3e4.firebaseapp.com",
  // projectId: "neo-loan-db3e4",
  // storageBucket: "neo-loan-db3e4.appspot.com",
  // messagingSenderId: "719146948971",
  // appId: "1:719146948971:web:d7ffb3a8759446eca1542e",
  // measurementId: "G-MZ2G5L9PZP",
  apiKey: "AIzaSyD5Sk8aGlnHxmEOJmlFgGn4vGHgl1-Vi0Q",
  authDomain: "bankse-1b555.firebaseapp.com",
  projectId: "bankse-1b555",
  storageBucket: "bankse-1b555.appspot.com",
  messagingSenderId: "115209285793",
  appId: "1:115209285793:web:3814bcfba40fe1667380e0",
  measurementId: "G-DNMWQLQMHJ",
};
// Initialize Firebase

//firebase.initializeApp(config);
//const messaging = firebase.messaging();
const firebaseApp = firebase.initializeApp(firebaseConfig);
// Get registration token. Initially this makes a network call, once retrieved
// subsequent calls to getToken will return from cache.
const messaging = getMessaging();
getToken(messaging, {
  vapidKey:
    "BGx1e3AujhE8Ex6CCo93wqlsGpqRLgDYwZMirVScowbCPbKg62hFThXjpaMD8CHI9UI9IYCfCCxlG7J7kooP9JM",
})
  .then((currentToken) => {
    if (currentToken) {
      // Send the token to your server and update the UI if necessary
      // ...
      localStorage.setItem("GCToken", currentToken);
    } else {
      // Show permission request UI
      console.log(
        "No registration token available. Request permission to generate one."
      );
      // ...
    }
  })
  .catch((err) => {
    console.log("An error occurred while retrieving token. ", err);
    // ...
  });

const analytics = getAnalytics(firebaseApp);
const gaLogEvent = (eventName, params) => {
  logEvent(analytics, eventName, {
    platform: CONSTANTS.GA_EVENTS_PARAMS.WEB,
    ...params,
  });
};

export { firebaseApp, messaging, gaLogEvent };
