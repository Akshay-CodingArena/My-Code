import { Component } from "react";
import { entries } from "../components/common/dropdownValues";
import SelectSearch from "../components/common/select";
class ShowEntries extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: {}

        }
    }


    availableEntries = () => {
        if (this.props.totalApplication <= 10) {
            return [{
                value: this.props.offset,
                label: this.props.offset
            }]
        }
        else if (this.props.totalApplication < 50) {
            return entries.slice(0, Math.floor(this.props.totalApplication / 10) + 1)
        }
        else {
            return entries
        }
    }

    componentDidMount = () => {
        this.setState({
            data: {
                ...this.state.data,
                entriesQty: {
                    value: this.props.offset,
                    label: this.props.offset
                }
            }
        })
    }

    componentDidUpdate = () => {
        if (this.props.offset !== this.state.data?.entriesQty?.value) {
            this.setState({
                data: {
                    ...this.state.data,
                    entriesQty: {
                        value: this.props.offset,
                        label: this.props.offset
                    }
                }
            })
        }
    }


    render() {
        return (<>
            <SelectSearch
                key={`i${Math.random()}`}
                removeLabel={true}
                placeholderValue={this.state.data?.entriesQty}
                value={this.state.data?.entriesQty}
                setSelectedOption={(e) => {

                    this.props.setCurrPage(1);

                    this.setState({
                        data: {
                            ...this.state.data, entriesQty: e.value
                        }
                    });

                    this.props.setOffset(e.value)
                }}
                dropDownOptions={this.availableEntries()}
                error={this.state.errors?.entriesQty}
            ></SelectSearch>
        </>)
    }
}

export default ShowEntries