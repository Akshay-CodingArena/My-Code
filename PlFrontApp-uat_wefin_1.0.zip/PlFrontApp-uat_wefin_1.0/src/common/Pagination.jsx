import Pagination from 'react-bootstrap/Pagination';

function Paging(props) {
    const arrayRange = (start, stop, step) =>
        Array.from(
            { length: (stop - start) / step + 1 },
            (value, index) => start + index * step
        );

    // const pages = arrayRange(1, props.pages, 1)
    const pages = []
    if (props.currPage > 1) {
        pages.push(props.currPage - 1)
    }
    pages.push(props.currPage)

    if (props.currPage < props.pages) {
        pages.push(props.currPage + 1)
    }

    const prevPage = () => {
        props.setCurrPage(props.currPage - 1)
    }
    const nextPage = () => {
        props.setCurrPage(props.currPage + 1)
    }
    const setPage = (page) => {
        props.setCurrPage(page);
    }

    return (
        <nav aria-label="...">
            <ul class="pagination" style={{ userSelect: "none" }}>
                {/* <li class="page-item disabled">
                    <a class="page-link previous" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li> */}
                <li class={`page-item ${props.currPage == 1 ? "disabled" : null}`}>
                    <a class={`page-link previous`} onClick={prevPage} >Previous</a>
                </li>
                {
                    props.currPage >= 3 ?
                        <li class={`page-item`}>
                            <a class={`page-link previous`} onClick={() => setPage(1)} >1</a>
                        </li>
                        : ""
                }
                {
                    props.currPage > 3 ? <Pagination.Ellipsis /> : ""
                }


                {pages.map(i => (
                    <li class={`page-item ${props.currPage == i ? "active" : null}`}>
                        <a class="page-link" onClick={() => setPage(i)}>{i}</a>
                    </li>
                ))}
                {
                    props.pages - props.currPage > 2 ? <Pagination.Ellipsis /> : ""
                }
                {
                    props.pages - props.currPage >= 2 ?
                        <li class={`page-item `}>
                            <a class={`page-link previous`} onClick={() => setPage(props.pages)} >{props.pages}</a>
                        </li>
                        : ""
                }
                {/* <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">2</a>
                </li>
                <li class="page-item"><a class="page-link" href="#">3</a></li> */}
                <li class={`page-item  ${props.currPage == props.pages ? " disabled" : null}`}>
                    <a class={`page-link previous ${props.currPage == props.pages ? "disabled" : null}`} onClick={nextPage}>Next</a>
                </li>
            </ul>
        </nav >
    );
}

export default Paging;
