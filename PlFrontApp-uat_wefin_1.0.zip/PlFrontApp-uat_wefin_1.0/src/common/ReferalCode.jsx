import React, { Component } from "react";
import { Modal } from "react-bootstrap";
import { sendReferCode } from "../store/sendReferCode";
import Swal from "sweetalert2";
import ReferIfon from "../include/assets/icons/referIcon.png";
import { withRouter } from "react-router";
import { connect } from "react-redux";

class ReferalCode extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: true,
      mobileNumber: "",
      MobileNumberError: "",
      referMobileNumber: "",
      name: "",
      referCode: "",
      disable: true,
    };
  }

  __handleMobileNumber = (event) => {
    event.preventDefault();
    const mobile_number = event.target.value;
    if (Number(mobile_number) && mobile_number.length === 10) {
      this.setState({ disable: false });
    }
    if (mobile_number.length === 10 && !/^[6789]\d{9}$/.test(mobile_number)) {
      this.setState({
        disable: true,
        MobileNumberError: "Please enter a valid mobile number.",
      });
    } else if (
      mobile_number.length === 10 &&
      mobile_number === this.state.mobileNumber
    ) {
      this.setState({
        disable: true,
        MobileNumberError:
          "Refer Mobile number and Register Mobile should not same",
      });
    } else {
      this.setState({
        MobileNumberError: "",
      });
    }
    if (
      (Number(mobile_number) && mobile_number.length < 10) ||
      event.target.value.length < 1
    ) {
      this.setState({ disable: true });
    }
    if (
      mobile_number.length <= 10 &&
      (/^[0-9]+$/.test(mobile_number) || mobile_number === "")
    ) {
      this.setState({ referMobileNumber: mobile_number });
    }
  };
  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "Enter Mobile Number":
          const mobile_number = event.target.value;
          this.setState({ disable: true });
          if (mobile_number.length === 10 && this.state.disable === false) {
            this._sendReferCode(event);
          } else {
            let msg = "Ten digits not Entered !";
          }
          break;
      }
    }
  };
  _sendReferCode = (e) => {
    e.preventDefault();
    const referData = {
      mobile: this.state.mobileNumber,
      refermobile: this.state.referMobileNumber,
      refercode: this.state.referCode,
      name: this.state.name,
    };
    this.props.sendReferCode(referData, this.callbackRefer);
  };
  callbackRefer = (res) => {
    if (res) {
      if (res.data.success) {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
        Swal.fire({
          position: "center",
          icon: "success",
          title: res.data.message,
          showConfirmButton: true,
          timer: 1800,
        });
      } else {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
        Swal.fire({
          position: "center",
          icon: "error",
          title: "Try after sometimes",
          showConfirmButton: true,
          timer: 1800,
        });
      }
    }
  };
  openModal = () => {
    this.setState({ isOpen: true });
    this.setState({ referCode: localStorage.getItem("referCode") });
    this.setState({ name: localStorage.getItem("fullName") });
    this.setState({ mobileNumber: localStorage.getItem("mobilenumber") });
  };
  closeModal = () => {
    this.setState({ isOpen: false });
    this.setState({ referMobileNumber: "" });
    this.setState({ disable: true });
  };

  render() {
    return (
      this.state.showModal && (
        <Modal
          className="ReferFriendModal"
          show={this.state.isOpen}
          onHide={this.closeModal}
        >
          <Modal.Header closeButton></Modal.Header>
          <Modal.Body className="text-center">
            <figure>
              <img src={ReferIfon} width="" height="" />
            </figure>
            <h4>Refer Your Friends</h4>
            <p>
              Invite Your friends to sign up with your referral code and avail
              loan.
            </p>
            <h6>
              Your Refrral Code: <span>{this.state.referCode}</span>
            </h6>
            <div className="rf-input-block">
              <input
                type="text"
                placeholder="Enter Your Friends Mobile No."
                value={this.state.referMobileNumber}
                onChange={this.__handleMobileNumber}
                maxLength="10"
                onKeyPress={(e) =>
                  this.__handleKeyPress(e, "Enter Mobile Number")
                }
                autoFocus
                id="MobileNumber"
                name="MobileNumber"
              />
              <button
                disabled={this.state.disable}
                type="submit"
                onClick={(e) => this._sendReferCode(e)}
                className="btn btn-primary get-otp-btn"
              >
                Invite
              </button>
              {this.state.MobileNumberError && (
                <p className="referModalError text-center">
                  {this.state.MobileNumberError}
                </p>
              )}
            </div>
          </Modal.Body>
        </Modal>
      )
    );
  }
}
// const mapStateToProps = (state) => ({});
// const mapDispatchToProps = (dispatch) => ({
//   sendReferCode: (params, callback) =>
//     dispatch(sendReferCode(params, callback)),
// });

// export default DownloadAppModal;
// export default withRouter(
//   connect(mapStateToProps, mapDispatchToProps)(ReferalCode)
// );
export default ReferalCode;
