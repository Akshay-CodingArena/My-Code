import React, { Component } from "react";
import { DropdownButton, Dropdown } from "react-bootstrap";
import { ReactComponent as SearchIcon } from "../include/assets/twoWheelerLogo/search.svg";
import { ReactComponent as ArrowUpwardIcon } from "../include/assets/twoWheelerLogo/arrow.svg";
class LocationDropDown extends Component {
  state = { anchorEl: false, pincode: "" };

  handleClose = () => {
    this.setState({ anchorEl: "" });
  };

  render() {
    const open = Boolean(this.state.anchorEl);
    return (
      <div className="bsLocationSearch">
        <DropdownButton
          show={open}
          onToggle={(isOpen, event, metadata) => {
            if (metadata.source !== "select") {
              this.setState({ anchorEl: isOpen });
            }
          }}
          title={this.props.childComponent}
          id="dropdown-menu-align-end"
        >
          <Dropdown.Item eventKey="1">
            <div className="form-group">
              <input
                className="form-control"
                style={{ border: "none" }}
                placeholder="Enter Pincode"
                name="pincode"
                id="pincode"
                maxLength="6"
                minLength="6"
                defaultValue={this.props.pin}
                onChange={(e) => this.props.__handlePinCode(e)}
              />

              <span className="input-icon">
                <SearchIcon
                  sx={{
                    color: "rgba(31, 31, 31, .4)",
                    marginRight: "-20px",
                  }}
                />
              </span>
              {this.props.pinError && <p>{this.props.pinError}</p>}
            </div>
          </Dropdown.Item>
          <Dropdown.Item eventKey="2">
            <div
              disableRipple={true}
              sx={{
                "&:hover": {
                  backgroundColor: "#fff",
                },
              }}
              onClick={this.handleClose}
              className="bsLocationSearchList"
            >
              <input
                className="form-control"
                style={{ border: "none", pointerEvents: "none" }}
                value={
                  this.props.pin && this.props.pin  + ", " + this.props.city
                }
              />
              <span className="input-icon">
                <ArrowUpwardIcon
                  sx={{
                    transform: "rotate(-45deg)",
                    color: "rgba(31, 31, 31, .4)",
                    margin: "0px -40px 0px 20px",
                  }}
                />
              </span>
            </div>
          </Dropdown.Item>
        </DropdownButton>
      </div>
    );
  }
}

export default LocationDropDown;
