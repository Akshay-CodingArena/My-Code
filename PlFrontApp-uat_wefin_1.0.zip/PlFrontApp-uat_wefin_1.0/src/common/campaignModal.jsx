import React, { Component } from "react";
import AppStore from "../include/assets/icons/appstore.svg";
import PlayStore from "../include/assets/icons/playstore.svg";
import { Modal } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";


class CampaignModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showModal: true,
        };
    }

    componentWillUnmount = () => {
        this.setState({ showModal: false });
    };


    componentDidMount = () => {
        console.log(this.props.campaignData)
    }

    render() {
        return (
            this.state.showModal && (
                <Modal
                    className="DownLoadAppModal campaignModal"
                    show={this.state.showModal}
                    onHide={() => this.setState({ showModal: false })}
                    dialogClassName="modal-90w"
                    aria-labelledby="example-custom-modal-styling-title"
                >
                    <Modal.Header closeButton></Modal.Header>
                    <Modal.Body className="text-center">
                        <div className="DownLoadAppBlock">
                            <p><strong>Thank You,</strong>
                                Your application has been submitted successfully.
                                Login to check the status of your application.</p>
                            <div className="loanId">Loan Application: <strong>{this.props.campaignData.loanName}</strong></div>
                            <div className="MobileNo">Mobile Number:<strong> {this.props.campaignData.mobileNumber}</strong></div>

                            {/* <p>
                One-Stop Solution for all your financial needs with hassle free
                process & quick disbursal.
              </p> */}
                            <div className="DownloadApp">
                                <span>App Available on</span>
                                <img src={PlayStore} alt="play store icon" />

                                <img src={AppStore} alt="app store icon" />

                                <a
                                    className="AppDownloadBtn"
                                    href="https://bankseapp.page.link/download"
                                >
                                    Download App Now
                                </a>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
            )
        );
    }
}


export default CampaignModal;
