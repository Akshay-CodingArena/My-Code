import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getAAdata, getExperian } from "../store/experian";
import NEO from "../include/assets/wefin_logo.svg";
import { Col, Row } from "react-bootstrap";
import moment from "moment/moment";


function getWords(monthCount) {
  function getPlural(number, word) {
    return number === 1 && word.one || word.other;
  }

  var months = { one: 'month', other: 'months' },
    years = { one: 'year', other: 'years' },
    m = monthCount % 12,
    y = Math.floor(monthCount / 12),
    result = [];

  y && result.push(y + ' ' + getPlural(y, years));
  m && result.push(m + ' ' + getPlural(m, months));
  return result.join(' and ');
}

class AApdf extends Component {
  constructor(props) {
    super(props);
  }


  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    ///////////////////////test////////////////
    let queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const consentId = urlParams.get('consentId');
    /////////////////////test//////////////////
    this.props.getAAdata({ consentId: consentId }, this.callBackAaData)
  };

  callBackAaData = (res) => {
  }

  render() {
    let bankData = {};
    if (this.props?.aaData?.BankData?.data[0]?.data) {
      bankData = JSON.parse(this.props?.aaData?.BankData?.data[0]?.data);
      console.log(JSON.parse(this.props?.aaData?.BankData?.data[0]?.data));
      let totalDebit = 0;
      let totalCredit = 0;
      if (bankData?.Transactions?.Transaction?.length) {
        bankData?.Transactions?.Transaction?.map((v) => {
          if (v.type === 'CREDIT') totalCredit += parseFloat(v.amount)
          else totalDebit += parseFloat(v.amount);
        })
      }

      bankData.Summary.totalCredit = totalCredit;
      bankData.Summary.totalDebit = totalDebit;
      bankData.closingBalance = bankData?.Transactions?.Transaction[bankData?.Transactions?.Transaction?.length - 1]?.currentBalance;
    }
    return (<React.Fragment>
      <div className="container-fluid aaPdfContainer">
        <Row>
          <Col sm={12} md={12} style={{ display: "flex", justifyContent: "end" }}>
            <img src={NEO} alt="" className="aaPdfImage" />
          </Col>

          <Col sm={12} md={12} style={{ marginBottom: "40px" }}>
            <h1 className="text-center">Bank Name : <span className="infoAcc">{bankData.bank}</span></h1>
            <h1>Account Number : <span className="infoAcc">{bankData.maskedAccountNumber}</span></h1>
            <h1>Statement Period : <span className="infoAcc">{getWords(Math.ceil(moment(bankData?.Transactions?.endDate, "YYYY-MM-DD").diff(moment(bankData?.Transactions?.startDate, "YYYY-MM-DD"), 'months', true)) + 1)}{"(From : " + moment(bankData?.Transactions?.startDate).format("DD MMMM YYYY") + " To: " + moment(bankData?.Transactions?.endDate).format("DD MMMM YYYY") + ")"}</span></h1>
          </Col>
          <Col sm={6} md={6}>
            <h1>Personal Details</h1>
          </Col>
          <Col sm={6} md={6}>
            <h1>Account Details</h1>
          </Col>
          <Col sm={6} md={6}>
            <p>Name : {bankData?.Profile?.Holders?.Holder[0]?.name}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Current Balance : {"₹" + Number(bankData?.Summary?.currentBalance)?.toLocaleString('en-IN')}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>DOB : {moment(bankData?.Profile?.Holders?.Holder[0]?.dob).format('DD/MM/YYYY')}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Currency : {bankData?.Summary?.currency}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Mobile : {bankData?.Profile?.Holders?.Holder[0]?.mobile}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Account Type : {bankData?.Profile?.Holders?.type}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Address : {bankData?.Profile?.Holders?.Holder[0]?.address}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>IFSC Code : {bankData?.Summary?.ifscCode}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Email : {bankData?.Profile?.Holders?.Holder[0]?.email?.toLowerCase()}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>MICR Code : {bankData?.Summary?.micrCode}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>PAN : {bankData?.Profile?.Holders?.Holder[0]?.pan}</p>
          </Col>
          <Col sm={6} md={6}>
            <p>Account Opening Date : {moment(bankData?.Summary?.openingDate).format('DD/MM/YYYY')}</p>
          </Col>
          <Col sm={6} md={6}>

          </Col>
          <Col sm={6} md={6}>
            <p>Current OD Limit : {bankData?.Summary?.currentODLimit}</p>
          </Col>

          <Col sm={12} md={12}>
            <table class="table table-bordered mt-3">
              <thead>
                <tr>
                  <th scope="col">Opening Balance(₹)</th>
                  <th scope="col">Total Debit(₹)</th>
                  <th scope="col">Total Credit(₹)</th>
                  <th scope="col">Closing Balance(₹)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{0}</td>
                  <td>{Number(bankData?.Summary?.totalDebit)?.toLocaleString('en-IN')}</td>
                  <td>{Number(bankData?.Summary?.totalCredit)?.toLocaleString('en-IN')}</td>
                  <td>{Number(bankData.closingBalance)?.toLocaleString('en-IN')}</td>
                </tr>
              </tbody>
            </table>
          </Col>

          <Col sm={12} md={12} style={{ marginTop: "50px" }}>
            <h1 className="mt-3 mb-3 text-center" style={{ fontSize: "130%" }}>Transaction Details</h1>
            <table className="table  table-striped table-bordered mt-3">
              <thead>
                <tr>
                  <th scope="col">Transaction Date</th>
                  <th scope="col">Description      </th>
                  <th scope="col">Reference</th>
                  <th scope="col">Debit(₹)</th>
                  <th scope="col">Credit(₹)</th>
                  <th scope="col">Balance(₹)</th>
                </tr>
              </thead>
              <tbody>
                {bankData?.Transactions?.Transaction?.map((v, index) => {
                  return <tr key={index}>
                    <td>{moment(v.transactionTimestamp).format('DD/MM/YYYY')}</td>
                    <td>{v.narration}</td>
                    <td>{v.reference}</td>
                    <td>{v.type === 'DEBIT' ? Number(v.amount)?.toLocaleString('en-IN') : ""}</td>
                    <td>{v.type === 'CREDIT' ? Number(v.amount)?.toLocaleString('en-IN') : ""}</td>
                    <td>{Number(v.currentBalance)?.toLocaleString('en-IN')}</td>
                  </tr>
                })
                }

              </tbody>
            </table>

          </Col>
        </Row>
      </div>
    </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  aaData: getExperian(state).aaData
});

const mapDispatchToProps = (dispatch) => ({
  getAAdata: (params, callbackDetail) =>
    dispatch(getAAdata(params, callbackDetail)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(AApdf)
);
