import React, { Component } from "react";
import Swal from "sweetalert2";
import { encryptStore, decryptStore, clearStore } from "../Utils/store";
import { Container, Row, Col, Card } from "react-bootstrap";
import Gauger from "../components/CibilCheck/gauge";
import plIcon from "../include/assets/icons/pl.svg";
import ccIcon from "../include/assets/icons/cc.svg";
import tlIcon from "../include/assets/icons/tl.svg";
import HomeLoanIcon from "../include/assets/homepageIcons/homeloan.svg";
import BusinessLoanIcon from "../include/assets/homepageIcons/businessloan.svg";
import creditScoreVector from "../include/assets/banner/credit-score-vector.png";
import { HomeProductLink, splitMulti } from "./helperCells";
import DashBoardAside from "./dashboardAside";
import CreditFooter from "../components/cibilFlow/footer";
import BackDropComponent from "./BackDropComponent";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import PreApprovedTwlOffer from "../common/preApprovedTwlOffer";
import PreApprovedTwlOfferSlider from "../common/preApprovedTwlOfferSlider";
import { getAccountInfo, getAccount, setAccountInfo } from "../store/account";
import {
  loadApplyLoan,
  getApplyLoan,
  loadLoanDetail,
  loadApprovalDetail,
} from "../store/applyLoan";
import moment from "moment";
import { checkPaPqOffer, papqData, getPaPqOffer } from "../store/papqOffer";
import {
  getBankOffer,
  getOffer,
  setBankOfferList,
  setOfferList,
} from "../store/bankOffer";
import { getExperian, loadExperianCheck } from "../store/experian";
import TopNavBar from "./TopNavBar";
import { gaLogEvent } from "../init-fcm";
import PATH from "../paths/Paths";
import CONSTANTS from "../constants/Constants";
import { JourneyContinueMoneyplus } from "../components/TwoWheelerJourney/Revolt/loanStages";
import path from "path";
import { loadGeoLocation } from "../store/pincode";
import { paysensePL, paysenseGetPlans } from "../store/personalLoan/paysense";
class HomeProducts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      setLoading: false,
      show: false,
      code: "",
      NoCheckCibil: "",
      cibilScore: "",
      credit: "",
      hasError: false,
      openPopup: false,
      showPAPQSlider: false,
    };
  }

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    let mobile = localStorage.getItem("mobilenumber");
    this.setState({ setLoading: true });
    clearStore(localStorage.getItem("mobilenumber"));
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
    this.props.checkPaPqOffer({ mobile: mobile, lenderName: "BJ" }, this.callbackPaPQ);
    if (!(localStorage.getItem("state") && localStorage.getItem("city") && localStorage.getItem("pin"))) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          let mobile = localStorage.getItem("mobilenumber");
          this.getGeoLocation(
            position.coords.latitude,
            position.coords.longitude,
            mobile
          );
        },
        (error) => {
          if (error) {
            Swal.fire({
              position: "center",
              icon: "warning",
              title: "Please allow your location !!",
              showConfirmButton: true,
            }).then(() => {
              this.props.history.push(PATH.PRIVATE.PRODUCTS);
            });
          }
        }
      );
    }
    this.handleExpShow();
  };
  callbackPaPQ = async (res) => {
    try {
      let r = await res;
      if (r?.data?.success) {
        let mobile = localStorage.getItem("mobilenumber");
        this.props.getPaPqOffer({ mobile: mobile }, this.callbackgetPaPQ);
      }
      else {
        throw r.data.message.toString();
      }
    } catch (e) {
      this.setState({ setLoading: false })
    }
  };
  callbackgetPaPQ = async (res) => {
    if (res?.data?.success) {
      this.setState({ setLoading: false, openPopup: true });
      this.setState({ setLoading: false, showPAPQSlider: true })
    }
  };

  callbackDetail = async (res) => {

    try {
      let r = await res;
      if (r.data.success) {
        localStorage.setItem("email", r.data.customer.personemail);
        localStorage.setItem("accsfid", r.data.customer.accsfid);
      } else {
        throw r?.data?.message?.toString();
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : "Error occured while fetching data...",
        showConfirmButton: false,
        timer: 1800,
      }).then(() => {
        this.props.history.push(PATH.PUBLIC.INDEX);
      });
    } finally {
      this.setState({ setLoading: false });
    }
  };

  bankOffer = (data) => {
    if (data) {
      let setDetailsData = {
        loanId: data[0].loan_application_id__c,
        loanType: data[0].loan_record_type__c,
        lenderId: data[0].lender_id__c,
        roi: data[0].roi,
        tenure: data[0].tenure,
        mobile: localStorage.getItem("mobilenumber"),
        emi: data[0].emi,
        offerSfid: data[0].offerSfid,
        downPayment: data[0].down_payment__c,
      };
      this.props.setBankOfferList(setDetailsData, this.callBack);
    }
  };

  callBack = (res) => {
    if (res) {
      if (res.data.success) {
        setTimeout(() => {
          this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD);
          this.setState({ setLoading: false });
        }, 2000);
      }
    }
  };
  loanCall = (id) => {
    const mobile = localStorage.getItem("mobilenumber");
    switch (id) {
      case "Personal_Loan":
        gaLogEvent(CONSTANTS.GA_EVENTS.PL_CLICKED);
        break;
      case "TW_Loan":
        gaLogEvent(CONSTANTS.GA_EVENTS.TW_CLICKED);
        break;
      case "Home_Loan":
        gaLogEvent(CONSTANTS.GA_EVENTS.HL_CLICKED);
        break;
      case "Business_Loan":
        gaLogEvent(CONSTANTS.GA_EVENTS.BL_CLICKED);
        break;
      default:
        gaLogEvent(CONSTANTS.GA_EVENTS.CC_CLICKED);
        break;
    }

    const query = splitMulti(this.props.location.search, ["?", "&", "="]);
    if (query.length > 0) {
      var formData;
      formData = {
        mobile: mobile,
        utm_source: query[2],
        utm_medium: query[4],
        utm_id: query[8],
        utm_campaign: query[6],
        loanType: id,
      };
    } else {
      formData = {
        mobile: mobile,
        loanType: id,
      };
    }
    this.props.loadApplyLoan(formData, this.callbackLoan);
  };
  callbackLoan = (res) => {
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid },
          loanType,
        } = res.data;

        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: loanType,
        };
        encryptStore(mobile, storeData);
        localStorage.setItem("loansfid", loansfid);
        this.props.getAccountInfo({ mobile: mobile }, this.callbackLoanDetail);
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res?.data?.message ? res.data.message : "Error occured while fetching data...",
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };


  callBackGeolocation = (res) => {
    if (res) {
      if (!res.data.success) {
        /////////show swal////////
        Swal.fire({
          position: "center",
          icon: "warning",
          title: "Error while fetching Geolocation informartion",
          timer: 1800,
        })
      } else {
        this.setState({
          pin: res.data.locInfo.pincode,
          city: res.data.locInfo.city,
          geoError: "",
        });
        localStorage.setItem("state", res.data.locInfo.state);
        localStorage.setItem("city", res.data.locInfo.city);
        localStorage.setItem("pin", res.data.locInfo.pincode);
      }
    }
  };

  callbackLoanDetail = (res) => {
    if (res?.data?.success) {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loansfid, loanType } = decryptedData;
      if (loanType === CONSTANTS.LOAN_TYPE.BUSINESS_LOAN) {
        if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail[0].bl_loans.length &&
          this.props.getAccountDetail[0].bl_loans[0].loanStage === "Captured"
        )
          this.props.history.push(PATH.PRIVATE.BUSINESS_LOAN_OFFERS);
        else if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail[0].bl_loans.length &&
          this.props.getAccountDetail[0].bl_loans[0].loanStage !== "Captured"
        )
          this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
        else if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail[0].bl_loans.length === 0
        ) {
          this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
        } else {
          this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
        }
      }
      if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
        if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail[0].hl_loans.length &&
          this.props.getAccountDetail[0].hl_loans[0].loanStage === "Captured"
        )
          this.props.history.push(PATH.PRIVATE.HOME_LOAN_OFFERS);
        else if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail[0].hl_loans.length &&
          this.props.getAccountDetail[0].hl_loans[0].loanStage !== "Captured"
        )
          this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
        else if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail[0].hl_loans.length === 0
        ) {
          this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
        } else {
          this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
        }
      } else if (loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
        if (this.props.getAccountDetail[0].pl_loans.length === 1) {
          if (
            this.props.getAccountDetail[0].pl_loans[0].loanStage !==
            "Assigned" ||
            this.props.getAccountDetail[0].pl_loans[0].loanStage !==
            "Soft Approved" ||
            this.props.getAccountDetail[0].pl_loans[0].loanStage !== "Declined"
          ) {
            if (
              this.props.getAccountDetail[0].pl_loans[0].loanStage === "Offers"
            ) {
              let formData =
                "mobile=" +
                mobile +
                "&loanId=" +
                this.props.getAccountDetail[0].pl_loans[0].loanId +
                "&loanType=" +
                this.props.getAccountDetail[0].pl_loans[0].loanType;

              this.props.getOffer(formData, this.callBackGet);
            } else if (
              this.props.getAccountDetail[0].pl_loans[0].loanStage ===
              "Mobile Registered" ||
              this.props.getAccountDetail[0].pl_loans[0].loanStage ===
              "customer details" ||
              this.props.getAccountDetail[0].pl_loans[0].loanStage ===
              "Basic Loan Details" ||
              this.props.getAccountDetail[0].pl_loans[0].loanStage === "Captured"
            ) {
              if (this.props.customerDetail.pan_verified__c === true) {
                this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
              } else {
                this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
              }
            } else {
              this.props.history.push(
                `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`
              );
            }
          }
        } else {
          this.props.history.push(
            `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`
          );
        }
      } else if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
        if (
          this.props.customerDetail.pan_verified__c === true &&
          this.props.getAccountDetail.length > 0 &&
          this.props.getAccountDetail[0]?.cc_loans &&
          this.props.getAccountDetail[0]?.cc_loans.length > 0 &&
          this.props.getAccountDetail[0]?.cc_loans[0].loanStage !==
          "Mobile Registered"
        ) {
          this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
        } else {
          this.props.history.push(PATH.PRIVATE.CREDIT_CARD);
        }
      } else if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {

        // if (
        //   this.props.getAccountDetail.length > 0 &&
        //   this.props.getAccountDetail[0].tw_loans &&
        //   this.props.getAccountDetail[0].tw_loans.length === 1 &&
        //   this.props.getAccountDetail[0].tw_loans[0].loanStage ===
        //   "PAN Verified"
        // ) {
        //   this.props.history.push({
        //     pathname: PATH.PRIVATE.PERSONAL_DETAIL,
        //     state: {
        //       bike: this.props.getAccountDetail[0].tw_loans[0].bikeData,
        //     },
        //   });
        // }
        if (this.props.getAccountDetail[0].tw_loans.length > 0) {
          let loanIdfc = this.props.getAccountDetail[0].tw_loans.filter((loan) => {
            if (loan.lenderName === "IDFC" || !loan.lenderName) {
              return true
            }
          })
          if (loanIdfc.length > 0) {
            encryptStore(localStorage.getItem("mobilenumber", { loanId: loanIdfc.loanId, loansfid: loanIdfc.loanId }))
          }
          if (loanIdfc[0].loanStage === "PAN Verified") {
            this.props.history.push({
              pathname: PATH.PRIVATE.PERSONAL_DETAIL,
              state: {
                bike: loanIdfc.bikeData,
              },
            });
          }
          else {
            this.setState({ setLoading: true });
            if (loanIdfc[0].loanStage === "Mobile Registered") {
              this.props.history.push(PATH.PRIVATE.TWO_WHEELER);
            }
            else {
              this.__handleTwoWheelerLoan(loanIdfc[0]?.loanId);
            }
          }
        } else {
          this.props.history.push(PATH.PRIVATE.TWO_WHEELER);
        }
      }
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res?.data?.message ? res.data.message : "Error occured while fetching data...",
        showConfirmButton: false,
        timer: 1800,
      }).then(() => {
        this.props.history.push(PATH.PUBLIC.INDEX);
      });
    }
  };
  callBackGet = (res) => {
    if (res) {
      if (res.data.success) {
        if (res.data.breData[0]?.loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
          this.props.history.push({
            pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
            state: res.data,
          });
        } else if (res.data.breData[0]?.loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
          this.props.history.push({
            pathname: PATH.PRIVATE.HOME_LOAN_OFFERS,
            state: res.data,
          });
        }
      }
    }
  };
  __handleTwoWheelerLoan = (loanId) => {
    let data = {
      mobile: localStorage.getItem("mobilenumber"),
      loanid: loanId
    };
    this.props.loadApprovalDetail(data, this.callApproval);
  };
  callApproval = (res) => {
    if (res) {
      if (res.data.success) {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loansfid, loanId } = decryptedData;
        const { loanStage, loanType } = res.data.details;
        // this.props.history.push({
        //   pathname: PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD,
        //   state: {
        //     bike: res.data.details.bikeData,
        //   }
        // })

        // Before Dashboard start
        if (
          loanStage === "Captured" ||
          loanStage === "Soft Approved" ||
          loanStage === "Declined"
        ) {
          let getBankData = {
            loanId: loansfid ?? loanId,
            loanType: loanType,
          };
          this.props.loadLoanDetail(getBankData, this.callBackBank);
        } else {
          this.setState({ setLoading: false });
          this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD);
        }
        //   Before Dashboard End

      }
    }
  };
  handleKnow = (e) => {
    let mobile = localStorage.getItem("mobilenumber");
    let storeData = {
      loanId: e.loanId,
      loansfid: e.loanId,
      loanName: e.loanName,
      loanType: e.loanType,
    };
    encryptStore(mobile, storeData);
    this.props.history.push({
      pathname: PATH.PRIVATE.CREDIT_CARD_DETAIL,
      state: { credit: e },
    });
  };
  handleCreditOffer = () => {
    if (this.props.getAccountDetail[0]) {
      console.log("account details", this.props.getAccountDetail[0]?.cc_loans)
      this.props.history.push({
        pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
        state: this.props.getAccountDetail[0]?.cc_loans
      });
    } else {
      this.props.history.push({
        pathname: PATH.PUBLIC.GET_CREDIT_CARD,
      });
    }
  };
  callBackBank = (res) => {
    if (res) {
      if (res.data.success) {
        localStorage.setItem(
          "loanDetail",
          JSON.stringify(res.data.getLoanDetails)
        );
        if (res.data.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          if (
            res.data?.getLoanDetails?.length > 0 &&
            res.data.getLoanDetails[0].status__c === "Active"
          ) {
            this.bankOffer(JSON.parse(localStorage.getItem("loanDetail")));
          } else {
            setTimeout(() => {
              this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD);
              this.setState({ setLoading: false });
            }, 2000);
          }
        }
      }
    }
  };


  getGeoLocation = (lat, lng, mobile) => {
    if (lat && lng) {
      const formData = "lat=" + lat + "&lng=" + lng + "&mobile=" + mobile;
      this.props.loadGeoLocation(formData, this.callBackGeolocation);
    }
  };

  handleHLContinue = (e) => {
    if (e.loanStage !== "Captured") {
      this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
    } else {
      this.props.history.push(PATH.PRIVATE.HOME_LOAN_OFFERS);
    }
  };

  handleBLContinue = (e) => {
    if (e.loanStage !== "Captured") {
      this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
    } else {
      this.props.history.push(PATH.PRIVATE.BUSINESS_LOAN_OFFERS);
    }
  };


  getOfferFunc = (mobile, loanId, loanType) => {
    let formData =
      "mobile=" +
      mobile +
      "&loanId=" +
      loanId +
      "&loanType=" +
      loanType;
    this.props.getOffer(formData, this.callBackGet);
  }

  handleTWContinue = (e) => {
    let mobile = localStorage.getItem("mobilenumber");
    let storeData = {
      loanSfid: e.loanSfid,
      loanName: e.loanName,
      loanType: e.loanType,
      loanId: e.loanId,
      lenderId: e?.lender_sfid ? e.lender_sfid : "",
      manufacturer: e?.bikeData?.manufacturer__c ? e.bikeData.manufacturer__c : "",
      appliedLoanAmount: e?.appliedLoanAmount ? e.appliedLoanAmount : "",
      lender: e?.lenderName ? e.lenderName : ""
    };
    encryptStore(mobile, storeData);

    if (e.loanStage === "Mobile Registered" || e.loanStage === "Offers") {
      this.props.history.push(PATH.PRIVATE.TWO_WHEELER)
    }
    // else if (e.lenderName === "Money Plus") {
    //   encryptStore(localStorage.getItem("mobilenumber"), {
    //     loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN,
    //     manufacturer: "REVOLT",
    //     loanId: e.loanId,
    //     loanSfid: e.loanSfid,
    //     loanName: e.loanName,
    //     lenderName: e.lenderName,
    //     lenderId: e.lender_id__c
    //   })
    //   this.props.history.push(JourneyContinueMoneyplus(e))
    // }
    else if (e.loanStage === "PAN Verified") {
      this.props.history.push({
        pathname: PATH.PRIVATE.PERSONAL_DETAIL,
        state: {
          bike: e.bikeData,
        },
      })
    } else {
      this.setState({ setLoading: true });
      this.__handleTwoWheelerLoan(e.loanId);
    }
  };
  handleCreditContinue = (e) => {
    console.log("event", e)
    let mobile = localStorage.getItem("mobilenumber");
    let storeData = {
      loansfid: e.loanId,
      loanName: e.loanName,
      loanType: e.loanType,
    };
    encryptStore(mobile, storeData);
    if (e.loanStage !== "Mobile Registered") {
      this.props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: this.props.getAccountDetail[0]?.cc_loans });
      //   this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
    } else {
      this.props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: this.props.getAccountDetail[0]?.cc_loans });
    }
  };


  callbackGetPlans = (res) => {
    if (res.data.success) {
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      this.props.history.push({
        pathname: PATH.PRIVATE.PAYSENSE_PL_FLOW,
        state: {
          step: CONSTANTS.GET_PLANS_SCREEN_PAYSENSE,
          stepperData: { ...decryptedData },
          data: res.data.response
        }
      })
    } else {
      Swal.fire({
        position: "center",
        icon: "error",
        title: res.data.message,
        position: "center",
        showConfirmButton: true,
      })
    }
  }


  handlePLContinue = (e) => {
    let mobile = localStorage.getItem("mobilenumber");
    let storeData = {
      loansfid: e.loanId,
      loanName: e.loanName,
      loanType: e.loanType,
    };
    encryptStore(mobile, storeData);

    if (e.loanStage === "Disbursement") {
      this.props.history.push({
        pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`,
        state: e,
      });
    }

    else if (e.lenderName === "HDFC") {
      let storeData = {
        loanAmount: e.appliedLoanAmount,
        proposedEmi: e.emi,
        tenure: parseInt(e.pl_applied_tenure__c),
        monthlySalary: this.props.customerDetail.monthlysalary,
        employerNameCode: this.props.customerDetail.pl_employer__pc,
        stageName: e.loanStage,
        isDropoff: true,
        lenderName: e.lenderName,
        applicationId: e.application_id ? e.application_id : "",
        loanName: e.loanName ? e.loanName : "",
        lenderId: e.lender_id__c ? e.lender_id__c : "",
        sfid: e.loanSfid ? e.loanSfid : "",
        platform: "Website"
      }
      encryptStore(mobile, storeData);
      let appliedLoanInfo =
      {
        IRR: e.IRR,
        PF: e.PF,
        appliedLoanAmount: e.appliedLoanAmount,
        bankImage: e.bankImage,
        emi: e.emi,
        pl_applied_tenure__c: e.pl_applied_tenure__c
      }
      if (e.loanStage === "Application in Review" ||
        e.loanStage === "Under Process" ||
        e.loanStage === "Case Initiated" ||
        e.loanStage === "Pre-Sanction Document Check" ||
        e.loanStage === "Decision Awaited" ||
        e.loanStage === "Disbursement Under Process" ||
        e.loanStage === "Disbursed" ||
        e.loanStage === "Approved" ||
        e.loanStage === "Additional Documents / Check pending" ||
        e.loanStage === "Reject" ||
        e.loanStage === "Duplicate Case"
      ) {

        let dataToEncrypt = {
          Filler1: e.filler1 ? e.filler1_as_resp : "",
          Filler4: e.filler4 ? e.filler1_as_resp : "",
          deviceId: e.device_id ? e.device_id : "",
        }


        encryptStore(mobile, dataToEncrypt);

        this.props.history.push({
          pathname: PATH.PRIVATE.HDFC_PL_FLOW,
          state: {
            step: CONSTANTS.CONGRATULATIONS_HDFC,
            stepperData: {},
            appliedLoanInfo: appliedLoanInfo,
            dropoffData: e,
            stepperStep: 6
          }
        })
      } else {
        this.props.history.push({
          pathname: PATH.PRIVATE.HDFC_PL_FLOW,
          state: {
            step: CONSTANTS.ADDITIONAL_INFO_HDFC_PL,
            stepperData: {},
            appliedLoanInfo: appliedLoanInfo,
            dropoffData: e
          }
        })
      }
    }
    else if (e.lenderName === "Pay Sense") {
      let data = {
        lenderName: e.lenderName,
        loanStage: e.loanStage,
        lenderId: e.lender_master__c,
        sfid: e.loanSfid,
        appliedLoanAmount: e.appliedLoanAmount,
        emi: e.emi,
        bankImage: e.bankImage,
        IRR: e.IRR,
        PF: e.pl_processing_fee_amount__c ? e.pl_processing_fee_amount__c : e.PF,
        pl_applied_tenure__c: e.pl_applied_tenure__c,
        pl_roi__c: e.pl_roi__c,
        pl_revised_emi__c: e.pl_revised_emi__c ? e.pl_revised_emi__c : "",
        pl_revised_tenure__c: e.pl_revised_tenure__c ? e.pl_revised_tenure__c : "",
        pl_revised_loan_amount__c: e.pl_revised_loan_amount__c ? e.pl_revised_loan_amount__c : "",
        pl_approved_interest_rate__c: e.pl_approved_interest_rate__c ? e.pl_approved_interest_rate__c : "",
      }
      encryptStore(mobile, { ...storeData, ...data });


      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

      if (e.loanStage === "Approval Pending" ||
        e.loanStage === "Hard Approved") {
        this.props.history.push({
          pathname: PATH.PRIVATE.PAYSENSE_PL_FLOW,
          state: {
            step: CONSTANTS.CONGRATS_SCREEN_PAYSENSE,
            stepperData: {
              ...decryptedData
            },
            stepperStep: 4
          }
        })
      }
      else {
        let formData = {
          lenderId: e.lender_master__c,
          loanName: e.loanName
        }
        this.props.paysenseGetPlans(formData, this.callbackGetPlans)
      }
    }
    else if (e.lenderName === "Fibe") {
      let data = {
        lenderName: e.lenderName,
        loanStage: e.loanStage,
        lenderId: e.lender_master__c,
        sfid: e.loanSfid
      }

      encryptStore(mobile, { ...storeData, ...data });

      if (e.loanStage === "Bank Offer Generated") { window.open(e.redirectionurl__c, "_blank") }

      else if (e.loanStage === "Assigned") {
        this.getOfferFunc(localStorage.getItem("mobilenumber"), e.loanId, e.loanType);
      }
      else if (e.loanStage === "Hold") {
        this.getOfferFunc(localStorage.getItem("mobilenumber"), e.loanId, e.loanType);
      }
      else if (e.loanStage === "Declined") {
        this.getOfferFunc(localStorage.getItem("mobilenumber"), e.loanId, e.loanType);
      }
    }
    else if (e.lenderName === "Money View") {
      let data = {
        lenderName: e.lenderName,
        loanStage: e.loanStage,
        lenderId: e.lender_master__c,
        sfid: e.loanSfid
      }

      encryptStore(mobile, { ...storeData, ...data });

      if (data.loanStage === "Assigned")
        this.getOfferFunc(localStorage.getItem("mobilenumber"), e.loanId, e.loanType);

      else if (data.loanStage === "Bank Offer Generated") {
        window.open(e.redirectionurl__c, "_blank")
      }
    }
    else if (
      e.loanStage !== "Assigned" ||
      e.loanStage !== "Soft Approved" ||
      e.loanStage !== "Declined"
    ) {
      if (e.loanStage === "Offers") {
        let formData =
          "mobile=" +
          mobile +
          "&loanId=" +
          e.loanId +
          "&loanType=" +
          e.loanType;

        this.props.getOffer(formData, this.callBackGet);
      } else if (
        e.loanStage === "Mobile Registered" ||
        e.loanStage === "customer details" ||
        e.loanStage === "Basic Loan Details" ||
        e.loanStage === "Captured"
      ) {
        if (this.props.customerDetail.pan_verified__c === true) {
          this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
        } else {
          this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
        }
      } else {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`,
          state: e,
        });
      }
    } else {
      this.props.history.push({
        pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`,
        state: e,
      });
    }
  };
  handleClose = () => {
    this.setState({ show: false });
  };
  handleShow = () => {
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackVerify);
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error" || res.data.success === false) {
          this.props.history.push(PATH.PRIVATE.CIBIL_SCORE_ANALYSIS);
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          let formData = {
            mobile: res.data.cibilData?.userData?.[0].mobileno,
            pincode: res.data.cibilData?.userData?.[0].pincode,
            name: res.data.cibilData?.userData?.[0].name,
            pan: res.data.cibilData?.userData?.[0].pan,
            dob: res.data.cibilData?.userData?.[0].dob,
            email: res.data.cibilData?.userData?.[0].email,
            cibilcheck: "Y",
            creditCode:
              (res.data.cibilData?.experianScore === -1 && "A") ||
              (res.data.cibilData?.experianScore >= 800 && "B") ||
              (res.data.cibilData?.experianScore >= 750 &&
                res.data.cibilData?.experianScore <= 799 &&
                "C") ||
              (res.data.cibilData?.experianScore >= 700 &&
                res.data.cibilData?.experianScore <= 749 &&
                "D") ||
              (res.data.cibilData?.experianScore >= 650 &&
                res.data.cibilData?.experianScore <= 699 &&
                "E") ||
              (res.data.cibilData?.experianScore >= 600 &&
                res.data.cibilData?.experianScore <= 649 &&
                "F") ||
              (res.data.cibilData?.experianScore >= 0 &&
                res.data.cibilData?.experianScore <= 599 &&
                "G"),
          };
          this.props.setAccountInfo(formData, this.callBackAcc);
        }
      }
    }
  };

  handleExpShow = () => {
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackExperian);
  };
  callBackExperian = (res) => {
    let mobile = localStorage.getItem("mobilenumber");
    if (res?.data?.status === 203) {
      this.props.getPaPqOffer({ mobile: mobile }, this.callbackgetPaPQ);
      this.setState({
        cibilScore: res.data.cibilData.experianData.experianScore,
        NoCheckCibil: false,
      });
      let formData = {
        mobile: res.data.cibilData?.userData?.[0].mobileno,
        pincode: res.data.cibilData?.userData?.[0].pincode,
        name: res.data.cibilData?.userData?.[0].name,
        pan: res.data.cibilData?.userData?.[0].pan,
        dob: res.data.cibilData?.userData?.[0].dob,
        email: res.data.cibilData?.userData?.[0].email,
        cibilcheck: "Y",
        creditCode: "A",
      };
      this.props.setAccountInfo(formData, this.callBackPlAcc);
    } else if (
      res?.data?.cibilData &&
      res.data.cibilData.experianStatus === "success" &&
      res.data.cibilData?.userData?.[0].pan
    ) {
      this.props.getPaPqOffer({ mobile: mobile }, this.callbackgetPaPQ);
      this.setState({
        cibilScore: res.data.cibilData.experianData.SCORE.BureauScore[0],
        NoCheckCibil: false,
      });
      let formData = {
        mobile: res.data.cibilData?.userData?.[0].mobileno,
        pincode: res.data.cibilData?.userData?.[0].pincode,
        name: res.data.cibilData?.userData?.[0].name,
        pan: res.data.cibilData?.userData?.[0].pan,
        dob: res.data.cibilData?.userData?.[0].dob,
        email: res.data.cibilData?.userData?.[0].email,
        cibilcheck: "Y",
        creditCode:
          (res.data.cibilData?.experianScore === -1 && "A") ||
          (res.data.cibilData?.experianScore >= 800 && "B") ||
          (res.data.cibilData?.experianScore >= 750 &&
            res.data.cibilData?.experianScore <= 799 &&
            "C") ||
          (res.data.cibilData?.experianScore >= 700 &&
            res.data.cibilData?.experianScore <= 749 &&
            "D") ||
          (res.data.cibilData?.experianScore >= 650 &&
            res.data.cibilData?.experianScore <= 699 &&
            "E") ||
          (res.data.cibilData?.experianScore >= 600 &&
            res.data.cibilData?.experianScore <= 649 &&
            "F") ||
          (res.data.cibilData?.experianScore >= 0 &&
            res.data.cibilData?.experianScore <= 599 &&
            "G"),
      };
      this.props.setAccountInfo(formData, this.callBackPlAcc);
    } else {
      this.setState({ NoCheckCibil: true });
    }
  };
  callBackPlAcc = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        this.setState({ setLoading: false });
        localStorage.setItem("fullName", this.props.userData?.[0]?.name);
        localStorage.setItem("firstName", this.props.userData?.[0]?.name);
        localStorage.setItem("pan", this.props.userData?.[0]?.pan);
      } else {
        throw r.data.message.toString();
      }
    } catch (e) {
      this.setState({ setLoading: false });
    }
  };
  callBackAcc = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
        localStorage.setItem("fullName", this.props.userData?.[0]?.name);
        localStorage.setItem("firstName", this.props.userData?.[0]?.name);
        localStorage.setItem("pan", this.props.userData?.[0]?.pan);
      }
    }
  };

  handleApply = (credit) => {
    this.setState({ credit: credit });
    let formData = {
      lenderId: credit.lender_id__c,
      loanType: credit.loanType,
      mobile: localStorage.getItem("mobilenumber"),
      loanAmount: "0",
      offerId: credit.id,
      emi: "0",
      roi: "0",
      tenure: "0",
      pf: "0",
      loanId: credit.loanId ? credit.loanId : "",
    };
    this.props.setOfferList(formData, this.callBackSet);
  };
  callBackSet = (res) => {
    if (res?.data?.success) {
      if (this.bbbb.credit.dev_name__c === "AXB") {
        window.open(
          "https://clctab.axisbank.co.in/DigitalChannel/WebForm/?ipa25",
          "_blank"
        );
      } else {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
            } / ${this.state.credit.loanType
              .split(/\s/)
              .join("-")
            } / ${this.state.credit.dev_name__c.split(/\s/).join("-")}`,
          state: { card: this.state.credit },
        });
      }
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res?.data?.message,
        showConfirmButton: false,
        timer: 1800,
      });
    }
  };

  render() {
    const { loading, loadingLoan, loadingGet, getAccountDetail } =
      this.props;
    const { loadingGetOffer, getoffer } =
      this.props.papqData;

    const { userData } = this.props;
    const arr = getAccountDetail?.[0]?.pl_loans.concat(
      getAccountDetail?.[0]?.tw_loans,
      getAccountDetail?.[0]?.cc_loans,
      getAccountDetail?.[0]?.hl_loans,
      getAccountDetail?.[0]?.bl_loans
    );

    // console.log(arr?.sort((a, b) => new Date(b.systemmodstamp) - new Date(a.systemmodstamp)))
    return (
      <>
        {" "}
        <section className="bs-main-section">
          <TopNavBar />
          {this.state.openPopup === true && (
            <PreApprovedTwlOffer getoffer={getoffer} />
          )}

          <Container>
            <Row>
              <Col sm={12} md={3}>
                <DashBoardAside />
              </Col>
              <Col sm={12} md={9}>
                {this.props.loadingCheck ||
                  loading ||
                  loadingLoan ||
                  loadingGet ||
                  // loadingCheckOffer ||
                  loadingGetOffer ||
                  this.state.setLoading
                  ||
                  this.props.loadingPaysense ? (
                  <BackDropComponent />
                ) : (
                  ""
                )}
                <h4 style={{ fontSize: "1.2rem", fontWeight: "bold" }}>Dashboard</h4>
                {/* <div className="bsDashHeader">

                  <h4>Your Credit Score</h4>
                </div>

                {/* credit score 
                {this.state.NoCheckCibil === true && (
                  <Card className="bsCheckScoreBox">
                    <Card.Body>
                      <Row>
                        <Col xs={6} sm={6}>
                          <h1>Free Credit Score</h1>
                          <p>Track Your Credit Report & Score.</p>

                          <HomeProductLink
                            text={"Check now"}
                            icon={<dArrow />}
                            clickFunc={() => this.handleShow()}
                          />
                        </Col>
                        <Col sm={6} xs={6}>
                          <img
                            src={creditScoreVector}
                            alt="creditScoreVectorIcon"
                            width=""
                            height=""
                          />
                        </Col>
                      </Row>

                      <Row></Row>
                    </Card.Body>
                  </Card>
                )} */}
                {/* {this.state.NoCheckCibil === false && (
                  <Card className="bsCibilBox">
                    <Card.Body>
                      <Row>
                        <Col sm={5}>
                          <h5>
                            Last Updated on:- &nbsp;
                            {moment(userData?.[0]?.created_on).format(
                              "DD-MMM-YYYY"
                            )}
                          </h5>
                          <Gauger
                            cibilScore={Number(this.state.cibilScore)}
                            error={this.state.error}
                          />
                        </Col>
                        <Col sm={7}>
                          <div className="bs-cs-information">
                            <h4>What does credit score mean?</h4>
                            <p>
                              It is a report based on your performance on loans.
                              It ranges between 300 and 900 and summarizes your
                              credit report, history, and rating. Banks & NBFCs uses
                              this information as one of the primary criteria for assessing your loan application.
                            </p>
                            <HomeProductLink
                              text={"View Detailed Report"}
                              clickFunc={() => this.handleShow()}
                            />
                          </div>
                        </Col>
                        <div className="bs-cs-logo">
                          <img
                            src="/experian.png"
                            alt=""
                            width="200"
                            height="65"
                          />
                        </div>
                      </Row>
                    </Card.Body>
                  </Card>
                )} */}
                <div className="bs-services">
                  <Row>
                    <Col sm={4}>
                      <a
                        className="bs-service-block"
                        href="javascript:void(0)"
                        onClick={() =>
                          this.loanCall(CONSTANTS.LOAN_TYPE.PERSONAL_LOAN)
                        }
                      >
                        <div className="bs-service-box">
                          <img
                            src={plIcon}
                            alt="Personal loan Icon"
                            width="60"
                            height="60"
                          />{" "}
                          <div>
                            <h5>Personal Loan</h5>
                            <p>
                              Get multiple personal loan offers and choose the best that
                              suits your needs
                            </p>
                          </div>
                        </div>
                        <div className="offersBtn">
                          <span>Get Best Offers</span>
                        </div>
                      </a>
                    </Col>
                    <Col sm={4}>
                      <a
                        className="bs-service-block"
                        href="javascript:void(0)"
                        onClick={() =>
                          this.loanCall(CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN)
                        }
                      >
                        <div className="bs-service-box">
                          <img
                            src={tlIcon}
                            alt="Two Wheeler Loan Icon"
                            width="60"
                            height="60"
                          />{" "}
                          <div>
                            <h5>Two Wheelers</h5>
                            <p>
                              Get instant two-wheeler loan approval for over 35
                              two-wheeler brands
                            </p>
                          </div>
                        </div>
                        <div className="offersBtn">
                          <span>Check Eligibility</span>
                        </div>
                      </a>
                    </Col>
                    <Col sm={4}>
                      <a
                        className="bs-service-block"
                        href="javascript:void(0)"
                        onClick={() => this.handleCreditOffer()
                        }
                      >
                        <div className="bs-service-box">
                          <img
                            src={ccIcon}
                            alt="credit card icon"
                            width="60"
                            height="60"
                          />{" "}
                          <div>
                            <h5>Credit Card</h5>
                            <p>
                              Get the credit card that suits you best from
                              India's trusted banks
                            </p>
                          </div>
                        </div>
                        <div className="offersBtn">
                          <span>Get Best Offers</span>
                        </div>
                      </a>
                    </Col>

                    <Col sm={4}>
                      <a
                        className="bs-service-block"
                        href="javascript:void(0)"
                        onClick={() =>
                          this.loanCall(CONSTANTS.LOAN_TYPE.HOME_LOAN)
                        }
                      >
                        <div className="bs-service-box">
                          <img
                            src={HomeLoanIcon}
                            alt="Home loan Icon"
                            width="60"
                            height="60"
                          />{" "}
                          <div>
                            <h5>Home Loan</h5>
                            <p>
                              Get multiple home loan offers and choose the best that
                              suits your needs
                            </p>
                          </div>
                        </div>
                        <div className="offersBtn">
                          <span>Apply now</span>
                        </div>
                      </a>
                    </Col>

                    <Col sm={4}>
                      <a
                        className="bs-service-block"
                        href="javascript:void(0)"
                        onClick={() =>
                          this.loanCall(CONSTANTS.LOAN_TYPE.BUSINESS_LOAN)
                        }
                      >
                        <div className="bs-service-box">
                          <img
                            src={BusinessLoanIcon}
                            alt="Business loan Icon"
                            width="60"
                            height="60"
                          />{" "}
                          <div>
                            <h5>Business Loan</h5>
                            <p>
                              Get multiple business loan offers and choose the best that
                              suits your needs
                            </p>
                          </div>
                        </div>
                        <div className="offersBtn">
                          <span>Apply now</span>
                        </div>
                      </a>
                    </Col>
                  </Row>
                </div>
                {/* preApproved Papq */}
                {this.state.showPAPQSlider === true && <PreApprovedTwlOfferSlider getoffer={getoffer} />}
                {/*PreApproved Papq */}

                {getAccountDetail?.[0]?.cc_loans.length > 0 ||
                  getAccountDetail?.[0]?.pl_loans.length > 0 ||
                  getAccountDetail?.[0]?.tw_loans.length > 0 ||
                  getAccountDetail?.[0]?.hl_loans.length > 0 ||
                  getAccountDetail?.[0]?.bl_loans.length > 0
                  ? (
                    <div className="bsActivites">
                      <h4>My Recent Applications</h4>
                      {arr
                        .slice()
                        // .sort(
                        //   (a, b) =>
                        //     new Date(b.systemmodstamp) - new Date(a.systemmodstamp)
                        // )
                        .map((e, i) => (
                          <>
                            {i < 5 && (
                              <Card>
                                <Row className="justify-content-center">
                                  <Col xs={8} sm={10}>
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
                                        <h3>Credit Card</h3>
                                      )}
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
                                        <h3>Personal Loan</h3>
                                      )}
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
                                        <h3>Two Wheeler Loan</h3>
                                      )}
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.HOME_LOAN && (
                                        <h3>Home Loan</h3>
                                      )}
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.BUSINESS_LOAN && (
                                        <h3>Business Loan</h3>
                                      )}
                                    <p>
                                      {" "}
                                      {moment(e.systemmodstamp).format(
                                        "DD-MMM-YYYY"
                                      )}
                                    </p>
                                  </Col>


                                  <Col xs={4} sm={2}>
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.HOME_LOAN && (
                                        <button
                                          onClick={() => this.handleHLContinue(e)}
                                        >
                                          Continue
                                        </button>
                                      )}

                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.BUSINESS_LOAN && (
                                        <button
                                          onClick={() => this.handleBLContinue(e)}
                                        >
                                          Continue
                                        </button>
                                      )}

                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
                                        <button
                                          onClick={() => this.handlePLContinue(e)}
                                        >
                                          Continue
                                        </button>
                                      )}
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
                                        <button
                                          onClick={() =>
                                            this.handleCreditContinue(e)
                                          }
                                        >
                                          Continue
                                        </button>
                                      )}
                                    {e.loanType ===
                                      CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
                                        <button
                                          onClick={() => this.handleTWContinue(e)}
                                        >
                                          Continue
                                        </button>
                                      )}
                                  </Col>
                                </Row>
                              </Card>
                            )}
                          </>
                        ))}
                    </div>
                  ) : (
                    <div className="bsMyApplication">
                      <h4>My Applications</h4>
                      <div className="bsMyApplicationBox">
                        You have not applied for any product in the last 60 days.
                        Compare and apply for loan products and credit cards now.{" "}
                      </div>
                    </div>
                  )}
              </Col>
            </Row>
          </Container>
        </section>
        <CreditFooter />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  offer: getAccount(state).getOffer,
  loading: getAccount(state).loading,
  loadingLoan: getApplyLoan(state).loadingLoan,
  getApplyLoan: getApplyLoan(state),
  getOffer: getBankOffer(state).getBreOffer,
  loadingGet: getBankOffer(state).loadingGet,
  loanDetail: getApplyLoan(state).loanDetail,
  loadApproval: getApplyLoan(state).loadApproval,
  loadingBank: getBankOffer(state).loadingBank,
  setBankOffer: getBankOffer(state).setBankOffer,
  experian: getExperian(state),
  userData: getExperian(state).userData,
  loadingCheck: getExperian(state).loadingCheck,
  papqData: papqData(state),
  loadingPaysense: paysensePL(state).loadingPaysense,
});

const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadApplyLoan: (params, callback) =>
    dispatch(loadApplyLoan(params, callback)),
  getOffer: (params, callback) => dispatch(getOffer(params, callback)),
  loadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  loadApprovalDetail: (params, callBack) =>
    dispatch(loadApprovalDetail(params, callBack)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
  setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
  checkPaPqOffer: (params, callBack) =>
    dispatch(checkPaPqOffer(params, callBack)),
  getPaPqOffer: (params, callBack) => dispatch(getPaPqOffer(params, callBack)),
  loadGeoLocation: (params, callBack) =>
    dispatch(loadGeoLocation(params, callBack)),
  paysenseGetPlans: (params, callback) =>
    dispatch(paysenseGetPlans(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(HomeProducts)
);
