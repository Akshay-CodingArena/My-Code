import React from "react";
import StepperComponent from "../components/PersonalLoanJourney/Stepper/StepperComponent";
import CONSTANTS from "../constants/Constants";
import plBanner from "./../include/assets/banner/pl-banner.png";
import cdBanner from "./../include/assets/banner/credit-card.png";
import twlBanner from "./../include/assets/banner/twl-banner.png";
import csBanner from "./../include/assets/banner/credit-score.svg";
import loanBanner from "./../include/assets/banner/2min_loan.png";
import LoginBanner from "./../include/assets/banner/login-banner.png";
import HLBanner from "./../include/assets/banner/hl-banner.svg";
import BLBanner from "./../include/assets/banner/bl-banner.svg";
import ASMBanner from "./../include/assets/banner/asm_login_banner.svg";
import PATH from "../paths/Paths";

const LeftMenuDecider = ({ leftComponent = 1, activeStep, stepperData, state }) => {
  if (leftComponent === CONSTANTS.LEFT_MENU_CONSTANTS.RENDER_STEPPER)
    return <StepperComponent activeStep={activeStep} stepperData={stepperData} state={state} />;
  else {
    return (
      <>
        <div className="bs-login-banner">

          {window.location.pathname === PATH.PUBLIC.BUSINESS_LOAN && (
            <div className="csbannerText">
              <figure>
                <img
                  src={BLBanner}
                  alt="personal loan banner"
                  width="340"
                  height="310"
                />
              </figure>
              <h3>Multiple Business Loan Offers </h3>
              <p>
                Multiple business loan options by Trusted Indian Banks and NBFCs. Get
                E-Approval in a few minutes from the comfort of your home. Quick
                Disbursals, Personalized Offers at Attractive Interest Rate.
              </p>
            </div>
          )}


          {window.location.pathname === PATH.PUBLIC.HOME_LOAN && (
            <div className="csbannerText">
              <figure>
                <img
                  src={HLBanner}
                  alt="personal loan banner"
                  width="340"
                  height="310"
                />
              </figure>
              <h3>Multiple Home Loan Offers </h3>
              <p>
                Multiple home loan options by Trusted Indian Banks and NBFCs. Get
                E-Approval in a few minutes from the comfort of your home. Quick
                Disbursals, Personalized Offers at Attractive Interest Rate.
              </p>
            </div>
          )}

          {window.location.pathname === PATH.PUBLIC.PERSONAL_LOAN && (
            <div className="csbannerText">
              <figure>
                <img
                  src={plBanner}
                  alt="personal loan banner"
                  width="340"
                  height="310"
                />
              </figure>
              <h3>Multiple Personal Loan Offers </h3>
              <p>
                Multiple loan options by trusted Indian Banks and NBFCs. Get
                E-Approval in a few minutes from the comfort of your home. Quick
                Disbursals, Personalized Offers at Attractive Interest Rate.
              </p>
            </div>
          )}
          {window.location.pathname === PATH.PUBLIC.TWO_WHEELER_LOAN && (
            <div className="csbannerText">
              <figure>
                <img
                  src={twlBanner}
                  alt="two wheeler banner"
                  width="344"
                  height="301"
                />
              </figure>

              <h3>Two-Wheeler Loan</h3>
              <p>
                If you are looking out for a two-wheeler loan online, you must
                have a clear idea about a few important points. You should know
                the various offers on Two-wheeler loans from leading lenders and
                their details. You can Apply for a Two-Wheeler Loan here and get
                instant approval in just a few clicks.
              </p>
            </div>
          )}
          {window.location.pathname === PATH.PUBLIC.CREDIT_LOGIN && (
            <div className="csbannerText">
              <figure>
                <img
                  src={cdBanner}
                  alt="credit card banner"
                  width="344"
                  height="301"
                />
              </figure>
              <h3> Latest Offers on Credit Cards </h3>
              <p>
                Contactless application process and instant approval from
                India’s leading trusted Banks. Apply for a credit card and get
                maximum rewards and lifestyle benefits.
              </p>
            </div>
          )}
          {window.location.pathname === PATH.PUBLIC.CREDIT_SCORE && (
            <div className="csbannerText">
              <figure>
                <img
                  src={csBanner}
                  alt="credit score banner"
                  width="340"
                  height="301"
                />
              </figure>
              <h3> Check credit Score </h3>
              <p>
                Your credit score is the top priority when it comes to getting a
                loan. Keep a track of your latest credit score. Get an Instant
                FREE credit score with us in just a few clicks.
              </p>
            </div>
          )}

          {window.location.pathname === PATH.PUBLIC.ASM_LOGIN && (
            <div className="csbannerText">
              <figure>
                <img
                  src={ASMBanner}
                  alt="credit score banner"
                  width="340"
                  height="301"
                />
              </figure>
              <h3 style={{ color: "#FF5800" }}>Welcome Back!</h3>
              <p>
                Sign in to your account to continue
              </p>
            </div>
          )}


          {(window.location.pathname !== PATH.PUBLIC.CREDIT_LOGIN && window.location.pathname !== PATH.PUBLIC.PERSONAL_LOAN && window.location.pathname !== PATH.PUBLIC.BUSINESS_LOAN && window.location.pathname !== PATH.PUBLIC.INDEX && window.location.pathname !== PATH.PUBLIC.TWO_WHEELER_LOAN && window.location.pathname !== PATH.PUBLIC.CREDIT_SCORE && window.location.pathname !== PATH.PUBLIC.GET_CREDIT_CARD && window.location.pathname !== PATH.PUBLIC.HOME_LOAN && window.location.pathname !== PATH.PUBLIC.ASM_LOGIN) ? (
            <div className="csbannerText csLoginText">
              <figure>
                <img
                  src={loanBanner}
                  alt="2 Min Loan Disbursal"
                  width="450"
                  height="300"
                />
              </figure>
              <h3> Instant Personal Loan
              </h3>
              <p>
                Get hassle free instant personal loan.
                <br />No documentation required.</p>
            </div>
          ) : ""}
          {window.location.pathname === PATH.PUBLIC.INDEX && (
            <div>
              <figure>
                <img
                  src={LoginBanner}
                  alt="login banner"
                  width="344"
                  height="301"
                />
              </figure>
              <div className="csbannerText">
                <h4>Signup | Login</h4>
                <p>
                  An OTP will be sent to your mobile number for verification.
                </p>
              </div>
            </div>
          )}
        </div>
      </>
    );
  }
};

export default LeftMenuDecider;
