import React from "react";
import Card from "react-bootstrap/Card";
import ReactLottie from "../common/ReactLottie";

const BackDropComponent = (props) => {
  return (
    <div>
      {props.loaderMessage && props.loaderMessage.lineOne ? (
        <div className="loaderBox">
          <Card className="BoxComeAgter">
            <div>
              <ReactLottie />
              <div>
                <h3>{props.loaderMessage.lineOne}</h3>
                <h4>{props.loaderMessage.lineTwo}</h4>
              </div>
            </div>
          </Card>
        </div>
      ) : (
        <div className="loadingSpinner">
          <div className="spinner-border spinner-border-sm" role="status">
            <span className="visually-hidden"></span>
          </div>
          <div className="spinner-grow spinner-grow-sm" role="status">
            <span className="visually-hidden"></span>
          </div>
          <div className="spinner-grow spinner-grow-sm" role="status">
            <span className="visually-hidden"></span>
          </div>
        </div>
      )}
    </div>
  );
};

export default BackDropComponent;
