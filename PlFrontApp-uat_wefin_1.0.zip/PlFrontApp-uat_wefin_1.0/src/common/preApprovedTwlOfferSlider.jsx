import React, { Component } from "react";
// import { Modal } from "react-bootstrap";
import BajajLogo from "../include/assets/icons/bajajLogo.svg";
// import PreApprovedCard from "../include/assets/preApprovedCard.svg";
import PreApprovedBike from "../include/assets/preApprovedBike.png";
// import { cleanObject } from "./helperCells";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import PATH from "../paths/Paths";
import { Card } from "react-bootstrap";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { papqData, setPaPqOffer } from "../store/papqOffer";
// import PreApprovedTwlOffer from "./preApprovedTwlOffer";
class PreApprovedTwlOfferSlider extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  setPAOffer = (e) => {
    let mobile = localStorage.getItem("mobilenumber");
    const { getPaPqData } = this.props.getoffer;
    const formdata = {
      paOfferId: getPaPqData?.[0]?.paOfferId,
      lenderId: getPaPqData?.[0]?.lender_id__c,
      mobile: mobile,
      loanType: "TW_Loan",
    };
    this.props.setPaPqOffer(formdata, this.callBackSet);
  };
  callBackSet = (res) => {
    if (res.data.success) {
      this.setState({ showModal: false });
      this.setState({ papqApplyLoanID: res.data.setPaPQData.loanName });
      this.props.history.push({
        pathname: PATH.PRIVATE.PAPQ_CONGRATULATION,
        state: { loanId: this.state.papqApplyLoanID },
      });
    }
  };

  render() {
    const options = {
      loop: false,
      margin: 15,
      nav: true,
      dots: false,
      responsive: {
        0: {
          items: 1,

          dots: false,
        },

        600: {
          items: 1,

          dots: false,
        },

        800: {
          items: 2,
          dots: false,
        },

        1000: {
          items: 2,
        },
      },
    };
    return (
      <>
        <div className="bs-papq-offers">
          <h4>Pre-Approved Offers</h4>

          <OwlCarousel {...options}>
            <Card className="bs-papq-offers-box bg1">
              <Card.Text>
                <div className="bs-papq-offers-box-details">
                  <figure>
                    <img src={BajajLogo} alt="BajajLogo" />
                  </figure>
                  <h4>Pre-Approved Two Wheeler Loans</h4>
                  <p>
                    <strong>30th Aug 2023</strong> (Offer Valid)
                  </p>

                  <button onClick={this.setPAOffer}>Apply Now</button>
                </div>
                <figure>
                  <img src={PreApprovedBike} alt="" />
                </figure>
              </Card.Text>
            </Card>
            {/* <Card className="bs-papq-offers-box bg1">
              <Card.Text>
                <div className="bs-papq-offers-box-details">
                  <figure>
                    <img src={BajajLogo} />
                  </figure>
                  <h4>Pre-Approved Two Wheeler Loans</h4>
                  <p>
                    <strong>30th Aug 2023</strong> (Offer Valid)
                  </p>

                  <button>Know More</button>
                </div>
                <figure>
                  <img src={PreApprovedBike} alt="" />
                </figure>
              </Card.Text>
            </Card>
            <Card className="bs-papq-offers-box bg1">
              <Card.Text>
                <div className="bs-papq-offers-box-details">
                  <figure>
                    <img src={BajajLogo} />
                  </figure>
                  <h4>Pre-Approved Two Wheeler Loans</h4>
                  <p>
                    <strong>30th Aug 2023</strong> (Offer Valid)
                  </p>

                  <button>Know More</button>
                </div>
                <figure>
                  <img src={PreApprovedBike} alt="" />
                </figure>
              </Card.Text>
            </Card> */}
          </OwlCarousel>
        </div>
      </>
    );
  }
}

// export default PreApprovedTwlOfferSlider;

const mapStateToProps = (state) => ({
  papqData: papqData(state),
});

const mapDispatchToProps = (dispatch) => ({
  setPaPqOffer: (params, callBack) => dispatch(setPaPqOffer(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(PreApprovedTwlOfferSlider)
);