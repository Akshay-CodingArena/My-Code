import React, { Component } from "react";
import AppStore from "../include/assets/icons/appstore.svg";
import PlayStore from "../include/assets/icons/playstore.svg";
import { DashBoardLinkList } from "./helperCells";
import Swal from "sweetalert2";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { getExperian, loadExperianCheck } from "../store/experian";
import { setAccountInfo } from "../store/account";
import { sendReferCode } from "../store/sendReferCode";
import PATH from "../paths/Paths";
import { Modal } from "react-bootstrap";
import ReferIfon from "../include/assets/icons/referIcon.png";
class DashBoardAside extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      isOpen: false,
      mobileNumber: "",
      MobileNumberError: "",
      referMobileNumber: "",
      name: "",
      referCode: "",
      disable: true,
    };
  }

  handleClose = () => {
    this.setState({ show: false });
  };
  handleShow = () => {
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackVerify);
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error" || res.data.success === false) {
          this.props.history.push(PATH.PRIVATE.CIBIL_SCORE_ANALYSIS);
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          let formData = {
            mobile: res.data.cibilData?.userData?.[0].mobileno,
            pincode: res.data.cibilData?.userData?.[0].pincode,
            name: res.data.cibilData?.userData?.[0].name,
            pan: res.data.cibilData?.userData?.[0].pan,
            dob: res.data.cibilData?.userData?.[0].dob,
            email: res.data.cibilData?.userData?.[0].email,
            cibilcheck: "Y",
            creditCode:
              (res.data.cibilData?.experianScore === -1 && "A") ||
              (res.data.cibilData?.experianScore >= 800 && "B") ||
              (res.data.cibilData?.experianScore >= 750 &&
                res.data.cibilData?.experianScore <= 799 &&
                "C") ||
              (res.data.cibilData?.experianScore >= 700 &&
                res.data.cibilData?.experianScore <= 749 &&
                "D") ||
              (res.data.cibilData?.experianScore >= 650 &&
                res.data.cibilData?.experianScore <= 699 &&
                "E") ||
              (res.data.cibilData?.experianScore >= 600 &&
                res.data.cibilData?.experianScore <= 649 &&
                "F") ||
              (res.data.cibilData?.experianScore >= 0 &&
                res.data.cibilData?.experianScore <= 599 &&
                "G"),
          };
          this.props.setAccountInfo(formData, this.callBackAcc);
        }
      }
    }
  };
  callBackAcc = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
        localStorage.setItem("fullName", this.props.userData?.[0]?.name);
        localStorage.setItem("pan", this.props.userData?.[0]?.pan);
      }
    }
  };

  __handleMobileNumber = (event) => {
    event.preventDefault();
    const mobile_number = event.target.value;
    if (Number(mobile_number) && mobile_number.length === 10) {
      this.setState({ disable: false });
    }
    if (mobile_number.length === 10 && !/^[6789]\d{9}$/.test(mobile_number)) {
      this.setState({
        disable: true,
        MobileNumberError: "Please enter a valid mobile number.",
      });
    } else if (
      mobile_number.length === 10 &&
      mobile_number === this.state.mobileNumber
    ) {
      this.setState({
        disable: true,
        MobileNumberError:
          "Refer Mobile number and Register Mobile should not same",
      });
    } else {
      this.setState({
        MobileNumberError: "",
      });
    }
    if (
      (Number(mobile_number) && mobile_number.length < 10) ||
      event.target.value.length < 1
    ) {
      this.setState({ disable: true });
    }
    if (
      mobile_number.length <= 10 &&
      (/^[0-9]+$/.test(mobile_number) || mobile_number === "")
    ) {
      this.setState({ referMobileNumber: mobile_number });
    }
  };
  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "Enter Mobile Number":
          const mobile_number = event.target.value;
          this.setState({ disable: true });
          if (mobile_number.length === 10 && this.state.disable === false) {
            this._sendReferCode(event);
          } else {
            // let msg = "Ten digits not Entered !";
          }
          break;

        default:
          break;
      }
    }
  };
  _sendReferCode = (e) => {
    e.preventDefault();
    const referData = {
      mobile: this.state.mobileNumber,
      refermobile: this.state.referMobileNumber,
      refercode: this.state.referCode,
      name: this.state.name,
    };
    this.props.sendReferCode(referData, this.callbackRefer);
  };
  callbackRefer = (res) => {
    if (res) {
      if (res.data.success) {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
        Swal.fire({
          position: "center",
          icon: "success",
          title: res.data.message,
          showConfirmButton: true,
          timer: 5000,
        });
      } else {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
        Swal.fire({
          position: "center",
          icon: "error",
          title: "Try after sometimes",
          showConfirmButton: true,
          timer: 5000,
        });
      }
    }
  };
  openModal = () => {
    this.setState({ isOpen: true });
    this.setState({ referCode: localStorage.getItem("referCode") });
    this.setState({ name: localStorage.getItem("fullName") });
    this.setState({ mobileNumber: localStorage.getItem("mobilenumber") });
  };
  closeModal = () => {
    this.setState({ isOpen: false });
    this.setState({ referMobileNumber: "" });
    this.setState({ disable: true });
  };
  render() {
    return (
      <div className="bs-das-sidebar">
        <ul>
          <DashBoardLinkList
            text={"Home"}
            onClick={() => this.props.history.push(PATH.PRIVATE.PRODUCTS)}
            hrefLink={"javascript:void(0)"}
            className={
              this.props.location.pathname === PATH.PRIVATE.PRODUCTS
                ? "active"
                : ""
            }
          />
          {/* <DashBoardLinkList
            text={"Credit Score"}
            hrefLink={"javascript:void(0)"}
            onClick={() => this.handleShow()}
            className={
              this.props.location.pathname ===
                PATH.PRIVATE.CREDIT_REPORT_ANALYSIS
                ? "active"
                : ""
            }
          /> */}
          {/* <DashBoardLinkList
            text={"Personal Loan"}
            hrefLink={"javascript:void(0)"}
          /> */}

          {/* <DashBoardLinkList
            text={"Two Wheeler"}
            hrefLink={"javascript:void(0)"}
          /> */}
          {/* <DashBoardLinkList
            text={"Credit Card"}
            hrefLink={"javascript:void(0)"}
          /> */}

          <DashBoardLinkList
            text={"FAQs"}
            onClick={() => this.props.history.push(PATH.PRIVATE.FAQ)}
            hrefLink={"javascript:void(0)"}
            className={
              this.props.location.pathname === PATH.PRIVATE.FAQ ? "active" : ""
            }
          />
          <DashBoardLinkList
            text={"Refer A Friend"}
            onClick={() => {
              this.openModal();
            }}
          />
        </ul>
        <div className="bsSupport">
          <h5>wefin Customer Care</h5>
          <ul>
            <li>
              <a href="mailto:info@wefin.in">
                info@wefin.in
              </a>
            </li>
            <li>
              <a href="tel:011-40724283" >
                011-40724283
              </a>
            </li>
          </ul>
        </div>
        <div className="bsGetApp">
          <div className="hover-top nav-btn-appstore">
            Get App
            <a
              href="https://play.google.com/store/apps/details?id=com.bankse"
              target=" _blank"
            >
              <img src={PlayStore} alt="play store icon" />
            </a>
            <a
              href="https://apps.apple.com/us/app/bankse/id1602186654"
              target=" _blank"
            >
              <img src={AppStore} alt="app store icon" />
            </a>
          </div>
        </div>
        <Modal
          className="ReferFriendModal"
          show={this.state.isOpen}
          onHide={this.closeModal}
        >
          {/* <Modal.Header closeButton></Modal.Header> */}
          <Modal.Body className="text-center">
            <figure>
              <img src={ReferIfon} alt="ReferIcon" width="" height="" />
            </figure>
            <h4>Refer Your Friends</h4>
            <p>
              Invite Your friends to sign up with your referral code and avail
              loan.
            </p>
            <h6>
              Your Referral Code: <span>{this.state.referCode}</span>
            </h6>
            <div className="rf-input-block">
              <input
                type="text"
                placeholder="Enter Your Friend Mobile No."
                value={this.state.referMobileNumber}
                onChange={this.__handleMobileNumber}
             q   maxLength="10"
                onKeyPress={(e) =>
                  this.__handleKeyPress(e, "Enter Mobile Number")
                }
                autoFocus
                id="MobileNumber"
                name="MobileNumber"
              />
              <button
                disabled={this.state.disable}
                type="submit"
                onClick={(e) => this._sendReferCode(e)}
                className="btn btn-primary get-otp-btn"
              >
                Invite
              </button>
              {this.state.MobileNumberError && (
                <p className="referModalError text-center">
                  {this.state.MobileNumberError}
                </p>
              )}
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  experian: getExperian(state),
  userData: getExperian(state).userData,
});
const mapDispatchToProps = (dispatch) => ({
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
  sendReferCode: (params, callback) =>
    dispatch(sendReferCode(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(DashBoardAside)
);
