import React, { Component } from "react";
import { Document, Page } from "react-pdf";
import { pdfjs } from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

export default class AllPagesPDFViewer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      numPages: null,
    };
  }


  onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages: numPages });
  };

  render() {
    const { pdf } = this.props;
    return (
      <Document
        file={pdf}
        onLoadSuccess={this.onDocumentLoadSuccess}
      >
        {Array.from(new Array(this.state.numPages), (el, index) => (
          <Page key={`page_${index + 1}`} pageNumber={index + 1} />
        ))}
      </Document>
    );
  }
}
