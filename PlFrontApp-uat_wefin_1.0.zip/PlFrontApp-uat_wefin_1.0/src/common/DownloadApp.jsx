import React, { Component } from "react";
// import { Button } from "react-bootstrap";
import AppStore from "../include/assets/icons/appstore.svg";
import PlayStore from "../include/assets/icons/playstore.svg";
import { Modal } from "react-bootstrap";
// import { Link } from "react-router-dom";


class DownloadAppModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: true,
    };
  }

  componentWillUnmount = () => {
    this.setState({ showModal: false });
  };

  // componentDidMount = () => {
  //   this.setState({showModal: true});
  // }

  render() {
    return (
      this.state.showModal && (
        <Modal
          className="DownLoadAppModal"
          show={this.state.showModal}
          onHide={() => this.setState({ showModal: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
        >
          <Modal.Header closeButton></Modal.Header>
          <Modal.Body className="text-center">
            <div className="DownLoadAppBlock">
              <h4>Download wefin App</h4>
              {/* <p>
                One-Stop Solution for all your financial needs with hassle free
                process & quick disbursal.
              </p> */}
              <div className="DownloadApp">
                <span>App Available on</span>
                <img src={PlayStore} alt="play store icon" />

                <img src={AppStore} alt="app store icon" />

                <a
                  className="AppDownloadBtn"
                  href="https://bankseapp.page.link/download"
                >
                  Download App Now
                </a>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      )
    );
  }
}

export default DownloadAppModal;
