import React from "react";
import bloggerAnimation from "./loader.json";
import { useLottie } from "lottie-react";
import confetti from "./Animation/confetti.json"

const ReactLottie = ({ keyIndex = 0 }) => {
    const chooseJson = [bloggerAnimation,confetti];
    const options = {
        animationData: chooseJson[keyIndex],
        loop: keyIndex?false:true,
        autoplay: true,
        style: {
            height: keyIndex?'600px':'120px',
            marginTop: keyIndex?-400:0
            // width: '250px'
        },
        interactivity: {
            mode: "cursor",
            actions: [
                {
                    position: { x: [0, 1], y: [0, 1] },
                    type: "seek",
                    frames: [0, 480]
                }
            ]
        }
    };

    const { View } = useLottie(options);

    return <div draggable="true">{View}</div>;
};

export default ReactLottie;
