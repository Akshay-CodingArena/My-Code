import React, { Component } from "react";
import { Link } from "react-router-dom";
import mailIcon from "../include/assets/icons/email.png";
import callIcon from "../include/assets/icons/call.png";
import PATH from "../paths/Paths";
class bottom extends Component {
  render() {
    return (
      <div className="bs-footer-links" >
        <div className="container" >
          <div className="row">
            <div className="col-md-4">
              <div className="cs-suppor">
                <ul>
                  <li>
                    <img src={mailIcon} alt="MailIcon" />{" "}
                    <a href="mailto:support@wefin.in">
                      support@wefin.in
                    </a>
                  </li>
                  <li>
                    <img src={callIcon} alt="CallIcon" />{" "}
                    <a href="tel:01140724283"> 011-40724283</a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="text-right col-md-8">
              <ul className="cs-links">
                <li>
                  <Link to="/business-loan">Business Loan</Link>
                </li>
                <li>
                  <Link to="/home-loan">Home Loan</Link>
                </li>
                {/* <li>
                  <Link to="/credit-score">Credit Score</Link>
                </li> */}
                <li>
                  {" "}
                  <Link to="/personal-loan">Personal Loan</Link>
                </li>
                <li>
                  {" "}
                  <Link to="/two-wheeler-loan">Two Wheeler Loan</Link>
                </li>
                <li>
                  {" "}
                  <Link to="/get-credit-card">Credit Card</Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default bottom;
