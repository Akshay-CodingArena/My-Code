import React, { Component } from "react";
import { Modal } from "react-bootstrap";
import PreIcon from "../include/assets/icons/preIcon.svg";
import BikeOfferBanner from "../include/assets/BikeOffer.png";
import BajajLogo from "../include/assets/icons/bajajLogo.svg";
// import { cleanObject } from "./helperCells";
import { papqData, setPaPqOffer } from "../store/papqOffer";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import PATH from "../paths/Paths";
class PreApprovedTwlOffer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: true,
      papqApplyLoanID: "",
    };
  }

  componentWillUnmount = () => {
    this.setState({ showModal: false });
  };

  componentDidMount = () => {
    this.setState({ showModal: true });
  };
  setPAOffer = (e) => {
    let mobile = localStorage.getItem("mobilenumber");
    const { getPaPqData } = this.props.getoffer;
    const formdata = {
      paOfferId: getPaPqData?.[0]?.paOfferId,
      lenderId: getPaPqData?.[0]?.lender_id__c,
      mobile: mobile,
      loanType: "TW_Loan",
    };
    this.props.setPaPqOffer(formdata, this.callBackSet);
  };
  callBackSet = (res) => {
    if (res.data.success) {
      this.setState({ showModal: false });
      this.setState({ papqApplyLoanID: res.data.setPaPQData.loanName });
      this.props.history.push({
        pathname: PATH.PRIVATE.PAPQ_CONGRATULATION,
        state: { loanId: this.state.papqApplyLoanID },
      });
    }
  };
  render() {
    // const name1 =
    //   localStorage.getItem("firstName").length > 1 &&
    //   localStorage.getItem("firstName").split(" ");
    // const name2 =
    //   localStorage.getItem("fullName").length > 1 &&
    //   localStorage.getItem("fullName").split(" ");

    // const userName = isNaN(localStorage.getItem("lastName"))
    //   ? name1[0]
    //   : name2[0];
    // const bool = cleanObject(userName);
    // const { getPaPqData } = this.props.getoffer;
    return (
      this.state.showModal && (
        <Modal
          className="PreApprovedModal "
          show={this.state.showModal}
          onHide={() => this.setState({ showModal: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
        >
          <Modal.Header className="text-center" closeButton>
            <img src={PreIcon} alt="PreIcon" /> Pre-Approval
          </Modal.Header>
          <Modal.Body>
            <div className="msgCongrats">
              {/* <p>
                Congrats,{" "}
                {bool === false
                  ? localStorage.getItem("mobilenumber")
                  : userName.charAt(0).toUpperCase() + userName.slice(1).toLowerCase()}
                ! you have a{" "}
              </p> */}
              {/* <h5>Two Wheelers Loan Offer</h5> */}
            </div>
            <div className="loanOfferBox">
              <figure>
                <img src={BajajLogo} alt="BajajLogo"></img>
              </figure>
              <p>CONGRATULATIONS!</p>
              <h4>You have a Pre-Approved Two Wheeler Loan</h4>
              <ul>
                <li>No Income Docs Required</li>
                <li>One Click Process</li>
              </ul>
              <button onClick={this.setPAOffer}>Apply</button>
              <div className="loanOfferBanner">
                <img src={BikeOfferBanner} alt="BikeOfferBanner" width="300" height="300" />
              </div>
            </div>
          </Modal.Body>
        </Modal>
      )
    );
  }
}
const mapStateToProps = (state) => ({
  papqData: papqData(state),
});

const mapDispatchToProps = (dispatch) => ({
  setPaPqOffer: (params, callBack) => dispatch(setPaPqOffer(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(PreApprovedTwlOffer)
);
