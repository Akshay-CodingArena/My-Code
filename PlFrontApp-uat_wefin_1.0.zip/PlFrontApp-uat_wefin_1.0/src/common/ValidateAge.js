//------------------------------------------Age Validation > 13 years-------------------------//

const dateFormatter = (date) => {
    if (date?.length > 10) {
        let year = date.slice(0, 4)
        let day = date.slice(8, 10)
        let month = date.slice(5, 7)
        return day + "-" + month + "-" + year
    } else {
        return date
    }
}

function ValidateAge(dobDate, minGap) {
    var date = new Date(Date.now());
    var year = parseInt(date.getFullYear())
    var month = parseInt(date.getMonth()) + 1
    var day = parseInt(date.getDate())
    var dob = dateFormatter(dobDate)
    console.log("Validations", parseInt(dob.slice(0, 2)), parseInt(dob.slice(6)), parseInt(dob.slice(3, 5)))
    let gap = (year - parseInt(dob.slice(6)))
    console.log("date", gap)
    if (parseInt(dob.slice(6)) >= year - minGap) {
        console.log("year gap", parseInt(dob.slice(6)), year)
        console.log("month", parseInt(dob.slice(3, 5)), month)
        console.log("day", parseInt(dob.slice(0, 2)), day)

        if (parseInt(dob.slice(6, 10)) == year - minGap && parseInt(dob.slice(3, 5)) - month <= 0) {
            console.log("year gap", year - 13, parseInt(dob.slice(3, 5)))
            console.log("month", parseInt(dob.slice(3, 5)) - month)
            if (parseInt(dob.slice(3, 5)) - month === 0 && (parseInt(dob.slice(0, 2)) - day) <= 0) {
                return true
            } else {
                return false
            }
        }
        return false
    } else {
        if (gap < 100) {
            if (parseInt(dob.slice(0, 2)) && parseInt(dob.slice(3, 5))) {
                return true
            }
            return "Invalid DOB"
        }
        else {
            return false
        }
    }
}

export default ValidateAge