import { Modal } from "react-bootstrap"

function PdfViewer({ link, closeViewer }) {
    return (
        <>
            {link ? <Modal
                style={{ overflow: 'hidden', width: '100vw' }}
                show={link}
                onHide={() => closeViewer(false)}
            > <Modal.Body style={{ padding: '0px', display: 'flex', justifyContent: 'center', marginTop: '-65px', width: '550px', marginLeft: '0px' }}><object className="pdfModal" data={link} type="application/pdf" width="100%" height="100%">
                <p>Alternative text - include a link <a href={link}>to the PDF!</a></p>
            </object ></Modal.Body></Modal > : null
            }
        </>
    )
}

export default PdfViewer