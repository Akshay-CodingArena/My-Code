import { ReactComponent as KeyboardArrowRightIcon } from "../include/assets/rightArrow.svg";
import React from "react";
import LOGO from "./../include/assets/logo.png";
import { ReactComponent as InfoIcon } from "../include/assets/fullertonLogos/Path 17030.svg";
// import bankIcon from "../include/assets/icons/bankIcon.svg";
import Card from "react-bootstrap/Card";
import ReactTooltip from "react-tooltip";
import { keyframes } from "@emotion/core";
import Close from "../include/assets/close.svg";


export const HomeProductLink = ({ text, icon, clickFunc, cls }) => {
  return (
    <a className={cls} onClick={clickFunc} style={{ cursor: "pointer" }}>
      {text}
      {icon}
    </a>
  );
};
export const HomeProductButton = ({ text, icon, clickFunc, cls, myStyle }) => {
  return (
    <button style={myStyle} className={cls} onClick={clickFunc}>
      {text}
      {icon}
    </button>
  );
};
export const DashBoardLinkList = ({ text, className, hrefLink, onClick }) => {
  return (
    <li className={className} onClick={onClick}>
      <a href={hrefLink}>{text}</a>
    </li>
  );
};
export const SidebarList = ({ icon, text, hrefLink, onClick }) => {
  return (
    <li onClick={onClick}>
      <a
        href={hrefLink}
        className="flex flex-row items-center h-12  text-gray-500 hover:text-gray-800 textList"
      >
        <div className="sideBarIconBox">{icon}</div>
        <span className="text-sm font-medium sidebarText">{text}</span>
        <div style={{ flex: "1" }}></div>
        <KeyboardArrowRightIcon className="arrowIcon" />
      </a>
    </li>
  );
};
export const H1SpanText = ({ header, span, styleColor }) => {
  return (
    <>
      <h1 className="header" style={{ color: `${styleColor}` }}>
        {header}
      </h1>
      <span className="text">{span}</span>
    </>
  );
};
export const liCells = (text) => {
  return <li style={{ color: "black" }}>{text} </li>;
};
export const commaFormat = (number) => {
  let numberVal = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(number);
  let result1 = numberVal.split("₹");
  let result2 = result1[1].split(".");
  let result = result2[0];
  return result;
};
export const Logo = () => {
  return (
    <div className={"logoContainer"}>
      <img alt="" src={LOGO} />
    </div>
  );
};
export const LoginBank = ({
  uploadText,
  icon,
  dataTip,
  fileUpload,
  doc,
  error
}) => {
  return (
    <div className="bsUploadBox bank_login_box">
      <div className="uploadTextSpan">
        {/* <span className="uploadText">
          <InfoIcon
            data-tip={dataTip}
            data-background-color="#FFFF"
            data-text-color="#000"
            data-place="bottom"
            data-html={true}
          />
        </span> */}

        <ReactTooltip html={true} />
        <span className="uploadHeadlineTxt">{uploadText}</span>
      </div>
      <Card>
        <Card.Text>
          <div>
            <input
              accept="image/*"
              type="file"
              id="file"
              onChange={(e) => fileUpload(e)}
            />
            <div>
              <img src={icon} width="40" height="" />
            </div>
            <label>{doc ? doc.name.toString() : dataTip}</label>
          </div>
        </Card.Text>
      </Card>

      {error && doc === "" && <p className="bsInputErr">{error}</p>}
    </div>
  );
};
export const PLAttachContainerCell = ({
  uploadText,
  dataTip,
  fileUpload,
  doc,
  error,
  previewPdf,
  isCancel,
  handleCancel
}) => {
  return (
    <div className="bsUploadBox">
      <div className="uploadTextSpan">
        <span className="uploadText">
          <InfoIcon
            data-tip={dataTip}
            data-background-color="#FFFF"
            data-text-color="#000"
            data-place="bottom"
            data-html={true}
          />
        </span>
        <ReactTooltip className="SalaryToolTip" html={true} />
        <span
          data-background-color="#2e0080"
          data-text-color="#FFF"
          data-place="top"
          style={{
            display: "inline-block",
            cursor: "pointer",
          }}
          className="uploadHeadlineTxt"
        >
          {uploadText}
        </span>
      </div>
      <Card
        style={{
          border: "1.4px dashed #2E0080 ",
          borderRadius: "15px",
          margin: "20px",
        }}
      >
        <Card.Text style={{ textAlign: "left", paddingTop: "8px" }}>
          <div
            style={{
              display: "grid",
              justifyContent: "center",
              textAlign: "center",
            }}
          >
            <input
              accept="image/*"
              type="file"
              id="file"
              onChange={(e) => fileUpload(e)}
            />
            <label
              style={{
                fontSize: "14px",
                letterSpacing: "0px",
                color: "#171717",
                opacity: "1",
              }}
              htmlFor="file"
            >
              {doc ? doc.name.toString() : " Click to Attach File"}
            </label>
          </div>
        </Card.Text>
      </Card>
      {doc ?

        <div style={{
          display: "flex"
        }}>
          < span className="fileNameUploaded mb-3" onClick={previewPdf} > {
            doc.name.length > 20 ? `${doc.name.slice(0, 15)} __ ${doc.name.slice(doc.name.length - 4)}`
              : doc.name
          }</span>

          {isCancel ? <img src={Close} onClick={handleCancel} alt="" style={{ height: "20px", width: "20px", cursor: "pointer" }} /> : ""}

        </div >

        : null}

      {error && doc === "" && <p className="bsInputErr">{error}</p>}
    </div>
  );
};

export const PLAttachContainerCellPdf = ({
  uploadText,
  dataTip,
  fileUpload,
  doc,
  error,
  position,
  previewPdf,
  required,
  isCancel,
  handleCancel
}) => {

  console.log(position)
  return (
    <div className="bsUploadBox">

      <div className="uploadTextSpan">
        <span className="uploadText">
          <InfoIcon
            data-tip={dataTip}
            data-background-color="#FFFF"
            data-text-color="#000"
            data-place="bottom"
            data-html={true}
          />
        </span>
        <ReactTooltip className="SalaryToolTip" html={true} />
        <span
          data-background-color="#2e0080"
          data-text-color="#FFF"
          data-place="top"
          style={{
            display: "inline-block",
            cursor: "pointer",
          }}
          className="uploadHeadlineTxt"
        >
          {uploadText}
        </span>
      </div>
      <Card
        style={{
          border: "1.4px dashed #2E0080 ",
          borderRadius: "15px",
          margin: "20px",
          cursor: "pointer",
        }}
      >
        <Card.Text style={{ textAlign: "left", paddingTop: "8px" }}>
          <div
            style={{
              display: "grid",
              justifyContent: "center",
              textAlign: "center",
            }}
          >
            <input
              className="file"
              accept="application/pdf"
              type="file"
              id={`file${position}`}
              onChange={(e) => fileUpload(e)}
            />
            <label
              style={{
                fontSize: "14px",
                letterSpacing: "0px",
                color: "#171717",
                opacity: "1",
                cursor: 'pointer'
              }}
              htmlFor={`file${position}`}
            >
              {/* {doc ? doc.name.toString().slice(0, 10) + "..." : " Click to Attach File"} */}
              {
                doc?.name ?
                  doc.name.length > 20 ? `${doc.name.slice(0, 15)} __ ${doc.name.slice(doc.name.length - 4)}`
                    : doc.name
                  :
                  < div >
                    Upload PDF{required ? <span style={{ color: 'red' }}>*</span> : ""}
                  </div>
              }

            </label>
          </div>
        </Card.Text >
      </Card >
      {
        doc ?

          <div style={{
            display: "flex"
          }
          } >
            < span className="fileNameUploaded mb-3" onClick={previewPdf} > {
              doc.name.length > 20 ? `${doc.name.slice(0, 15)} __ ${doc.name.slice(doc.name.length - 4)}`
                : doc.name
            }</span>

            {isCancel ? <img src={Close} onClick={handleCancel} alt="" style={{ height: "20px", width: "20px", cursor: "pointer" }} /> : ""}

          </div >

          : null}
      {error && !doc && < p className="bsInputErr">{error}</p>}

    </div >
  );
};

export const cleanObject = (obj) => {
  if (
    obj === null ||
    obj === undefined ||
    obj === "" ||
    obj === "" ||
    obj === "undefined" ||
    obj === "null"
  ) {
    return false;
  }
};
export const capitalizeFirstLetter = (string) => {
  return string?.charAt(0)?.toUpperCase() + string?.slice(1)?.toLowerCase();
};
export const splitMulti = (str, tokens) => {
  var tempChar = tokens[0]; // We can use the first token as a temporary join character
  for (var i = 1; i < tokens.length; i++) {
    str = str.split(tokens[i]).join(tempChar);
  }
  str = str.split(tempChar);
  return str;
};
