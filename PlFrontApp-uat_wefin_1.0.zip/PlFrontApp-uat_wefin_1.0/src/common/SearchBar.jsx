import { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import CreatableSelect from "react-select/creatable";
import { loadEmployerDetail } from "../store/employer";
import SearchIcon from "../include/assets/moneyPlus/search.svg"
class SearchBar extends Component {
    constructor(props) {
        super(props)
        this.state = {
            data: {},
            errors: {}
        }
    }

    formatCreate = (inputValue) => {
        return <p> Add: {inputValue}</p>;
    };

    handleInputChange = (e) => {

        this.props.setSearch(e)
    }


    render() {
        const { employerDetail, bankName } = this.props
        const searchDetail = [{
            value: "LA-12345",
            label: "LA-12345"
        }, {
            value: "LA-12346",
            label: "LA-12346"
        }]

        return (
            <div className="d-flex asmSearchBar" style={{ width: '100%', gap: '20px' }
            }>
                <img className="asm asmSearchIcon" src={SearchIcon} />
                <label htmlFor="search" className="font-weight-bolder">
                    Search
                </label>
                <input type="text" className="dashboardSearch"
                    onChange={this.props.handleSearch}
                    value={this.props.search} />
                {/* <CreatableSelect
                    style={{ color: "#f00", width: "100%" }}
                    isClearable
                    styles={this.customStyles}
                    name="search"
                    onChange={(e) => {
                        if (e) {
                            if (e.__isNew__) {
                                const data = { ...this.state.data };
                                const errors = { ...this.state.errors };
                                errors.search = "";
                                data.search = e;
                                this.props.setSearch(e.value)
                                this.setState({ errors, data, value: e.value });
                            } else {
                                const data = { ...this.state.data };
                                const errors = { ...this.state.errors };
                                errors.search = "";
                                data.search = e;
                                this.props.setSearch(e)
                                this.setState({
                                    data,
                                    errors,
                                    searchName: e.value,
                                });
                            }
                        }
                        if (e === null) {
                            const data = { ...this.state.data };
                            data.search = "";
                            this.setState({
                                data,
                                searchName: {},
                                value: "",
                            });
                        }
                    }}
                    onInputChange={this.handleInputChange}
                    options={searchDetail.map((item) => ({
                        label: item.name,
                        value: item,
                    }))}
                    placeholder="Enter Name, Mobile No. , Appl. No."
                    formatCreateLabel={this.formatCreate}
                    value={
                        this.props.searchQuery &&
                        this.state.data?.search &&
                        this.state.data?.search?.label &&
                        this.state?.data?.search
                    }
                />

                {
                    this.state.errors.search && (
                        <p className="bsInputErr">{this.state.errors.search}</p>
                    )
                } */}
            </div >
        )
    }
}

const mapStateToProps = (state) => ({

});
const mapDispatchToProps = (dispatch) => ({
    loadEmployerDetail: (params) => dispatch(loadEmployerDetail(params)),

});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(SearchBar))