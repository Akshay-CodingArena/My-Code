import React, { Component } from "react";
import Swal from "sweetalert2";
import SecureLS from "secure-ls";
import { cleanObject } from "./helperCells";
import LogoutIcon from "../include/assets/logoutIcon.svg";
import UserIcon from "../include/assets/icons/user.svg";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getAccount } from "../store/account";
import {
    Navbar,
    Container,
    Nav,
    Form,
    Dropdown,
    Button,
} from "react-bootstrap";
import { getExperian, loadExperianCheck } from "../store/experian";
import { Link } from "react-router-dom";
import BackDropComponent from "./BackDropComponent";
import PATH from "../paths/Paths";
import { Modal } from "react-bootstrap";
import ReferIfon from "../include/assets/icons/referIcon.png";
import { sendReferCode } from "../store/sendReferCode";
import { getCustomer, logout } from "../store/login";
import {
    getBase64Encryption,
    getHashEncryption,
} from "../Utils/crypto";

let localStore = new SecureLS({
    encodingType: "aes",
    isCompression: true,

});

class CreditTopNavBar extends Component {

    componentDidMount = () => {
        document.body.classList.remove("TwScrool");
        document.body.classList.add("variantScroll");
    };


    redirectRoute = () => {
        let role = localStorage.getItem("role");
        if (role === "FOS" || role === "FOS_CALL") {
            this.props.history.push(PATH.PRIVATE.FOS_DASHBOARD);
        } else {
            this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
    }

    render() {
        return (
            <>
                <header className="bsHeader">
                    <Navbar expand="lg" fixed="top">
                        <Container>
                            {this.props.loading ? <BackDropComponent /> : ""}
                            <Link onClick={this.redirectRoute}>
                                <Navbar.Brand>
                                    {" "}
                                    <img src="/wefin-logo.svg" alt={"logo"} className="topbarLogo" />
                                </Navbar.Brand>
                            </Link>
                            {(localStorage.getItem("role") === "FOS" || localStorage.getItem("role") === "FOS_CALL") ? "" : <Dropdown className="ccLogin">
                                <button onClick={this.props.handleLogin}>  <Dropdown.Toggle
                                    id="dropdown-button-dark-example1"
                                    variant="secondary"
                                >
                                    <img src={UserIcon} alt="" width="20px" height="20px" />
                                    Login

                                </Dropdown.Toggle>
                                </button>
                            </Dropdown>}
                        </Container>
                    </Navbar>
                </header>
            </>
        );
    }
}
const mapStateToProps = (state) => ({
    customerDetail: getAccount(state).customerDetail,
    experian: getExperian(state),
    userData: getExperian(state).userData,
    loadingLogout: getCustomer(state).loadingLogout
});

const mapDispatchToProps = (dispatch) => ({
    loadExperianCheck: (params, callback) =>
        dispatch(loadExperianCheck(params, callback)),
    sendReferCode: (params, callback) =>
        dispatch(sendReferCode(params, callback)),
    logout: (params, callback) =>
        dispatch(logout(params, callback))
});


export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(CreditTopNavBar)
);
