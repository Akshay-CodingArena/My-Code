import CONSTANTS from "./../constants/Constants";
const { VALIDATION_CONSTANTS } = CONSTANTS;

const Validations = (field, fieldFlag) => {
  switch (fieldFlag) {
    //==========================================Switch Case Validation starts========================================//
    case VALIDATION_CONSTANTS.EMAIL: {
      return ValidateEmail(field);
    }

    case VALIDATION_CONSTANTS.PAN: {
      return ValidatePAN(field);
    }

    case VALIDATION_CONSTANTS.FULL_NAME: {
      return ValidateName(field);
    }

    case VALIDATION_CONSTANTS.PIN_CODE: {
      return validatePinCode(field);
    }

    case VALIDATION_CONSTANTS.SALARY: {
      return validateSalary(field);
    }
    case VALIDATION_CONSTANTS.MOBILE_NO: {
      return ValidateMobileNO(field);
    }

    case VALIDATION_CONSTANTS.OTP: {
      return ValidateOTP(field);
    }
    case VALIDATION_CONSTANTS.D_O_B: {
      return ValidateDOB(field);
    }
    case VALIDATION_CONSTANTS.Booking_Number: {
      return ValidateBookingNo(field);
    }

    default: {
      return `Validating field does not Exists`;
    }
  }

  //===================================================Validation Switch Case end==============================//

  //======================================================== Validate functions ====================================//

  //EMAIL VALIDATE FUNCTION START//
  function ValidateEmail(field) {
    // const mailRegex = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/;
    const mailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (mailRegex.test(field)) {
      return false;
    } else {
      return true;
    }
  }

  //PAN Number  VALIDATE FUNCTION//
  function ValidatePAN(field) {
    const PanRegex = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
    if (field.match(PanRegex)) {
      return false;
    } else {
      return true;
    }
  }
  //---------------------End of pan number validate function---------//

  //-------------------------------full NAME VALIDATE FUNCTION -----------------------------------//
  function ValidateName(field) {
    // const NameRegex = "^[A-Z][A-Z \\s]"
    const NameRegex = "^[a-zA-Z ]*$";
    if (field.match(NameRegex)) {
      return false;
    } else {
      return true;
    }
  }

  //----------------------------------------------End of fullName validate function---------------------- //

  //------------------------------------------------PIN CODE Validate Function---------------------------//
  function validatePinCode(field) {
    let PinCodeRegex = "([1-9]{1}[0-9]{5}|[1-9]{1}[0-9]{3}\\s[0-9]{3})";
    if (field.match(PinCodeRegex)) {
      return false;
    } else {
      return true;
    }
  }
  //------------------------------------------------end of PIN CODE Validate Function---------------------------//

  //---------------------------------------------SALARY Validate function--------------------------------------//
  function validateSalary(field) {
    let numberRegex = "[0-9]+([,][0-9]+)?";
    if (field.match(numberRegex)) {
      return false;
    } else {
      return true;
    }
  }
  //------------------------------------------end salary validate function ---------------------//

  //------------------------------------------MobileNumber validate function ---------------------//
  function ValidateMobileNO(field) {
    const mobileNumberRegx = /^[0]?[789]\d{9}$/;
    if (field.match(mobileNumberRegx)) {
      return false;
    } else {
      return true;
    }
  }

  //------------------------------------------end MobileNumber validate function ---------------------//

  //------------------------------------------OTP validate function ---------------------//
  function ValidateOTP(field) {
    const OTPRegx = /^[0-9]+$/;
    if (field.match(OTPRegx)) {
      return false;
    } else {
      return true;
    }
  }

  //------------------------------------------End OTP validate function ---------------------//
  function ValidateDOB(field) {
    const DOBRegex = " ^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$";
    if (field.match(DOBRegex)) {
      return false;
    } else {
      return true;
    }
  }

  function ValidateBookingNo(field) {
    const NumberRegex = "/^[0-9]+$/";
    if (field.match(NumberRegex)) {
      return false;
    } else {
      return true;
    }
  }
};

export default Validations;
