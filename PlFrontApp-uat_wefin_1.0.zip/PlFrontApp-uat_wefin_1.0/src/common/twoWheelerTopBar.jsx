import React, { Component } from "react";
import Swal from "sweetalert2";
import SecureLS from "secure-ls";
import { cleanObject } from "./helperCells";
import LogoutIcon from "../include/assets/logoutIcon.svg";
import UserIcon from "../include/assets/icons/user.svg";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getAccount, setAccountInfo } from "../store/account";
import { Navbar, Container, Nav, Form, Dropdown } from "react-bootstrap";
import { getExperian, loadExperianCheck } from "../store/experian";
import LocationDropDown from "./LocationDropDown.js";
import PATH from "../paths/Paths";
import ReferIfon from "../include/assets/icons/referIcon.png";
import { sendReferCode } from "../store/sendReferCode";
import { getCustomer, logout } from "../store/login";
import {
  getBase64Encryption,
  getHashEncryption,
} from "../Utils/crypto";
import { Modal } from "react-bootstrap";

let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});
class TopNavBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dropdownDisplay: false,
      isOpen: false,
      isOpenCheckBalance: false,
      mobileNumber: "",
      MobileNumberError: "",
      referMobileNumber: "",
      name: "",
      referCode: "",
      disable: true,
    };
  }

  componentDidMount = () => {
    document.body.classList.remove("TwScrool");
    document.body.classList.add("variantScroll");
  };

  logout = () => {
    Swal.fire({
      icon: "warning",
      title: "Are you sure you want to exit?",
      showCancelButton: true,
      confirmButtonText: "Log Out",
      confirmButtonColor: "#d63031",
      cancelButtonColor: "#2e0080",
    }).then((res) => {
      if (res.isConfirmed) {
        localStorage.clear();
        localStore.removeAll();
        this.props.history.push(PATH.PUBLIC.INDEX);
      }
    });
  };
  _sendReferCode = (e) => {
    e.preventDefault();
    const referData = {
      mobile: this.state.mobileNumber,
      refermobile: this.state.referMobileNumber,
      refercode: this.state.referCode,
      name: this.state.name,
    };
    this.props.sendReferCode(referData, this.callbackRefer);
  };
  callbackRefer = (res) => {
    if (res) {
      if (res.data.success) {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
        Swal.fire({
          position: "center",
          icon: "success",
          title: res.data.message,
          showConfirmButton: true,
          timer: 5000,
        });
      } else {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
        Swal.fire({
          position: "center",
          icon: "error",
          title: "Try after sometimes",
          showConfirmButton: true,
          timer: 5000,
        });
      }
    }
  };
  openModal = () => {
    this.setState({ isOpen: true });
    this.setState({ referCode: localStorage.getItem("referCode") });
    this.setState({ name: localStorage.getItem("fullName") });
    this.setState({ mobileNumber: localStorage.getItem("mobilenumber") });
  };
  closeModal = () => {
    this.setState({ isOpen: false });
    this.setState({ referMobileNumber: "" });
    this.setState({ disable: true });
  };

  closeModalCheckBalance = () => {
    this.setState({ isOpenCheckBalance: false });
  }

  checkBalance = () => {
    this.setState({ isOpenCheckBalance: true });
  }
  handleShow = () => {
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackVerify);
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error" || res.data.success === false) {
          this.props.history.push(PATH.PRIVATE.CIBIL_SCORE_ANALYSIS);
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          let formData = {
            mobile: res.data.cibilData?.userData?.[0].mobileno,
            pincode: res.data.cibilData?.userData?.[0].pincode,
            name: res.data.cibilData?.userData?.[0].name,
            pan: res.data.cibilData?.userData?.[0].pan,
            dob: res.data.cibilData?.userData?.[0].dob,
            email: res.data.cibilData?.userData?.[0].email,
            cibilcheck: "Y",
            creditCode:
              (res.data.cibilData?.experianScore === -1 && "A") ||
              (res.data.cibilData?.experianScore >= 800 && "B") ||
              (res.data.cibilData?.experianScore >= 750 &&
                res.data.cibilData?.experianScore <= 799 &&
                "C") ||
              (res.data.cibilData?.experianScore >= 700 &&
                res.data.cibilData?.experianScore <= 749 &&
                "D") ||
              (res.data.cibilData?.experianScore >= 650 &&
                res.data.cibilData?.experianScore <= 699 &&
                "E") ||
              (res.data.cibilData?.experianScore >= 600 &&
                res.data.cibilData?.experianScore <= 649 &&
                "F") ||
              (res.data.cibilData?.experianScore >= 0 &&
                res.data.cibilData?.experianScore <= 599 &&
                "G"),
          };
          this.props.setAccountInfo(formData, this.callBackAcc);
        }
      }
    }
  };
  callBackAcc = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
        localStorage.setItem("fullName", this.props.userData?.[0]?.name);
        localStorage.setItem("firstName", this.props.userData?.[0]?.name);
        localStorage.setItem("pan", this.props.userData?.[0]?.pan);
      }
    }
  };
  render() {
    const name1 =
      localStorage.getItem("firstName").length > 1 &&
      localStorage.getItem("firstName").split(" ");
    const name2 =
      localStorage.getItem("fullName").length > 1 &&
      localStorage.getItem("fullName").split(" ");

    const userName = isNaN(localStorage.getItem("lastName"))
      ? name1[0]
      : name2[0];
    const bool = cleanObject(userName);
    let mobile = getBase64Encryption(getHashEncryption(localStorage.getItem('mobilenumber')));
    let access_token = getBase64Encryption(getHashEncryption(localStorage.getItem('accessToken')));
    let deviceId = getBase64Encryption(getHashEncryption(localStorage.getItem('deviceId')));
    let redirectUrl = `${process.env.REACT_APP_AAFRONTENDAPP}?deviceId=${deviceId}&mobile_number=${mobile}&access_token=${access_token}`
    return (
      <>
        <header className="bsHeader">
          <Navbar expand="lg" fixed="top">
            <Container>
              <Navbar.Brand href={PATH.PRIVATE.PRODUCTS}>
                {" "}
                <img src="/wefin-logo.svg" alt={"logo"} className="topbarLogo" />
              </Navbar.Brand>
              <Navbar.Toggle aria-controls="navbarScroll" className="x" />
              <Navbar.Collapse id="navbarScroll">
                <Nav className="me-auto my-2 my-lg-0" navbarScroll>
                  <Nav.Link
                    onClick={() =>
                      this.props.history.push(PATH.PRIVATE.PRODUCTS)
                    }
                    hrefLink={"javascript:void(0)"}
                  >
                    Home{" "}
                  </Nav.Link>
                  <Nav.Link
                    hrefLink={"javascript:void(0)"}
                    onClick={() => this.handleShow()}
                  >
                    Credit Score{" "}
                  </Nav.Link>
                  <Nav.Link
                    onClick={() => this.props.history.push(PATH.PRIVATE.FAQ)}
                    hrefLink={"javascript:void(0)"}
                  >
                    {" "}
                    FAQs
                  </Nav.Link>
                  <Nav.Link
                    onClick={() => {
                      this.openModal();
                    }}
                  >
                    {" "}
                    Refer A Friend
                  </Nav.Link>

                  <Nav.Link
                    onClick={this.checkBalance}
                    className={
                      this.props.location.pathname === PATH.PRIVATE.CHECK_BALANCE
                        ? "active"
                        : ""
                    }
                  >
                    {" "}
                    Check Balance
                    <span>New</span>
                  </Nav.Link>
                </Nav>
                <Modal
                  className="ReferFriendModal"
                  show={this.state.isOpen}
                  onHide={this.closeModal}
                >
                  <Modal.Body className="text-center">
                    <figure>
                      <img src={ReferIfon} width="" height="" />
                    </figure>
                    <h4>Refer Your Friends</h4>
                    <p>
                      Invite Your friends to sign up with your referral code and
                      avail loan.
                    </p>
                    <h6>
                      Your Referral Code: <span>{this.state.referCode}</span>
                    </h6>
                    <div className="rf-input-block">
                      <input
                        type="text"
                        placeholder="Enter Your Friend Mobile No."
                        value={this.state.referMobileNumber}
                        onChange={this.__handleMobileNumber}
                        maxLength="10"
                        onKeyPress={(e) =>
                          this.__handleKeyPress(e, "Enter Mobile Number")
                        }
                        autoFocus
                        id="MobileNumber"
                        name="MobileNumber"
                      />
                      <button
                        disabled={this.state.disable}
                        type="submit"
                        onClick={(e) => this._sendReferCode(e)}
                        className="btn btn-primary get-otp-btn"
                      >
                        Invite
                      </button>
                      {this.state.MobileNumberError && (
                        <p className="referModalError text-center">
                          {this.state.MobileNumberError}
                        </p>
                      )}
                    </div>
                  </Modal.Body>
                </Modal>

                <Modal
                  className="ReferFriendModal AaModal"
                  show={this.state.isOpenCheckBalance}
                  onHide={this.closeModalCheckBalance}
                  closeButton={true}
                >
                  <Modal.Body className="text-center">
                    <div className="container-iframe">
                      <iframe class="responsive-iframe" src={redirectUrl}></iframe>
                    </div>
                  </Modal.Body>
                </Modal>
                <Form className="d-none d-flex display-mobile">
                  <div className="bsMapLocation">
                    <LocationDropDown
                      childComponent={
                        <>
                          <img
                            src="/locator.svg"
                            alt=""
                            className="locator"
                            style={{ cursor: "pointer" }}
                          />

                          <div
                            className="location"
                            style={{ cursor: "pointer" }}
                          >
                            {this.props.geoError && (
                              <p>{this.props.geoError}</p>
                            )}
                            {this.props.pin &&
                              this.props.pin +
                              " " +
                              "-" +
                              " " +
                              this.props.city}
                          </div>
                        </>
                      }
                      __handlePinCode={this.props.__handlePinCode}
                      pin={this.props.pin}
                      city={this.props.city}
                      pinError={this.props.pinError}
                    />
                  </div>
                  <Dropdown>
                    <Dropdown.Toggle
                      id="dropdown-button-dark-example1"
                      variant="secondary"
                    >
                      <img src={UserIcon} alt="" width="20px" height="20px" />
                      Hi,{" "}
                      {bool === false
                        ? localStorage.getItem("mobilenumber")
                        : userName.toLowerCase()}
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                      <Dropdown.Item>
                        {bool === false
                          ? localStorage.getItem("mobilenumber")
                          : userName.toLowerCase()}
                        <p>
                          {" "}
                          {localStorage.getItem("mobilenumber")
                            ? localStorage.getItem("mobilenumber")
                            : ""}
                        </p>
                      </Dropdown.Item>
                      <div className="dropdown-divider"></div>
                      <Dropdown.Item
                        onClick={this.logout}
                        className="bsLogoutbtn"
                        href="javascript:void(0)"
                      >
                        <img src={LogoutIcon} alt="" />
                        Logout
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </Form>
              </Navbar.Collapse>
              <div className="bsLogoutMobile d-block d-sm-none d-md-none d-lg-none">
                <Dropdown>
                  <Dropdown.Toggle
                    id="dropdown-button-dark-example1"
                    variant="secondary"
                  >
                    <img src={UserIcon} alt="" width="20px" height="20px" />
                    Hi,{" "}
                    {bool === false
                      ? localStorage.getItem("mobilenumber")
                      : userName.toLowerCase()}
                  </Dropdown.Toggle>

                  <Dropdown.Menu variant="dark">
                    <Dropdown.Item>
                      {bool === false
                        ? localStorage.getItem("mobilenumber")
                        : userName.toLowerCase()}
                      <p>
                        {" "}
                        {localStorage.getItem("mobilenumber")
                          ? localStorage.getItem("mobilenumber")
                          : ""}
                      </p>
                    </Dropdown.Item>
                    <div className="dropdown-divider"></div>
                    <Dropdown.Item
                      onClick={this.logout}
                      className="bsLogoutbtn"
                      href="javascript:void(0)"
                    >
                      <img src={LogoutIcon} alt="" />
                      Logout
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            </Container>
          </Navbar>
        </header>

        {/* map display on mobile for two wheelers section */}

        <div className="bsMapLocation bsMapLocationMobile d-block d-sm-none d-md-none d-lg-none">
          <LocationDropDown
            childComponent={
              <>
                <img
                  src="/locator.svg"
                  alt=""
                  className="locator"
                  style={{ cursor: "pointer" }}
                />

                <div className="location" style={{ cursor: "pointer" }}>
                  {this.props.geoError && <p>{this.props.geoError}</p>}
                  {this.props.pin &&
                    this.props.pin + " - " + this.props.city}
                </div>
              </>
            }
            __handlePinCode={this.props.__handlePinCode}
            pin={this.props.pin}
            city={this.props.city}
            pinError={this.props.pinError}
          />
        </div>
        {/* map display on mobile for two wheelers section */}
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  customerDetail: getAccount(state).customerDetail,
  experian: getExperian(state),
  userData: getExperian(state).userData,
  loadingLogout: getCustomer(state).loadingLogout

});

const mapDispatchToProps = (dispatch) => ({
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
  logout: (params, callback) =>
    dispatch(logout(params, callback)),
  sendReferCode: (params, callback) =>
    dispatch(sendReferCode(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TopNavBar)
);
