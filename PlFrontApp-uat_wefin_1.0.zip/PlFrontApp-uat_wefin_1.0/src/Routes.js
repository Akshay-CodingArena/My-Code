import React, { useState } from "react";
import { BrowserRouter as Router, Switch, Route, Redirect } from "react-router-dom";
import PrivateRoute from "./components/common/privateRoute";
import BackDropComponent from "./common/BackDropComponent";
import ErrorBoundary from "./ErrorHandling/ErrorBoundary";
import PATH from "./paths/Paths";
import Dashboard from "./components/ASM/Dashboard"
import HdfcBank from "./components/PersonalLoanJourney/lenders/HDFC/parent";
import FOSDashboard from "./components/FOS/Dashboard.jsx";
import FOSAddCustomer from "./components/FOS/FOSAddCustomer.jsx";
import FosUploadDocs from "./components/FOS/UploadDocs.jsx";

const ICICIPaymentSuccess = React.lazy(() =>
  import("./components/ASM/insurance/icici/paymentSuccess.jsx")
);

const ICICIPaymentFailed = React.lazy(() =>
  import("./components/ASM/insurance/icici/paymentFailed.jsx")
);

const LoginHLMain = React.lazy(() =>
  import("./components/Authentication/hlLogin/loginMain")
);
const HomeLoanBankVerification = React.lazy(() =>
  import("./components/HomeLoanJourney/bankVerification/bankVerification")
);
const LoginBLMain = React.lazy(() =>
  import("./components/Authentication/blLogin/loginMain")
);
const PlLenderLogin = React.lazy(() =>
  import("./components/Authentication/plLenderLogin/loginMain")
);
const HomeProducts = React.lazy(() => import("./common/HomeProducts"));
const LoginMain = React.lazy(() =>
  import("./components/Authentication/Login/loginMain")
);
const LoginTWMain = React.lazy(() =>
  import("./components/Authentication/twLogin/loginMain")
);
const CreditHome = React.lazy(() =>
  import("./components/cibilFlow/creditHome")
);
const LoginCibilMain = React.lazy(() =>
  import("./components/Authentication/cibilLogin/loginMain")
);
const LoginCreditMain = React.lazy(() =>
  import("./components/Authentication/creditCLogin/loginMain")
);
const LoginPLMain = React.lazy(() =>
  import("./components/Authentication/plLogin/loginMain")
);


const CreditCheck = React.lazy(() =>
  import("./components/cibilFlow/creditCheck")
);

const PanVerify = React.lazy(() =>
  import("./components/personalDetail/panVerify")
);

const PersonalDetailMain = React.lazy(() =>
  import("./components/personalDetail/personalDetailMain")
);
const BankVerification = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/bankVerification")
);
const SelfieUpload = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/selfieUpload")
);
const Aadhar = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/aadhar")
);
const CreditCardMain = React.lazy(() =>
  import("./components/creditCard/creditCard")
);
const CreditDetail = React.lazy(() =>
  import("./components/creditCard/creditDetail")
);
const TwGrid = React.lazy(() =>
  import("./components/TwoWheelerJourney/TwDetail/TwGrid")
);
const TwVariants = React.lazy(() =>
  import("./components/TwoWheelerJourney/TwDetail/TwVariants")
);
const TwVariantsDummy = React.lazy(() =>
  import("./components/TwoWheelerJourney/TwDetail/TwVariantsDummy")
);
const TwList = React.lazy(() =>
  import("./components/TwoWheelerJourney/TwDetail/TwList")
);
const LoanApplications = React.lazy(() =>
  import("./components/common/loanApplications")
);
const CreditCardOffer = React.lazy(() =>
  import("./components/creditCard/creditCardOffer")
);
const VerifyIncome = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/VerifyIncome")
);
const AddPrimaryReference = React.lazy(() =>
  import(
    "./components/PersonalLoanJourney/bankVerification/AddPrimaryReference"
  )
);
const PLOffer = React.lazy(() => import("./components/personalDetail/plOffer"));
const CibilCheck = React.lazy(() =>
  import("./components/CibilCheck/CibilCheck")
);
const CibilScore = React.lazy(() =>
  import("./components/CibilCheck/cibilScore")
);
const NotFound = React.lazy(() => import("./components/common/notFound"));
const FAQ = React.lazy(() => import("./components/common/faq"));
const Failed = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/failed")
);
const FullertonCongralution = React.lazy(() =>
  import(
    "./components/PersonalLoanJourney/bankVerification/fullertonCongralution"
  )
);
const PapqCongralution = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/congratulationPapq")
);
const UploadSalary = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/UploadSalary")
);
const CheckCreditSaisonPerfios = React.lazy(() =>
  import(
    "./components/PersonalLoanJourney/bankVerification/CheckCreditSaisonPerfios"
  )
);

const BankDetails = React.lazy(() =>
  import("./components/PersonalLoanJourney/BankDetailsVerification/BankDetails")
);
const MandateDetails = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/emandate_details")
);
const ESignAgreement = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/ESignAgreement")
);
const EquitasCongratulation = React.lazy(() =>
  import(
    "./components/PersonalLoanJourney/bankVerification/EquitasCongratulation"
  )
);

const BusinessLoanDetailMain = React.lazy(() =>
  import(
    "./components/BusinessLoanJourney/BankDetailsVerification/ApplyBusinessLoan"
  )
);
const CongratulationMain = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/congratulation")
);

const HLOffer = React.lazy(() =>
  import("./components/HomeLoanJourney/BankDetailsVerification/HLOffer")
);
const BLOffer = React.lazy(() =>
  import("./components/BusinessLoanJourney/BankDetailsVerification/BLOffer")
);
const HlDashboard = React.lazy(() => {
  import("./components/HomeLoanJourney/hlDashboard");
});

const HomeOffer = React.lazy(() =>
  import("./components/HomeLoanJourney/BankDetailsVerification/HomeOffer")
);
const PersonalDetailPLMain = React.lazy(() =>
  import("./components/personalDetail/personalDetailPlMain")
)

const CreditCardCategory = React.lazy(() =>
  import("./components/creditCard/creditcardCategory")
)

const CreditCardInfoScreen = React.lazy(() =>
  import("./components/creditCard/creditCardInfo")
);
const CreditCardListNew = React.lazy(() =>
  import("./components/creditCard/creditCardListNew")
);

const CreditCardAppliedScreen = React.lazy(() =>
  import("./components/creditCard/creditCardApplied")
);

const HomeLoanDetailMain = React.lazy(() =>
  import("./components/HomeLoanJourney/BankDetailsVerification/ApplyHomeLoan")
)

const TeleVerificationDashBoard = React.lazy(() =>
  import("./components/TeleVerification/Dashboard"))

const ExternalTeleVerificationDashBoard = React.lazy(() =>
  import("./components/ExternalVerifier/Dashboard"))
// const AApdfMain = React.lazy(() =>
//   import("./common/aapdf")
// );

const MyProfile = React.lazy(() => import("./components/Profile/MyProfile"))

const FeedbackMain = React.lazy(() =>
  import("./components/Myprofile/feedback")
)

const LoginASMMain = React.lazy(() =>
  import("./components/Authentication/asmLogin/LoginForm.jsx")
)

const LoginTeleVerificationMain = React.lazy(() =>
  import("./components/Authentication/teleVerificationLogin/loginMain")
)

const TWOffer = React.lazy(() =>
  import("./components/personalDetail/twOffer"))

const LoanApplication = React.lazy(() =>
  import("./components/TeleVerification/LoanApplication"))

const EVLoanApplication = React.lazy(() => import("./components/ExternalVerifier/LoanApplication"))

const UploadBankStatement = React.lazy(() =>
  import("./components/PersonalLoanJourney/bankVerification/uploadBankStatement")
);

const TWDashboard = React.lazy(() => import("./components/TwoWheelerJourney/TwDetail/twoWheelerOffers"))

const AadhaarSelfie = React.lazy(() => import("./components/PersonalLoanJourney/bankVerification/selfieUpload"))

const ICICILombard = React.lazy(() => import("./components/ASM/insurance/icici/main"))

const ICICILombardAddtionalDeatails = React.lazy(() => import("./components/ASM/insurance/icici/additionalDetails"))

const ICICIFailed = React.lazy(() => import("./components/ASM/insurance/icici/failed"))

const ICICIWaiting = React.lazy(() => import("./components/ASM/insurance/icici/waiting"));

const ICICICongratulations = React.lazy(() => import("./components/ASM/insurance/icici/congratulation"))

const ICICIKyc = React.lazy(() => import("./components/ASM/insurance/icici/dropfile"))

const PaysenseParent = React.lazy(() => import("./components/PersonalLoanJourney/lenders/paysense/parent"))

const Routes = () => {
  const [pLData, setpLData] = useState([]);
  return (
    <React.Suspense fallback={<BackDropComponent />}>
      <Router>
        <ErrorBoundary>
          <Switch>
            <Route exact path={PATH.PUBLIC.INDEX} component={LoginMain} />


            <Route
              exact
              path={PATH.PUBLIC.TELE_VERIFICATION_LOGIN}
              component={LoginTeleVerificationMain}
            />
            <Route
              path={PATH.PUBLIC.TWO_WHEELER_LOAN}
              component={LoginTWMain}
            />
            <Route path={PATH.PUBLIC.CREDIT_REPORT} component={CreditHome} />
            <Route path={`${PATH.PUBLIC.PERSONAL_LOAN_JOURNEY}=:bankName/offer=:offerType`}
              component={PlLenderLogin} />
            <Route
              exact
              path={PATH.PUBLIC.PERSONAL_LOAN}
              component={LoginPLMain}
            />
            <Route
              exact
              path={PATH.PUBLIC.GET_CREDIT_CARD}
              component={CreditCardCategory}
            />
            <Route
              exact
              path={PATH.PUBLIC.GET_CREDIT_CARD_LIST}
              component={CreditCardListNew}
            />
            <Route
              exact
              path={PATH.PUBLIC.CREDIT_LOGIN}
              component={LoginCreditMain}
            />

            <Route
              exact
              path={PATH.PUBLIC.ICICI_PAYMENT_SUCCESS}
              component={ICICIPaymentSuccess}
            />

            <Route
              exact
              path={PATH.PUBLIC.ICICI_PAYMENT_FAILED}
              component={ICICIPaymentFailed}
            />

            {/* <Route
              exact
              path={PATH.PUBLIC.AA_PDF}
              component={AApdfMain}
            /> */}

            {/* <Route path={PATH.PUBLIC.CREDIT_SCORE} component={LoginCibilMain} /> */}
            <Route path={PATH.PUBLIC.HOME_LOAN} component={LoginHLMain} />

            <Route path={PATH.PUBLIC.BUSINESS_LOAN} component={LoginBLMain} />

            <Route
              path={PATH.PUBLIC.CHECK_CREDIT_REPORT}
              component={CreditCheck}
            />
            <Route
              path={PATH.PUBLIC.CREDIT_SAISON_PERFIOS_COMPLETE}
              component={CheckCreditSaisonPerfios}
            />
            <Route
              exact
              path={PATH.PUBLIC.CREDIT_CARD_INFO_SCREEN}
            >
              {<CreditCardInfoScreen />}
            </Route>
            <Route
              exact
              path={PATH.PUBLIC.ASM_LOGIN}
            >
              {<LoginASMMain />}
            </Route>
            <Route
              exact
              path={`${PATH.PUBLIC.TWO_WHEELER_VARIANT}/:name/:product`}
            >
              <TwVariantsDummy />
            </Route>


            <PrivateRoute path={PATH.PRIVATE.PROFILE}>
              <MyProfile />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.CUSTOMER_FEEDBACK_FORM}>
              <FeedbackMain />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN}>
              <CreditCardAppliedScreen />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.TELE_VERIFICATION_DASHBOARD}>
              <TeleVerificationDashBoard />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.EXTERNAL_TELE_VERIFICATION_DASHBOARD}>
              <ExternalTeleVerificationDashBoard />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.CONGRATULATION_SCREEN}>
              <CongratulationMain />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.UPLOAD_BANK_SALARY}>
              <UploadSalary />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.UPLOAD_BANK_STATEMENT} >
              <UploadBankStatement />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.APPLY_HOME_LOAN}>
              <HomeLoanDetailMain />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.APPLY_BUSINESS_LOAN}>
              <BusinessLoanDetailMain />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.PRODUCTS}>
              <HomeProducts />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS}>
              <TWOffer />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD}>
              <TWDashboard />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.PAN_VERIFY}>
              <PanVerify />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.FULLERTON_CONGRATULATION}>
              <FullertonCongralution />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.PAPQ_CONGRATULATION}>
              <PapqCongralution />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.LOAN_APP_FAILED}>
              <Failed />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.ASM_ADD_CUSTOMER}>
              <LoginTWMain />
            </PrivateRoute>

            <PrivateRoute
              path={`${PATH.PRIVATE.PERSONAL_DETAIL}/:bankName/offer=:offerType`}>
              <PersonalDetailPLMain pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.PERSONAL_DETAIL}>
              <PersonalDetailMain pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.HOME_LOAN_OFFERS}>
              <HLOffer />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.HOME_LOAN_DASHBOARD}>
              <HlDashboard />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.BUSINESS_LOAN_OFFERS}>
              <BLOffer />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.PERSONAL_LOAN_OFFERS}>
              <PLOffer />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.BANK_SPECIFIC_DETAILS}/:loantype/:bankname`}
            >
              <BankVerification pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.HOME_LOAN_BANK_SPECIFIC_DETAIL}/:loantype/:bankname`}
            >
              <HomeLoanBankVerification pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.BANK_SELFIE_UPLOAD}/:loantype/:bankname`}
            >
              <SelfieUpload pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.AADHAAR_SELFIE}`}
            >
              <AadhaarSelfie />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}/:loantype/:bankname`}
            >
              <AddPrimaryReference pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}`}
            >
              <AddPrimaryReference pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.VERIFY_INCOME_PERFIOS}/:loantype/:bankname`}
            >
              <VerifyIncome pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.AADHAR_DETAILS}/:loantype/:bankname`}
            >
              <Aadhar pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.VERIFY_BANK_DETAILS}/:loantype/:bankname`}
            >
              <BankDetails />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.EMANDATE_DETAILS}/:loantype/:bankname`}
            >
              <MandateDetails />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.ASM_DASHBOARD}`}
            >
              <Dashboard />
            </PrivateRoute>

            <PrivateRoute
              path={`${PATH.PRIVATE.FOS_DASHBOARD}`}
            >
              <FOSDashboard />
            </PrivateRoute>


            <PrivateRoute
              path={`${PATH.PRIVATE.FOS_ADD_CUSTOMER}`}
            >
              <FOSAddCustomer />
            </PrivateRoute>

            <PrivateRoute
              path={`${PATH.PRIVATE.FOS_ADD_CUSTOMER}`}
            >
              <FOSAddCustomer />
            </PrivateRoute>

            <PrivateRoute
              path={`${PATH.PRIVATE.ESIGN_AGREEMENT}/:loantype/:bankname`}
            >
              <ESignAgreement />
            </PrivateRoute>
            <PrivateRoute path={`${PATH.PRIVATE.EQUITAS_CONGRATULATION}`}>
              <EquitasCongratulation />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.TWO_WHEELER}>
              <TwList />
            </PrivateRoute>
            <PrivateRoute path={`${PATH.PRIVATE.TWO_WHEELER_LIST}/:name`}>
              <TwGrid />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.TWO_WHEELER_VARIANT}/:name/:product`}
            >
              <TwVariants />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.CREDIT_CARD_DETAIL}>
              <CreditDetail />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.CREDIT_CARD}>
              <CreditCardMain />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.CREDIT_CARD_OFFERS}>
              <CreditCardOffer />
            </PrivateRoute>
            <PrivateRoute path={PATH.PRIVATE.CREDIT_REPORT_ANALYSIS}>
              <CibilCheck />
            </PrivateRoute>
            <PrivateRoute path={`${PATH.PRIVATE.VIEW_LOAN_APP_EXTERNAL}/:loanName`}>
              <EVLoanApplication />
            </PrivateRoute>
            <PrivateRoute path={`${PATH.PRIVATE.VIEW_LOAN_APP}/:loanName`}>
              <LoanApplication />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.LOAN_APPLICATIONS}/:name/:offer`}
            >
              <LoanApplications />
            </PrivateRoute>
            <PrivateRoute
              path={`${PATH.PRIVATE.UPLOAD_SALARY_SLIP}/:loantype/:bankname`}
            >
              <UploadSalary pLData={pLData} setpLData={setpLData} />
            </PrivateRoute>
            {/* <PrivateRoute path={PATH.PRIVATE.CIBIL_SCORE_ANALYSIS}>
              <CibilScore />
            </PrivateRoute> */}
            <PrivateRoute path={PATH.PRIVATE.FAQ}>
              <FAQ />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.ASM_INSURANCE_ICICI}>
              <ICICILombard />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.ASM_INSURANCE_ADDITIONAL_DETAILS_ICICI}>
              <ICICILombardAddtionalDeatails />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.ASM_INSURANCE_FAILED_SCREEN}>
              <ICICIFailed />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.ASM_INSURANCE_WAITING_SCREEN}>
              <ICICIWaiting />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.ASM_INSURANCE_CONGRATS_SCREEN}>
              <ICICICongratulations />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.ASM_INSURANCE_KYC_SCREEN}>
              <ICICIKyc />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.HDFC_PL_FLOW}>
              <HdfcBank />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.PAYSENSE_PL_FLOW}>
              <PaysenseParent />
            </PrivateRoute>

            <PrivateRoute path={PATH.PRIVATE.FOS_UPLOAD_DOCS}>
              <FosUploadDocs />
            </PrivateRoute>
            <Route
              render={(props) => (
                <NotFound
                  isAuth={localStorage.getItem("accessToken") ? true : false}
                  {...props}
                />
              )}
            />
          </Switch>
        </ErrorBoundary>
      </Router>
    </React.Suspense >
  );
};

export default Routes;
