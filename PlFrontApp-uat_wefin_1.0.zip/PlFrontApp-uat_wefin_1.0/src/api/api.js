import axios from "axios";

const callApi = async ({
  baseUrl,
  headers = {},
  url,
  method,
  params = {},
  data,
  timeout,
}) => {
  try {
    return await axios.request({
      baseURL: baseUrl,
      headers,
      url,
      method,
      params,
      data,
      // timeout: 1000 * timeout,
    });
  } catch (e) {
    console.log(`Error =======> ${e}`);
  }
};

export { callApi };
