import React, { Component } from "react";
import CreditHeader from "./header";
import CreditForm from "./creditscoreform";
import CreditScoreBanner from "../../include/assets/credit-score.svg";
import { getpanName } from "../../store/panName";
import CreditFooter from "./footer";
import { connect } from "react-redux";
import { withRouter } from "react-router";
class CreditHome extends Component {
  render() {
    const { creditloading } = this.props.getpanName;

    return (
      // header start
      <main>
        {creditloading && (
          <div className="bs-loader">
            {" "}
            <div className="bs-loader-block">
              {" "}
              <img src="/loadar.gif" alt="" />
            </div>
          </div>
        )}
        <CreditHeader />

        <section className="cssection">
          <div className="container-fluid">
            <div className="row justify-content-center">
              <div className="col-12 col-sm-6 col-md-5 order-2 order-md-1 text-center min-vh-100">
                <div className="csbannerBlock">
                  <figure>
                    <img src={CreditScoreBanner} alt="CreditScoreBanner" width="300px" height="300px" />
                  </figure>
                  <p>
                    Keeping a track of your credit score is very important to
                    maintain it. Lenders use the credit score to access a
                    borrower's creditworthiness and so an updated and maintained
                    credit score is an ideal practice for a borrower.
                  </p>
                </div>
              </div>
              <div className="col-12 col-sm-6 col-md-7  order-md-2 form-bg min-vh-100">
                <div className="csformBlock">
                  <h1 className="text-center">
                    CHECK <span>FREE </span>CREDIT SCORE
                  </h1>
                  <CreditForm />
                </div>
              </div>
            </div>
          </div>
        </section>
        <CreditFooter />
      </main>
    );
  }
}

const mapStateToProps = (state) => ({
  getpanName: getpanName(state),
});

export default withRouter(connect(mapStateToProps, null)(CreditHome));
