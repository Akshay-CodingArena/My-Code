import React from "react";
import Joi from "joi-browser";
import Moment from "moment";
import Form from "../common/form";
import { getpanName, loadcreditPanName } from "../../store/panName";
import InputMask from "react-input-mask";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getpinCode, loadcreditPinCode } from "../../store/pincode";
import { getExperian, loadExperianCheck } from "../../store/experian";
import CreditOTPModal from "./creditotpModal";
import PATH from "../../paths/Paths";
const InputWithMask = (props) => (
  <InputMask mask="99-99-9999" value={props.value} onChange={props.onChange}>
    {(inputProps) => <input {...props} type="tel" disableUnderline />}
  </InputMask>
);
class CreditForm extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      terms: false,
      stgOneHitId: "",
      stgTwoHitId: "",
      openOtp: false,
    };
  }

  schema = {
    fullName: Joi.string()
      .required()
      .label("Full Name")
      .error(() => {
        return { message: "Full Name field is required." };
      }),
    pan: Joi.string()
      .min(10)
      .max(10)
      .required()
      .label("PAN Number")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "PAN Number field is required.";
              break;
            case "string.max":
              err.message = "PAN Number field is invalid.";
              break;
            case "string.min":
              err.message = "PAN Number field is invalid.";
              break;
            default:
              err.message = "PAN Number field is required.";
              break;
          }
        });
        return errors;
      }),
    email: Joi.string()
      .email()
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Email field is required.";
              break;
            case "string.email":
              err.message = "Email field is invalid.";
              break;
            default:
              err.message = "Email field is required.";
              break;
          }
        });
        return errors;
      }),
    pincode: Joi.string()
      .min(6)
      .max(6)
      .required()
      .label("Pincode")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Pincode field is required.";
              break;
            case "string.max":
              err.message = "Pincode field is invalid.";
              break;
            case "string.min":
              err.message = "Pincode field is invalid.";
              break;
            default:
              err.message = "Pincode field is required.";
              break;
          }
        });
        return errors;
      }),
    mobile: Joi.number()
      .required()
      .label("Landline No.")
      .error(() => {
        return { message: "Mobile Number field is required." };
      }),
    dob: Joi.string()
      .required()
      .label("Date of Birth")
      .error(() => {
        return { message: "Date of Birth field is required." };
      }),
  };
  doSubmit = () => {
    if (!Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
      const errors = { ...this.state.errors };
      errors.dob = "Date of Birth field is invalid.";
      this.setState({ errors });
    } else {
      let formData = {
        mobile: this.state.data.mobile,
        pincode: this.state.data.pincode,
        name: this.state.data.fullName,
        pan: this.state.data.pan,
        dob: reverseDateString(this.state.data.dob),
        email: this.state.data.email,
        isExperian: true,
      };
      this.props.loadExperianCheck(formData, this.callBackVerify);
    }
  };
  callBackVerify = (res) => {
    if (res?.data?.success) {
      if (res.data.cibilData) {
        this.props.history.push({
          pathname: PATH.PUBLIC.CHECK_CREDIT_REPORT,
          state: this.state.data.mobile,
        });
      } else {
        this.setState({
          stgOneHitId: res.data.data.stgOneHitId,
          stgTwoHitId: res.data.data.stgTwoHitId,
          openOtp: true,
        });
      }
    }
  };
  __handlePANChange = (e) => {
    let panNumber = e.target.value.toUpperCase();
    if (e.target.value.length <= 10) {
      const data = { ...this.state.data };
      data.pan = panNumber;
      this.setState({ data });
      if (e.target.value.length === 10) {
        let formData = {
          pan: panNumber,
        };
        this.props.loadcreditPanName(formData, this.callback);
      }
    }
  };
  onDateChange = (e) => {
    e.preventDefault();
    const data = { ...this.state.data };
    data.dob = e.target.value;
    this.setState({ data });
  };
  handleCheckBoxChange = () => {
    this.setState({
      terms: !this.state.terms,
    });
  };
  callback = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data.success === false) {
        let data = { ...this.state.data };
        data.fullName = "";
        errors.pan = res.data.message;
        localStorage.setItem("fullName", "");
        localStorage.setItem("firstName", "");
        localStorage.setItem("pan", "");
        this.setState({ data, errors });
      } else {
        const data = { ...this.state.data };
        data.fullName = res.data.name;
        localStorage.setItem("fullName", res.data.name);
        localStorage.setItem("firstName", res.data.name);
        localStorage.setItem("pan", this.state.data.pan);
        errors.pan = "";
        errors.fullName = "";
        this.setState({ data, errors });
      }
    }
  };

  __handlePinCode = (e) => {
    let pin = e.target.value;
    if (e.target.value.length <= 6) {
      const data = { ...this.state.data };
      data.pincode = pin;
      this.setState({ data });
      if (e.target.value.length === 6) {
        let formData = {
          pincode: pin,
        };
        this.props.loadcreditPinCode(formData, this.callbackPin);
      }
    }
  };
  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data.errorDetails) {
        errors.pincode = res.data.errorDetails;
        this.setState({ errors });
      } else if (!res.data.success) {
        errors.pincode = res.data.message;
        this.setState({ errors });
      } else if (res.data.success) {
        errors.pincode = "";
        this.setState({ errors });
      }
    }
  };

  __handleMobileNumber = (event) => {
    const mobile_number = event.target.value;
    if (mobile_number.length === 10 && !/^[6789]\d{9}$/.test(mobile_number)) {
      const errors = { ...this.state.errors };
      errors.mobile = "Please enter a valid mobile number.";
      this.setState({
        errors,
      });
    } else {
      const errors = { ...this.state.errors };
      errors.mobile = "";
      this.setState({
        errors,
      });
    }
    if (
      mobile_number.length <= 10 &&
      (/^[0-9]+$/.test(mobile_number) || mobile_number === "")
    ) {
      const data = { ...this.state.data };
      data.mobile = mobile_number;
      this.setState({ data });
    }
  };
  onDateChange = (e) => {
    e.preventDefault();
    const data = { ...this.state.data };
    data.dob = e.target.value;
    this.setState({ data });
  };
  closeOTPModal = () => {
    this.setState({
      openOtp: false,
      data: {
        pan: "",
        fullName: "",
        dob: "",
        email: "",
        pincode: "",
        mobile: "",
      },
    });
  };
  render() {
    // const { creditloading } = this.props.getpanName;

    return (
      <>
        <form autocomplete="off">
          <div className="contact">
            <div className="form-area">
              <div className="row">
                <div className="col-sm-6">
                  <div className="group form-group">
                    <input
                      name="pan"
                      id="pan"
                      className="form-control"
                      onChange={this.__handlePANChange}
                      value={this.state.data.pan}
                      required
                      autoComplete="off"
                    />
                    {this.state.errors.pan && (
                      <span className="error-form">
                        {this.state.errors.pan}
                      </span>
                    )}
                    <span className="highlight"></span>
                    <span className="bar"></span>
                    <label htmlFor="pan">
                      Pan Number <span>*</span>
                    </label>
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="group form-group">
                    <input
                      name="fullName"
                      id="fullName"
                      className="form-control"
                      defaultValue={this.state.data.fullName}
                      required
                      autoComplete="off"
                    />
                    {this.state.errors.fullName && (
                      <span className="error-form">
                        {this.state.errors.fullName}
                      </span>
                    )}
                    <span className="highlight"></span>
                    <span className="bar"></span>
                    <label htmlFor="fullName">
                      Full Name <span>*</span>
                    </label>
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="group form-group">
                    <InputWithMask
                      value={this.state.data.dob}
                      name="dob"
                      id="dob"
                      className="form-control"
                      onChange={this.onDateChange}
                      required
                      autoComplete="off"
                    />
                    {this.state.errors.dob && (
                      <span className="error-form">
                        {this.state.errors.dob}
                      </span>
                    )}
                    <span className="highlight"></span>
                    <span className="bar"></span>
                    <label htmlFor="dob">
                      Date of Birth <span>*</span>
                    </label>
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="group form-group">
                    <input
                      name="pincode"
                      id="pincode"
                      className="form-control"
                      onChange={this.__handlePinCode}
                      value={this.state.data.pincode}
                      required
                      autoComplete="off"
                    />
                    {this.state.errors.pincode && (
                      <span className="error-form">
                        {this.state.errors.pincode}
                      </span>
                    )}
                    <span className="highlight"></span>
                    <span className="bar"></span>
                    <label htmlFor="pincode">
                      Pin Code <span>*</span>
                    </label>
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="group form-group">
                    <input
                      name="mobile"
                      id="mobile"
                      maxLength="10"
                      className="form-control"
                      onChange={this.__handleMobileNumber}
                      value={this.state.data.mobile}
                      required
                      autoComplete="off"
                    />
                    {this.state.errors.mobile && (
                      <span className="error-form">
                        {this.state.errors.mobile}
                      </span>
                    )}
                    <span className="highlight"></span>
                    <span className="bar"></span>
                    <label htmlFor="mobile">
                      Phone Number <span>*</span>
                    </label>
                  </div>
                </div>
                <div className="col-sm-6">
                  {this.renderCreditInput("email", "Email ID")}
                </div>
              </div>
              <div className="col-sm-12">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    checked={this.state.terms}
                    onChange={this.handleCheckBoxChange}
                  />
                  <label className="form-check-label " htmlFor="form-check-label">
                    You hereby consent to Neotec being appointed as your
                    authorised representative to receive your Credit Information
                    from Experian on an ongoing basis until the purpose of
                    monitoring credit health's and providing financial offers
                    (“End Use Purpose”) is satisfied or expiry of 6 months from
                    date the consent is collected; whichever is earlier.
                    <a
                      style={{
                        color: "#2e0080",
                        cursor: "pointer",
                        textDecoration: "underline",
                      }}
                      href="https://www.bankse.in/experian-tnc.html"
                      target="_blank"
                      rel="noreferrer"
                    >
                      {" "}
                      Terms and Conditions{" "}
                    </a>
                  </label>
                </div>
              </div>
              <div className="col-sm-12 text-center">
                {this.state.terms === true ? (
                  <button
                    type="submit"
                    onClick={this.handleSubmit}
                    className="btn btn-primary col-md-12"
                  >
                    Get Free Credit Report
                  </button>
                ) : (
                  <button
                    type="submit"
                    onClick={this.handleSubmit}
                    className="btn btn-primary col-md-12"
                    disabled
                    style={{
                      opacity: "0.5",
                      cursor: "not-allowed",
                    }}
                  >
                    Get Free Credit Report
                  </button>
                )}
              </div>
            </div>
          </div>
        </form>
        {this.state.openOtp === true && (
          <CreditOTPModal
            show={this.state.openOtp}
            handleCloseOTP={this.closeOTPModal}
            mobile={this.state.data.mobile}
            stgOneHitId={this.state.stgOneHitId}
            stgTwoHitId={this.state.stgTwoHitId}
            data={this.state.data}
          />
        )}
      </>
    );
  }
}
function reverseDateString(str) {
  var splitString = str.split("-");
  var reverseArray = splitString.reverse();
  var joinArray = reverseArray.join("-");
  joinArray = joinArray + "T00:00:00.000Z";
  return joinArray;
}

const mapStateToProps = (state) => ({
  getpanName: getpanName(state),
  getpinCode: getpinCode(state),
  experian: getExperian(state).accountData,
  loadingCheck: getExperian(state).loadingCheck,
});
const mapDispatchToProps = (dispatch) => ({
  loadcreditPanName: (params, callback) =>
    dispatch(loadcreditPanName(params, callback)),
  loadcreditPinCode: (params, callback) =>
    dispatch(loadcreditPinCode(params, callback)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreditForm)
);
