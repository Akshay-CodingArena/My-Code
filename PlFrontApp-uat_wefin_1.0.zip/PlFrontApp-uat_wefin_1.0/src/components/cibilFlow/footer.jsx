import React, { Component } from "react";
var appVersion = require("../../../package.json").version;

class footer extends Component {
  render() {
    return (
      <footer className="bs-footer-main">
        <div className="bs-footer-copy-right">
          <div className="container">
            <div className="row">

              <div className="col-sm-12">
                <div>
                  <p>
                    CIN No. U74999DL2021PLC378755 © Copyright owned by Neotec
                    Enterprises Ltd. 2022
                  </p>

                  <ul>
                    <li>
                      <a
                        href="https://wefin.in/terms-of-use.html"
                      // target="_blank"
                      >
                        Terms of Use
                      </a>{" "}
                      <span>|</span>
                    </li>
                    <li>
                      <a
                        href="https://wefin.in/privacy-policy.html"
                      // target="_blank"
                      >
                        Privacy Policy
                      </a>
                    </li>
                    <li></li>
                  </ul>
                  <div></div>
                </div>
              </div>
            </div>
          </div>
          <span className="bs-version">Version:{appVersion}</span>
        </div>
      </footer>
    );
  }
}

export default footer;
