import React, { Component } from "react";
import PATH from "../../paths/Paths";

class CreditHeader extends Component {
  render() {
    return (
      <header id="header" className="bs-cs-header">
        <div className="container-fluid d-flex align-items-center justify-content-between">
          <a className="logo d-flex align-items-center scrollto me-auto me-lg-0">
            <img src="/logo.png" alt="logo" width="125px" height="44px" />
          </a>

          <a className="btnLogin" href={PATH.PUBLIC.INDEX}>
            <img src="/user.svg" alt="user_logo" width="16" height="16" /> Login
          </a>
        </div>
      </header>
    );
  }
}

export default CreditHeader;
