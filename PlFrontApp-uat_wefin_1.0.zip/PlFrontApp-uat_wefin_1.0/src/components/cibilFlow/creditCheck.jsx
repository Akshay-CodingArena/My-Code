import React, { Component } from "react";
import Gauger from "../CibilCheck/gauge";
import { withRouter } from "react-router";
import CreditFooter from "./footer";
import { connect } from "react-redux";
import { getExperian, loadExperianCheck } from "../../store/experian";
import moment from "moment";
import { ReactComponent as HomeLoanIcon } from "../CibilCheck/icons/home-loan-icon.svg";
import { ReactComponent as OverdueIcon } from "../CibilCheck/icons/overdue.svg";
import { ReactComponent as DeleaydIcon } from "../CibilCheck/icons/deleayd.svg";
import { ReactComponent as TickIcon } from "../CibilCheck/icons/tick.svg";
import { ReactComponent as DotsIcon } from "../CibilCheck/icons/dots.svg";
import { ReactComponent as OnTimePaymentIcon } from "../CibilCheck/icons/ontime-payment.svg";
import { ReactComponent as CreditAgeIcon } from "../CibilCheck/icons/credit-age.svg";
import { ReactComponent as CreditMixIcon } from "../CibilCheck/icons/credit-mix.svg";
import { ReactComponent as NewCreditAccountIcon } from "../CibilCheck/icons/new-credit-ac.svg";
import { ReactComponent as TotalAccountIcon } from "../CibilCheck/icons/total-ac.svg";
import CreditHeader from "./header";
import {
  getAccountType,
  accountStatus,
  existMonth,
} from "../CibilCheck/accountType";
import { numberFormat } from "../../Utils/numberFormat";
import { monthDiff, getWords } from "../CibilCheck/creditHelper";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
// import _ from "lodash";
import "react-accessible-accordion/dist/fancy-example.css";
class CreditCheck extends Component {
  state = {
    cibilScore: "",
    error: "",
    accountNumber: "",
    Identification_Number: "",
  };

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    let formData = {
      mobile: this.props.location.state,
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackVerify);
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error") {
          this.setState({ error: "Something went wrong!!" });
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          this.setState({
            cibilScore: res.data.cibilData.experianData.SCORE.BureauScore[0],
          });
        }
      }
    }
  };

  render() {
    const { userData } = this.props;
    let accountHistory = [];
    let SCORE = [];
    let creditEnquiries = [];
    let totalAccountSummary = [];
    if (this.props.experian) {
      accountHistory = this.props.experian.accountHistory;
      SCORE = this.props.experian.SCORE;
      creditEnquiries = this.props.experian.creditEnquiries;
      totalAccountSummary = this.props.experian.totalAccountSummary;
    }

    const creditAge =
      Array.isArray(accountHistory) &&
      accountHistory.slice().sort((a, b) => {
        var da = new Date(moment(a.Open_Date?.[0]).format("YYYY-MM-DD"));
        var db = new Date(moment(b.Open_Date?.[0]).format("YYYY-MM-DD"));
        return da - db;
      });

    const creditAgeDiff = monthDiff(
      new Date(moment(new Date()).format("YYYY-MM-DD")),
      new Date(moment(creditAge?.[0]?.Open_Date?.[0]).format("YYYY-MM-DD"))
    );
    const data = Array.isArray(accountHistory) && accountHistory;
    var onTime = 0;
    var Late = 0;
    var highestCredit = 0;
    var totalLimitUsed = 0;
    var overdue = 0;
    var m = new Map();
    var arrayList = {};
    if (data) {
      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j <= data[i].Payment_History_Profile.length; j++) {
          if (
            data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !== "null" &&
            data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !== ""
          ) {
            if (
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] === "0"
            ) {
              onTime++;
            } else if (
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] > 0
            ) {
              Late++;
            }
          } else if (
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "?" ||
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "N" ||
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "S"
          ) {
            onTime++;
          } else if (
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] >
            0 ||
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "L"
          ) {
            Late++;
          }
        }
      }
    }
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (
          data[i]?.Account_Type?.[0] === "10" &&
          data[i]?.AccountStatus?.[0] !== "13"
        ) {
          highestCredit =
            parseInt(highestCredit) +
            parseInt(data[i].Highest_Credit_or_Original_Loan_Amount);
        }
        if (
          data[i]?.Account_Type?.[0] === "10" &&
          data[i]?.AccountStatus?.[0] !== "13" &&
          data[i].Amount_Past_Due?.[0] !== ""
        ) {
          totalLimitUsed =
            totalLimitUsed +
            parseInt(data[i].Amount_Past_Due?.[0]) +
            parseInt(data[i].Current_Balance?.[0]);
        }
      }
    }
    const totalPayment = onTime + Late;
    const paymentParcent = Math.round((onTime / totalPayment) * 100);
    const creditUtilization = Math.round(
      (totalLimitUsed / highestCredit) * 100
    );
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (
          this.state.accountNumber === data[i].Account_Number &&
          this.state.Identification_Number === data[i].Identification_Number
        ) {
          for (
            let j = 0;
            j <= data[i].Payment_History_Profile.length - 1;
            j++
          ) {
            arrayList = m[data[i]?.Payment_History_Profile[j]?.Year[0]];
            var element = data[i]?.Payment_History_Profile[j]?.Month[0];
            if (arrayList == null || arrayList.length < 12) {
              arrayList = {
                "01": "0",
                "02": "0",
                "03": "0",
                "04": "0",
                "05": "0",
                "06": "0",
                "07": "0",
                "08": "0",
                "09": "0",
                10: "0",
                11: "0",
                12: "0",
              };
            }
            arrayList[element] = 1;
            m.set(data[i]?.Payment_History_Profile[j]?.Year[0], arrayList);

            if (
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !==
              "null" &&
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !== ""
            ) {
              if (
                data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] === "0"
              ) {
                m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
              } else {
                arrayList[element] = -1;
                m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
                overdue++;
              }
            } else if (
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "?" ||
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "N" ||
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "S"
            ) {
              m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
            } else if (
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] >
              0 ||
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "L"
            ) {
              arrayList[element] = -1;
              m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
              overdue++;
            }
          }
        }
      }
    }
    return (
      <>
        <CreditHeader />
        <section className="bs-cs-section bs-cibil-section">
          {" "}
          <div className="container">
            <div className="bs-cs-box">
              <div className="bs-cs-header">
                <span>{userData?.[0]?.name}</span>, here’s your score for&nbsp;
                {moment(userData?.[0]?.created_on).format("DD-MMM-YYYY")}
              </div>
              <div className="row align-items-center">
                <div className="col-md-5">
                  <div className="bs-cs-circle">
                    {" "}
                    <Gauger
                      cibilScore={this.state.cibilScore}
                      error={this.state.error}
                    />
                  </div>
                </div>
                <div className="col-md-7">
                  <div className="bs-cs-information">
                    <h4>What does credit score mean?</h4>
                    <p>
                      It is a report based on your performance on loans.
                      It ranges between 300 and 900 and summarizes your
                      credit report, history, and rating. Banks & NBFCs uses
                      this information as one of the primary criteria for assessing your loan application.
                    </p>
                  </div>
                </div>

                <div className="col-md-12">
                  <h1>Download</h1>
                </div>

              </div>
              <div className="bs-cs-logo">
                <img src="/experian.png" alt="" width="200" height="65" />
              </div>
            </div>

            <div className="bs-cibil-container">
              <div className="row">
                <div className="col-sm-12">
                  <div className="bs-cs-al-cf-header">
                    <h2>Your Credit Activity</h2>
                    {SCORE && SCORE.BureauScore && SCORE.BureauScore[0] > 1
                      ? ""
                      : "Experian doesn't have enough credit information about you to generate your score"}
                  </div>
                  <Accordion allowZeroExpanded>
                    {Array.isArray(accountHistory) &&
                      accountHistory.map((data) => (
                        <AccordionItem
                          onClick={() =>
                            this.setState({
                              accountNumber: data.Account_Number,
                              Identification_Number: data.Identification_Number,
                            })
                          }
                        >
                          <AccordionItemHeading>
                            <AccordionItemButton>
                              <div className="row g-0 bs-cs-acl-box">
                                <div className="col-12 col-sm-6 col-md-4">
                                  <div className="bs-cs-acl-card">
                                    <HomeLoanIcon />
                                    <div>
                                      <h4>{data.Identification_Number}</h4>
                                      <span>
                                        {" "}
                                        <small>
                                          {getAccountType[data.Account_Type]}
                                        </small>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-12 col-md-3">
                                  <h4>Loan Number</h4>
                                  <p>{data.Account_Number}</p>
                                </div>
                                <div className="col-8 col-sm-6 col-md-4">
                                  <h4>Loan Amount</h4>
                                  <p>
                                    {numberFormat(
                                      data.Highest_Credit_or_Original_Loan_Amount
                                    )}
                                  </p>
                                </div>
                                <div className="col-4 col-sm-6 col-md-1">
                                  <h4>Status</h4>
                                  <p className="text-success">
                                    {" "}
                                    {accountStatus[data.Account_Status]}
                                  </p>
                                </div>
                              </div>
                            </AccordionItemButton>
                          </AccordionItemHeading>
                          <AccordionItemPanel>
                            <div className="container bs-cibil-details-box">
                              <div className="row bs-cs-acl-box bs-cibil-row">
                                <div className="col-7 col-sm-8 col-md-10">
                                  <div>
                                    <h4>Payment History</h4>
                                  </div>
                                </div>
                                <div className="col-5 col-sm-2 col-md-2">
                                  <div className="btn-overdue">
                                    {overdue} Overdue
                                  </div>
                                </div>
                              </div>{" "}
                              <div className="row bs-cs-acl-box bs-cibil-row">
                                <div className="col-12 col-sm-12 col-md-12">
                                  <table className="bs-cibil-table">
                                    <tr>
                                      <th>&nbsp;</th>
                                      {existMonth.map((e1, i) => (
                                        <th>{e1.label}</th>
                                      ))}
                                    </tr>

                                    {m.size > 0 &&
                                      Object.entries(m).map(
                                        ([key, value]) => (
                                          (
                                            <>
                                              <tr>
                                                <td>{key} </td>
                                                {Object.entries(value)
                                                  .sort()
                                                  .map(([key, value]) => (
                                                    <td key={key}>
                                                      {value === 1 ? (
                                                        <TickIcon />
                                                      ) : value === -1 ? (
                                                        <DeleaydIcon />
                                                      ) : (
                                                        <DotsIcon />
                                                      )}
                                                    </td>
                                                  ))}
                                              </tr>
                                            </>
                                          )
                                        )
                                      )}
                                  </table>
                                  <hr />
                                  <div className="bs-cibil-status">
                                    <div className="bs-cibil-status-box">
                                      <TickIcon /> On Time Payment
                                    </div>
                                    <div className="bs-cibil-status-box">
                                      <DeleaydIcon /> Delayed
                                    </div>
                                    <div className="bs-cibil-status-box">
                                      <OverdueIcon />
                                      Overdue
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </AccordionItemPanel>
                        </AccordionItem>
                      ))}
                  </Accordion>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  <div className="bs-cs-al-cf-header">
                    <h2>Credit Factors</h2>
                    See the factors affecting your score
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-6">
                  <div className="row g-0 bs-cs-acl-box cf">
                    <div className="col-8 col-sm-8 col-sm-8">
                      <div className="bs-cs-acl-card">
                        <OnTimePaymentIcon />

                        <div>
                          <h4>Payments on time</h4>
                          <span>High Impact</span>
                        </div>
                      </div>
                    </div>

                    {paymentParcent ? (
                      <div className="col-4 col-sm-4 col-sm-4">
                        <h4>{paymentParcent}%</h4>
                        {paymentParcent > 90 && (
                          <p className="text-success">Very Good</p>
                        )}
                        {paymentParcent > 70 && paymentParcent < 90 && (
                          <p className="text-success">Good</p>
                        )}
                        {paymentParcent < 70 && (
                          <p className="text-danger">Very poor</p>
                        )}
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                </div>

                <div className="col-sm-6">
                  <div className="row g-0 bs-cs-acl-box cf">
                    <div className="col-8 col-sm-8 col-sm-8">
                      <div className="bs-cs-acl-card">
                        <CreditAgeIcon />

                        <div>
                          <h4>Credit History</h4>
                          <span>Medium Impact</span>
                        </div>
                      </div>
                    </div>

                    <div className="col-4 col-sm-4 col-sm-4">
                      <h4> {getWords(creditAgeDiff)}</h4>
                      <p className="text-secondary">Age of account</p>
                    </div>
                  </div>
                </div>

                <div className="col-sm-6">
                  <div className="row g-0 bs-cs-acl-box cf">
                    <div className="col-8 col-sm-8 col-sm-8">
                      <div className="bs-cs-acl-card">
                        <NewCreditAccountIcon />

                        <div>
                          <h4>Credit Card Utilization</h4>
                          <span>High Impact</span>
                        </div>
                      </div>
                    </div>

                    {creditUtilization ? (
                      <div className="col-4 col-sm-4 col-sm-4">
                        <h4>{creditUtilization}%</h4>
                        <p className="text-success">Good</p>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                </div>

                <div className="col-sm-6">
                  <div className="row g-0 bs-cs-acl-box cf">
                    <div className="col-8 col-sm-8 col-sm-8">
                      <div className="bs-cs-acl-card">
                        <CreditMixIcon />

                        <div>
                          <h4>Credit Enquiry</h4>
                          <span>Low Impact</span>
                        </div>
                      </div>
                    </div>

                    <div className="col-4 col-sm-4 col-sm-4">
                      <h4>
                        {
                          creditEnquiries?.CAPS_Summary?.[0]
                            ?.CAPSLast30Days?.[0]
                        }
                      </h4>
                      <p className="text-secondary">In Last 30 days</p>
                    </div>
                  </div>
                </div>

                <div className="col-sm-6">
                  <div className="row g-0 bs-cs-acl-box cf">
                    <div className="col-8 col-sm-8 col-sm-8">
                      <div className="bs-cs-acl-card">
                        <TotalAccountIcon />

                        <div>
                          <h4>Total Account</h4>
                          <span>Low Impact</span>
                        </div>
                      </div>
                    </div>

                    <div className="col-4 col-sm-4 col-sm-4">
                      <h4>
                        {totalAccountSummary?.[0]?.CreditAccountActive?.[0]}
                      </h4>
                      <p className="text-success">Active Account</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <CreditFooter />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  experian: getExperian(state).accountData,
  userData: getExperian(state).userData,
  loadingCheck: getExperian(state).loadingCheck,
});
const mapDispatchToProps = (dispatch) => ({
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreditCheck)
);
