import React, { Component } from "react";
import {Modal, Row, Col } from "react-bootstrap";
import {
  getExperian,
  loadExperianOtp,
  loadExperianCheck,
} from "../../store/experian";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { ReactComponent as Close } from "../../include/assets/close.svg";
import PATH from "../../paths/Paths";

class CreditOTPModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showOTP: false,
      otp: "",
      OTPError: "",
      stgOneHitId: "",
      stgTwoHitId: "",
      resend: false,
    };
  }

  OTPButton = (e) => {
    e.preventDefault();
    let formData = {
      mobile: this.props.mobile,
      stgOneHitId: this.state.stgOneHitId
        ? this.state.stgOneHitId
        : this.props.stgOneHitId,
      stgTwoHitId: this.state.stgTwoHitId
        ? this.state.stgTwoHitId
        : this.props.stgTwoHitId,
      otp: this.state.otp,
    };
    this.props.loadExperianOtp(formData, this.callBackOtp);
  };
  callBackOtp = (res) => {
    if (res) {
      if (res.data.status === 203) {
        this.props.history.push({
          pathname: PATH.PUBLIC.CHECK_CREDIT_REPORT,
          state: this.props.mobile,
        });
        this.setState({
          OTPError: "",
        });
      } else if (res.data.success) {
        if (res.data.experianData.responseData.errorString) {
          if (
            res.data.experianData.responseData.errorString ===
            "OTP validation failed, OTP is not match"
          ) {
            this.setState({
              resend: true,
              otp: "",
              OTPError: res.data.experianData.responseData.errorString,
            });
            let formData = {
              mobile: this.props.mobile,
              pincode: this.props.data.pincode,
              name: this.props.data.fullName,
              pan: this.props.data.pan,
              dob: reverseDateString(this.props.data.dob),
              email: this.props.data.email,
              isExperian: true,
            };
            this.props.loadExperianCheck(formData, this.callBackVerify);
          } else {
            this.setState({
              OTPError: res.data.experianData.responseData.errorString,
            });
          }
        } else {
          this.props.handleCloseOTP();
          this.props.history.push({
            pathname: PATH.PUBLIC.CHECK_CREDIT_REPORT,
            state: this.props.mobile,
          });
          this.setState({
            OTPError: "",
          });
        }
      }
    }
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data.success) {
        this.setState({
          stgOneHitId: res.data.data.stgOneHitId,
          stgTwoHitId: res.data.data.stgTwoHitId,
          OTPError: "",
          resend: false,
        });
      }
    }
  };

  render() {
    return (
      <Modal className="bsOtpbox" show={this.props.show}>
        <Modal.Body style={{ textAlign: "center" }}>
          <p
            className="modalClose"
            onClick={() => {
              this.props.handleCloseOTP();
              this.setState({ otp: "", OTPError: "" });
            }}
          >
            <Close />
          </p>
          <form onSubmit={this.OTPButton}>
            <Row>
              <Col>
                <div className="logo-exp">
                  <img alt="experian logo" src="/experian.png"></img>
                </div>
                <h2>Enter OTP</h2>
                <p>
                  To check your Credit Score, Enter <br />
                  verification code sent to
                </p>
                <h4>+91 {this.props.data.mobile}</h4>
              </Col>
            </Row>
            <br />
            <input
              placeholder="******"
              value={this.state.otp}
              onChange={(e) => this.setState({ otp: e.target.value })}
              autoFocus
              id="otpField"
              className="OtpField"
              name="otpField"
              maxLength="6"
            />
            {this.state.OTPError && (
              <span className="error-form">{this.state.OTPError}</span>
            )}
            <div className="otpBottomContainer">
              <div
                style={{
                  marginTop: "20px",
                  color: "#7C7C7C",
                  fontSize: "15px",
                  marginRight: "40px",
                }}
              ></div>
            </div>

            <Row>
              <button type="submit" className="OtpSubmitBtn">
                {this.state.resend ? "Resend" : "Submit"}
              </button>
            </Row>
          </form>
        </Modal.Body>
      </Modal>
    );
  }
}
function reverseDateString(str) {
  var splitString = str.split("-");
  var reverseArray = splitString.reverse();
  var joinArray = reverseArray.join("-");
  joinArray = joinArray + "T00:00:00.000Z";
  return joinArray;
}
const mapStateToProps = (state) => ({
  experian: getExperian(state),
  // experian: getExperian(state),
});
const mapDispatchToProps = (dispatch) => ({
  loadExperianOtp: (params, callback) =>
    dispatch(loadExperianOtp(params, callback)),

  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreditOTPModal)
);
