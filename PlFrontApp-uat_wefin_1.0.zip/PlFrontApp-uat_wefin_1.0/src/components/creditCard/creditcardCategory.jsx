import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { Container, Row, Col, Card } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
import BottomSection from "../../common/bottom"
import { getCreditCard, loadCreditCardList, setFilters } from "../../store/creditCard";
import BackDropComponent from "../../common/BackDropComponent";
import CreditTopNavBar from "../../common/creditTopNav";
import PATH from "../../paths/Paths";
import TopNavBar from "../../common/TopNavBar";
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import Button from 'react-bootstrap/Button';
import CcToolTip from "./toolTip";
import CcLogin from "./ccLogin";
class CreditCardCategory extends Component {
    state = {
        checkValue: []
    }

    static getDerivedStateFromProps(props, state) {
        //    console.log("props are", props)
        return {
            bankNameDetails: props.ccData.bankNameDetails,
            cardDetails: props.ccData.cardDetails,
            categoryDetails: props.ccData.categoryDetails
        }
    }

    componentDidMount = () => {
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        this.props.loadCreditCardList();
        localStorage.setItem("cardsCompare", JSON.stringify({ details: [] }))

        const urlSearchParams = new URLSearchParams(window.location.search);
        const params = Object.fromEntries(urlSearchParams.entries());
        /////////////UTM CODE////////////
        let isUTM = params.hasOwnProperty("utm_source");
        /////////////////////////////////////////////////////////////
        if (isUTM) {
            localStorage.setItem("creditUTMLink", window.location.search)
        }
        console.log(this.state);
    }



    handleClick = (e) => {
        this.props.setFilters({ checkValue: this.state.checkValue, checkBankValue: [] })
        this.props.history.push({
            pathname: "/get-credit-card/card-list",
            state: {
                ...this.state,
                isASM: this.props.location?.state?.isASM,
                isFOS: this.props.location?.state?.isFOS,
                mobile_no: this.props.location?.state?.mobile_no,
                id: this.props.location?.state?.id
            },
        });
    }

    handleCheckbox = (e) => {
        let r = e;
        if (r.target.checked) {
            this.setState({ ...this.state, checkValue: [...this.state.checkValue, r.target.id] })
        } else {
            this.setState({ ...this.state, checkValue: this.state.checkValue.filter(element => element !== r.target.id) })
        }
        //    console.log(this.state)
    };

    isFilterApplied = () => {
        //  console.log("checkedValues", this.state.checkValue.length)
        if (this.state.checkValue.length > 0) {
            return false
        } else {
            return true
        }
    }

    render() {


        return (
            <>
                <section className="bs-main-section ccCatMainSection">
                    {this.state.ccLogin ? <CcLogin show={this.state.ccLogin} appliedCard={JSON.parse(localStorage.getItem("appliedCard"))} handleCloseLogin={() => this.setState({ ...this.state, ccLogin: false })} /> : null}
                    {localStorage.getItem('mobilenumber') && localStorage.getItem('firstName') ? <TopNavBar /> : <CreditTopNavBar handleLogin={() => this.setState({ ...this.state, ccLogin: true })} />}
                    <Container>
                        <h1 className="text-center">Find the right credit card for you</h1>
                        {this.props.loading ? <BackDropComponent /> : <>
                            <Row> {this.state.categoryDetails && this.state.categoryDetails.map((category) => (

                                <Col xs={6} sm={4} md={2} xl={2} className="text-center">
                                    <div className="csMainCatBox">
                                        {category.value === 'best_sellers__c' ? <input type="checkbox" id={category.value}
                                            name={category.value}
                                            // defaultChecked
                                            onChange={this.handleCheckbox} /> : <input type="checkbox" id={category.value}
                                                name={category.value}
                                                onChange={this.handleCheckbox} />}
                                        <label for={category.value}>
                                            <img src={category.image} width="" height="" />
                                            <span className="checkTitle">{category.name} <CcToolTip desc={category.description} /></span>
                                            <span className="checkBox">&nbsp;</span>

                                        </label>
                                    </div>
                                </Col>

                            ))}
                            </Row>
                            <Row>
                                <Col className="text-center">
                                    <button className="nextButton" onClick={this.handleClick}>Get Cards</button>
                                </Col>
                            </Row></>}
                    </Container>
                </section>
                <section className="cs-login-content">
                    <Container>
                        <Row>
                            <Col xs={12}>
                                <h2> Latest Offers on Credit Cards </h2>
                                <p>Contactless application process and instant approval from India’s leading trusted Banks. Apply for a credit card and get maximum rewards and lifestyle benefits.</p>
                            </Col>
                            <Col xs={12}>
                                <h3>Your advantage with WeFin </h3>
                                <ul style={{ marginBottom: "25px" }}>
                                    <li>Hassle-free process</li>
                                    <li>Compare with other Credit Cards</li>
                                    <li>Paperless Process and Digital processes</li>
                                </ul>

                                <h5>Credit Card Eligibility</h5>
                                <table>
                                    <tr>
                                        <th>Criteria</th>
                                        <th>Requirement</th>
                                    </tr>
                                    <tr>
                                        <td>Nationality</td>
                                        <td>Indian</td>
                                    </tr>
                                    <tr>
                                        <td>Age</td>
                                        <td>18 years</td>
                                    </tr>
                                    <tr>
                                        <td>Employment </td>
                                        <td>Salaried or Self-employed</td>
                                    </tr>
                                    <tr>
                                        <td>Income</td>
                                        <td>Depends on one bank to the other</td>
                                    </tr>
                                    <tr>
                                        <td>Credit Score</td>
                                        <td>Good credit score (700 and above)</td>
                                    </tr>
                                </table>
                            </Col>
                        </Row>
                    </Container>
                </section>
                {localStorage.getItem('mobilenumber') ? null :
                    <div className="marginTop">
                        <BottomSection />
                    </div>
                }
                <CreditFooter />
            </>
        )
    }
}
const mapStateToProps = (state) => ({
    ccData: getCreditCard(state).ccData,
    loading: getCreditCard(state).loading,

});

const mapDispatchToProps = (dispatch) => ({
    loadCreditCardList: () => dispatch(loadCreditCardList()),
    setFilters: (payload) => dispatch(setFilters(payload))
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CreditCardCategory));