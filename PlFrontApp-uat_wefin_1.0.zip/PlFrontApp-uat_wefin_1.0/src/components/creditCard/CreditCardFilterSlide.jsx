import React, { Component } from "react";
import { useEffect } from "react";
import { Card, Container, Row, Button, Col, Form } from "react-bootstrap";
import closeIcon from "./../../include/assets/icons/closeIcon.svg";
class CreditCardFilterSlide extends Component {
    constructor(props) {
        super(props)
        this.state = {
            checkValue: [],
            checkBankValue: [],
            update: false
        }
    }

    componentDidMount = () => {
        debugger
        console.log(this.props.state.bankNameDetails);
        debugger
        this.setState({ ...this.state, checkValue: this.props.state.filters.category, checkBankValue: this.props.state.filters.bank })
    }

    componentDidUpdate(prevState) {
        if (this.state.update) {
            this.props.setFilter(this.state, false)
            this.setState({ ...this.state, update: false })
        }
    }

    handleCategory = (e) => {
        let r = e;
        if (r.target.checked) {
            debugger
            this.setState({ ...this.state, update: true, checkValue: [...this.state.checkValue, r.target.id] })
        } else {
            this.setState({ ...this.state, update: true, checkValue: this.state.checkValue.filter(element => element !== r.target.id) })
        }
    }

    handleBank = (e) => {
        let r = e;
        if (r.target.checked) {
            debugger
            this.setState({ ...this.state, update: true, checkBankValue: [...this.state.checkBankValue, r.target.id] })
        } else {
            this.setState({ ...this.state, update: true, checkBankValue: this.state.checkBankValue.filter(element => element !== r.target.id) })
        }
    }

    filterApply = () => {
        this.props.setFilter(this.state, true)
    }

    render() {
        return (
            <div className="ccFilterSlideSection">
                <div className="ccFilterSlide">
                    <Card>
                        <Card.Header>
                            <Button onClick={this.props.setState}><img src={closeIcon} alt="closeIcon" /></Button>
                            <Button className="text-right" onClick={this.filterApply}>Apply Filter</Button>
                        </Card.Header>
                        <Card.Body>
                            <Container>
                                <h4 className="text-center">Find the right credit card for you</h4>
                                <Row>
                                    {this.props.state.categoryDetails.map((category) => (
                                        <Col xs={6} sm={4} md={4} xl={4} className="text-center">
                                            <div className="csMainCatBox">
                                                <input type="checkbox" id={category.value}
                                                    name={category.name}
                                                    checked={this.state.checkValue.indexOf(category.value) >= 0 ? true : false}
                                                    onClick={this.handleCategory}
                                                />
                                                <label for={category.value}>
                                                    <img src={category.image} width="" height="" alt="" />
                                                    <span className="checkTitle">{category.name}</span>
                                                </label>
                                            </div>
                                        </Col>
                                    ))}
                                </Row>
                            </Container>
                        </Card.Body>
                        <Card.Footer>
                            <h4 className="text-center">Filter by Bank</h4>
                            <Form className="csFilterCheck">
                                <div key={`inline-checkbox`} className="mb-3">
                                    {this.props.state.bankNameDetails.map((bank, index) => (
                                        <Form.Check
                                            inline
                                            label={bank.name}
                                            name="group1"
                                            type='checkbox'
                                            id={bank.value}
                                            onClick={this.handleBank}
                                            checked={this.state.checkBankValue.indexOf(bank.value) >= 0 ? true : false}
                                        />
                                    ))}
                                </div>

                                {/*     {['checkbox'].map((type) => (
                                       <div key={`inline-${type}`} className="mb-3">
                                         <Form.Check
                                            inline
                                            label="IDFC Bank"
                                            name="group1"
                                            type={type}
                                            id={`inline-${type}-1`}
                                        />
                                        <Form.Check
                                            inline
                                            label="HDFC Bank"
                                            name="group1"
                                            type={type}
                                            id={`inline-${type}-2`}
                                        />
                                        <Form.Check
                                            inline
                                            label="Kotak Mahindra Bank"
                                            name="group1"
                                            type={type}
                                            id={`inline-${type}-3`}
                                        />
                                        <Form.Check
                                            inline
                                            label="Yes Bank"
                                            name="group1"
                                            type={type}
                                            id={`inline-${type}-4`}
                                        />
                                        </div>))}

                                  
                                 */}
                            </Form>
                        </Card.Footer>
                    </Card>
                </div>
            </div>
        )
    }
}
export default CreditCardFilterSlide;