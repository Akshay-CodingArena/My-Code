import React, { Component } from "react";
import OwlCarousel from "react-owl-carousel";
import Card from "react-bootstrap/Card";
import dummyCard from "../../include/assets/banner/dummy-card.svg";

class CreditCardList extends Component {
  render() {
    const options = {
      loop: false,
      margin: 15,
      nav: true,
      responsive: {
        0: {
          items: 1,

          dots: true,
        },

        600: {
          items: 2,

          dots: true,
        },

        800: {
          items: 3,
          dots: true,
        },

        1000: {
          items: 3,
          nav: true,
          dots: true,
          loop: false,
        },
      },
    };
    return (
      <div>
        <OwlCarousel {...options} className="owl-theme" loop>
          {this.props.ccData.map((e, i) => (
            <Card className="creditCardMain">
              <Card.Text className="creditCardInner">
                <figure>
                  <img  width="" height=""  src={e.card_image__c?e.card_image__c:dummyCard} alt="" />
                </figure>
                <h3 className="creditCardHead">{e.card_name__c}</h3>

                <div className="creditCardBenifts">
                  <h4 className="creditCardBeniftsTitle">Key Card Benefits</h4>
                  <ul className="creditCardBeniftsList">
                    {e.cardBenefits &&
                      e.cardBenefits.map((e, i) => (
                        <>{i < 2 && <li>{e}</li>}</>
                      ))}
                  </ul>
                </div>

                <div className="creditCardJoining">
                  <h4 className="creditCardJoiningTitle">
                    Joining and Annual Fee
                  </h4>
                  <ul className="creditCardJoiningList">
                    {e.joinFee &&
                      e.joinFee.map((e, i) => <>{i < 1 && <li>{e}</li>}</>)}
                  </ul>
                </div>
                <div className="creditCardBtns">
                  <button
                    className="creditCardBtnsApply"
                    onClick={() => this.props.handleApply(e)}
                  >
                    APPLY NOW
                  </button>
                  <button
                    className="creditCardBtnsknowMore"
                    onClick={() => this.props.handleKnow(e)}
                  >
                    KNOW MORE
                  </button>
                </div>
              </Card.Text>
            </Card>
          ))}
        </OwlCarousel>
      </div>
    );
  }
}
export default CreditCardList;
