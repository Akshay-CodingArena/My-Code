import { callStack } from "joi-browser";
import React, { Component } from "react";
import Swal from "sweetalert2";
import { useEffect } from "react";
import TopNavBar from "../../common/TopNavBar";
import Collapse from 'react-bootstrap/Collapse';
import { Form, Container, Row, Col, Button, Figure, Tab, Tabs, Nav, Navbar, NavDropdown } from "react-bootstrap";
// import Offcanvas from 'react-bootstrap/Offcanvas';
import CreditFooter from "../cibilFlow/footer";
// import SpeedometerIcon from "../../include/assets/creditCardIcons/speedometer2.0.png";
import StandardChartered from "../../include/assets/creditCardIcons/StandardChartered.png"
// import AxisLogo from "../../include/assets/creditCardIcons/Axis.png";
import FilterIcon from "../../include/assets/creditCardIcons/filterIcon.svg"
import plusIcon from "../../include/assets/creditCardIcons/plusIcon.svg"
import minusIcon from "../../include/assets/creditCardIcons/minusIcon.svg"
import easyEmiIcon from "../../include/assets/creditCardIcons/easyEmi.svg"
import freeIcon from "../../include/assets/creditCardIcons/freeIcon.svg"
import infoIcon from "../../include/assets/creditCardIcons/infoIcon.svg"
import moviesIcon from "../../include/assets/creditCardIcons/moviesIcon.svg"
import rewardIcon from "../../include/assets/creditCardIcons/rewardIcon.svg"
import CreditTopNavBar from "../../common/creditTopNav";
import { numberFormat } from "../../Utils/numberFormat";
import tickIcon from "../../include/assets/creditCardIcons/tickIcon.svg"
import PATH from "../../paths/Paths";
import { getCreditCard, setFilters, } from "../../store/creditCard";
import { Redirect, withRouter } from "react-router";
import { connect, useDispatch, useSelector } from "react-redux";
import CreditCardFilterSlide from "./CreditCardFilterSlide";
import creditDefault from '../../include/assets/creditCardIcons/defaultCredit.png'
import { loadccApplyLoan } from "../../store/applyLoan";
import CONSTANTS from "../../constants/Constants"
import { getAccount, getAccountInfo } from "../../store/account";
import { encryptStore } from "../../Utils/store";
import BackDropComponent from "../../common/BackDropComponent";
import CcToolTip from "./toolTip";
import CcLogin from "./ccLogin";
import cardRedirection from "./cardRedirection";
import { applyLoanCCFOS } from "../../store/asm";

class ApplyCard extends Component {
    constructor(props) {
        super(props)
    }
    //  useDispatch()
    render() {
        let checkCard = (card) => {
            let ccLoans = this.props.getAccountDetail[0]?.cc_loans
            let flag = 0

            if (ccLoans) {
                for (let loan of ccLoans) {
                    if (loan["card_sfid"] === card["sfid"]) {
                        flag = 1
                    }
                }
            }

            if (flag === 0 && this.props.getCustomerDetail.pan_verified__c) {
                if (card.utm_links__c) {
                    let win = window.open(card.utm_links__c)
                    win.focus()
                }
            }
            else if (flag === 1) {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "Card already applied",
                    showConfirmButton: true,
                    timer: 1800,
                })
            }
            return flag

        }
        let callBackLoans = () => {
            let ccLoans = this.props.getAccountDetail[0]?.cc_loans
            this.props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: ccLoans })
        }

        let callbackLoan = (res) => {
            if (res) {
                if (res.data.loan_exists !== true) {
                    localStorage.setItem('loansfid', res.data.data.loansfid)
                    localStorage.setItem('CCLA', res.data.data.loanName)
                    let storeData = {
                        loansfid: res.data.data.loansfid,
                        loanName: res.data.data.loanName,
                        loanType: CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN,
                    };
                    encryptStore(localStorage.getItem("mobilenumber"), storeData);
                    cardRedirection(this.props, this.props.card, this.props.getAccountInfo, false, this.props.isASM)

                    //   else {
                    // try {
                    //     let win = window.open(appliedCard.utm_links__c)
                    //     this.props.history.push(PATH.PRIVATE.PRODUCTS)
                    //     win.focus()
                    // }
                    // catch {
                    //     Swal.fire({
                    //         position: "center",
                    //         icon: "error",
                    //         title: "You will be redirected to a 3rd party.",
                    //         showConfirmButton: true,
                    //         timer: 1800,
                    //     }).then(() => {
                    //         let win = window.open(appliedCard.utm_links__c)
                    //         this.props.history.push(PATH.PRIVATE.PRODUCTS)
                    //         win.focus()
                    //     });
                    // }
                    //    }
                    //    this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
                } else {
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: "Card already applied",
                        showConfirmButton: true,
                        timer: 1800,
                    })
                    // this.props.history.push({
                    //     pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
                    //     state: this.props.getAccountDetail[0]?.cc_loans
                    // })
                }
            }
        }


        const callbackApplyLoanFOS = (res) => {
            debugger
            if (res) {
                if (res.data.success) {
                    window.open(res.data.data.utm_links, "_blank");
                    this.props.history.push(PATH.PRIVATE.FOS_DASHBOARD);
                } else {
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: res.data.message,
                        showConfirmButton: true,
                        timer: 1800,
                    })
                }
            }
        }

        let handleApply = (appliedCard) => {
            debugger

            let urlEncodedData = this.props.urlEncodedData;

            if (urlEncodedData.isFOS) {
                formData = {
                    cardsfid: appliedCard.sfid,
                    lenderid: appliedCard.lender_sfid__c,
                    id: urlEncodedData.id,
                    mobile_no: urlEncodedData.mobile_no
                }
                this.props.applyLoanCCFOS(formData, callbackApplyLoanFOS)
            }
            else if (localStorage.getItem('mobilenumber') && localStorage.getItem('firstName')) {
                const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
                const mobile = localStorage.getItem("mobilenumber");
                var formData;
                localStorage.setItem("lenderId", appliedCard.lender_sfid__c)
                formData = {
                    mobile: mobile,
                    loanType: loanType,
                    cardSfid: appliedCard.sfid,
                    lenderId: appliedCard.lender_sfid__c
                };
                if (this.props.getCustomerDetail?.pan_verified__c) {
                    if (!checkCard(appliedCard)) {
                        this.setState({ card: appliedCard })
                        this.props.loadccApplyLoan(formData, callbackLoan)
                    } else {
                        Swal.fire({
                            position: "center",
                            icon: "error",
                            title: "Card already applied",
                            showConfirmButton: true,
                            timer: 1800,
                        })
                    }
                }
                else {
                    let storeData = { loanType: loanType }
                    encryptStore(mobile, storeData)
                    this.props.history.push({ pathname: PATH.PRIVATE.PAN_VERIFY, appliedCard: appliedCard, ccformData: formData })
                }
            }
            else {
                localStorage.setItem("appliedCard", JSON.stringify(this.props.card))
                this.props.handleLogin()
            }
        }

        return (
            <Button className={`applyBtn ccApplyBtn ${this.props?.bottomBtn ? "ccBottomBtn" : null}`} onClick={() => handleApply(this.props.card)}>Apply Now</Button >
        )
    }
}




const mapStateToProps = (state) => ({
    isLoading: getAccount(state).loading,
    getFilters: getCreditCard(state).filters,
    getAccountDetail: getAccount(state).getAccountDetail,
    getCustomerDetail: getAccount(state).customerDetail
})
const mapDispatchToProps = (dispatch) => ({
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    loadccApplyLoan: (params, callback) =>
        dispatch(loadccApplyLoan(params, callback)),
    setFilters: (payload) => dispatch(setFilters(payload)),
    applyLoanCCFOS: (params, callback) =>
        dispatch(applyLoanCCFOS(params, callback))
})

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ApplyCard))