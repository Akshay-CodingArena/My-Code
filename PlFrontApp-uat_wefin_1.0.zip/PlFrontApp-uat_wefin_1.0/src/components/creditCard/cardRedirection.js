import Swal from "sweetalert2"
import PATH from "../../paths/Paths"
import { createStore } from 'redux';
import { store } from "react-redux";
import configureStore from "../../store/configureStore";


let cardRedirection = (props, card, getAccountInfo, utmRedirect, isASM) => {
    //   console.log("redirection", card, getAccountInfo, utmRedirect, props.getAccountDetail[0])
    let callBackLoans = (res) => {
        if (isASM) {
            props.history.push({ pathname: PATH.PRIVATE.ASM_DASHBOARD })
        } else {
            console.log("loan data is", res.data.details.loanData[0]?.cc_loans)
            props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: res.data.details.loanData[0]?.cc_loans })
        }
    }

    if (card.utm_links__c === null || card.lender_name__c === "SCB") {
        props.history.replace({ pathname: '/bank-specific-details/Credit_Card/SCB', state: card })
    }
    else {
        if (utmRedirect) {
            let bankCode = card.lender_name__c
            let bankName = () => {
                switch (bankCode) {
                    case "AXB": return "Axis Bank";
                    case "SCB": return "Standard Charterd Bank"
                    case "YB": return "YES Bank"
                    case "IDFC": return "IDFC Bank"
                }
            }


            try {
                let win = window.open(card.utm_links__c)
                //       this.props.history.push(PATH.PRIVATE.PRODUCTS)
                win.focus()
            }

            catch {
                Swal.fire({
                    position: "center",
                    title: `You will be redirected to ${bankName()} website.`,
                    showConfirmButton: true,
                    confirmButtonText: "Continue",
                    confirmButtonColor: '#5200bb !important',
                    className: "swalContinue"
                }).then(() => {
                    let win = window.open(card.utm_links__c)
                    // if (props.getAccountDetail) {
                    //     let ccLoans = props.getAccountDetail[0]?.cc_loans
                    //     props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: ccLoans })
                    // }
                    win.focus()
                });
            }
        }

        getAccountInfo({ mobile: localStorage.getItem('mobilenumber') }, callBackLoans)
    }

}

export default cardRedirection