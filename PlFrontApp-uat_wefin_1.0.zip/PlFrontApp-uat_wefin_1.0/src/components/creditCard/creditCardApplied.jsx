import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import TopNavBar from "../../common/TopNavBar";
import CreditFooter from "../../components/cibilFlow/footer";
import DashBoardAside from "../../common/dashboardAside";
import PATH from "../../paths/Paths";
import NavLink from "react-bootstrap";
import CreditCardImage from "../../include/assets/creditCardIcons/scb_card.png";
import AxisCardImage from "../../include/assets/creditCardIcons/axis_card.png";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import Swal from "sweetalert2";
import newLoanArrow from "../../include/assets/newLoanArrow.svg";
import { loadccApplyLoan } from "../../store/applyLoan";
import { encryptStore } from "../../Utils/store";
import CONSTANTS from "../../constants/Constants";
import { getAccount } from "../../store/account";

class CreditCardApplied extends Component {
    constructor(props) {
        super(props)
    }

    componentDidMount = () => {
        //    console.log(this.props.location.state);
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
    }

    handleContinue = (card) => {
        if (card.lenderName === "SCB" || card.lenderName === "Standard Chartered" || !card.utm_links__c) {
            //      console.log("scb calling")
            const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
            const mobile = localStorage.getItem("mobilenumber");
            let storeData = { loanType: loanType }
            encryptStore(mobile, storeData)
            localStorage.setItem('CCLA', card.loanName)
            localStorage.setItem('loansfid', card.loanId)
            this.props.history.replace({ pathname: '/bank-specific-details/Credit_Card/SCB', state: card, loan: card })
        }
        else {
            //    console.log("Opening the products")
            let win = window.open(card.utm_links__c)
            win.focus()
        }
    }

    handleApply = () => {
        this.props.history.push({ pathname: PATH.PUBLIC.GET_CREDIT_CARD })
    }

    clearCacheData = () => {
        caches.keys().then((names) => {
            names.forEach((name) => {
                caches.delete(name);
            });
        });
    };
    render() {
        const cards = this.props.location?.state ?? this.props.getAccountDetail[0]?.cc_loans
        this.clearCacheData()
        if (this.props.location?.showPopUp) {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Card already applied",
                showConfirmButton: true,
                timer: 1800,
            })
        }
        //    console.log("getting data", this.props.location)
        if (this.props.location.state.length === 0) {
            this.props.history.push({ pathname: PATH.PUBLIC.GET_CREDIT_CARD })
        }
        return <React.Fragment>
            {" "}
            <section className="bs-main-section">
                <TopNavBar />

                <div className="credit-card-appliedinfo-section">
                    <Container>
                        <Row>
                            <Col sm={12} md={3}>
                                <DashBoardAside />
                            </Col>
                            <Col sm={12} md={9}>
                                <h1 className="heading">Credit Cards</h1>
                                {this.props.location.state.map((card, index) => (
                                    <div key={(new Date()).getTime()} className="row cards">
                                        <div className="col-sm-3 col-xs-12 mb-2">
                                            <img key={(new Date()).getTime()} src={card.card_image__c + '?time' + (new Date()).getTime()} />
                                        </div>
                                        <div className="col-sm-9 col-xs-12">
                                            <div className="row card-info">
                                                <div className="col-6 col-sm-6 col-md-6">
                                                    <p>{card.card_name__c}</p>
                                                </div>
                                                {/*<div className="col-6 col-sm-6 col-md-6">
                                                    <p className="sub-title">Card Limit</p>
                                                    <p className="sub-heading">₹1,00,000</p> 
                                                </div>*/}
                                                <div className="col-6 col-sm-6 col-md-6 text-right">
                                                    <p className="sub-heading">Card Status: <span style={{ color: card.loanStage === 'Assigned' ? "#047C4C" : "red" }}>{card.loanStage === 'Assigned' ? 'Application Initiated' : 'Declined'}</span></p>
                                                </div>
                                                <div className="col-12 col-sm-12 col-md-12 seperator">
                                                    <hr />
                                                </div>

                                                <div className="col-6 col-sm-6 col-md-6">
                                                    <p className="sub-heading">Application No.</p>
                                                    <p className="sub-heading">{card.loanName}</p>
                                                </div>
                                                {/* <div className="col-4 col-sm-4 col-md-4">
                                                    <p className="sub-title"> <p className="sub-title">Annual Charges</p>
                                                        <p className="sub-heading">₹ 5000 + GST</p></p>
                                                </div> 
                                                <div className="col-4 col-sm-4 col-md-4">
                                                    <p className="sub-heading">Bank Status: <span style={{ color: "#047C4C" }}>{card.loanStage}</span></p> 
                                                </div>*/}
                                                <div className="col-md-6 col-6 col-sm-6 text-right">
                                                    <p className="bsContinue csContinue">
                                                        <button
                                                            variant="contained"
                                                            className="nextButton"
                                                            disabled={!(card.loanStage === "Assigned")}
                                                            onClick={() => this.handleContinue(card)}
                                                            style={{ cursor: !(card.loanStage === "Assigned") ? "not-allowed" : "pointer" }}
                                                        >
                                                            Continue
                                                            <img alt="" src={newLoanArrow} />
                                                        </button>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                <div className="row d-flex justify-content-center m-t-40">
                                    <div className="col-xs-12 col-sm-4">
                                        <button className="applyBtn" onClick={this.handleApply}>Apply New Card</button>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </section>
            <CreditFooter />
        </React.Fragment>
    }

}

const mapStateToProps = (state) => ({
    getAccountDetail: getAccount(state).getAccountDetail
})

const mapDispatchToProps = (dispatch) => ({
    loadccApplyLoan: (params, callback) =>
        dispatch(loadccApplyLoan(params, callback))
})

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(CreditCardApplied)
);
