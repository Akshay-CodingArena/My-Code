import { callStack } from "joi-browser";
import React from "react"
import { useEffect } from "react";
import TopNavBar from "../../common/TopNavBar";
import CreditFooter from "../../components/cibilFlow/footer";
import SpeedometerIcon from "../../include/assets/creditCardIcons/speedometer2.0.png";
import StandardCharteredLogo from "../../include/assets/creditCardIcons/StandardChartered.png"
import AxisLogo from "../../include/assets/creditCardIcons/Axis.png";
import CrossLogo from "../../include/assets/creditCardIcons/cross_compressed.png"
import CreditTopNavBar from "../../common/creditTopNav";
import ReactSelect from "react-select";
import { ReactComponent as SearchIcon } from "../../include/assets/twoWheelerLogo/search.svg";
import { components } from "react-select";
import { selectStyles } from "../common/textStyle";
import { connect } from "react-redux";
import { Redirect, withRouter } from "react-router";
import PATH from "../../paths/Paths";
import creditDefault from '../../include/assets/creditCardIcons/defaultCredit.png'
import { loadccApplyLoan } from "../../store/applyLoan";
import CONSTANTS from "../../constants/Constants"
import { getAccount, getAccountInfo } from "../../store/account";
import { encryptStore } from "../../Utils/store";
import Swal from "sweetalert2";
import BackDropComponent from "../../common/BackDropComponent";
import CcLogin from "./ccLogin";
import ApplyCard from "./applyCard";
import { applyLoanCCFOS, getASM } from "../../store/asm";

const CaretDownIcon = () => {
    return <SearchIcon />;
};


const DropdownIndicator = (props) => {
    return (
        <components.DropdownIndicator {...props}>
            <CaretDownIcon />
        </components.DropdownIndicator>
    );
};
class CreditCardInfo extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            cardsCompare: {},
            appliedCard: {},
            rendered: false,
            ccLogin: false
        }
    }

    static getDerivedStateFromProps(props, state) {
        if (!state.rendered) {
            return {
                cardsCompare: JSON.parse(localStorage.getItem("cardsCompare")),
                cardDetails: props.location.state?.cardDetails,
            }
        } else {
            return {
            }
        }
    }

    callBackInfo = (res) => {
        console.log("getAccountDetails called compare", res.data.details.loanData[0].cc_loans)
        console.log('Loan', this.props.getAccountDetail[0]?.cc_loans)
    }
    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        if (localStorage.getItem('mobilenumber') && localStorage.getItem('firstName')) {
            this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') })
            this.props.getAccountDetail[0]?.cc_loans ?? this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') })
        }
        if (!this.state.rendered) {
            localStorage.getItem('mobilenumber') && localStorage.getItem('firstName') ? this.setState({ ...this.state, rendered: true, isLoggedIn: true }) : this.setState({ ...this.state, rendered: true, isLoggedIn: false })
        }

    }
    handleRemove = (id) => {
        if (this.state.cardsCompare.details.length === 1) {
            localStorage.setItem("cardsCompare", JSON.stringify({ details: [] }))
            this.props.history.goBack()
        }
        else {
            const temp = {
                details: [],

            }
            this.state.cardsCompare.details.map((card, index) => {
                if (id != card.id) {
                    temp.details.push(card)
                }
            }
            )
            this.setState({ ...this.state, cardsCompare: temp })
            localStorage.setItem("cardsCompare", JSON.stringify(temp))
        }
    }

    setAvailCards = () => {
        const availCards = []
        this.state.cardDetails.map(card => {
            let found = false
            this.state.cardsCompare.details.map(compCard => {
                if (card.id === compCard.id) {
                    found = true
                }
            })
            if (!found) {
                availCards.push(card)
            }
        })
        //   console.log("available cards", availCards)
        return availCards
    }

    addToCompare = (cardName, cards) => {
        const card = cards.filter(card => card.card_name__c === cardName)
        this.setState({
            ...this.state, cardsCompare: { ...this.state.cardsCompare, details: [...this.state.cardsCompare.details, ...card] }
        })
        localStorage.setItem("cardsCompare", JSON.stringify({ details: [...this.state.cardsCompare.details, ...card] }))
    }

    callBackLoans = () => {
        let ccLoans = this.props.getAccountDetail[0]?.cc_loans
        if (this.props?.location?.state?.isASM) {
            this.props.history.push({ pathname: PATH.PRIVATE.ASM_DASHBOARD })
        } else {
            this.props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: ccLoans })
        }
    }

    callbackLoan = (res) => {
        //    console.log("loan is", res)
        if (res) {
            if (res.data.loan_exists != true) {
                console.log("card is", this.state.appliedCard)
                localStorage.setItem('loansfid', res.data.data.loansfid)
                localStorage.setItem('CCLA', res.data.data.loanName)
                if (this.state.appliedCard.utm_links__c === null && this.state.appliedCard.lender_name__c === "SCB") {
                    this.props.history.replace({ pathname: '/bank-specific-details/Credit_Card/SCB', state: this.state.appliedCard })
                }
                else {
                    this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') }, this.callBackLoans)
                    // let win = window.open(this.state.appliedCard.utm_links__c)
                    // this.props.history.push(PATH.PRIVATE.PRODUCTS)
                    // win.focus()
                }
                //    this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
            } else {
                this.setState({ ...this.state, appliedCard: {} })
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "Card already applied",
                    showConfirmButton: true,
                    timer: 1800,
                })
                // this.props.history.push({
                //     pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
                //     state: this.props.getAccountDetail[0].cc_loans
                // })
            }
        }
    }

    callbackDetail = (res) => {
        if (res) {
            if (res.data.success === false) {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.GET_CREDIT_CARD);
                });
            } else {
                const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
                const mobile = localStorage.getItem("mobilenumber");
                let storeData = { loanType: loanType }
                encryptStore(mobile, storeData)
                if (!(res.data?.customer?.pan_verified__c ?? false)) {
                    this.props.history.push({ pathname: PATH.PRIVATE.PAN_VERIFY, appliedCard: this.state.appliedCard })
                } else {
                    let card = this.state.appliedCard
                    localStorage.setItem("lenderId", card.lender_sfid__c)
                    if (card) {
                        var formData;
                        formData = {
                            mobile: mobile,
                            loanType: loanType,
                            cardSfid: card.sfid,
                            lenderId: card.lender_sfid__c
                        };
                        this.props.loadccApplyLoan(formData, this.callbackLoan);
                    }
                }
            }
        }
    };

    checkCard = (card) => {
        let ccLoans = this.props.getAccountDetail[0]?.cc_loans
        let flag = 0
        for (let loan of ccLoans) {
            if (loan["card_sfid"] === card["sfid"]) {
                flag = 1
            }
        }
        if (flag === 0 && this.props.getCustomerDetail?.pan_verified__c) {
            if (card.utm_links__c) {
                let win = window.open(card.utm_links__c)
                win.focus()
            }
        }
    }


    callbackApplyLoanFOS = (res) => {
        if (res) {
            if (res.data.success) {
                window.open(res.data.data.utm_links, "_blank");
                this.props.history.push(PATH.PRIVATE.FOS_DASHBOARD);
            } else {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: res.data.message,
                    showConfirmButton: true,
                    timer: 1800,
                })
            }
        }
    }

    handleApply = (card) => {
        localStorage.setItem("appliedCard", JSON.stringify(card))

        let isFOS = this.props.location?.state?.isFOS;

        if (isFOS) {

            let formData = {
                cardsfid: card.sfid,
                lenderid: card.lender_sfid__c,
                id: this.props.location?.state?.id,
                mobile_no: this.props?.location?.state?.mobile_no
            }
            this.props.applyLoanCCFOS(formData, this.callbackApplyLoanFOS)
        }
        else if (this.state.isLoggedIn || (localStorage.getItem('mobilenumber') && localStorage.getItem('firstName'))) {
            let flag = this.checkCard(card)
            if (!flag) {
                this.setState({ ...this.state, appliedCard: card })
                this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') }, this.callbackDetail)
            }
        } else {
            this.setState({ ...this.state, ccLogin: true })

            // this.props.history.push({
            //     pathname: PATH.PUBLIC.CREDIT_LOGIN,
            //     state: {
            //         card: card
            //     },
            // });
        }
    }

    render() {
        if (!this.props.location?.state) {
            return <Redirect to="/get-credit-card" />
        }
        else {
            const comparesQty = this.state.cardsCompare.details.length
            const dropDowns = []
            if (comparesQty != 3) {
                let i = comparesQty
                while (i < 3) {
                    dropDowns.push(i)
                    i++
                }
            }
            //Array(3 - comparesQty).fill(comparesQty.length)
            return (<React.Fragment>
                {this.state.appliedCard.id || this.props.loadingApplyLoanCCFOS ? <BackDropComponent /> : null}
                <section className="bs-main-section ccCompareSection">
                    {this.state.ccLogin ? <CcLogin show={this.state.ccLogin} appliedCard={JSON.parse(localStorage.getItem("appliedCard"))} handleCloseLogin={() => this.setState({ ...this.state, ccLogin: false })} /> : null}
                    {this.state.isLoggedIn || localStorage.getItem('mobilenumber') && localStorage.getItem('firstName') ? <TopNavBar /> : <CreditTopNavBar handleLogin={() => this.setState({ ...this.state, ccLogin: true })} />}
                    <p className="ccCardHeading">Comparing{this.state.cardsCompare.details.map((card, index) => <>{index == this.state.cardsCompare.details.length - 1 && this.state.cardsCompare.details.length > 1 ? " and " + card.card_name__c : index == 0 ? " " + card.card_name__c : ", " + card.card_name__c}</>)}
                    </p>
                    <div className="container ccContainer">
                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading ccHeadingTop">Features</div>
                            {this.state.cardsCompare.details.map((card, index) => (
                                <div className="col-4 col-md-3 col-sm-3 ccBox text-center">
                                    <div className="">
                                        <div className="ccImage">
                                            <img src={card.card_image__c ?? creditDefault} />
                                        </div>
                                        <button className="crossBtn" onClick={() => this.handleRemove(card.id)}>
                                            <img src={CrossLogo} />
                                        </button>
                                        <h5>{card.card_name__c}</h5>
                                        <button
                                            type="button"
                                            variant="contained"
                                            className="ccApplyBtn"
                                            onClick={() => this.handleApply(card)}
                                        >
                                            Apply Card
                                        </button>
                                    </div>
                                </div>
                            ))}
                            {dropDowns?.map((item) => (
                                <div key={item} className="col-4 col-md-3 col-sm-3 p-0">
                                    {/* <div className="credit-card-main-image"></div> */}
                                    <div className="text-center">
                                        <ReactSelect
                                            className="ccSearchBarBox"
                                            classNamePrefix="select"
                                            maxMenuHeight={130}
                                            components={{
                                                DropdownIndicator,
                                                IndicatorSeparator: () => null,
                                            }}
                                            name="credit-card"
                                            options={
                                                this.setAvailCards().map((card, index) => ({
                                                    label: (
                                                        <div className="ccSearchBarBoxLabel">
                                                            <span className="ccSearchBarBoxSelect">
                                                                <div

                                                                    className="ccSearchBarBoxModel"
                                                                >
                                                                    {card.card_name__c}
                                                                </div>
                                                            </span>
                                                        </div>
                                                    ),
                                                    value: card.card_name__c,
                                                }))
                                            }
                                            styles={selectStyles}
                                            menuPlacement="bottom"
                                            onChange={(e) => this.addToCompare(e.value, this.setAvailCards())}
                                        />
                                    </div>
                                </div>
                            ))}

                        </div>
                        <hr />
                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Approval Chances</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className=" col-4 col-md-3 col-sm-3 ccBox" >
                                    <img className="mx-auto d-block" src={SpeedometerIcon} style={{ maxWidth: "100px", height: "auto" }} />
                                </div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Annual Fee</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className=" col-4 col-md-3 col-sm-3 ccBox">{card.annual_fee__c}</div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Joining Fee</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className=" col-4 col-md-3 col-sm-3 ccBox">{card.joining_fee__c}</div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Welcome Benefits</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className=" col-4 col-md-3 col-sm-3 ccBox">{card.welcome_benefits__c}</div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Insurance Benefits</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className=" col-4 col-md-3 col-sm-3 ccBox">{card.insurance_benefits__c}</div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Rewards & Cashback</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className="col-4 col-md-3 col-sm-3 ccBox">{card.rewards_and_cashbacks__c}</div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Lounge Access</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className="col-4 col-md-3 col-sm-3 ccBox">{card.lounge_access__c}</div>
                            ))}
                        </div>
                        <hr />

                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Fuel Surcharge</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className="col-4 col-md-3 col-sm-3 ccBox">{card.fuel_surcharge__c}</div>
                            ))}
                        </div>
                        <hr />
                        <div className="row align-items-center g-0">
                            <div className="col-12 col-md-3 col-sm-3 ccHeading">Additional Benefits</div>
                            {this.state.cardsCompare.details.map((card) => (
                                <div className="col-4 col-md-3 col-sm-3 ccBox ccAb">
                                    <p>{card.additional_benefits__c}</p>
                                    <ApplyCard card={card} bottomBtn={true} handleLogin={() => this.setState({ ...this.state, ccLogin: true })} isASM={this.props?.location?.state?.isASM} urlEncodedData={this.props?.location?.state} />
                                </div>
                            ))}
                        </div> <hr />
                    </div >
                </section >
                <CreditFooter />
            </React.Fragment >)
        }
    }
}



const mapStateToProps = (state) => ({
    getAccountDetail: getAccount(state).getAccountDetail,
    getCustomerDetail: getAccount(state).customerDetail,
    loadingApplyLoanCCFOS: getASM(state).loadingApplyLoanCCFOS
})

const mapDispatchToProps = (dispatch) => ({
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    loadccApplyLoan: (params, callback) =>
        dispatch(loadccApplyLoan(params, callback)),
    applyLoanCCFOS: (params, callback) =>
        dispatch(applyLoanCCFOS(params, callback))
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CreditCardInfo))