import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import TopNavBar from "../../common/TopNavBar";
import { getAccountInfo, getAccount } from "../../store/account";
import Swal from "sweetalert2";
import { getBankOffer, setOfferList } from "../../store/bankOffer";
import { encryptStore } from "../../Utils/store";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";

class CreditDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "Key Card Benefits",
      credit: "",
    };
  }

  handleTabChange = (e) => {
    this.setState({ value: e.currentTarget.dataset.id });
  };

  handleApply = (credit) => {
    this.setState({ credit: credit });
    if (credit.lender_id__c) {
      let formData = {
        lenderId: credit.lender_id__c,
        loanType: CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN,
        mobile: localStorage.getItem("mobilenumber"),
        loanAmount: "0",
        offerId: credit.id,
        cardSfid: credit.cardSfid,
        emi: "0",
        roi: "0",
        tenure: "0",
        pf: "0",
        loanId: credit.loanId ? credit.loanId : "",
      };
      
      this.props.setOfferList(formData, this.callBackSet);
    } else {
      if (credit.bank_name) {
        if (credit.bank_name === "AXB") {
          window.open(
            "https://clctab.axisbank.co.in/DigitalChannel/WebForm/?ipa44",
            "_blank"
          );
        } else {
          this.props.history.push({
            pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS}/${credit.loanType
              .split(/\s/)
              .join("-")}/${credit.bank_name.split(/\s/).join("-")}`,
            state: { card: credit },
          });
        }
      } else {
        if (this.props.customerDetail.pan_verified__c === true) {
          this.props.history.push({
            pathname: PATH.PRIVATE.PERSONAL_DETAIL,
            state: { credit: credit },
          });
        } else {
          this.props.history.push({
            pathname: PATH.PRIVATE.PAN_VERIFY,
            state: { credit: credit },
          });
        }
      }
    }
  };
  callBackSet = (res) => {
    let mobileNumber = localStorage.getItem("mobilenumber");

    if (res?.data?.success) { 
	let storeData = {
        loansfid: res.data.data.loansfid,
      };
      encryptStore(mobileNumber, storeData);
      if (this.state.credit.utmUrl) {
        window.open(this.state.credit.utmUrl, "_blank");
      }else{
      if (this.state.credit.bank_name) {
        if (this.state.credit.bank_name === "AXB") {
          window.open(
            "https://clctab.axisbank.co.in/DigitalChannel/WebForm/?ipa25",
            "_blank"
          );
        } else {
          this.props.history.push({
            pathname: `${
              PATH.PRIVATE.BANK_SPECIFIC_DETAILS
            }/${this.state.credit.loanType
              .split(/\s/)
              .join("-")}/${this.state.credit.bank_name.split(/\s/).join("-")}`,
            state: { card: this.state.credit },
          });
        }
      } else {
        if (this.props.customerDetail.pan_verified__c === true) {
          this.props.history.push({
            pathname: PATH.PRIVATE.PERSONAL_DETAIL,
            state: { credit: this.state.credit },
          });
        } else {
          this.props.history.push({
            pathname: PATH.PRIVATE.PAN_VERIFY,
            state: { credit: this.state.credit },
          });
        }
      }
    }
    }
  };
  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    let mobile = localStorage.getItem("mobilenumber");
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
  };
  callbackDetail = (res) => {
    if (res) {
      if (!res.data.success) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };
  render() {
    return (
      <>
        <TopNavBar />
        <section className="bsCreditCardSection">
          <div className="container  creditCardInside">
            <div className="row BankVerForm">
              <div className="col-sm-4">
                <figure>
                  <img
                    src={
                      this.props.location.state &&
                      this.props.location.state.credit.card_image__c
                    }
                    alt=""
                    width=""
                    height=" "
                  />
                </figure>
              </div>
              <div className="col-sm-8">
                <div className="creditCardetails">
                  <h3>
                    {this.props.location.state &&
                      this.props.location.state.credit.card_name__c}
                  </h3>

                  <p>
                    Be it travel, dining, shopping or golf, now turn every
                    Indulgence into an Ultimate Experience.
                  </p>
                  <div>
                    <button
                      className="creditCardApply"
                      onClick={() =>
                        this.handleApply(
                          this.props.location.state &&
                            this.props.location.state.credit
                        )
                      }
                    >
                      APPLY NOW
                    </button>
                  </div>
                </div>
              </div>

              <div className="col-sm-12">
                <ul className="nav nav-pills bs-form-tab">
                  <li
                    onClick={(e) => this.handleTabChange(e)}
                    style={{ cursor: "pointer" }}
                    data-id="Key Card Benefits"
                  >
                    <a
                      className={
                        this.state.value === "Key Card Benefits" ? "active" : ""
                      }
                      href="javascript:;"
                    >
                      Key Card Benefits
                    </a>
                  </li>
                  <li
                    onClick={(e) => this.handleTabChange(e)}
                    style={{ cursor: "pointer" }}
                    data-id="Joining & Annual Fee"
                  >
                    <a
                      className={
                        this.state.value === "Joining & Annual Fee"
                          ? "active"
                          : ""
                      }
                      href="javascript:void(0)"
                    >
                      Joining & Annual Fee
                    </a>
                  </li>
                </ul>
                {this.state.value === "Key Card Benefits" && (
                  <ul className="CardkeyBenefits">
                    {this.props.location.state &&
                      this.props.location.state.credit.cardBenefits.map(
                        (e, i) => (
                          <>
                            <li>{e}</li>
                          </>
                        )
                      )}
                  </ul>
                )}
                {this.state.value === "Joining & Annual Fee" && (
                  <ul className="CardkeyBenefits">
                    {this.props.location.state &&
                      this.props.location.state.credit.joinFee.map((e, i) => (
                        <>
                          <li>{e}</li>
                        </>
                      ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  customerDetail: getAccount(state).customerDetail,
  setBankOffer: getBankOffer(state).setBankOffer,
});

const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreditDetail)
);
