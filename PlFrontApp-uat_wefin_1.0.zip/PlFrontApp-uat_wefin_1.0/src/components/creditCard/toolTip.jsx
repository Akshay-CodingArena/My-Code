import Button from 'react-bootstrap/Button';
import { usePopperTooltip } from 'react-popper-tooltip';
import infoIcon from "../../include/assets/creditCardIcons/infoIcon.svg"
// import 'react-popper-tooltip/dist/styles.css';
export default function CcToolTip(props) {
    const {
        getArrowProps,
        getTooltipProps,
        setTooltipRef,
        setTriggerRef,
        visible,
    } = usePopperTooltip();

    return (
        <>
            <Button variant="secondary" ref={setTriggerRef}>
                <img src={infoIcon} width="" height="" alt="" />
            </Button>

            {visible && (
                <div
                    ref={setTooltipRef}
                    {...getTooltipProps({ className: 'tooltip-container' })}
                >
                    {props.desc}
                    <div {...getArrowProps({ className: 'tooltip-arrow' })} />
                </div>
            )}
        </>
    );
}

// <OverlayTrigger
//     trigger="click"
//     placement={"bottom"}
//     overlay={
//         <Popover id={`popover-positioned-${"bottom"}`}>
//             <Popover.Header as="h3">{`Popover ${"bottom"}`}</Popover.Header>
//             <Popover.Body>
//                 <strong>Holy guacamole!</strong> Check this info.
//             </Popover.Body>
//         </Popover>

//     }
// >
//     <Button variant="secondary"><img src={infoIcon} width="" height="" alt="" /></Button>
// </OverlayTrigger>
