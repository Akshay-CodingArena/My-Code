import React, { Component } from "react";
// import { withRouter } from "react-router";
// import { connect } from "react-redux";
import TopNavBar from "../../common/TopNavBar";
import { Badge, Container } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
// import TopNavbarBlue from "../../common/TopNavbarBlue";
import BottomSection from "../../common/bottom"
import "../../include/css/dev.css";
// import icon1 from '../../../src/include/assets/badge1.svg'
// import icon2 from '../../../src/include/assets/badge2.svg'
// import icon3 from '../../../src/include/assets/badge3.svg'
// import icon4 from '../../../src/include/assets/badge4.svg'
// import icon5 from '../../../src/include/assets/badge5.svg'
// import icon6 from '../../../src/include/assets/badge6.svg'
// import creditLogo from '../../../src/include/assets/CreditLogo.png'
// import creditLogo from '../../../src/include/assets/credit_sprites.png'
class CreditCardPage extends Component {

    componentDidMount = () => {
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
    }


    render() {
        return (
            <>
                <section className="bs-main-section">
                    <TopNavBar />
                    <Container>
                        <div
                            style={{
                                textAlign: "center",
                                color: "#4E4E4E",
                                fontWeight: "400",
                                fontSize: "24px",
                            }}
                        >
                            Find the right credit
                            <div>card for you...</div>
                        </div>
                        {/* <div class="spaceVart"> */}

                        <div className="row spaceVert">
                            <div className="col-6 col-sm-4 col-md-2 text-center">
                                {/* <a href="#" target="_blank"><div className="creditBadge best-sellers">
                                    {/* <img src={icon1} alt="Icon1" />{" "} 
                                </div></a> */}

                                <div className="creditBadge best-sellers">
                                    {/* <img src={icon1} alt="Icon1" />{" "} */}
                                </div>
                                <p className="selectMargin">Best Sellers</p>
                                {/* <div class="checkBox radio text-center" checked="checked"></div> */}
                                {/* <div class="form-check"></div> */}
                                <input
                                    className="form-check-input marginForm"
                                    type="checkbox"
                                    onChange={this.handleSubscribe}
                                />
                            </div>

                            <div className="col-6 col-sm-4 col-md-2 text-center">
                                <div className="creditBadge free-cards">
                                    {/* <img src={icon6} alt="Icon1" />{" "} */}
                                </div>
                                <p className="selectMargin">Free Cards</p>
                                {/* <div class="checkBox radio text-center" checked="checked"></div> */}
                                {/* <div class="form-check "> </div> */}
                                <input
                                    className="form-check-input marginForm"
                                    type="checkbox"
                                />

                            </div>

                            <div className="col-6 col-sm-4 col-md-2 text-center">
                                <div className="creditBadge life-style">
                                    {/* <img src={icon5} alt="Icon1" />{" "} */}
                                </div>
                                <p className="selectMargin">LifeStyle</p>
                                {/* <div class="checkBox radio text-center" checked="checked"></div> */}
                                {/* <div class="form-check "></div> */}
                                <input
                                    className="form-check-input marginForm"
                                    type="checkbox"
                                />
                            </div>

                            <div className="col-6 col-sm-4 col-md-2 text-center">
                                <div className="creditBadge cashbach-reward">
                                    {/* <img src={icon2} alt="Icon1" />{" "} */}
                                </div>
                                <p className="selectMargin" id="onlyMargin">CashBack & Rewards</p>
                                {/* <div class="checkBox radio text-center" checked="checked"></div> */}
                                {/* <div class="form-check "></div> */}
                                <input
                                    className="form-check-input marginForm"
                                    type="checkbox"
                                />
                            </div>

                            <div className="col-6 col-sm-4 col-md-2 text-center">
                                <div className="creditBadge travel-fuel">
                                    {/* <img src={icon4} alt="Icon1" />{" "} */}
                                </div>
                                <p className="selectMargin">Travel & Fuel</p>
                                {/* <div class="checkBox radio text-center" checked="checked"></div> */}
                                {/* <div class="form-check "></div> */}
                                <input
                                    className="form-check-input marginForm"
                                    type="checkbox"
                                />
                            </div>

                            <div className="col-6 col-sm-4 col-md-2 text-center">
                                <div className="creditBadge premium">
                                    {/* <img src={icon3} alt="Icon1" />{" "} */}
                                </div>
                                <p className="selectMargin">Premium</p>
                                {/* <div class="checkBox radio text-center" checked="checked"></div> */}
                                {/* <div class="form-check"></div> */}
                                <input
                                    className="form-check-input marginForm"
                                    type="checkbox"
                                />
                            </div>
                        </div>

                        {/* </div> */}

                        <div className="col-sm-12 text-center">
                            <button
                                type="submit"
                                onClick={this.handleSubmit}
                                variant="contained"
                                className="nextButton applyCss"
                            >
                                Get Cards
                            </button>
                        </div>

                    </Container>

                </section>
                <div className="marginTop">
                    <BottomSection /></div>
                <CreditFooter />
            </>
        )
    }
}



export default CreditCardPage;