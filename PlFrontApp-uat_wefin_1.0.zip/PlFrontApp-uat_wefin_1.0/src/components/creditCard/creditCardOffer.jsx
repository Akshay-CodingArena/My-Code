import React, { Component } from "react";
import BackDropComponent from "../../common/BackDropComponent";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { withRouter } from "react-router";
import TopNavBar from "../../common/TopNavBar";
import CreditCardList from "./creditCardList";
import { getAccountInfo, getAccount } from "../../store/account";
import { connect } from "react-redux";
import Swal from "sweetalert2";
import { getBankOffer, setOfferList } from "../../store/bankOffer";
import { gaLogEvent } from "../../init-fcm";
import CONSTANTS from "../../constants/Constants";
import { encryptStore } from "../../Utils/store";
import PATH from "../../paths/Paths";

class CreditCardOffer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      setLoading: true,
      credit: "",
    };
  }

  componentDidMount = () => {
    gaLogEvent(CONSTANTS.GA_EVENTS.CC_OFFERS);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    setTimeout(() => {
      this.setState({ setLoading: !this.state.setLoading });
    }, 2000);
    let mobile = localStorage.getItem("mobilenumber");
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
  };
  callbackDetail = (res) => {
    if (res) {
      if (!res.data.success) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      } else {
        localStorage.setItem("email", res.data.customer.personemail);
      }
    }
  };

  handleApply = (credit) => {
    this.setState({ credit: credit });
    let formData = {
      lenderId: credit.lender_id__c,
      loanType: credit.loanType,
      mobile: localStorage.getItem("mobilenumber"),
      loanAmount: "0",
      offerId: credit.id,
      cardSfid: credit.cardSfid,
      emi: "0",
      roi: "0",
      tenure: "0",
      pf: "0",
      loanId: credit.loanId ? credit.loanId : "",
    };
    if (localStorage.getItem("isUTM")) {
      let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
      formData.utm_source = UTM_Data?.utm_source;
      formData.utm_medium = UTM_Data?.utm_medium;
      formData.utm_id = UTM_Data?.utm_id;
      formData.utm_campaign = UTM_Data?.utm_campaign;
    }
    
    this.props.setOfferList(formData, this.callBackSet);
  };

  callBackSet = (res) => {
    let mobileNumber = localStorage.getItem("mobilenumber");

    if (res?.data?.success) {
      localStorage.setItem("CCLA", res.data?.data?.loanName);
      gaLogEvent(CONSTANTS.GA_EVENTS.CC_CARD_SELECTED, {
        Lender_Name: this.state.credit.bank_name,
      });
      let storeData = {
        loansfid: res.data.data.loansfid,
      };
      encryptStore(mobileNumber, storeData);

      if (this.state.credit.utmUrl) {
        let myWindow = window.open(this.state.credit.utmUrl, "_blank");
        if (myWindow !== null) {
        } else {
          Swal.fire({
            position: "center",
            icon: "warning",
            title: "Turn on pop-up in your browser settings",
            showConfirmButton: true,
          });
        }
      } else if (this.state.credit.bank_name === "AXB") {
        let myWindow = window.open(
          "https://clctab.axisbank.co.in/DigitalChannel/WebForm/?ipa25",
          "_blank"
        );
        if (myWindow !== null) {
        } else {
          Swal.fire({
            position: "center",
            icon: "warning",
            title: "Turn on pop-up in your browser settings",
            showConfirmButton: true,
          });
        }
      } else {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
            }/${this.state.credit.loanType
              .split(/\s/)
              .join("-")}/${this.state.credit.bank_name.split(/\s/).join("-")}`,
          state: { card: this.state.credit },
        });
      }
    } else {
    }
  };
  handleKnow = (e) => {
    this.props.history.push({
      pathname: PATH.PRIVATE.CREDIT_CARD_DETAIL,
      state: { credit: e },
    });
  };
  render() {
    // const { offers } = this.props;
    const ccData = this.props.location.state;
    // const offerList =
    //   offers && offers.length > 0 && offers[0].cc_offers
    //     ? offers[0].cc_offers
    //     : ccData;
    return (
      <>
        <TopNavBar />
        <section className="bsCreditCardSection">
          <div className="container">
            {this.state.setLoading ? <BackDropComponent /> : ""}
            <h1> Select Your Card </h1>
            <div className="row">
              <div className="col-sm-12">
                <CreditCardList
                  handleApply={this.handleApply}
                  handleKnow={this.handleKnow}
                  ccData={ccData}
                />
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  offers: getAccount(state).getOffer,
  setBankOffer: getBankOffer(state).setBankOffer,
});

const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreditCardOffer)
);
