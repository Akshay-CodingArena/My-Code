import { callStack } from "joi-browser";
import React, { Component } from "react";
import Swal from "sweetalert2";
import { useEffect } from "react";
import TopNavBar from "../../common/TopNavBar";
import Collapse from 'react-bootstrap/Collapse';
import { Form, Container, Row, Col, Button, Figure, Tab, Tabs, Nav, Navbar, NavDropdown } from "react-bootstrap";
// import Offcanvas from 'react-bootstrap/Offcanvas';
import CreditFooter from "../../components/cibilFlow/footer";
// import SpeedometerIcon from "../../include/assets/creditCardIcons/speedometer2.0.png";
import StandardChartered from "../../include/assets/creditCardIcons/StandardChartered.png"
// import AxisLogo from "../../include/assets/creditCardIcons/Axis.png";
import FilterIcon from "../../include/assets/creditCardIcons/filterIcon.svg"
import plusIcon from "../../include/assets/creditCardIcons/plusIcon.svg"
import minusIcon from "../../include/assets/creditCardIcons/minusIcon.svg"
import easyEmiIcon from "../../include/assets/creditCardIcons/easyEmi.svg"
import freeIcon from "../../include/assets/creditCardIcons/freeIcon.svg"
import infoIcon from "../../include/assets/creditCardIcons/infoIcon.svg"
import moviesIcon from "../../include/assets/creditCardIcons/moviesIcon.svg"
import rewardIcon from "../../include/assets/creditCardIcons/rewardIcon.svg"
import CreditTopNavBar from "../../common/creditTopNav";
import { numberFormat } from "../../Utils/numberFormat";
import tickIcon from "../../include/assets/creditCardIcons/tickIcon.svg"
import PATH from "../../paths/Paths";
import { getCreditCard, setFilters, } from "../../store/creditCard";
import { Redirect, withRouter } from "react-router";
import { connect } from "react-redux";
import CreditCardFilterSlide from "./CreditCardFilterSlide";
import creditDefault from '../../include/assets/creditCardIcons/defaultCredit.png'
import { loadccApplyLoan } from "../../store/applyLoan";
import CONSTANTS from "../../constants/Constants"
import { getAccount, getAccountInfo } from "../../store/account";
import { encryptStore } from "../../Utils/store";
import BackDropComponent from "../../common/BackDropComponent";
import CcToolTip from "./toolTip";
import CcLogin from "./ccLogin";
import ApplyCard from "./applyCard";
import { getASM } from "../../store/asm";

class CreditCardList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoggedIn: false,
            rendered: false,
            open: false,
            openId: -1,
            show: false,
            cardsCompare: {
                ids: [],
                details: []
            },
            filterOpen: false,
            cardDetails: [],
            filters: {
                category: [],
                bank: []
            },
            appliedCard: {},
            ccLogin: false
        };
    }

    filterCard1 = []

    static getDerivedStateFromProps(props, state) {
        if (!state.rendered) {
            if (!JSON.parse(localStorage.getItem("cardsCompare"))?.details) {
                return {
                    categoryDetails: props.location.state?.categoryDetails,
                    rendered: true,
                    cardDetails: props.location.state?.cardDetails,
                    bankNameDetails: props.location.state?.bankNameDetails,
                    filters: {
                        category: props.getFilters.checkValue.length ? props.getFilters.checkValue : props.location.state?.checkValue,
                        bank: props.getFilters.checkBankValue ?? []
                    },
                    cardsCompare: JSON.parse(localStorage.getItem("cardsCompare")) ?? {
                        ids: [],
                        details: []
                    }
                }
            }
            else {
                return {
                    categoryDetails: props.location.state?.categoryDetails,
                    rendered: true,
                    cardsCompare: JSON.parse(localStorage.getItem("cardsCompare")) ?? {
                        ids: [],
                        details: []
                    },
                    cardDetails: props.location.state?.cardDetails,
                    bankNameDetails: props.location.state?.bankNameDetails,
                    filters: {
                        category: props.getFilters.checkValue.length ? props.getFilters?.checkValue : props.location.state?.checkValue,
                        bank: props.getFilters?.checkBankValue ?? []
                    }
                }
            }
        } else {
            return {}
        }
    }
    callBackInfo = () => {
        console.log("getAccountDetails called")
    }

    componentDidMount = () => {
        if (localStorage.getItem("role") === "FOS_CALL") {

        }
        else if (localStorage.getItem('mobilenumber')) {
            this.props.getAccountDetail[0]?.cc_loans ?? this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') })
            this.setState({ ...this.state, isLoggedIn: true })
        }
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
    };


    setOpen = (e) => {
        if (this.state.openId === e.currentTarget.id) {
            this.setState({ ...this.state, open: !this.state.open })
        }
        else {
            this.setState({ ...this.state, open: true, openId: e.currentTarget.id })
        }

    }
    setShow = () => {
        this.setState({ show: !this.state.show })
    }

    handleFilterClick = () => {
        //     console.log("Filter status......", this.state.filterOpen, this.state.filters, "yupps")
        this.setState({ ...this.state, filterOpen: !this.state.filterOpen })
    }

    handleClose = () => {
        //     console.log("History", this.state.filtersDefault)
        this.setState({ ...this.state, filterOpen: false })
    }

    handleCompare = () => {
        if (this.state.cardsCompare.details.length < 2) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "Please select at least 2 cards in order to compare",
                showConfirmButton: true,
                timer: 5000,
            });
        }
        else {
            this.props.history.push({
                pathname: PATH.PUBLIC.CREDIT_CARD_INFO_SCREEN,
                state: {
                    cardsCompare: this.state.cardsCompare,
                    // cardDetails: this.filterCard1
                    cardDetails: this.props.location.state?.cardDetails,
                    isASM: this.props.location?.state?.isASM,
                    isFOS: this.props.location?.state?.isFOS,
                    id: this.props.location?.state?.id,
                    mobile_no: this.props.location?.state?.mobile_no,
                },
            });
        }
    }

    callBackLoans = () => {
        let ccLoans = this.props.getAccountDetail[0]?.cc_loans
        this.props.history.push({ pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN, state: ccLoans })

    }

    callbackLoan = (res) => {
        if (res) {
            if (res.data.loan_exists !== true) {
                if (this.state.appliedCard.utm_links__c === null || this.state.appliedCard.lender_name__c === "SCB") {
                    localStorage.setItem('loansfid', res.data.data.loansfid)
                    localStorage.setItem('CCLA', res.data.data.loanName)
                    this.props.history.replace({ pathname: '/bank-specific-details/Credit_Card/SCB', state: this.state.appliedCard })
                }
                else {
                    this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') }, this.callBackLoans)
                }
                //   else {
                // try {
                //     let win = window.open(this.state.appliedCard.utm_links__c)
                //     this.props.history.push(PATH.PRIVATE.PRODUCTS)
                //     win.focus()
                // }
                // catch {
                //     Swal.fire({
                //         position: "center",
                //         icon: "error",
                //         title: "You will be redirected to a 3rd party.",
                //         showConfirmButton: true,
                //         timer: 1800,
                //     }).then(() => {
                //         let win = window.open(this.state.appliedCard.utm_links__c)
                //         this.props.history.push(PATH.PRIVATE.PRODUCTS)
                //         win.focus()
                //     });
                // }
                //    }
                //    this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
            } else {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "Card already applied",
                    showConfirmButton: true,
                    timer: 1800,
                })
                // this.props.history.push({
                //     pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
                //     state: this.props.getAccountDetail[0]?.cc_loans
                // })
            }
        }
    }
    callbackDetail = (res) => {
        if (res) {
            //   console.log("response is ", res)
            if (res.data.success === false) {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.GET_CREDIT_CARD);
                });
            } else {
                const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
                const mobile = localStorage.getItem("mobilenumber");
                let storeData = { loanType: loanType }
                encryptStore(mobile, storeData)
                if (!(res.data?.customer?.pan_verified__c ?? false)) {
                    let card = this.state.appliedCard
                    if (card) {
                        let formData;
                        formData = {
                            mobile: mobile,
                            loanType: loanType,
                            cardSfid: card.sfid,
                            lenderId: card.lender_sfid__c
                        };
                        this.props.history.push({ pathname: PATH.PRIVATE.PAN_VERIFY, appliedCard: this.state.appliedCard, ccformData: formData })
                    }
                } else {
                    let card = this.state.appliedCard
                    if (card) {
                        let formData;
                        localStorage.setItem("lenderId", card.lender_sfid__c)
                        formData = {
                            mobile: mobile,
                            loanType: loanType,
                            cardSfid: card.sfid,
                            lenderId: card.lender_sfid__c
                        };

                        if (localStorage.getItem("isUTM")) {
                            let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
                            formData.utm_source = UTM_Data?.utm_source;
                            formData.utm_medium = UTM_Data?.utm_medium;
                            formData.utm_id = UTM_Data?.utm_id;
                            formData.utm_campaign = UTM_Data?.utm_campaign;
                        }

                        this.props.loadccApplyLoan(formData, this.callbackLoan);
                    }
                }
            }
        }
    };

    isChecked = (id) => {
        let isChecked = false

        this.state.cardsCompare.details.map(card => {
            if (card.id === id) {
                isChecked = true
            }
        })
        return isChecked
    }

    addToCompare = (card) => {
        const compareId = card.id
        const compareArr = this.state.cardsCompare.details
        let found = false
        if (compareArr.length < 3) {
            const newcardsArr = []
            if (compareArr.length != 0) {
                compareArr.map((card) => {
                    if (card.id !== compareId) {
                        newcardsArr.push(card)
                    }
                    else {
                        found = true
                    }
                })
            }
            if (found === false) {
                newcardsArr.push(card)
            }
            localStorage.setItem("cardsCompare", JSON.stringify({ details: newcardsArr }))
            this.setState({ ...this.state, cardsCompare: { details: newcardsArr } })
        }
        else {
            if (this.state.cardsCompare.details.length === 3) {
                const newcardsArr = []
                compareArr.map((card) => {
                    if (card.id !== compareId) {
                        newcardsArr.push(card)
                    }
                    else {
                        found = true
                    }
                })

                if (found === true) {
                    localStorage.setItem("cardsCompare", JSON.stringify({ details: newcardsArr }))
                    this.setState({ ...this.state, cardsCompare: { details: newcardsArr } })
                }
                else {
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: "Cannot add more than 3 cards in compare",
                        showConfirmButton: true,
                        timer: 5000,
                    });
                }
            }
        }

    }
    // handleFilterClick = () => {

    //     console.log("Filter status", this.state.filterOpen)

    //     this.setState({ ...this.state, filterOpen: !this.state.filterOpen })

    // }

    setFilter = (filters, close) => {
        if (close) {
            this.setState({ ...this.state, filters: { category: filters.checkValue, bank: filters.checkBankValue }, filterOpen: false })
        } else {
            this.setState({ ...this.state, filters: { category: filters.checkValue, bank: filters.checkBankValue } })
        }
        this.props.setFilters(filters)
    }

    render() {
        console.log("details of customer", this.props.getCustomerDetail.pan_verified__c)
        if (!this.props.location.state) {
            //    console.log("redirect")
            //  this.props.history.replace({ pathname: "" })
            return <Redirect to="/get-credit-card" />
        }
        else {
            // console.log("store filters", this.state.filters, " ....", this.props.getFilters, this.props.location.state.checkValue)
            // console.log(this.state.filterOpen)
            this.filterCard1 = this.state.cardDetails
            if (this.state.filters.bank.length) {
                this.filterCard1 = this.state.cardDetails.filter(card => this.state.filters.bank.includes(card.lender_name__c)
                )
            }

            if (this.state.filters.category.length) {
                this.filterCard1 = this.filterCard1.filter((card) => {
                    let cardFound = this.state.filters.category.some(category => card.cardCategory.includes(category))
                    if (cardFound) {
                        return card
                    }
                })
            }
            //    console.log("compare", this.state.cardsCompare, "screen", JSON.parse(localStorage.getItem("cardsCompare")))
            return (
                <>
                    {this.state.filterOpen ? document.body.classList.add("RemoveScrool") : document.body.classList.remove("RemoveScrool")}
                    {this.state.filterOpen ? <CreditCardFilterSlide setFilter={this.setFilter} setState={this.handleClose} state={this.state} /> : null}
                    {this.props.isLoading || this.state.appliedCard.cardSfid || this.props.loadingApplyLoanCCFOS ? <BackDropComponent /> : null}
                    {this.state.ccLogin ? <CcLogin show={this.state.ccLogin} appliedCard={JSON.parse(localStorage.getItem("appliedCard"))} handleCloseLogin={() => this.setState({ ...this.state, ccLogin: false })} /> : null}
                    {localStorage.getItem('mobilenumber') && localStorage.getItem('firstName') ? <TopNavBar /> : <CreditTopNavBar handleLogin={() => this.setState({ ...this.state, ccLogin: true })} />}
                    <section className="bs-main-section ccMainSection">
                        <Container>
                            <div className="ccMainHeading" >
                                <Row>
                                    <Col xs={7} sm={6} md={6} xl={6} ><h1>{this.filterCard1.length} &nbsp;Credit Cards for You</h1></Col>
                                    <Col xs={5} sm={6} md={6} xl={6} className="text-right">
                                        <Button className="compareBtn cs_dv" onClick={this.handleCompare}>Compare Credit Cards <span>{this.state.cardsCompare?.details.length}</span></Button>
                                        <Button className="filterBtn" onClick={this.handleFilterClick}>Filter <img src={FilterIcon} alt="FilterIcon" /></Button>
                                    </Col>
                                </Row>
                            </div>
                            <div>
                                {this.filterCard1?.map((card, index) => (
                                    <div className="ccMainList">
                                        <Row>
                                            <Col xs={12} sm={4} md={3} xl={3} className="d-flex align-items-center ccImgaeCol " >

                                                <Figure>
                                                    <img src={card.card_image__c ?? creditDefault} width="" height="" alt={card.card_image__c} />
                                                </Figure>
                                            </Col>
                                            <Col xs={12} sm={8} md={9} xl={9} className="ccDecCol">
                                                <div className="ccMainSubHeading">
                                                    <h3>{card.card_name__c}</h3>
                                                    <p>{card.card_description__c}</p>
                                                    <Button className="compareBtn" onClick={() => this.addToCompare(card)}>{!this.isChecked(card.id) ? <><img src={plusIcon} width="" height="" alt="Plus Icon" />Compare</> : <img src={tickIcon} width="" height="" alt="Plus Icon" />}</Button>
                                                </div>
                                                <div>
                                                    <Row>

                                                        <Col xs={12} sm={4} md={3} xl={2} >
                                                            <div className="infoBlock"><p>1st Year Fees
                                                                <CcToolTip desc={"Fee levied by the bank only for the first year for owning the credit card."} />
                                                            </p>
                                                                <p>{card.joining_fee_amount__c === 0 ? <img src={freeIcon} width="" height="" alt="" /> : null}{numberFormat(card.joining_fee_amount__c)}</p></div> </Col>
                                                        <Col xs={12} sm={4} md={3} xl={5}>
                                                            <div className="infoBlock"><p>Best Suited for  <CcToolTip desc={"Major benefits of owning the credit card."} /></p>
                                                                <p>{
                                                                    card.bestSuited.map((suited) => (<span>
                                                                        <img src={suited.image} width="20" height="20" alt="" />
                                                                        {suited.name}
                                                                    </span>))
                                                                } </p></div> </Col>
                                                        <Col xs={12} sm={4} md={3} xl={5}>
                                                            <div className="infoBlock qcBlock"> <p>Qualifying Criteria <CcToolTip desc={"Minimum eligibility for applying the credit card."} /></p>
                                                                <p>Age: {card.age__c} Y min<span>&nbsp;</span>Monthly income: {numberFormat(card.monthly_income__c / 1000)}k above</p></div></Col>
                                                    </Row>
                                                </div>

                                                <div className="ccBtnBlock">

                                                    <Button className="kmBtn"
                                                        id={index}
                                                        onClick={(e) => this.setOpen(e)}
                                                        aria-controls="creditCollapse1"
                                                        aria-expanded={this.state.open}
                                                    >
                                                        <img src={this.state.openId == index && this.state.open ? minusIcon : plusIcon} width="" heiight="" />Know More
                                                    </Button>
                                                    <ApplyCard
                                                        card={card}
                                                        handleLogin={() => this.setState({ ...this.state, ccLogin: true })}
                                                        isASM={this.props.location?.state?.isASM}
                                                        urlEncodedData={this.props?.location?.state}
                                                    />
                                                </div>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col>

                                                <Collapse in={this.state.openId == index ? this.state.open : false}>
                                                    <div id="creditCollapse">
                                                        <Tabs
                                                            defaultActiveKey="cardBenefits"
                                                            transition={false}
                                                            id="noanim-tab-example"
                                                            className="mb-3"
                                                        >
                                                            <Tab eventKey="cardBenefits" title="Key Card Benefits">
                                                                <ul>
                                                                    {
                                                                        card.card_benefits__c.map(benefit => (

                                                                            <li>{benefit}</li>

                                                                        ))}
                                                                </ul>
                                                            </Tab>
                                                            <Tab eventKey="joiningFees" title="Joining & Annual Fee">
                                                                <ul>
                                                                    <li>{card.joining_fee__c}</li>
                                                                    <li>{card.annual_fee__c}</li>                                                            </ul>
                                                            </Tab>

                                                        </Tabs>
                                                    </div>
                                                </Collapse>
                                            </Col>
                                        </Row>
                                    </div>))}
                            </div>
                            <div className="cs_compare_mobile"><Button className="compareBtn cs_mv" onClick={this.handleCompare}>Compare Credit Cards <span>{this.state.cardsCompare?.details.length}</span></Button></div>

                        </Container>

                    </section >
                    <CreditFooter />

                </>
            );
        }
    }
}

const mapStateToProps = (state) => ({
    isLoading: getAccount(state).loading,
    getFilters: getCreditCard(state).filters,
    getAccountDetail: getAccount(state).getAccountDetail,
    getCustomerDetail: getAccount(state).customerDetail,
    loadingApplyLoanCCFOS: getASM(state).loadingApplyLoanCCFOS
})
const mapDispatchToProps = (dispatch) => ({
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    loadccApplyLoan: (params, callback) =>
        dispatch(loadccApplyLoan(params, callback)),
    setFilters: (payload) => dispatch(setFilters(payload))
})

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(CreditCardList))