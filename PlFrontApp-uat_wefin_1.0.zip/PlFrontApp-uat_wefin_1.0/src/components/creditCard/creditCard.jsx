import React, { Component } from "react";
import BackDropComponent from "../../common/BackDropComponent";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { getCreditCard, loadCreditCardList } from "../../store/creditCard";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import TopNavBar from "../../common/TopNavBar";
import CreditCardList from "./creditCardList";
import { getAccountInfo, getAccount } from "../../store/account";
import Swal from "sweetalert2";
import PATH from "../../paths/Paths";
class CreditCardMain extends Component {
  constructor(props) {
    super(props);
    this.state = {
      setLoading: true,
    };
  }

  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    let mobile = localStorage.getItem("mobilenumber");
    this.props.loadCreditCardList("mobile=" + mobile);
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
    setTimeout(() => {
      this.setState({ setLoading: !this.state.setLoading });
    }, 2000);
  };
  callbackDetail = (res) => {
    if (res) {
      if (!res.data.success) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      } else {
        localStorage.setItem("email", res.data.customer.personemail);
      }
    }
  };
  handleApply = () => {
    if (this.props.customerDetail.pan_verified__c === true) {
      this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
    } else {
      this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
    }
  };
  handleKnow = (e) => {
    this.props.history.push({
      pathname: PATH.PRIVATE.CREDIT_CARD_DETAIL,
      state: { credit: e },
    });
  };
  render() {
    const { ccData, loading } = this.props;
    return (
      <>
        <TopNavBar />
        <section className="bsCreditCardSection">
          <div className="container">
            {loading || this.state.setLoading ? <BackDropComponent /> : ""}
            <h1> Select Your Card</h1>
            <div className="row">
              <div className="col-sm-12">
                <CreditCardList
                  ccData={ccData}
                  handleApply={this.handleApply}
                  handleKnow={this.handleKnow}
                />
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  ccData: getCreditCard(state).ccData,
  loading: getCreditCard(state).loading,
  customerDetail: getAccount(state).customerDetail,
});

const mapDispatchToProps = (dispatch) => ({
  loadCreditCardList: (params) => dispatch(loadCreditCardList(params)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CreditCardMain)
);
