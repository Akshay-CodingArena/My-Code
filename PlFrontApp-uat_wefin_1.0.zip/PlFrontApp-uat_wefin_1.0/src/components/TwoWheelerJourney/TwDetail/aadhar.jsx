import React, { Component } from "react";
import { Container, Row, Form, Col, Card } from "react-bootstrap";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import AADHAR_PHOTO from "../../../include/assets/1/aadhar.png";
// import ArrowForwardIcon from "../../../include/assets/otpArrow.png";
import { decryptStore } from "../../../Utils/store";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import BackDropComponent from "../../../common/BackDropComponent";
import Swal from "sweetalert2";
import PATH from "../../../paths/Paths";
import { getOS } from "../../../Utils/device_function";
import { loadConsents } from "../../../store/consent";
import CONSTANTS from "../../../constants/Constants";
import ASMNavBar from "../../ASM/ASMNavBar";
import { validateAadhar, getKycStatus } from "../../../store/validateAadhar";
import { nstpRevolt, nstpActions } from "../../../store/nstp";
let reg = new RegExp("^[0-9]*$");

class Aadhar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            geoLocation: {},
            formFieldSelect: "aadhar",
            otpSeconds: 40,
            showOTPField: false,
            showSubmitAadharButton: true,
            aadhar: "",
            showResendOTPSection: false,
            loading: false,
            showCounter: true,
            showSubmitOTPButton: false,
            otp: "",
            bank: {},
            terms: false,
            stepperStep: 4
        };



        this.getGeoLocation = this.getGeoLocation.bind(this);
        this.setPageLayout = this.setPageLayout.bind(this);
        this.handleOTPTimer = this.handleOTPTimer.bind(this);
        this.submitAadhar = this.submitAadhar.bind(this);
        this.handleInitiateAadharCallback =
            this.handleInitiateAadharCallback.bind(this);
    }

    componentDidMount = () => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"))
        if (decryptedData.lender === "Money Plus" && decryptedData.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
            this.props.setStepperStep(2)
        }
        this.getGeoLocation();
        this.setPageLayout();
    };

    componentWillUnmount = () => {
        clearInterval(this.handleOTPTimer);
    };

    submitAadhar = async (e) => {
        e.preventDefault();
        //this.props?.setpLData({ ...this.props.pLData, AadhaarDetails: r.data.data?.responseData?.result?.dataFromAadhaar })
        //   this.props?.setStep(CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_PERMANENT)

        let mobile = localStorage.getItem("mobilenumber");
        let { loansfid } = decryptStore(mobile);
        const { state } = this.props.location;
        this.setState(({ bank }) => ({ bank: { ...bank, ...state } }));
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        const data = {
            processType: "initiateaadhaar",
            aadhaarNo: this.state.aadhar.toString().replace(/\s+/g, ""),
            loanId: decryptedData.loanId
        };
        this.props.validateAadhar(
            data,
            this.handleInitiateCreditAadharCallback
        );

        this.setState({
            loading: true,
            showSubmitAadharButton: true,
            showSubmitOTPButton: false,
        });
    };

    handleInitiateCreditAadharCallback = async (res) => {

        try {
            let r = await res;

            if (r.data.data.success) {
                this.setState({ loading: false, showOTPField: true, showSubmitOTPButton: true, showSubmitAadharButton: false, requestId: res.data?.data?.responseData });
                this.handleOTPTimer();
            } else {
                throw new Error(
                    "It is taking longer than usual… requesting your kind patience",
                    { cause: "pending" }
                );
            }
        } catch (e) {
            this.setState({
                loading: false,
                showSubmitAadharButton: true,
                showSubmitOTPButton: false,
                aadhar: "",
            });
            Swal.fire({
                icon: "warning",
                title: "It is taking longer than usual… requesting your kind patience",
            });
        }
    };

    handleInitiateAadharCallback = async (res) => {
        try {
            let r = await res;
            if (await r.data.success) {
                this.setState({ loading: false });
                this.setState({ showOTPField: true });
                this.handleOTPTimer();
            } else {
                throw new Error(r.data.message);
            }
        } catch (e) {
            this.setState({ loading: false });
            Swal.fire({
                icon: "warning",
                title: e.message.toString(),
            });
        }
    };

    handleOTPTimer = () => {
        let myInterval = setInterval(() => {
            if (this.state.otpSeconds > 0) {
                this.setState((state) => {
                    return { otpSeconds: state.otpSeconds - 1 };
                });
            } else {
                this.setState({
                    showResendOTPSection: true,
                    showCounter: false,
                    formFieldSelect: "otp",
                });
                clearInterval(myInterval);
            }
        }, 1000);
        return myInterval;
    };

    resendOTP = (e) => {
        e.preventDefault();
        this.setState({
            showCounter: true,
            loading: false,
            formFieldSelect: "aadhar",
            otpSeconds: 40,
            showOTPField: false,
            showSubmitAadharButton: true,
            showResendOTPSection: false,
            showSubmitOTPButton: false,
        });
        this.submitAadhar(e);
    };

    submitOTP = async (e) => {
        e.preventDefault();
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

        const data = {
            processType: "validateaadhaar",
            aadhaarNo: this.state.aadhar.toString().replace(/\s+/g, ""),
            otp: this.state.otp.toString(),
            requestId: this.state.requestId.requestId,
            loanId: decryptedData.loanId
        };
        // loanId: this.props.location.state.loanId
        //   ? this.props.location.state.loanId
        //   : loansfid
        //     ? loansfid
        //     : localStorage.getItem("loansfid")

        this.props.validateAadhar(
            data,
            this.handleValidateCreditAadharCallback
        );

        this.setState({ loading: true });
    };

    handleValidateCreditAadharCallback = (res) => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        try {
            let r = res;
            if (r.data?.success) {
                this.setState({ loading: false });

                let kycData = r.data.data.kycResult;

                if (kycData.status) {
                    /////////////////checks///////////
                    if (kycData.dobCompare && kycData.nameScore >= 70) {
                        this.props.setpLData({ ...this.props.pLData, AadhaarDetails: r.data.data?.responseData?.result?.dataFromAadhaar });
                        this.props.setStep(CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_PERMANENT);
                    } else if (kycData.dobCompare && kycData.nameScore < 70) {
                        /////////show swal for big mismatching in name/////////


                        let formData = {
                            panName: kycData.panName,
                            aadhaarName: r?.data.data?.responseData?.result?.dataFromAadhaar?.name ? r.data.data.responseData.result.dataFromAadhaar.name : "",
                            loanId: decryptedData.loanId
                        }

                        Swal.fire({
                            icon: "warning",
                            title: `The Aadhar Name : ${formData.aadhaarName} and PAN Name : ${formData.panName} doesn't match with each other.Do you want to continue?`,
                            showCancelButton: true,
                            confirmButtonText: "Yes",
                            confirmButtonColor: "#d63031",
                            cancelButtonColor: "#2e0080",
                            cancelButtonText: "No"
                        }).then((res) => {
                            if (res.isConfirmed) {
                                formData.approve = true;
                                this.props.nstpRevolt(formData, this.callbackNstpRevolt)
                            }

                            else if (res.isDismissed) {
                                formData.approve = false;
                                this.props.nstpRevolt(formData, this.callbackNstpRevolt)
                            }
                        });
                    } else {
                        /////////show swal for dob mismatching///////
                        Swal.fire({
                            position: "center",
                            icon: "warning",
                            title: "The date of birth provided does not match the records associated with the PAN.",
                            showConfirmButton: false,
                            timer: 1800,
                        });
                    }
                }
                else {

                    this.props.history.push({
                        pathname: PATH.PRIVATE.LOAN_APP_FAILED,
                        state: { bike: this.props.location.state.bike, failedMessage: kycData?.message ? kycData.message : "We have carefully reviewed your KYC application, but unfortunately, we are unable to proceed with your account opening due to the information provided not meeting our requirements." },
                    });
                }
            } else {
                throw new Error(r.data.message);
            }
        } catch (e) {
            let r = res;
            this.setState({ loading: false, otp: "" });
            Swal.fire({
                icon: "warning",
                title: "Oops...",
                text: r.data?.message,
            });
        }
    };


    callbackNstpRevolt = (res) => {
        console.log(this.props.validateKycStatus)
        if (res.data.success) {
            let data = res.data.data;
            if (data.approve) {
                this.props?.setpLData({ ...this.props.pLData, AadhaarDetails: this.props.validateKycStatus?.responseData?.result?.dataFromAadhaar })
                this.props?.setStep(CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_PERMANENT)
            } else {
                this.setState({
                    formFieldSelect: "aadhar",
                    otpSeconds: 40,
                    showOTPField: false,
                    showSubmitAadharButton: true,
                    aadhar: "",
                    showResendOTPSection: false,
                    loading: false,
                    showCounter: true,
                    showSubmitOTPButton: false,
                    otp: "",
                    bank: {},
                    terms: false,
                })
            }
        } else {
            Swal.fire({
                icon: "warning",
                title: "Oops...",
                text: res.data?.message ? res.data.message : "Some error occured",
            });
        }
    }

    setPageLayout = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
    };

    getCurrentPosition() {
        return new Promise((res, rej) => {
            navigator.geolocation.getCurrentPosition(res, rej);
        });
    }

    getGeoLocation = async () => {
        try {
            let cord = await this.getCurrentPosition();
            cord && this.setState({ geoLocation: cord });
        } catch (e) {
        }
    };
    handleAadharInput = (e) => {
        const inputVal = e.target.value.replace(/ /g, "");
        let inputNumbersOnly = inputVal.replace(/\D/g, "");

        if (inputNumbersOnly.length > 12) {
            inputNumbersOnly = inputNumbersOnly.substr(0, 12);
        }
        const splits = inputNumbersOnly.match(/.{1,4}/g);

        let spacedNumber = "";
        if (splits) {
            spacedNumber = splits.join(" ");
        }
        this.setState({
            aadhar: spacedNumber
        });
    };

    handleCheckBoxChange = () => {
        let mobile = localStorage.getItem("mobilenumber");
        let { loanName } = decryptStore(mobile);
        const formData = {
            consentName: "CONSENT_AADHAAR",
            consentType: "CB",
            consentStatus: "true",
            accountName: localStorage.getItem("accsfid"),
            loanApplicationName: this.state.bank ? this.state.bank.loanName : loanName,
            platform: getOS() === "ios"
                ? "web_ios"
                : getOS() === "android"
                    ? "web_android"
                    : "web",
        };
        this.props.loadConsents(formData, this.consentCallback);
    };
    consentCallback = (res) => {
        if (res) {
            this.setState({
                terms: true,
            });
        }
    };

    render() {

        return (
            <>
                {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
                <section className={`${this.props.state?.bike?.manufacturer__c === "REVOLT" ? null : "bs - main - section"} AddharDetails`}>
                    <Container>
                        <Row>
                            {this.props.state?.bike?.manufacturer__c === "REVOLT" ?
                                null :
                                <Col xs={12} sm={3}>
                                    {" "}
                                    <LeftMenuDecider activeStep={this.state.stepperStep} />
                                </Col>}
                            <Col xs={12} sm={12}>
                                {this.state.loading || this.props.loadingNstpRevolt ? <BackDropComponent /> : ""}
                                <Card>
                                    <Card.Header className="text-center">
                                        <h5>Get Quick KYC</h5>
                                    </Card.Header>

                                    <Card.Body>
                                        <div>
                                            <img
                                                src={AADHAR_PHOTO}
                                                alt={"aadhar_photo"}
                                                className="aadharPhoto"
                                            />
                                        </div>
                                        <Form>
                                            <div className="form-group">
                                                <label htmlFor={"Enter Aadhaar Card No."}>
                                                    Enter Aadhaar Card No.
                                                    <span style={{ color: "#FF4C30" }}>*</span>
                                                </label>
                                                <input
                                                    className="form-control"
                                                    placeholder="xxxx xxxx xxxx"
                                                    value={this.state.aadhar}
                                                    onKeyPress={this.handleAadharInput}
                                                    onChange={this.handleAadharInput}
                                                    autoFocus={this.state.formFieldSelect === "aadhar"}
                                                />
                                            </div>
                                            <div className="aadhar_check_box">
                                                <div className="form-check">
                                                    <input

                                                        type="checkbox"
                                                        name="checkedG"
                                                        id="checkedG"
                                                        onChange={this.handleCheckBoxChange}
                                                        checked={this.state.terms}
                                                    />
                                                    {/* <label
                                                    className="form-check-label"
                                                    htmlFor="checkedG"

                                                >
                                                    By continuing, I authorize Credit Saison on wefin to fetch my Aadhaar XML record including KYC information through web.
                                                </label> */}
                                                </div></div>

                                            {this.state.showOTPField && (
                                                <>
                                                    <div className="LoginFormFields aadharFormFields">
                                                        <div className="form-group text-center">
                                                            <input
                                                                type={"password"}
                                                                placeholder="******"
                                                                value={this.state.otp}
                                                                onChange={(e) => {
                                                                    if (reg.test(e.target.value) === true) {
                                                                        this.setState({ otp: e.target.value });

                                                                    }
                                                                }}
                                                                className="addharOtpField"
                                                                name="addharOtpField"
                                                                autoFocus={this.state.formFieldSelect === "otp"}
                                                                maxLength="6"
                                                            />
                                                        </div>
                                                    </div>
                                                    <Row>
                                                        <Col sm={12} className={"text-center"}>
                                                            <div className="bsAadharResendOtp">
                                                                {this.state.showCounter && (
                                                                    <>
                                                                        <p>
                                                                            {`We have sent you a 6 digit verification code on your registered mobile number.`}

                                                                        </p>
                                                                        <br />
                                                                        <h5>
                                                                            Resend OTP in 00:
                                                                            {this.state.otpSeconds.toString().length <
                                                                                2
                                                                                ? `0${this.state.otpSeconds}`
                                                                                : this.state.otpSeconds}{" "}
                                                                            secs
                                                                        </h5>
                                                                    </>
                                                                )}

                                                                {this.state.showResendOTPSection && (
                                                                    <>
                                                                        <button
                                                                            disabled={this.state.aadhar.length !== 14}
                                                                            type="submit"
                                                                            onClick={this.resendOTP}
                                                                            variant="contained"
                                                                            className="nextSmallButton"
                                                                        >
                                                                            Resend OTP
                                                                        </button>
                                                                    </>
                                                                )}
                                                            </div>
                                                        </Col>
                                                    </Row>
                                                </>
                                            )}

                                            <Row>
                                                <Col sm={12} className="text-center">
                                                    {this.state.showSubmitAadharButton && (
                                                        <button
                                                            disabled={this.state.aadhar.length !== 14}
                                                            type="submit"
                                                            onClick={this.submitAadhar}
                                                            variant="contained"
                                                            className="nextButton"

                                                        >
                                                            Next
                                                        </button>

                                                    )}
                                                    {this.state.showSubmitOTPButton && (

                                                        <button
                                                            type="submit"
                                                            onClick={this.submitOTP}
                                                            variant="contained"
                                                            className="nextButton"
                                                        >
                                                            Submit OTP
                                                        </button>
                                                    )}
                                                </Col>
                                            </Row>
                                        </Form>
                                    </Card.Body>
                                </Card>
                            </Col>
                        </Row>
                    </Container>
                </section>
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    // kycStatus: getKycStatus(state).kycStatus,
    loadingNstpRevolt: nstpActions(state).loadingNstpRevolt,
    validateKycStatus: getKycStatus(state).validateKycStatus
});
const mapDispatchToProps = (dispatch) => ({
    validateAadhar: (params, callback) => dispatch(validateAadhar(params, callback)),
    nstpRevolt: (params, callback) => dispatch(nstpRevolt(params, callback)),
});
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Aadhar));
