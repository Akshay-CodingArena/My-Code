import React, { Component } from "react";
import { connect } from "react-redux";
import { encryptStore } from "../../../Utils/store";
import { ReactComponent as ArrowForwardIosIcon } from "../../../include/assets/buttonArrow.svg";
import { withRouter } from "react-router";
import BackDropComponent from "../../../common/BackDropComponent";
import { getTwoWheeler, loadTwList } from "../../../store/twoWheeler";
import LocationDropDown from "../../../common/LocationDropDown.js";
import TopNavBar from "../../../common/TopNavBar";
import { numberFormat } from "../../../Utils/numberFormat";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import PATH from "../../../paths/Paths";
import CreditTopNavBar from "../../../common/creditTopNav";

class TwVariants extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        sfid: 'a0cC6000000CmAhIAK'
      },
      pin: "",
      city: "",
      pinError: "",
    };
  }
  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    let mobile = localStorage.getItem("mobilenumber");
    const cityname = localStorage.getItem("city");
  };
  __handlePinCode = (e) => {
    e.preventDefault();
    if (e.target.value.length === 6) {
      let mobile = localStorage.getItem("mobilenumber");
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callBackPin);
    }
  };
  callBackPin = (res) => {
    if (res) {
      if (!res.data.success) {
        this.setState({ pinError: res.data.message });
      } else {
        this.setState({
          pin: res.data.data.pincode,
          city: res.data.data.cityname,
        });
        localStorage.setItem("city", res.data.data.cityname);
        localStorage.setItem("pin", res.data.data.pincode);
      }
    }
  };
  componentDidUpdate = (prevProps, prevState) => {
    if (prevState.city !== this.state.city) {
      let mobile = localStorage.getItem("mobilenumber");
      document.body.classList.remove("variantScroll");
      document.body.classList.add("TwScrool");
      this.props.loadTwList({
        mobile: mobile,
        cityName: this.state.city,
        search: this.props.match.params.name.split("-").join(" "),
      });
    }
  };
  getTwDetail = async (name, data) => {
    this.props.history?.push({ pathname: PATH.PUBLIC.PERSONAL_DETAIL, state: data })
  };

  getTwVariant = async (name, product, data) => {
    this.props.history.push(
      `${PATH.PRIVATE.TWO_WHEELER_VARIANT}/${product
        .split(/\s/)
        .join("-")}/${name.split(/\s/).join("-")}`
    );
    this.setState({ data: data });
  };
  addDefaultSrc = (ev) => {
    ev.target.src = "/noBike.png";
  };
  render() {
    const { twList, loading, loadingPin } = {
      loadingPin: false,
      loading: false,
      twList: [{
        "city": "DELHI",
        "sfid": "a0cC6000000CmAhIAK",
        "brand__c": "20670",
        "model__c": "RV400",
        "logo__c": null,
        "product__c": "RV400",
        "product_sku__c": "3121691",
        "asset_group__c": "759",
        "manufacturer__c": "REVOLT",
        "name": "T-3795",
        "engine__c": "3.21 KW",
        "power__c": "4 bhp",
        "weight__c": null,
        "onRoadPrice": "138298"
      }]
    };
    var filterData = {};

    this.state.data.sfid
      ? (filterData = twList.filter(
        (lists) => lists.sfid === this.state.data.sfid
      ))
      : (filterData = twList.filter(
        (lists) =>
          lists.model__c ===
          this.props.match.params.product.split("-").join(" ")
      ));

    let S3_URL = process.env.REACT_APP_S3_URL;

    return (
      <div>
        <CreditTopNavBar />
        {loading || loadingPin ? (
          <BackDropComponent />
        ) : (
          <div className="mainTw varaintTw">
            {twList.length > 0 && filterData.length > 0 ? (
              <div className="container">
                {filterData && (
                  <div className="row twVariantTop">
                    <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                      <img
                        src={
                          "https://cloud-cube-jp.s3.ap-northeast-1.amazonaws.com/qncbr3d6hueb/public/Bike/3121691.jpg"
                        }
                        onError={this.addDefaultSrc}
                        className="twVariantImg"
                        alt="bike"
                      />
                    </div>
                    <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                      <div className="variant">
                        <span className="variantTitle">
                          {filterData?.[0]?.model__c}
                        </span>
                        <div className="display-flex variantDetail">
                          <div className="twGrid-engine">
                            Engine {filterData?.[0]?.engine__c}
                          </div>
                          <div className="twGrid-engine">
                            Power {filterData?.[0]?.power__c}
                          </div>
                          <div className="twGrid-engine">
                            {filterData?.[0]?.weight__c}
                          </div>
                        </div>
                        <div className="variantSpanTw variantSpan">
                          Ex Showroom in
                          <LocationDropDown
                            childComponent={
                              <span style={{ fontWeight: "600" }}>
                                {this.state.city
                                  ? this.state.city
                                  : localStorage.getItem("city")}

                                <img
                                  className="variantLocator"
                                  src="/locator2.svg"
                                  alt=""
                                  style={{
                                    cursor: "pointer",
                                    width: "100px",
                                  }}
                                />
                              </span>
                            }
                            __handlePinCode={this.__handlePinCode}
                            pin={this.state.pin}
                            city={this.state.city}
                            pinError={this.state.pinError}
                          />
                          <span className="variantPrice">
                            {numberFormat(filterData?.[0]?.onRoadPrice)} onwards
                          </span>
                        </div>

                        <button
                          className="variantButton"
                          type="submit"
                          onClick={() =>
                            this.getTwDetail(
                              filterData?.[0]?.sfid,
                              filterData?.[0]
                            )
                          }
                        >
                          Apply for Loan{" "}
                          <ArrowForwardIosIcon
                            style={{ width: "15px", height: "15px" }}
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                <div className="twGrid-head headline">Variants</div>
                <ul className="twGrid-head">
                  {twList
                    .slice()
                    .sort((a, b) => a.onRoadPrice - b.onRoadPrice)
                    .map((e, i) => (
                      <li
                        className={
                          filterData?.[0]?.sfid === e.sfid
                            ? "twVariant-li variant-selected"
                            : "twVariant-li"
                        }
                        key={i}
                        onClick={() =>
                          this.getTwVariant(e.model__c, e.product__c, e)
                        }
                      >
                        <div className="display-flex">
                          <span className="variant-li">
                            <div className="variantModel">{e.model__c}</div>
                            <div className="display-flex">
                              <div className="twGrid-engine twVariant-spec">
                                Engine {e.engine__c}
                              </div>
                              <div className="twGrid-engine twVariant-spec">
                                Power {e.power__c}
                              </div>
                              <div className="twGrid-engine twVariant-spec">
                                {e.weight__c}
                              </div>
                            </div>
                            <span className="variantPrice-1">
                              Ex Showroom in
                              <p className="variantLocation-1">
                                {this.state.city
                                  ? this.state.city
                                  : localStorage.getItem("city")}
                              </p>
                              <p className="variantPrice variantFont">
                                {numberFormat(e.onRoadPrice)} onwards
                              </p>
                            </span>
                          </span>
                        </div>
                      </li>
                    ))}
                </ul>
              </div>
            ) : (
              <div className="mainTw">
                <div className="container">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="twVariantTop noRecoardFound">
                        <div>
                          Dear Customer, Our Service are not available for this
                          Location, we will update you soon.
                        </div>
                        <div
                          className="variant"
                          style={{ paddingTop: "0px", paddingBottom: "0px" }}
                        >
                          <span
                            className="variantSpan"
                            style={{ paddingTop: "0px", paddingBottom: "0px" }}
                          >
                            <p className="variantLocation">
                              <LocationDropDown
                                childComponent={
                                  <span>
                                    {localStorage.getItem("city")}

                                    <img
                                      className="variantLocator"
                                      src="/locator2.svg"
                                      alt=""
                                      style={{ cursor: "pointer" }}
                                    />
                                  </span>
                                }
                                __handlePinCode={this.__handlePinCode}
                                pin={this.state.pin}
                                city={this.state.city}
                                pinError={this.state.pinError}
                              />
                            </p>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({

  loading: getTwoWheeler(state).loading,
  pincode: getpinCode(state).pincode,
  loadingPin: getpinCode(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
  loadTwList: (params) => dispatch(loadTwList(params)),
  loadPinCode: (params, callBack) => dispatch(loadPinCode(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TwVariants)
);
