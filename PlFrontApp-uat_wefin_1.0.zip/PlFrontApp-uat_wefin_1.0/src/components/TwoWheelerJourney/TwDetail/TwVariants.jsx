import React, { Component } from "react";
import { connect } from "react-redux";
import { encryptStore } from "../../../Utils/store";
import { ReactComponent as ArrowForwardIosIcon } from "../../../include/assets/buttonArrow.svg";
import { withRouter } from "react-router";
import BackDropComponent from "../../../common/BackDropComponent";
import { getTwoWheeler, loadTwList } from "../../../store/twoWheeler";
import LocationDropDown from "../../../common/LocationDropDown.js";
import TopNavBar from "../../../common/TopNavBar";
import { numberFormat } from "../../../Utils/numberFormat";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import PATH from "../../../paths/Paths";
import ASMNavBar from "../../ASM/ASMNavBar";
import {
  getApplyLoan,
} from "../../../store/applyLoan";

import {
  getExperian,
  loadExperianCheck
} from "../../../store/experian";
import { getAccount } from "../../../store/account";
class TwVariants extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      pin: "",
      city: "",
      pinError: "",
    };
  }
  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    let mobile = localStorage.getItem("mobilenumber");
    const cityname = localStorage.getItem("city");
    this.props.loadTwList({
      mobile: mobile,
      cityName: cityname,
      search: this.props.match.params.name.split("-").join(" "),
    });

    let formData = {
      isExperian: true,
      mobile: mobile
    };
    this.props.loadExperianCheck(formData, this.callbackCheck);
  };
  callbackCheck = (res) => {

  }
  __handlePinCode = (e) => {
    e.preventDefault();
    if (e.target.value.length === 6) {
      let mobile = localStorage.getItem("mobilenumber");
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callBackPin);
    }
  };
  callBackPin = (res) => {
    if (res) {
      if (!res.data.success) {
        this.setState({ pinError: res.data.message });
      } else {
        this.setState({
          pin: res.data.data.pincode,
          city: res.data.data.cityname,
        });
        localStorage.setItem("state", res.data.data.statename);
        localStorage.setItem("city", res.data.data.cityname);
        localStorage.setItem("pin", res.data.data.pincode);
      }
    }
  };
  componentDidUpdate = (prevProps, prevState) => {
    if (prevState.city !== this.state.city) {
      let mobile = localStorage.getItem("mobilenumber");
      document.body.classList.remove("variantScroll");
      document.body.classList.add("TwScrool");
      this.props.loadTwList({
        mobile: mobile,
        cityName: this.state.city,
        search: this.props.match.params.name.split("-").join(" "),
      });
    }
  };
  getTwDetail = async (name, data) => {
    let mobile = localStorage.getItem("mobilenumber");
    if (name) {
      gaLogEvent(CONSTANTS.GA_EVENTS.TW_BIKE_SELECTED);
      let storeData = {
        twMasterSfid: name,
        manufacturer: data.manufacturer__c
      };
      encryptStore(mobile, storeData);
      let userData = this.props.customerDetails;

      ///////it means vo pan verified h//////

      if (userData.pan_verified__c && localStorage.getItem("isASM")) {
        let experianData = this.props.experianCheck;
        if (!experianData?.moneyPlusCreditProfileCheck) {
          //Testing code
          // console.log(this.props.maxDpPercent)
          // this.props.history.push(
          //   {
          //     pathname: `${PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS}`,
          //     state: {
          //       bike: data, appliedData:
          //       {
          //         maxDpPercent: this.props.maxDpPercent
          //       }
          //     }
          //   });
          //Testing Code End

          let failedMessage = experianData?.hasOwnProperty("moneyPlusCreditProfileCheck") ? experianData?.moneyPlusCreditProfileCheckMessage : "Consumer record not found";

          if (experianData?.experianData?.data?.[0]?.bureau_score === -1) {
            failedMessage = "Unable able to fetch your Credit Score.";
          }
          this.props.history.push({
            pathname: PATH.PRIVATE.LOAN_APP_FAILED,
            state: { bike: data, failedMessage: failedMessage },
          });
        }
        else {
          console.log(this.props.maxDpPercent)
          this.props.history.push(
            {
              pathname: `${PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS}`,
              state: {
                bike: data, appliedData:
                {
                  maxDpPercent: this.props.maxDpPercent
                }
              }
            });
        }
      } else {
        this.props.history.push({
          pathname: PATH.PRIVATE.PAN_VERIFY,
          state: {
            bike: data, appliedData:
            {
              maxDpPercent: this.props.maxDpPercent
            }
          },
        });
      }
    }
  };

  getTwVariant = async (name, product, data) => {
    this.props.history.push(
      `${PATH.PRIVATE.TWO_WHEELER_VARIANT}/${product
        .split(/\s/)
        .join("-")}/${name.split(/\s/).join("-")}`
    );
    this.setState({ data: data });
  };
  addDefaultSrc = (ev) => {
    ev.target.src = "/noBike.png";
  };
  render() {
    const { twList, loading, loadingPin } = this.props;
    var filterData = {};

    this.state.data.sfid
      ? (filterData = twList.filter(
        (lists) => lists.sfid === this.state.data.sfid
      ))
      : (filterData = twList.filter(
        (lists) =>
          lists.model__c ===
          this.props.match.params.product.split("-").join(" ")
      ));

    let S3_URL = process.env.REACT_APP_S3_URL;

    return (
      <div>
        {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
        {loading || loadingPin || this.props.loadingCheck ? (
          <BackDropComponent />
        ) : (
          <div className="mainTw varaintTw">
            {twList.length > 0 && filterData.length > 0 ? (
              <div className="container">
                {filterData && (
                  <div className="row twVariantTop">
                    <div className="col-12 col-sm-12 col-md-6 col-lg-5">
                      <img
                        src={
                          filterData.length > 0 &&
                            filterData?.[0].product_sku__c
                            ? `${S3_URL}${filterData?.[0]?.product_sku__c}.jpg`
                            : "/noBike.png"
                        }
                        onError={this.addDefaultSrc}
                        className="twVariantImg"
                        alt="bike"
                      />
                    </div>
                    <div className="col-12 col-sm-12 col-md-6 col-lg-7">
                      <div className="variant">
                        <span className="variantTitle">
                          {filterData?.[0]?.model__c}
                        </span>
                        <div className="display-flex variantDetail">
                          <div className="twGrid-engine">
                            Engine {filterData?.[0]?.engine__c}
                          </div>
                          <div className="twGrid-engine">
                            Power {filterData?.[0]?.power__c}
                          </div>
                          <div className="twGrid-engine">
                            {filterData?.[0]?.weight__c}
                          </div>
                        </div>
                        {/* <div>{filterData?.[0].isCharger ? <div >Charger Price(Including 5% GST)  - {numberFormat(filterData?.[0]?.chargerPrice)}</div> : null}</div> */}
                        <div className="variantSpanTw variantSpan">
                          <div className="variantPrice">
                            {filterData?.[0]?.product__c === "RV400" ? numberFormat(filterData[0]?.onRoadPrice) : numberFormat(parseInt(filterData[0]?.bikeshowroomprice) + parseInt(filterData[0]?.chargerPrice))} {filterData?.[0]?.manufacturer__c === "REVOLT" ? "" : "onwards"}
                          </div>
                          <div className="bikePriceBlock"><span> {filterData?.[0]?.manufacturer__c === "REVOLT" ? "On Road Price*" : "Ex Showroom in"}</span>  <LocationDropDown
                            childComponent={
                              <span style={{ fontWeight: "600" }}>
                                {this.state.city
                                  ? this.state.city
                                  : localStorage.getItem("city")}

                                <img
                                  className="variantLocator"
                                  src="/locator2.svg"
                                  alt=""
                                  style={{
                                    cursor: "pointer",
                                    width: "20",
                                  }}
                                />
                              </span>
                            }
                            __handlePinCode={this.__handlePinCode}
                            pin={this.state.pin}
                            city={this.state.city}
                            pinError={this.state.pinError}
                          /></div>
                          {filterData?.[0].isCharger ? <div className="charger_price">*The price is inclusive of charger worth  {numberFormat(filterData?.[0]?.chargerPrice)}</div> : null}
                        </div>

                        {(filterData?.[0]?.model__c.includes("BAJAJ PLATINA") || filterData?.[0]?.model__c.includes("BAJAJ CT") || filterData?.[0]?.model__c.includes("BAJAJ PULSAR 125")) ? <div>
                          <p className="text-danger mb-1">Exclusive Offer Alert!</p>
                          <em className="fst-italic" style={{ fontWeight: '500' }}>{`Down Payment of just Rs. ${filterData?.[0]?.model__c.includes("BAJAJ PLATINA") ? '1,999' : ''} ${filterData?.[0]?.model__c.includes("BAJAJ CT") ? '999' : ''} ${filterData?.[0]?.model__c.includes("BAJAJ PULSAR") ? '2,999' : ''} ! Don't miss out on this amazing opportunity, grab it now and ride away with your dream bike!`}</em>
                          <p className="text-success mt-1">Hurry Up ! Offer valid until 30th June 2023.</p>
                        </div> : ""}

                        <button
                          className="variantButton"
                          type="submit"
                          onClick={() =>
                            this.getTwDetail(
                              filterData?.[0]?.sfid,
                              filterData?.[0]
                            )
                          }
                        >
                          Apply for Loan{" "}
                          <ArrowForwardIosIcon
                            style={{ width: "15px", height: "15px" }}
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                <div className="twGrid-head headline">Variants</div>
                <ul className="twGrid-head">
                  {twList
                    .slice()
                    .sort((a, b) => a.onRoadPrice - b.onRoadPrice)
                    .map((e, i) => (
                      <li
                        className={
                          filterData?.[0]?.sfid === e.sfid
                            ? "twVariant-li variant-selected"
                            : "twVariant-li"
                        }
                        key={i}
                        onClick={() =>
                          this.getTwVariant(e.model__c, e.product__c, e)
                        }
                      >
                        <div className="display-flex">
                          <span className="variant-li">
                            <div className="variantModel">{e.model__c}</div>
                            <div className="display-flex">
                              <div className="twGrid-engine twVariant-spec">
                                Engine {e.engine__c}
                              </div>
                              <div className="twGrid-engine twVariant-spec">
                                Power {e.power__c}
                              </div>
                              <div className="twGrid-engine twVariant-spec">
                                {e.weight__c}
                              </div>
                            </div>
                            <span className="variantPrice-1">
                              {e.manufacturer__c === "REVOLT" ? "On Road Price" : "Ex Showroom in"}
                              <p className="variantLocation-1">
                                {this.state.city
                                  ? this.state.city
                                  : localStorage.getItem("city")}
                              </p>
                              <p className="variantPrice variantFont">
                                {e.product__c === "RV400" ? numberFormat(e.onRoadPrice) : numberFormat(parseInt(e.bikeshowroomprice) + parseInt(e.chargerPrice))} {e.manufacturer__c === "REVOLT" ? "" : "onwards"}
                              </p>
                            </span>
                          </span>
                        </div>
                      </li>
                    ))}
                </ul>
              </div>
            ) : (
              <div className="mainTw">
                <div className="container">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="twVariantTop noRecoardFound">
                        <div>
                          Dear Customer, Our Service are not available for this
                          Location, we will update you soon.
                        </div>
                        <div
                          className="variant"
                          style={{ paddingTop: "0px", paddingBottom: "0px" }}
                        >
                          <span
                            className="variantSpan"
                            style={{ paddingTop: "0px", paddingBottom: "0px" }}
                          >
                            <p className="variantLocation">
                              <LocationDropDown
                                childComponent={
                                  <span>
                                    {localStorage.getItem("city")}

                                    <img
                                      className="variantLocator"
                                      src="/locator2.svg"
                                      alt=""
                                      style={{ cursor: "pointer" }}
                                    />
                                  </span>
                                }
                                __handlePinCode={this.__handlePinCode}
                                pin={this.state.pin}
                                city={this.state.city}
                                pinError={this.state.pinError}
                              />
                            </p>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  maxDpPercent: getTwoWheeler(state).maxDpPercent,
  twList: getTwoWheeler(state).twList,
  loading: getTwoWheeler(state).loading,
  pincode: getpinCode(state).pincode,
  loadingPin: getpinCode(state).loading,
  applyLoan: getApplyLoan(state).applyLoan,
  loadingCheck: getExperian(state).loadingCheck,
  experianCheck: getExperian(state).experianCheck,
  customerDetails: getAccount(state).customerDetail
});

const mapDispatchToProps = (dispatch) => ({
  loadTwList: (params) => dispatch(loadTwList(params)),
  loadPinCode: (params, callBack) => dispatch(loadPinCode(params, callBack)),
  loadExperianCheck: (params, callBack) => dispatch(loadExperianCheck(params, callBack))
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TwVariants)
);