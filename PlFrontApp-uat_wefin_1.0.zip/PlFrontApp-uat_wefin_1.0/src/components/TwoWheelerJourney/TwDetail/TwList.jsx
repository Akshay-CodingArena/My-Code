import React, { Component } from "react";
import { connect } from "react-redux";
import { components } from "react-select";
import { numberFormat } from "../../../Utils/numberFormat";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { Container, Row, Col, Card } from "react-bootstrap";
import twList1 from "../../../include/assets/twoWheelerLogo/twList1.svg";
import twList2 from "../../../include/assets/twoWheelerLogo/twList2.svg";
import twList3 from "../../../include/assets/twoWheelerLogo/twList3.svg";
import twList4 from "../../../include/assets/twoWheelerLogo/twList4.svg";
import twList6 from "../../../include/assets/twoWheelerLogo/twList6.svg";
import twList5 from "../../../include/assets/twoWheelerLogo/layer1.svg";
import royalLogo from "../../../include/assets/twoWheelerLogo/royal.png";
import yahamaLogo from "../../../include/assets/twoWheelerLogo/yahama.svg";
import ktmLogo from "../../../include/assets/twoWheelerLogo/ktm.svg";
import mahindraLogo from "../../../include/assets/twoWheelerLogo/mahindra.svg";
import JawaLogo from "../../../include/assets/twoWheelerLogo/jawa.png";
import olaLogo from "../../../include/assets/twoWheelerLogo/ola.svg";
import atherLogo from "../../../include/assets/twoWheelerLogo/ather.png";
import bgaussLogo from "../../../include/assets/twoWheelerLogo/bgauss.png";
import dskLogo from "../../../include/assets/twoWheelerLogo/dsk.png";
import atulLogo from "../../../include/assets/twoWheelerLogo/atul.png";
import ducatiLogo from "../../../include/assets/twoWheelerLogo/ducati.png";
import heroelcLogo from "../../../include/assets/twoWheelerLogo/heroelc.png";
import husqvarnaLogo from "../../../include/assets/twoWheelerLogo/husqvarna.png";
import lmlLogo from "../../../include/assets/twoWheelerLogo/lml.png";
import indianmotorLogo from "../../../include/assets/twoWheelerLogo/indianmotor.png";
import okinawaLogo from "../../../include/assets/twoWheelerLogo/okinawa.png";
import triumphLogo from "../../../include/assets/twoWheelerLogo/triumph.png";
import kenitecLogo from "../../../include/assets/twoWheelerLogo/kenitec.png";
import regalLogo from "../../../include/assets/twoWheelerLogo/regal.svg";
import ampreLogo from "../../../include/assets/twoWheelerLogo/ampre.png";
import harleyLogo from "../../../include/assets/twoWheelerLogo/harley.svg";
import kawasakiLogo from "../../../include/assets/twoWheelerLogo/kawasaki.png";
import unitedLogo from "../../../include/assets/twoWheelerLogo/united.svg";
import BMWLogo from "../../../include/assets/twoWheelerLogo/bmw.png";
import piaggioLogo from "../../../include/assets/twoWheelerLogo/piaggio.png";
import BikeBanner from "../../../include/assets/bike-img.png";
import HondaBanner from "../../../include/assets/honda-bike.png";
import CreditFooter from "../../cibilFlow/footer";
import { ReactComponent as SearchIcon } from "../../../include/assets/twoWheelerLogo/search.svg";
import BackDropComponent from "../../../common/BackDropComponent";
import { withRouter } from "react-router";
import { getTwoWheeler, loadTwList } from "../../../store/twoWheeler";
import TwoWheelerTopBar from "../../../common/twoWheelerTopBar";
import { selectStyles } from "../../common/textStyle";
import {
  getpinCode,
  loadPinCode,
  loadGeoLocation,
} from "../../../store/pincode";
import Swal from "sweetalert2";
import ReactSelect from "react-select";
import PATH from "../../../paths/Paths";
const CaretDownIcon = () => {
  return <SearchIcon />;
};

const DropdownIndicator = (props) => {
  return (
    <components.DropdownIndicator {...props}>
      <CaretDownIcon />
    </components.DropdownIndicator>
  );
};
class TwList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pin: "",
      city: "",
      pinError: "",
      geoError: "",
    };
  }

  componentDidMount = () => {
    window.scrollTo(0, 0);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        let mobile = localStorage.getItem("mobilenumber");
        this.getGeoLocation(
          position.coords.latitude,
          position.coords.longitude,
          mobile
        );
      },
      (error) => {
        if (error) {
          Swal.fire({
            position: "center",
            icon: "warning",
            title: "Please allow your location !!",
            showConfirmButton: true,
          }).then(() => {
            this.props.history.push(PATH.PRIVATE.PRODUCTS);
          });
        }
      }
    );
    if (this.state.city) {
      let mobile = localStorage.getItem("mobilenumber");
      this.props.loadTwList({ mobile: mobile, cityName: this.state.city });
    }
  };

  getGeoLocation = (lat, lng, mobile) => {
    if (lat && lng) {
      const formData = "lat=" + lat + "&lng=" + lng + "&mobile=" + mobile;
      this.props.loadGeoLocation(formData, this.callBack);
    }
  };
  callBack = (res) => {
    if (res) {
      if (!res.data.success) {
        this.setState({ geoError: "Enter Your Pincode" });
      } else {
        this.setState({
          pin: res.data.locInfo.pincode,
          city: res.data.locInfo.city,
          geoError: "",
        });
        localStorage.setItem("state", res.data.locInfo.state);
        localStorage.setItem("city", res.data.locInfo.city);
        localStorage.setItem("pin", res.data.locInfo.pincode);
      }
    }
  };

  __handlePinCode = (e) => {
    e.preventDefault();
    if (e.target.value.length === 6) {
      let mobile = localStorage.getItem("mobilenumber");
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callBackPin);
    }
  };
  callBackPin = (res) => {
    if (res) {
      if (!res.data.success) {
        this.setState({ pinError: res.data.message });
      } else {
        this.setState({
          pin: res.data.data.pincode,
          city: res.data.data.cityname,
          geoError: "",
        });
        localStorage.setItem("city", res.data.data.cityname);
        localStorage.setItem("pin", res.data.data.pincode);
      }
    }
  };
  componentDidUpdate = (prevProps, prevState) => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    if (prevState.city !== this.state.city) {
      let mobile = localStorage.getItem("mobilenumber");
      this.props.loadTwList({ mobile: mobile, cityName: this.state.city });
    }
  };
  getTwDetail = (name, product) => {
    this.props.history.push(
      `${PATH.PRIVATE.TWO_WHEELER_VARIANT}/${product
        .split(/\s/)
        .join("-")}/${name.split(/\s/).join("-")}`
    );
  };
  setRevolt = (name, product) => {
    this.props.history.push(
      `${PATH.PRIVATE.TWO_WHEELER_VARIANT}/${name}/${product}`
    );
  };

  OnClick = (name) => {
    this.props.history.push(`${PATH.PRIVATE.TWO_WHEELER_LIST}/${name}`);
  };
  setSearchValue = (listData) => {
    const myArr = listData.split(",");
    const product = myArr[0];
    const name = myArr[2];
    this.props.history.push(
      `${PATH.PRIVATE.TWO_WHEELER_VARIANT}/${product
        .split(/\s/)
        .join("-")}/${name.split(/\s/).join("-")}`
    );
  };
  render() {
    let S3_URL = process.env.REACT_APP_S3_URL;

    const { twList, loading } = this.props.getTwoWheeler;
    const options = {
      loop: false,
      margin: 15,
      nav: true,
      dots: false,
      responsive: {
        0: {
          items: 1,

          dots: false,
        },

        600: {
          items: 2,

          dots: false,
        },

        800: {
          items: 4,
          dots: false,
        },

        1000: {
          items: 4,
        },
      },
    };
    let responseList = twList.filter(
      (lists) =>
        lists.product_sku__c === "3091226" ||
        lists.product_sku__c === "3087481" ||
        lists.product_sku__c === "3091065" ||
        lists.product_sku__c === "3087840" ||
        lists.product_sku__c === "3121691" ||
        lists.product_sku__c === "3088209" ||
        lists.product_sku__c === "3090915" ||
        lists.product_sku__c === "3090904"
    );

    return (
      <>
        <div>
          <TwoWheelerTopBar
            __handlePinCode={this.__handlePinCode}
            pin={this.state.pin}
            city={this.state.city}
            pinError={this.state.pinError}
            geoError={this.state.geoError}
          />
          {/* <div className="LoginLeftProductMenu"></div> */}
          {loading ? <BackDropComponent /> : ""}
          <div>
            <section className="bsBikeBannerTop">
              <Container>
                <a onClick={() => this.setRevolt("REVOLT", "RV400")}>
                  <Card>
                    <Card.Text>
                      <div className="bsBannerTopDetails">
                        <h2>You Choose Your Dream Vehicle</h2>
                        <p>We get you instant Loan</p>
                        <button>Apply Now</button>
                      </div>
                      <figure>
                        <img src={BikeBanner} width="" height="" alt=""></img>
                      </figure>
                    </Card.Text>
                  </Card>
                </a>
              </Container>
            </section>
            <section className="twSearchBar">
              <div className="container">
                <div className="row">
                  <div className="col-sm-12">
                    <div className="text-center">
                      <ReactSelect
                        className="twSearchBarBox"
                        classNamePrefix="select"
                        maxMenuHeight={130}
                        components={{
                          DropdownIndicator,
                          IndicatorSeparator: () => null,
                        }}
                        name="bike"
                        options={
                          twList &&
                          twList.map((item) => ({
                            label: (
                              <div className="twList-label">
                                <span className="twGrid-span">
                                  <div
                                    style={{
                                      fontWeight: "500",
                                      fontSize: "14px",
                                      padding: "5px 0px",
                                      borderBottom: "1px solid #f2f2f2",
                                      width: "100%",
                                    }}
                                    className="twGrid-model"
                                  >
                                    {item.product__c}
                                  </div>
                                </span>
                              </div>
                            ),
                            value:
                              item.product__c +
                              "," +
                              item.manufacturer__c +
                              "," +
                              item.model__c +
                              "," +
                              item.sfid,
                          }))
                        }
                        styles={selectStyles}
                        menuPlacement="bottom"
                        onChange={(e) => this.setSearchValue(e.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="bsBikeSlider">
              <Container>
                <h3>Top Sold Bikes</h3>
                {responseList && (
                  <OwlCarousel
                    key={responseList && responseList.length}
                    {...options}
                  >
                    {responseList.map(
                      (item, i) =>
                        i < 8 && (
                          <Card className="bsBikeSliderBox">
                            <Card.Text className="bsBikeSliderBlock">
                              <figure>
                                <img
                                  onError={this.addDefaultSrc}
                                  src={`${S3_URL}${item.product_sku__c}.jpg`}
                                  alt=""
                                />
                              </figure>
                              <div className="bsBikeSliderDetails">
                                <h4>{item.product__c}</h4>
                                <div>
                                  <span>{item.engine__c}</span>
                                  <span>{item.power__c}</span>
                                  <span>{item.weight__c}</span>
                                </div>
                                <div className="priceTag">
                                  {item.product__c === "RV400" ? numberFormat(item.onRoadPrice) : numberFormat(parseInt(item.bikeshowroomprice) + parseInt(item.chargerPrice))} onwards
                                </div>
                                <div>
                                  <button
                                    onClick={() =>
                                      this.getTwDetail(
                                        item.model__c,
                                        item.product__c
                                      )
                                    }
                                  >
                                    Know More
                                  </button>
                                </div>
                              </div>
                            </Card.Text>
                          </Card>
                        )
                    )}
                  </OwlCarousel>
                )}
              </Container>
            </section>
            <section className="bsBikeBanner">
              <Container>
                <Row>
                  <Col xs={12} sm={6}>
                    <Card className="bg1">
                      <Card.Text>
                        <div className="">
                          <h5>EASY AND QUICK Two-Wheeler</h5>
                          <p>
                            loans Choose your loan from a list of trusted banks
                          </p>
                          <a onClick={() => this.setRevolt("REVOLT", "RV400")}>
                            Apply Now
                          </a>
                        </div>
                        <figure>
                          <img src={BikeBanner} width="" height="" alt=""></img>
                        </figure>
                      </Card.Text>
                    </Card>
                  </Col>
                  <Col xs={12} sm={6}>
                    <Card className="bg2">
                      <Card.Text>
                        <div className="">
                          <h5>PERSONALISED Two Wheeler </h5>
                          <p>
                            Loans Easy apply | Quick disbursal | Paperless
                            process
                          </p>
                          <a onClick={() => this.OnClick("HONDA")}>Apply Now</a>
                        </div>
                        <figure>
                          <img
                            src={HondaBanner}
                            width=""
                            height=""
                            alt=""
                          ></img>
                        </figure>
                      </Card.Text>
                    </Card>
                  </Col>
                </Row>
              </Container>
            </section>
            <section className="twBrandsSlider">
              <div className="container">
                <div className="twBrand">Brands We Support</div>
                <Row>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.setRevolt("REVOLT", "RV400")}
                    >
                      <img
                        src={twList1}
                        className="twBrandLogo"
                        alt={twList6}
                      />
                      <span className="twLogoTxt">REVOLT</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("HONDA")}
                    >
                      <img
                        src={twList6}
                        className="twBrandLogo"
                        alt={twList1}
                      />
                      <span className="twLogoTxt">HONDA</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("TVS")}
                    >
                      <img
                        className="twBrandLogo"
                        src={twList2}
                        alt={twList2}
                      />
                      <span className="twLogoTxt">TVS</span>
                    </div>
                  </Col>

                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("BAJAJ")}
                    >
                      <img
                        className="twBrandLogo"
                        src={twList3}
                        alt={twList3}
                      />
                      <span className="twLogoTxt">BAJAJ</span>
                    </div>
                  </Col>

                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("SUZUKI")}
                    >
                      <img
                        className="twBrandLogo"
                        src={twList5}
                        alt={twList5}
                      />
                      <span className="twLogoTxt">SUZUKI</span>
                    </div>
                  </Col>

                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("HERO")}
                    >
                      <img
                        className="twBrandLogo"
                        src={twList4}
                        alt={twList4}
                      />
                      <span className="twLogoTxt">HERO</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("ROYAL ENFIELD")}
                    >
                      <img
                        className="twBrandLogo"
                        src={royalLogo}
                        alt={"ROYAL ENFIELD"}
                      />
                      <span className="twLogoTxt">ROYAL ENFIELD</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("YAMAHA")}
                    >
                      <img
                        className="twBrandLogo"
                        src={yahamaLogo}
                        alt={"YAMAHA"}
                      />
                      <span className="twLogoTxt">YAMAHA</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("KTM")}
                    >
                      <img className="twBrandLogo" src={ktmLogo} alt={"KTM"} />
                      <span className="twLogoTxt">KTM</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("MAHINDRA")}
                    >
                      <img
                        className="twBrandLogo"
                        src={mahindraLogo}
                        alt={"MAHINDRA"}
                      />
                      <span className="twLogoTxt">MAHINDRA</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("JAWA")}
                    >
                      <img
                        className="twBrandLogo"
                        src={JawaLogo}
                        alt={"JAWA"}
                      />
                      <span className="twLogoTxt">JAWA</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("OLA ELECTRIC")}
                    >
                      <img
                        className="twBrandLogo"
                        src={olaLogo}
                        alt={"OLA ELECTRIC"}
                      />
                      <span className="twLogoTxt">OLA</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("ATHER")}
                    >
                      <img
                        className="twBrandLogo"
                        src={atherLogo}
                        alt={"ATHER ENERGY"}
                      />
                      <span className="twLogoTxt">ATHER ENERGY</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("BGAUSS")}
                    >
                      <img
                        className="twBrandLogo"
                        src={bgaussLogo}
                        alt={"  BGAUSS"}
                      />
                      <span className="twLogoTxt"> BGAUSS</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("DSK BENELLI")}
                    >
                      <img
                        className="twBrandLogo"
                        src={dskLogo}
                        alt={"DSK BENELLI"}
                      />
                      <span className="twLogoTxt"> DSK BENELLI</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("ATUL AUTO")}
                    >
                      <img
                        className="twBrandLogo"
                        src={atulLogo}
                        alt={"ATUL AUTO"}
                      />
                      <span className="twLogoTxt">ATUL AUTO</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("DUCATI")}
                    >
                      <img
                        className="twBrandLogo"
                        src={ducatiLogo}
                        alt={"DUCATI MOTOR"}
                      />
                      <span className="twLogoTxt">DUCATI MOTOR</span>
                    </div>
                  </Col>

                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("HUSQVARNA")}
                    >
                      <img
                        className="twBrandLogo"
                        src={husqvarnaLogo}
                        alt={"HUSQVARNA"}
                      />
                      <span className="twLogoTxt">HUSQVARNA</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("LML")}
                    >
                      <img className="twBrandLogo" src={lmlLogo} alt={"LML"} />
                      <span className="twLogoTxt">LML</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("INDIAN MOTORCYCLES")}
                    >
                      <img
                        className="twBrandLogo"
                        src={indianmotorLogo}
                        alt={"INDIAN MOTORCYCLES"}
                      />
                      <span className="twLogoTxt">INDIAN MOTORCYCLES</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("OKINAWA")}
                    >
                      <img
                        className="twBrandLogo"
                        src={okinawaLogo}
                        alt={"OKINAWA AUTOTECH"}
                      />
                      <span className="twLogoTxt"> OKINAWA AUTOTECH</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("TRIUMPHLES")}
                    >
                      <img
                        className="twBrandLogo"
                        src={triumphLogo}
                        alt={"TRIUMPHLES"}
                      />
                      <span className="twLogoTxt"> TRIUMPHLE</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("HERO ELECTRIC")}
                    >
                      <img
                        className="twBrandLogo"
                        src={heroelcLogo}
                        alt={"HERO ELECTRIC"}
                      />
                      <span className="twLogoTxt"> HERO ELECTRIC</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("KINETIC GEP")}
                    >
                      <img
                        className="twBrandLogo"
                        src={kenitecLogo}
                        alt={"KINETIC GEP"}
                      />
                      <span className="twLogoTxt"> KINETIC GEP</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("REGAL RAPTOR")}
                    >
                      <img
                        className="twBrandLogo"
                        src={regalLogo}
                        alt={" REGAL RAPTOR"}
                      />
                      <span className="twLogoTxt"> REGAL RAPTOR</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("AMPERE VEHICLES")}
                    >
                      <img
                        className="twBrandLogo"
                        src={ampreLogo}
                        alt={" AMPERE VEHICLES"}
                      />
                      <span className="twLogoTxt"> AMPERE VEHICLES</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("HARLEY")}
                    >
                      <img
                        className="twBrandLogo"
                        src={harleyLogo}
                        alt={"HARLEY DAVIDSON"}
                      />
                      <span className="twLogoTxt"> HARLEY DAVIDSON</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("KAWASAKI")}
                    >
                      <img
                        className="twBrandLogo"
                        src={kawasakiLogo}
                        alt={"KAWASAKI MOTORS"}
                      />
                      <span className="twLogoTxt"> KAWASAKI MOTORS</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("UNITED MOTORS")}
                    >
                      <img
                        className="twBrandLogo"
                        src={unitedLogo}
                        alt={"UNITED-MOTORS"}
                      />
                      <span className="twLogoTxt">UNITED MOTORS</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("BMW")}
                    >
                      <img className="twBrandLogo" src={BMWLogo} alt={"BMW"} />
                      <span className="twLogoTxt">BMW</span>
                    </div>
                  </Col>
                  <Col xs={6} sm={4} md={3} lg={2}>
                    <div
                      className="twLogoList"
                      onClick={() => this.OnClick("PIAGGIO")}
                    >
                      <img
                        className="twBrandLogo"
                        src={piaggioLogo}
                        alt={"PIAGGIO"}
                      />
                      <span className="twLogoTxt">PIAGGIO</span>
                    </div>
                  </Col>
                </Row>
              </div>
            </section>
            <section className="bsBikeSlider bsLatestBikes">
              <Container>
                <h3>Latest Bikes</h3>
                {twList && (
                  <OwlCarousel key={twList && twList.length} {...options}>
                    {twList.map(
                      (item, i) =>
                        i < 10 && (
                          <Card className="bsBikeSliderBox">
                            <Card.Text className="bsBikeSliderBlock">
                              <figure>
                                <img
                                  onError={this.addDefaultSrc}
                                  src={`${S3_URL}${item.product_sku__c}.jpg`}
                                  alt=""
                                />
                              </figure>
                              <div className="bsBikeSliderDetails">
                                <h4>{item.product__c}</h4>
                                <div>
                                  <span>{item.engine__c}</span>
                                  <span>{item.power__c}</span>
                                  <span>{item.weight__c}</span>
                                </div>
                                <div className="priceTag">
                                  {item.product__c === "RV400" ? numberFormat(item.onRoadPrice) : numberFormat(parseInt(item.bikeshowroomprice) + parseInt(item.chargerPrice))} onwards
                                </div>
                                <div>
                                  <button
                                    onClick={() =>
                                      this.getTwDetail(
                                        item.model__c,
                                        item.product__c
                                      )
                                    }
                                  >
                                    Know More
                                  </button>
                                </div>
                              </div>
                            </Card.Text>
                          </Card>
                        )
                    )}
                  </OwlCarousel>
                )}
              </Container>
            </section>
          </div>
        </div>
        <CreditFooter />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  getTwoWheeler: getTwoWheeler(state),
  geoLocation: getpinCode(state).geoLocation,
  loadingGeo: getpinCode(state).loadingGeo,
  pincode: getpinCode(state).pincode,
  loading: getpinCode(state).loading,
});
const mapDispatchToProps = (dispatch) => ({
  loadTwList: (params) => dispatch(loadTwList(params)),
  loadPinCode: (params, callBack) => dispatch(loadPinCode(params, callBack)),
  loadGeoLocation: (params, callBack) =>
    dispatch(loadGeoLocation(params, callBack)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(TwList));
