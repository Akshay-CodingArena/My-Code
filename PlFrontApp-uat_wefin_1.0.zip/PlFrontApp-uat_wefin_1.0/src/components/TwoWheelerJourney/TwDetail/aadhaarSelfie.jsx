import { Component } from "react"
import SelfieUpload from "../../PersonalLoanJourney/bankVerification/selfieUpload"
import { getKycStatus } from "../../../store/kyc"
import BackDropComponent from "../../../common/BackDropComponent"
import { withRouter } from "react-router-dom/cjs/react-router-dom"
import { connect } from "react-redux"
class AadhaarSelfie extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (<>
            {this.props.getKycStatus ? <BackDropComponent /> : null}
            <SelfieUpload bike={this.props.location.state.bike} />
        </>)
    }
}



const mapStateToProps = (state) => ({
    getKycStatus: getKycStatus(state).loadingInitiateKyc
});

const mapDispatchToProps = (dispatch) => ({
    uploadAadhaarSelfie: (params, callBack) => dispatch(uploadAadhaarSelfie(params, callBack))
});


export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(AadhaarSelfie)
);
