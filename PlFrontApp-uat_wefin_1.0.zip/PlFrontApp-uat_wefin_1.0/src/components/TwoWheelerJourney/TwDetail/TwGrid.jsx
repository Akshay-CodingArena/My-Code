import React, { Component } from "react";
import { connect } from "react-redux";
import { ReactComponent as ArrowForwardIosIcon } from "../../../include/assets/buttonArrow.svg";
import { withRouter } from "react-router";
import { getTwoWheeler, loadTwList } from "../../../store/twoWheeler";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import BackDropComponent from "../../../common/BackDropComponent";
import TwoWheelerTopBar from "../../../common/twoWheelerTopBar";
import { numberFormat } from "../../../Utils/numberFormat";
import PATH from "../../../paths/Paths";

class TwGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pin: "",
      city: "",
      pinError: "",
      geoError: "",
    };
  }
  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    this.setState({
      city: localStorage.getItem("city"),
      pin: localStorage.getItem("pin"),
    });
    if (localStorage.getItem("city")) {
      let mobile = localStorage.getItem("mobilenumber");
      const cityname = localStorage.getItem("city");
      this.props.loadTwList({
        mobile: mobile,
        cityName: cityname,
      });
    }
  };
  componentDidUpdate = (prevProps, prevState) => {
    if (prevState.city !== this.state.city) {
      let mobile = localStorage.getItem("mobilenumber");
      this.props.loadTwList({ mobile: mobile, cityName: this.state.city });
    }
  };
  __handlePinCode = (e) => {
    e.preventDefault();
    if (e.target.value.length === 6) {
      let mobile = localStorage.getItem("mobilenumber");
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callBackPin);
    }
  };
  callBackPin = (res) => {
    if (res) {
      if (!res.data.success) {
        this.setState({ pinError: res.data.message });
      } else {
        this.setState({
          pin: res.data.data.pincode,
          city: res.data.data.cityname,
          geoError: "",
        });
        localStorage.setItem("city", res.data.data.cityname);
        localStorage.setItem("pin", res.data.data.pincode);
      }
    }
  };
  getTwDetail = (name, product) => {
    this.props.history.push(
      `${PATH.PRIVATE.TWO_WHEELER_VARIANT}/${product
        .split(/\s/)
        .join("-")}/${name.split(/\s/).join("-")}`
    );
  };
  addDefaultSrc = (ev) => {
    ev.target.src = "/noBike.png";
  };
  render() {
    let S3_URL = process.env.REACT_APP_S3_URL;
    const { twList, loading } = this.props;
    let responseList = twList.filter(
      (lists) => lists.manufacturer__c === this.props.match.params.name
    );
    return (
      <div>
        <TwoWheelerTopBar
          __handlePinCode={this.__handlePinCode}
          pin={this.state.pin}
          city={this.state.city}
          pinError={this.state.pinError}
          geoError={this.state.geoError}
        />
        <div className="LoginLeftProductMenu"></div>
        {loading ? (
          <BackDropComponent />
        ) : (
          <div className="container">
            <div className="row">
              <section className="mainTw">
                <div className="container">
                  <h1 className="twGrid-head">
                    {this.props.match.params.name} Two Wheelers
                  </h1>
                  <div className="row">
                    {responseList.length > 0 ? (
                      <div className="col-sm-12">
                        <div className="row twGrid-ul">
                          {responseList.map((e, i) => (
                            <div
                              className="col-sm-12 col-md-12 col-lg-6"
                              key={i}
                            >
                              <div className="row twGrid-li">
                                <div className="col-sm-6 col-md-6 twGrid-span">
                                  <div className="twGrid-model">
                                    <img
                                      onError={this.addDefaultSrc}
                                      src={`${S3_URL}${e.product_sku__c}.jpg`}
                                      alt=""
                                    />

                                    <div>
                                      <p className="twGrid-price">
                                        {e?.product__c === "RV400" ? numberFormat(e?.onRoadPrice) : numberFormat(parseInt(e?.bikeshowroomprice) + parseInt(e?.chargerPrice))} {e?.manufacturer__c === "REVOLT" ? "" : "onwards"}
                                      </p>
                                    </div>
                                  </div>
                                </div>

                                <div className="col-sm-6 col-md-6 twGrid-span">
                                  <div className="twGrid-model">
                                    {e.product__c}
                                  </div>
                                  <div className="display-flex twGridDesc">
                                    <div className="twGrid-engine">
                                      {e.engine__c}
                                    </div>
                                    <div className="twGrid-engine">
                                      {e.power__c}
                                    </div>
                                    <div className="twGrid-engine">
                                      {e.weight__c}
                                    </div>
                                  </div>

                                  <button
                                    className="variantButton"
                                    onClick={() =>
                                      this.getTwDetail(e.model__c, e.product__c)
                                    }
                                  >
                                    Know More{" "}
                                    <ArrowForwardIosIcon
                                      style={{ width: "15px", height: "15px" }}
                                    />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="col-sm-12">
                          <ul className="twGrid-ul notFoundDataBlock">
                            <li className="twGrid-li">
                              <div className="notFoundData">
                                <span className="twGrid-span">
                                  Dear Customer, Our Service are not available
                                  for this Location, we will update you soon.
                                </span>
                              </div>
                            </li>
                          </ul>
                          <div className="text-center">
                            <button
                              type="submit"
                              variant="contained"
                              className="nextButton"
                              style={{ width: "20%" }}
                              onClick={() =>
                                this.props.history.push(
                                  PATH.PRIVATE.TWO_WHEELER
                                )
                              }
                            >
                              Back
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </section>
            </div>
          </div>
        )}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  twList: getTwoWheeler(state).twList,
  loading: getTwoWheeler(state).loading,
  pincode: getpinCode(state).pincode,
  loadingPin: getpinCode(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
  loadTwList: (params) => dispatch(loadTwList(params)),
  loadPinCode: (params, callBack) => dispatch(loadPinCode(params, callBack)),
});
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(TwGrid));
