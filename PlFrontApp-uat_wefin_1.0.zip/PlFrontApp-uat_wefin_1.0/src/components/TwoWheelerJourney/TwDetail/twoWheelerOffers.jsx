import React, { Component } from "react";
import {
  getBankOffer,
  setBankOfferList,
  setIdfcStatus,
} from "../../../store/bankOffer";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { numberFormat } from "../../../Utils/numberFormat";
// import Back from "../../common/back";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import { Container, Row, Col } from "react-bootstrap";
import moment from "moment";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import PlOffer from "../../personalDetail/plOffer";
import PATH from "../../../paths/Paths";
class TwDetail extends Component {
  state = { count: 0 };
  bankOffer = (data) => {
    if (data) {
      let setDetailsData = {
        loanId: data[0].loan_application_id__c,
        loanType: data[0].loan_record_type__c,
        lenderId: data[0].lender_id__c,
        roi: data[0].roi,
        tenure: data[0].tenure,
        mobile: localStorage.getItem("mobilenumber"),
        emi: data[0].emi,
        offerSfid: data[0].offerSfid,
        downPayment: data[0].down_payment__c,
      };
      this.props.setBankOfferList(setDetailsData, this.callBack);
    }
  };
  callBack = (res) => { };

  componentDidUpdate = (prevProps, prevState) => {
    if (this.state.count !== prevState.count && this.state.count <= 20) {
      setTimeout(() => {
        this.getLoanStatus(JSON.parse(localStorage.getItem("loanDetail")));
      }, 30000);
    }
  };

  componentDidMount = () => {
    this.getLoanStatus(JSON.parse(localStorage.getItem("loanDetail")));
  };

  getLoanStatus = (data) => {
    if (data && data.length > 0) {
      let setDetailsData = {
        loanName: data[0].loanName,
        lenderName: data[0].lenderName,
        offerSfid: data[0].offerSfid,
        offerId: data[0].offerId,
      };
      this.props.setIdfcStatus(setDetailsData, this.callBackIdfc);
    }
  };
  callBackIdfc = (res) => {
    if (res) {
      if (res.data.loanStage === CONSTANTS.LOAN_STAGE.DECLINED) {
        gaLogEvent(CONSTANTS.GA_EVENTS.TW_DECLINED);
      } else if (res.data.loanStage === CONSTANTS.LOAN_STAGE.HARD_APPROVED) {
        gaLogEvent(CONSTANTS.GA_EVENTS.TW_HARD_APPROVED);
      } else if (res.data.loanStage === CONSTANTS.LOAN_STAGE.SOFT_APPROVED) {
        gaLogEvent(CONSTANTS.GA_EVENTS.TW_SOFT_APPROVED);
      } else if (res.data.loanStage === CONSTANTS.LOAN_STAGE.DISBURSEMENT) {
        gaLogEvent(CONSTANTS.GA_EVENTS.TW_DISBURED);
      }
      if (res.data.status__c === "Active") {
        this.bankOffer(JSON.parse(localStorage.getItem("loanDetail")));
      }
      if (res.data.success === true) {
        this.setState({ count: this.state.count + 1 });
      }
    }
  };

  callApproval = (res) => { };
  render() {
    // let str = this.props.location && this.props.location.state;
    const { loanStage, bankSubStatus } = this.props.setIdfc;

    const storedData = JSON.parse(localStorage.getItem("loanDetail"));
    return (
      <>
        <div
          style={{
            background: "#e5f6fd",
            height: "100 vh",
            width: " 5%",
            "overflow-y": "hidden",
          }}
        ></div>
        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col xs={12} sm={3}>
                <LeftMenuDecider activeStep={3} />
              </Col>
              <Col xs={12} sm={9}>
                {/* <Back
                  onClick={() => {
                    this.props.history.push("/products");
                  }}
                /> */}
                <div className="row bsFormBlock">
                  <div className="col-sm-12 text-left">
                    <div className="bsFormHeader">
                      <div className="bsFormHeaderIcon">
                        {/* {" "}
                        <img alt="" src="/loanApp.svg" />
                          </div> */}
                        <h1
                          style={{
                            marginBottom: "0px",
                            marginLeft: "15px",
                            paddingBottom: "10px",
                            fontWeight: "600",
                          }}
                        >
                          Two Wheeler Loan{" "}
                        </h1>
                      </div>
                    </div>
                    {storedData && storedData.length > 0 ? (
                      <>
                        {storedData.map((e, i) => (
                          <div className="col-sm-12 bsMyLoanSection">
                            <div className="row g-0 align-items-center bsMyLoanBox">
                              <div className="col-sm-9">
                                <div className="row g-0">
                                  <div className="col-6 col-sm-3">
                                    <p> Application No.</p>

                                    <strong>{e.recordId} </strong>
                                  </div>
                                  <div className="col-6 col-sm-3">
                                    <p>Date</p>
                                    <strong>
                                      {moment(e.createddate).format(
                                        "DD-MMM-YYYY"
                                      )}
                                    </strong>
                                  </div>
                                  <div className="col-6 col-sm-3">
                                    <p>Loan Amount</p>

                                    <strong>{e.amount__c ? numberFormat(e.amount__c) : "------"}</strong>
                                  </div>

                                  <div className="col-6 col-sm-3">
                                    <p>EMI</p>

                                    <strong> {e.emi ? numberFormat(e.emi) : "------"} </strong>
                                  </div>
                                </div>

                                <hr className="bsBorder" />
                                <div className="row g-0 align-items-center">
                                  <div className="col-6 col-sm-3">
                                    <div>
                                      {e.lenderName === "IDFC" && (
                                        <img
                                          src="/bankLogos/idfc-bank.svg"
                                          alt=""
                                          style={{ width: "100px" }}
                                        />
                                      )}
                                    </div>
                                  </div>
                                  <div className="col-6 col-sm-3">
                                    <p>Location</p>
                                    <strong>{e.location.toUpperCase()}</strong>
                                  </div>
                                  <div className="col-6 col-sm-3">
                                    <p>Interest Rate</p>

                                    <strong> {e.roi} %*</strong>
                                  </div>
                                  <div className="col-6 col-sm-3">
                                    {" "}
                                    <p>Tenure</p>
                                    <strong>
                                      {e.tenure
                                        ? e.tenure + " months"
                                        : "------"}
                                    </strong>
                                  </div>
                                  <div className="col-6 col-sm-3"></div>
                                </div>
                              </div>

                              <div className=" col-12 col-sm-3 text-center">
                                <p
                                  className="bsContinue"
                                  style={{
                                    marginBottom: "revert",
                                    display: "grid",
                                  }}
                                >
                                  Loan Status
                                  <strong
                                    style={{
                                      fontWeight: "bolder",
                                      color: "#2E0080 ",
                                      fontSize: "16px",
                                    }}
                                  >
                                    {loanStage ? loanStage : e.loanStage}
                                  </strong>
                                </p>
                                <p className="bsContinue">
                                  <strong></strong>
                                </p>
                                <p
                                  className="bsContinue"
                                  style={{
                                    marginBottom: "revert",
                                    display: "grid",
                                  }}
                                >
                                  Bank Status
                                  <strong
                                    style={{
                                      fontWeight: "bolder",
                                      color: "rgba(0, 0, 0, 0.87)",
                                      fontSize: "16px",
                                    }}
                                  >
                                    {bankSubStatus
                                      ? bankSubStatus
                                      : e.bankSubStatus}
                                  </strong>
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </>
                    ) : (
                      <div className="col-sm-12 bsMyLoanSection">
                        <div className="row g-0 align-items-center bsMyLoanBox">
                          <div className="col-sm-9">
                            <div className="row g-0">
                              <div className="col-6 col-sm-3">
                                <p> Application No.</p>

                                <strong> {"------"}</strong>
                              </div>
                              <div className="col-6 col-sm-3">
                                <p>Date</p>
                                <strong> {"------"}</strong>
                              </div>
                              <div className="col-6 col-sm-3">
                                <p>Loan Amount</p>

                                <strong> {"------"}</strong>
                              </div>
                              <div className="col-6 col-sm-3">
                                <p>EMI</p>

                                <strong> {"------"}</strong>
                              </div>
                            </div>

                            <hr className="bsBorder" />
                            <div className="row g-0 align-items-center">
                              <div className="col-6 col-sm-3">
                                <div>
                                  <span style={{ color: "red" }}>
                                    No Loan Offers!
                                  </span>
                                </div>
                              </div>
                              <div className="col-6 col-sm-3">
                                <p>Location</p>
                                <strong> {"------"}</strong>
                              </div>
                              <div className="col-6 col-sm-3">
                                <p>Interest Rate</p>

                                <strong> {"------"}</strong>
                              </div>
                              <div className="col-6 col-sm-3">
                                {" "}
                                <p>Tenure</p>
                                <strong>{"------"}</strong>
                              </div>
                              <div className="col-6 col-sm-3"></div>
                            </div>
                          </div>

                          <div className=" col-12 col-sm-3 text-center">
                            <p
                              className="bsContinue"
                              style={{
                                marginBottom: "revert",
                                display: "grid",
                              }}
                            >
                              Loan Status
                              <strong
                                style={{
                                  fontWeight: "bolder",
                                  color: "#2E0080 ",
                                  fontSize: "16px",
                                }}
                              >
                                {"------"}
                              </strong>
                            </p>
                            <p
                              className="bsContinue"
                              style={{ marginBottom: "revert" }}
                            >
                              <strong
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                }}
                              ></strong>
                            </p>
                            <p
                              className="bsContinue"
                              style={{
                                marginBottom: "revert",
                                display: "grid",
                              }}
                            >
                              Bank Status
                              <strong
                                style={{
                                  fontWeight: "bolder",
                                  color: "rgba(0, 0, 0, 0.87)",
                                  fontSize: "16px",
                                }}
                              >
                                {"------"}
                              </strong>
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
        {
        }
      </>)
  }
}

const mapStateToProps = (state) => ({
  loadingBank: getBankOffer(state).loadingBank,
  setBankOffer: getBankOffer(state).setBankOffer,
  setIdfc: getBankOffer(state).setIdfc,
});
const mapDispatchToProps = (dispatch) => ({
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  setIdfcStatus: (params, callBack) =>
    dispatch(setIdfcStatus(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TwDetail)
);
