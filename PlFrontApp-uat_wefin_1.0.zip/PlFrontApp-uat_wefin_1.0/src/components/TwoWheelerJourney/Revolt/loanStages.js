import CONSTANTS from "../../../constants/Constants"
import PATH from "../../../paths/Paths"
import { decryptStore } from "../../../Utils/store"

export const JourneyContinueMoneyplus = (e) => {
    let JourneyData;
    switch (e.loanStage) {
        case "Mobile Registered":
        case "Offers":
            JourneyData = {
                pathname: PATH.PRIVATE.TWO_WHEELER_VARIANT + "/REVOLT/RV400", isAddCustomer: true
            }
            break
        case "Assigned": JourneyData = {
            pathname: PATH.PRIVATE.AADHAAR_SELFIE,
            state: { bike: e.bikeData }
        }
            break
        case "Aadhar Image Uploaded":
        case "Aadhaar Initiate": JourneyData = {
            pathname: PATH.PRIVATE.PERSONAL_DETAIL,
            state: { bike: e.bikeData, step: CONSTANTS.RENDER_TWO_WHEELER_AADHAR }
        }
            break
        case "E-KYC Complete":
            JourneyData = {
                pathname: PATH.PRIVATE.PERSONAL_DETAIL,
                state: { bike: e.bikeData, step: CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL }
            }
            break
        case "E-KYC Reject": JourneyData = {
            pathname: PATH.PRIVATE.LOAN_APP_FAILED,
            state:
            {
                bike: e.bikeData,
                failedMessage: "We have carefully reviewed your KYC application, but unfortunately, we are unable to proceed with your account opening due to the information provided not meeting our requirements."
            }
        }
            break
        case "Employment Checked": JourneyData = {
            pathname: PATH.PRIVATE.UPLOAD_BANK_STATEMENT,
            state: { bike: e.bikeData }
        }
            break;
        case "Perfios Initiated": JourneyData = {
            pathname: PATH.PRIVATE.UPLOAD_SALARY_SLIP + `/${e.loanType}/${e.lenderName}`,
            state: { bike: e.bikeData, loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN }
        }
            break
        case "Financial Check": JourneyData = {
            pathname: PATH.PRIVATE.ADD_PRIMARY_REFERENCE,
            state: { bike: e.bikeData }
        }
            break
        case "CPV Check Pass":
        case "Bank Detail Validation Failed":
        case "Reference Capture": JourneyData = {
            pathname: PATH.PRIVATE.VERIFY_BANK_DETAILS + "/" + CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN + "/" + e.lenderName,
            state: { bike: e.bikeData, loanStage: e.loanStage, loanType: e.loanType, lender: e.lenderName }
        }
            break
        case "NSTP Approved":
        case "Hard Approved": JourneyData = {
            pathname: PATH.PRIVATE.VERIFY_BANK_DETAILS + "/" + CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN + "/" + decryptStore(localStorage.getItem("mobilenumber")).lenderName,
            state: { bike: e.bikeData, loanStage: e.loanStage, loanType: e.loanType, lender: e.lenderName, mandate_url: e.mandate_url__c }
        }
            break

        case "Bank Detail Validation Failed": JourneyData = {
            pathname: PATH.PRIVATE.VERIFY_BANK_DETAILS + "/" + CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN + "/" + decryptStore(localStorage.getItem("mobilenumber")).lenderName,
            state: { bike: e.bikeData }
        }
            break
        case "Soft Approved": JourneyData = {
            pathname: `${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}`,
            state: { bike: e.bikeData }
        }
            break

        case "Televerification":
        case "Bank Detail Validated":
        case "Application in Review": JourneyData = {
            pathname: PATH.PRIVATE.PERSONAL_DETAIL,
            state: { bike: e.bikeData, step: CONSTANTS.RENDER_WAITING_SCREEN_REVOLT, loanType: e.loanType, lender: e.lenderName, loanStage: e.loanStage }
        }
            break

        case "E-Mandate Completed": JourneyData = {
            pathname: PATH.PRIVATE.PERSONAL_DETAIL,
            state: { bike: e.bikeData, step: CONSTANTS.RENDER_ESIGN_AGREEMENT_REVOLT }
        }
            break
        case "E-Sign Rejected":
        case "E-Sign Initiated": JourneyData = {
            pathname: PATH.PRIVATE.PERSONAL_DETAIL,
            state: { bike: e.bikeData, step: CONSTANTS.RENDER_ESIGN_AGREEMENT_REVOLT, loanType: e.loanType, lender: e.lenderName, loanStage: e.loanStage }
        }
            break
        case "Pre-Disbursement":
        case "Disbursement":
            JourneyData = {
                pathname: PATH.PRIVATE.CONGRATULATION_SCREEN,
                state: { bike: e.bikeData }
            }
            break

    }
    return JourneyData
}
