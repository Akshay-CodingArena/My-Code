import React from "react";
import Joi from "joi-browser";
import Form from "../../common/form";
import SelectSearch from "../../common/select";
import Pincode from "../../common/pincode";
import { ReactComponent as AddressLine1Icon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as LocationIcon } from "../../../include/assets/fullertonLogos/Places.svg";
import CONSTANTS from "../../../constants/Constants";
import {
    residence_type_credit_saison,
    cityField,
} from "../../common/dropdownValues";
import Back from "../../common/back";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import BackDropComponent from "../../../common/BackDropComponent";
import {
    getApplyLoan,
} from "../../../store/applyLoan";

import { addressUpdate, getTwoWheeler } from "../../../store/twoWheeler";
import Swal from "sweetalert2";
import { decryptStore } from "../../../Utils/store";
import PATH from "../../../paths/Paths";


const months = [
    {
        value: "1",
        label: "1",
    },
    {
        value: "2",
        label: "2",
    },
    {
        value: "3",
        label: "3",
    },
    {
        value: "4",
        label: "4+",
    },
];
class CurrentDetails extends Form {
    state = {
        data: {},
        errors: {},
        loading: false,
        checked: false,
        pinSfid: "",
        stateSfid: "",
        citySfid: "",
    };

    schema = {
        add1: Joi.string()
            .required()
            .label("Address Line 1 ")
            .error(() => {
                return { message: "Address Line 1 field is required." };
            }),
        add2: Joi.string()
            .required()
            .label("Address Line 2")
            .error(() => {
                return { message: "Address Line 2 field is required." };
            }),
        street: Joi.string().allow(""),
        pincode: Joi.number()
            .required()
            .label("Pin Code")
            .error(() => {
                return { message: "Pincode field is required." };
            }),
        residence: Joi.object()
            .required()
            .label("Residence Type ")
            .error(() => {
                return { message: "This field is required." };
            }),
        city: Joi.string().label("City"),
        state: Joi.string().label("State"),
    };
    doSubmit = () => {
        let decryptData = decryptStore(localStorage.getItem("mobilenumber"));
        let permanentAddressDetails = this.props.pLData.permanentAddressDetails;
        let currentAddressDetails = this.state.data;
        let formData = {
            mobile: localStorage.getItem("mobilenumber"),
            aadhaarName: localStorage.getItem("fullName"),
            loanName: decryptData.loanName,
            currentAddress:
            {
                addline1: currentAddressDetails.add1,
                addline2: currentAddressDetails.add2,
                pinCodeSfid: this.state.pinSfid,
                stateSfid: this.state.stateSfid,
                citySfid: this.state.citySfid
            }, permanentAddress:
            {
                addline1: permanentAddressDetails.add1,
                addline2: permanentAddressDetails.add2,
                pinCodeSfid: permanentAddressDetails.pinSfid,
                stateSfid: permanentAddressDetails.stateSfid,
                citySfid: permanentAddressDetails.citySfid
            }
        }
        this.props.addressUpdate(formData, this.callbackAddressUpdate);
    };

    callbackAddressUpdate = (res) => {
        if (res.data.success) {
            this.props.updateStep(null, CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL);
        }
        else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: false,
                timer: 1800,
            });
        }
    }

    __handlePinCode = (pincodevalue) => {
        let mobile = localStorage.getItem("mobilenumber");
        this.setState(({ data }) => ({ data: { ...data, city: "", state: "" } }));
        if (pincodevalue && !/^[0-9]+$/.test(pincodevalue)) {
            if (pincodevalue.length === 6) {
                const errors = { ...this.state.errors };
                errors.pincode = "Pincode must be number";
                this.setState({ errors });
            } else {
                const errors = { ...this.state.errors };
                errors.pincode = "";
                this.setState({ errors });
            }
        } else {
            if (pincodevalue.length === 6) {
                const data = { ...this.state.data };
                const errors = { ...this.state.errors };
                data.pincode = pincodevalue;
                errors.pincode = "";
                this.setState({ data, errors });
                let formData = { mobile: mobile, pincode: pincodevalue };
                this.props.loadPinCode(formData, this.callbackPin);
            }
        }
    };
    callbackPin = (res) => {
        if (res) {
            let errors = { ...this.state.errors };
            if (res.data?.success === false) {
                errors.pincode = res.data.message;
                this.setState({ errors });
            } else if (res.data?.success === true) {
                const errors = { ...this.state.errors };
                let data = { ...this.state.data };
                data.pincode = res.data.data.pincode;
                data.city = res.data.data.cityname;
                data.state = res.data.data.statename;
                errors.pincode = "";
                this.setState({
                    loading: false,
                    data,
                    errors,
                    pinSfid: res.data.data.sfid,
                    stateSfid: res.data.data.state__c,
                    citySfid: res.data.data.city__c,
                });
            }
        }
    };

    handleCheckbox = (isChecked) => {
        let data = { ...this.props.pLData.permanentAddressDetails };
        this.setState({ loading: true, checked: isChecked });
        if (isChecked) {
            setTimeout(() => {
                this.setState({
                    data: {
                        add1: data.add1,
                        add2: data.add2,
                        street: data.street,
                        pincode: data.pincode,
                        city: data.city,
                        state: data.state
                    },
                    loading: false
                })
                this.__handlePinCode(data.pincode);
            }, 1000)

        } else {
            setTimeout(() => {
                this.setState({
                    data: {
                        add1: "",
                        add2: "",
                        street: "",
                        pincode: "",
                        city: "",
                        state: ""
                    },
                    loading: false
                })
            }, 1000)
        }
        setTimeout(() => {
            this.setState({ loading: false });
        }, 1000)
    }
    render() {
        return (
            <>
                < div className="row insideFormBlock" >
                    <div className="col-sm-12 text-center">
                        <div className="bsFormHeader">
                            <h1> Residence Address </h1>
                        </div>
                    </div>

                    <div className="col-sm-12">
                        {this.state.loading || this.props.pincodeLoading || this.props.loadingAddressDetails ? <BackDropComponent /> : ""}

                        <form className="panVeryfyForm">
                            <ul className="nav nav-pills bs-form-tab">
                                <li>
                                    <a className="">Permanent Address</a>
                                </li>
                                <li>
                                    <a className="active">Current Address</a>
                                </li>
                            </ul>
                            <div className="tab-content clearfix">
                                <div className="row">
                                    <div className="col-sm-12">
                                        <div className="form-check">
                                            <div className="form-check-input">
                                                <input
                                                    id="copyaddress"
                                                    type="checkbox"
                                                    checked={this.state.checked}
                                                    onChange={() => {
                                                        this.handleCheckbox(!this.state.checked)
                                                    }}
                                                />
                                                <label htmlFor="copyaddress">
                                                    &nbsp; Same as Permanent Address
                                                </label>
                                            </div>
                                            <br />
                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        {" "}
                                        {this.renderInput(
                                            "add1",
                                            "Address Line 1",
                                            <AddressLine1Icon />
                                        )}
                                    </div>
                                    <div className="col-sm-6">
                                        {this.renderInput(
                                            "add2",
                                            "Address Line 2",
                                            <AddressLine1Icon />
                                        )}
                                    </div>
                                    <div className="col-sm-6">
                                        {this.renderInput(
                                            "street",
                                            "Street/Landmark",
                                            <LocationIcon />,
                                            false,
                                            undefined,
                                            undefined,
                                            undefined,
                                            false
                                        )}
                                    </div>

                                    <div className="col-sm-6">
                                        <Pincode
                                            value={this.state.data.pincode}
                                            __handlePinCode={(e) => {
                                                this.__handlePinCode(e.target.value)
                                            }}
                                            error={this.state.errors.pincode}
                                        />
                                    </div>

                                    <div className="col-sm-3">
                                        {this.renderInput("city", "City", <LocationIcon />, true)}
                                    </div>

                                    <div className="col-sm-3">
                                        {this.renderInput("state", "State", <LocationIcon />, true)}
                                    </div>

                                    <div className="col-sm-6">
                                        <SelectSearch
                                            placeholderValue={"Residence Type"}
                                            label={"Residence Type"}
                                            value={this.state.data.residence}
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.residence = e;
                                                    errors.residence = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={
                                                residence_type_credit_saison
                                            }
                                            error={this.state.errors.residence}
                                            icon={
                                                <AddressLine1Icon
                                                    style={{
                                                        marginRight: "5px",
                                                        marginTop: "3px",
                                                    }}
                                                />
                                            }
                                        ></SelectSearch>
                                    </div>

                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Next
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div >
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    pincodeLoading: getpinCode(state).loading,
    applyLoan: getApplyLoan(state).applyLoan,
    loadingAddressDetails: getTwoWheeler(state).loadingAddressDetails
});
const mapDispatchToProps = (dispatch) => ({
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
    addressUpdate: (params, callback) => dispatch(addressUpdate(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(CurrentDetails)
);
