import React from "react";
import Joi from "joi-browser";
import Form from "../../common/form";
import Pincode from "../../common/pincode";
import { ReactComponent as AddressLine1Icon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as LocationIcon } from "../../../include/assets/fullertonLogos/Places.svg";
import CONSTANTS from "../../../constants/Constants";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import Swal from "sweetalert2";
import BackDropComponent from "../../../common/BackDropComponent";
import { getpinCode, loadPinCode } from "../../../store/pincode";

class PermanentAddress extends Form {
    constructor(props) {
        super(props);
        this.state = {
            data: {},
            errors: {},
            pinSfid: "",
            stateSfid: "",
            citySfid: "",
            loading: false,
        };
    }

    schema = {
        add1: Joi.string()
            .required()
            .label("Address Line 1")
            .error(() => {
                return { message: "Address Line 1 field is required." };
            }),
        add2: Joi.string()
            .required()
            .label("Address Line 2")
            .error(() => {
                return { message: "Address Line 2 field is required." };
            }),
        street: Joi.string().allow(""),
        pincode: Joi.number()
            .required()
            .label("Pin Code")
            .error(() => {
                return { message: "Pincode field is required." };
            }),
        city: Joi.string().label("City"),
        state: Joi.string().label("State"),
    };
    doSubmit = () => {

    };

    componentDidMount = () => {
        const data = this.props?.pLData?.AadhaarDetails;
        let pincode = data?.address?.splitAddress?.pincode ? data.address.splitAddress.pincode : ""
        this.__handlePinCode(pincode)
    }

    __handlePinCode = (pincodevalue) => {
        let mobile = localStorage.getItem("mobilenumber");
        this.setState(({ data }) => ({ data: { ...data, city: "", state: "" } }));
        if (pincodevalue && !/^[0-9]+$/.test(pincodevalue)) {
            if (pincodevalue.length === 6) {
                const errors = { ...this.state.errors };
                errors.pincode = "Pincode must be number";
                this.setState({ errors });
            } else {
                const errors = { ...this.state.errors };
                errors.pincode = "";
                this.setState({ errors });
            }
        } else {
            if (pincodevalue.length === 6) {
                const data = { ...this.state.data };
                const errors = { ...this.state.errors };
                data.pincode = pincodevalue;
                errors.pincode = "";
                this.setState({ data, errors });
                let formData = { mobile: mobile, pincode: pincodevalue };
                this.props.loadPinCode(formData, this.callbackPin);
            }
        }
    };
    callbackPin = (res) => {
        if (res) {
            let errors = { ...this.state.errors };
            if (res.data?.success === false) {
                errors.pincode = res.data.message;
                this.setState({ errors });
            } else if (res.data?.success === true) {
                const errors = { ...this.state.errors };
                const pinData = this.props?.pLData?.AadhaarDetails;
                let data = { ...this.state.data };
                data.add1 = pinData.address.combinedAddress.split(", ").slice(0, 5).join(",");
                data.add2 = pinData.address.combinedAddress.split(", ").slice(4).join(",");
                data.street = pinData?.address?.splitAddress?.street ? pinData?.address?.splitAddress.street : "";
                data.pincode = res.data.data.pincode;
                data.city = res.data.data.cityname;
                data.state = res.data.data.statename;

                errors.pincode = "";
                this.setState({
                    loading: false,
                    data,
                    errors,
                    pinSfid: res.data.data.sfid,
                    stateSfid: res.data.data.state__c,
                    citySfid: res.data.data.city__c,
                });
            }
        }
    };


    handleSubmit = (e) => {
        this.props.setpLData({
            ...this.props.pLData, permanentAddressDetails: {
                ...this.state.data,
                pinSfid: this.state.pinSfid,
                stateSfid: this.state.stateSfid,
                citySfid: this.state.citySfid,
            }
        });
        this.props.updateStep(null, CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_CURRENT)
    }

    render() {
        return (
            <>
                {this.state.loading || this.props.pincodeLoading ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}
                <div className="row insideFormBlock">
                    <div className="col-sm-12 text-center">
                        <div className="bsFormHeader">
                            <h1>Residence Address</h1>
                        </div>
                    </div>
                    <div className="col-sm-12">
                        <form onSubmit={this.handleSubmit} className="panVeryfyForm">
                            <ul className="nav nav-pills bs-form-tab">
                                <li>
                                    <a className="active">Permanent Address</a>
                                </li>
                                <li>
                                    <a className="">Current Address</a>
                                </li>
                            </ul>
                            <div className="tab-content clearfix">
                                <div className="row">
                                    <div className="col-sm-6">
                                        {this.renderInput(
                                            "add1",
                                            "Address Line 1",
                                            <AddressLine1Icon />,
                                            true
                                        )}
                                    </div>
                                    <div className="col-sm-6">
                                        {this.renderInput(
                                            "add2",
                                            "Address Line 2",
                                            <AddressLine1Icon />,
                                            true
                                        )}
                                    </div>
                                    <div className="col-sm-6">
                                        {this.renderInput(
                                            "street",
                                            "Street/Landmark",
                                            <LocationIcon />,
                                            true,
                                            undefined,
                                            undefined,
                                            "text",
                                            false

                                        )}
                                    </div>
                                    <div className="col-sm-6">
                                        <Pincode
                                            value={this.state.data.pincode}
                                            error={this.state.errors.pincode}
                                            step={this.props.step}
                                            disabled={true}
                                        />
                                    </div>

                                    <div className="col-sm-3">
                                        {this.renderInput("city", "City", <LocationIcon />, true)}
                                    </div>
                                    <div className="col-sm-3">
                                        {this.renderInput("state", "State", <LocationIcon />, true)}
                                    </div>


                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Next
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    pincodeLoading: getpinCode(state).loading
});
const mapDispatchToProps = (dispatch) => ({
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(PermanentAddress)
);
