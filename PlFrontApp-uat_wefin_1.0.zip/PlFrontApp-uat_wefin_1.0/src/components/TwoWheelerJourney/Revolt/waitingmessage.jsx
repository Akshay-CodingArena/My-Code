import React, { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import { decryptStore } from "../../../Utils/store";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../../cibilFlow/footer";
import PATH from "../../../paths/Paths";
import CONSTANTS from "../../../constants/Constants";



const WaitingMessage = () => {
    let location = useLocation();
    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.add("NoScrool");
        document.body.classList.remove("variantScroll");
    });


    return (
        <>
            <section className="bs-main-section">
                <Container>
                    <Row>
                        <Col sm={12} md={12} lg={12}>
                            <div className="CongratsContainer backImage">
                                <div className="Congrats">
                                    <div className="CongratsMain">
                                        <p className="waitingMessage">We are currently conducting tele-verification and request you to return once it is completed. </p>
                                        <Link
                                            to={localStorage.getItem("isASM") ? PATH.PRIVATE.ASM_DASHBOARD : PATH.PRIVATE.PRODUCTS}
                                            className="failedLoanBtn"
                                        >
                                            {`Go Back to ${localStorage.getItem("isASM") ? 'Dashboard' : 'Home Page'}`}
                                        </Link>

                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>

        </>
    );
};
export default WaitingMessage;
