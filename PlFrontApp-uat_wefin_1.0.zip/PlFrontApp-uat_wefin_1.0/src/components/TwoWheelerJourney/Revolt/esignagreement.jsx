import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import EsignAgreementLogo from "../../../include/assets/twoWheelerLogo/esignagreement_dummy.jpg";
import PATH from "../../../paths/Paths";
import { decryptStore } from "../../../Utils/store";
import { esignAgreementRevoltMoneyplus, eSignAgreementData, updateESignAgreementDataCreditSaison } from "../../../store/eSignAgreement";
import AllPagesPDFViewer from "../../../common/pdf/AllPagesPDFViewer";
import BackDropComponent from "../../../common/BackDropComponent";
import Swal from "sweetalert2";
import { getAccount, getAccountInfo } from "../../../store/account";
import CONSTANTS from "../../../constants/Constants";


class ESignAgreementRevolt extends Component {
    state =
        {
            terms: false,
            loading: false
        };


    handleChange = () => {
        this.setState({ terms: !this.state.terms })
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"))
        let formData =
        {
            name: localStorage.getItem("fullName") || "",
            email: localStorage.getItem("email") || "",
            mobile: localStorage.getItem("mobilenumber") || "",
            loanId: decryptedData.loanId,
            accountSfid: localStorage.getItem("accsfid") || "",
            loanName: decryptedData.loanName,
            loanAmount: decryptedData.appliedLoanAmount
        }

        this.props.esignAgreementRevoltMoneyplus(formData, this.callbackLoadAgreement);
    }

    callbackLoadAgreement = (res) => {
        if (!res.data.success) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.description,
            })
        } else {
            ///////////////////check for moneyplus e sign agreement///////////
            if (this.props.location.state.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && this.props.location.state.lender === "Money Plus" && this.props.location.state.loanStage === "E-Sign Initiated") {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: "Thank you for submitting your application. Our team is currently reviewing it, and we appreciate your patience during this process.",
                    timer: 5500,
                    showConfirmButton: true
                })
            }
            else if (this.props.location.state.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && this.props.location.state.lender === "Money Plus" && this.props.location.state.loanStage === "E-Sign Rejected") {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: "We regret to inform you that your e-signature has been rejected. Please check that you have signed the document correctly and resubmit.",
                    timer: 5500,
                    showConfirmButton: true
                })
            }
        }
    }



    signAgreeementhandle = () => {

        this.setState({ loading: true });
        const script = document.createElement("script");
        script.id = "digioScriptId";
        script.src = "https://app.digio.in/sdk/v8/digio.js";
        script.async = true;
        script.onload = () => this.digioScriptLoaded();
        document.body.appendChild(script);
        this.setState({ digioScript: script.id });
    }

    digioScriptLoaded = () => {
        var options = {
            environment: "production",
            callback: (res) => {
                this.setState({ loading: true });
                this.handleDigioSignInCallBack(res);
            },
            logo: "http://www.rattanindia.com/wp-content/themes/rattanindia/images/rattanindia_logo.jpg",
            theme: {
                primaryColor: "#028855",
                secondaryColor: "#ffffff",
            },
        };

        var digio = new window.Digio(options);
        this.setState({ loading: false });

        digio.init();
        console.log(this.props.dataMoneyplusRevoltAgreement)

        digio.submit(
            this.props.dataMoneyplusRevoltAgreement.csAgreementData.agreementId,
            this.props.dataMoneyplusRevoltAgreement.csAgreementData.identifier
        );
    }

    handleDigioSignInCallBack = (res) => {

        let mobile = localStorage.getItem("mobilenumber");
        let { loanId } = decryptStore(mobile);

        if (res["error_code"] || res["code"]) {
            let digioData = {
                documentId: res.digio_doc_id,
                code: res.code,
                response: "response",
                status: "failure",
            };
            let data = {
                mobile: mobile,
                loanId: loanId,
                digioResponse: digioData,
            };
            this.props.updateLoanAgreement(
                data,
                this.digioCallbackFailed
            );
        }
        else {
            let digioData = {
                documentId: res.digio_doc_id,
                message: res.message,
                status: "success",
            };
            let data = {
                mobile: mobile,
                loanId: loanId,
                digioResponse: JSON.stringify(digioData),
            };
            this.props.updateLoanAgreement(
                data,
                this.updateESignAgreementData
            )
        }
    };

    digioCallbackFailed = (res) => {

    }


    updateESignAgreementData = (res) => {
        try {
            if (res.data.success) {
                let agreeStatus = res.data.updateEsignResult;
                if (agreeStatus.eSignSuccess && agreeStatus.success) {
                    let formData = {
                        mobile: localStorage.getItem("mobilenumber")
                    }
                    this.props.getAccountInfo(formData, this.callbackGetAccountInfo)

                } else {
                    throw new Error(agreeStatus.message);
                }
            } else {
                throw new Error(res.data.description);
            }
        }
        catch (e) {
            this.setState({ loading: false });
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
            });
        }
    }

    callbackGetAccountInfo = (res) => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        if (decryptedData.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && decryptedData.lenderName === "Money Plus") {
            let data = this.props?.getAccountDetail[0]?.tw_loans?.filter((value, index) => value.loanName === decryptedData.loanName)
            let loanStage = data[0].loanStage;

            this.setState({ loading: false })

            if (loanStage === "Disbursement" ||
                loanStage === "Pre-Disbursement") {
                this.props.history.push(
                    PATH.PRIVATE.CONGRATULATION_SCREEN,
                );
            } else {
                //////////////show swal for return after some time/////
                Swal.fire({
                    icon: "warning",
                    title: "Process will took some time.Please continue your journey after 5-10 mins",
                    confirmButtonText: "Ok",
                    confirmButtonColor: "#d63031",
                }).then((res) => {
                    if (res.isConfirmed) {
                        this.props.history.push(PATH.PRIVATE.ASM_DASHBOARD);
                    }
                });
            }
        }
    }

    render() {
        let pdf = this.props?.dataMoneyplusRevoltAgreement?.csAgreementData?.loanAgreementDocument;
        console.log(this.props.loadingMoneyplusRevoltAgreement);
        return (
            <div>
                {this.props.loadingMoneyplusRevoltAgreement || this.state.loading ? <BackDropComponent /> : ""}
                <div className="e_agreement">
                    <h1 className="title">Sign E-Agreement</h1>
                    <p className="mt-3 mb-3">Read Agreement</p>
                    <p className="sub-title">Copy of the agreement will be sent via email and post</p>

                    {pdf ? (
                        <div className="all-page-container">
                            <AllPagesPDFViewer
                                pdf={`data:application/pdf;base64,${pdf}`}
                            />
                        </div>
                    ) : (
                        <div className="esignagreement_box">
                            <img src={EsignAgreementLogo} />
                        </div>
                    )}
                    <div className="terms">
                        <div className="form-check">
                            <input
                                className="form-check-input"
                                type="checkbox"
                                name="checkedG"
                                id="checkedG"
                                onChange={this.handleChange}
                                checked={this.state.terms}
                            />
                            <label
                                className="form-check-label"
                                htmlFor="checaakedG"
                            >
                                I accept the&nbsp;
                                <a
                                    href="https://www.bankse.in/experian-tnc.html"
                                    target="_blank"
                                    rel="noreferrer"
                                >
                                    Terms and Conditions
                                </a>
                            </label>

                        </div>
                    </div>
                    <div className="submitBtn" >
                        <button
                            type="submit"
                            variant="contained"
                            className="nextButton"
                            onClick={this.state.terms ? this.signAgreeementhandle : () => { }}
                            style={{ cursor: this.state.terms ? "pointer" : "not-allowed", opacity: this.state.terms ? "1" : "0.7" }}
                        >
                            Sign in Loan Agreement
                        </button>

                    </div>

                </div >
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    loadingMoneyplusRevoltAgreement: eSignAgreementData(state).loadingMoneyplusRevoltAgreement,
    dataMoneyplusRevoltAgreement: eSignAgreementData(state).dataMoneyplusRevoltAgreement,
    getAccountDetail: getAccount(state).getAccountDetail
});
const mapDispatchToProps = (dispatch) => ({
    esignAgreementRevoltMoneyplus: (params, callBack) =>
        dispatch(esignAgreementRevoltMoneyplus(params, callBack)),
    updateLoanAgreement: (params, callBack) =>
        dispatch(updateESignAgreementDataCreditSaison(params, callBack)),
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ESignAgreementRevolt)
);
