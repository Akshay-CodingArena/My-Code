import React from "react";
import { ReactComponent as LocalPhoneIcon } from "../../include/assets/phoneIcon.svg";
import { ReactComponent as EmailIcon } from "../../include/assets/emailIcon.svg";
import { ReactComponent as PersonIcon } from "../../include/assets/Profile.svg";
import BackDropComponent from "../../common/BackDropComponent";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/panIcon.svg";
import Joi from "joi-browser";
import Form from "../../components/common/form";
import Date from "../../components/common/date";
import Pincode from "../../components/common/pincode";
import PersonalInput from "../common/personalInput";
import { withRouter } from "react-router";
import { getpanName, loadPanName } from "../../store/panName";
import { connect } from "react-redux";
import { getpinCode, loadPinCode } from "../../store/pincode";
import Swal from "sweetalert2";
import Moment from "moment";
import {
  getAccount,
  setAccountInfo,
  getAccountInfo,
} from "../../store/account";
import { getExperian, loadExperianCheck } from "../../store/experian";
import OTPModal from "../HomeProducts/OTPModal";
import DashBoardAside from "../../common/dashboardAside";
import TopNavBar from "../../common/TopNavBar";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
import { gaLogEvent } from "../../init-fcm";
// import configureStore from "../../store/configureStore";
import CONSTANTS from "../../constants/Constants";
import PATH from "../../paths/Paths";
import {
  myprofile_marital_status,
} from "../common/fullerTonDropdown";
class PanVerify extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      terms: false,
      stgOneHitId: "",
      stgTwoHitId: "",
      openOtp: false,
      loadingView: true,
      cibil: true,
    };
  }

  schema = {
    fullName: Joi.string()
      .required()
      .label("Full Name")
      .error(() => {
        return { message: "Full Name field is required." };
      }),
    pan: Joi.string()
      .min(10)
      .max(10)
      .required()
      .label("PAN Number")
      .error(() => {
        return { message: "PAN Number field is required." };
      }),
    email: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Email field is required";
              break;

            case "string.email":
              err.message = "Email field is invalid";
              break;
            case "string.max":
              err.message = "Email field is invalid";
              break;
            default:
              break;
          }
        });
        return errors;
      }),
    pincode: Joi.string()
      .required()
      .error(() => {
        return { message: "Pincode field is required" };
      }),
    mobile: Joi.number()
      .required()
      .label("Landline No.")
      .error(() => {
        return { message: "Mobile Number field is required" };
      }),
    dob: Joi.string()
      .required()
      .label("Date of Birth")
      .error(() => {
        return { message: "Date of Birth field is required." };
      }),
  };

  populateData = () => {
    console.log("customer details", this.props.getCustomerDetail)
    return {
      dob: this.props.getCustomerDetail?.dob?.length <= 10 ? this.props.getCustomerDetail?.dob : this.props.getCustomerDetail?.dob?.slice(8, 10) + "-" + this.props.getCustomerDetail?.dob?.slice(5, 7) + "-" + this.props.getCustomerDetail?.dob?.slice(0, 4),
      pincode: this.props.getCustomerDetail?.resAddrDetails?.pincode,
      fullName: this.props.getCustomerDetail?.name,
      pan: this.props.getCustomerDetail?.panNumber,
      //  maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail?.maritalstatus === data.value)[0]
    }
  }

  doSubmit = () => {
    // let mobile = localStorage.getItem("mobilenumber");
    if (!Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
      const errors = { ...this.state.errors };
      errors.dob = "Date of Birth field is invalid.";
      this.setState({ errors });
    } else {
      let formData = {
        mobile: this.state.data.mobile,
        pincode: this.state.data.pincode,
        name: this.state.data.fullName,
        pan: this.state.data.pan,
        dob: reverseDateString(this.state.data.dob),
        email: this.state.data.email,
        isExperian: true,
      };

      this.props.loadExperianCheck(formData, this.callBackVerify);
    }
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data.status === 203) {
        let formData = {
          mobile: this.state.data.mobile,
          pincode: this.state.data.pincode,
          name: this.state.data.fullName,
          pan: this.state.data.pan,
          dob: reverseDateString(this.state.data.dob),
          email: this.state.data.email,
          cibilcheck: "Y",
          creditCode: "A",
        };
        this.props.setAccountInfo(formData, this.callBackAcc);
      } else if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.CREDIT_SCORE_INITIATE);
        this.setState({
          stgOneHitId: res.data.data.stgOneHitId,
          stgTwoHitId: res.data.data.stgTwoHitId,
          openOtp: true,
        });
      }
    }
  };
  callBackAcc = (res) => {
    if (res) {
      if (res.data.success) {
        localStorage.setItem("fullName", this.state.data.fullName);
        localStorage.setItem("pan", this.state.data.pan);
        this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
      }
    }
  };
  callbackDetail = async (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      } else {
        this.setState((p) => ({
          ...p,
          gender: this.props.getCustomerDetail?.gender ?? this.state.gender,
          loader: false,
          data: {
            ...p.data,
            ...this.populateData(),
            mobile: localStorage.getItem("mobilenumber"),
            email: localStorage.getItem("email"),
          },
        }))
      }
      setTimeout(() => {
        this.setState({ loadingView: false });
      }, 1500);
    };
  }
  __handlePANChange = (e) => {
    let panNumber = e.target.value.toUpperCase();
    if (e.target.value.length <= 10) {
      const data = { ...this.state.data };
      data.pan = panNumber;
      this.setState({ data });
      if (e.target.value.length === 10) {
        let mobile = localStorage.getItem("mobilenumber");
        let formData = {
          mobile: mobile,
          pan: panNumber,
        };
        this.props.loadPanName(formData, this.callback);
      }
    }
  };

  callback = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data.success === false) {
        let data = { ...this.state.data };
        data.fullName = "";
        errors.pan = res.data.message;
        localStorage.setItem("fullName", "");
        localStorage.setItem("firstName", "");
        localStorage.setItem("pan", "");

        this.setState({ data, errors });
      } else {
        const data = { ...this.state.data };
        data.fullName = res.data.name;
        localStorage.setItem("fullName", res.data.name);
        localStorage.setItem("firstName", res.data.name);
        localStorage.setItem("pan", this.state.data.pan);
        errors.pan = "";
        errors.fullName = "";
        this.setState({ data, errors });
      }
    }
  };

  populateData = () => {
    console.log("customer details", this.props.getCustomerDetail)
    return {
      dob: this.props.getCustomerDetail.dob?.length <= 10 ? this.props.getCustomerDetail.dob : this.props.getCustomerDetail.dob?.slice(8, 10) + "-" + this.props.getCustomerDetail.dob?.slice(5, 7) + "-" + this.props.getCustomerDetail.dob?.slice(0, 4),
      pincode: this.props.getCustomerDetail?.resAddrDetails?.pincode,
      fullName: this.props.getCustomerDetail?.name,
      pan: this.props.getCustomerDetail?.panNumber,
      //  maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail?.maritalstatus === data.value)[0]
    }
  }

  callbackDetail = async (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      } else {
        this.setState((p) => ({
          ...p,
          gender: this.props.getCustomerDetail?.gender ?? this.state.gender,
          loader: false,
          data: {
            ...p.data,
            ...this.populateData(),
            mobile: localStorage.getItem("mobilenumber"),
            email: localStorage.getItem("email"),
          },
        }))
      }
      setTimeout(() => {
        this.setState({ loadingView: false });
      }, 1500);
    };
  }
  componentDidUpdate = () => {
    console.log("state is", this.state)
  }
  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    let data = this.populateData()
    data.mobile = localStorage.getItem("mobilenumber");
    data.email = localStorage.getItem("email");

    if (this.props.getCustomerDetail?.length) {
      this.setState((p) => ({
        ...p,
        data: {
          ...p.data,
          ...this.populateData(),
          mobile: localStorage.getItem("mobilenumber"),
          email: localStorage.getItem("email"),
        },
      }));
      setTimeout(() => {
        this.setState({ loadingView: false });
      }, 1500);
    } else {
      this.setState({ ...this.state, loader: true })
      this.props.getAccountInfo({ mobile: localStorage.getItem("mobilenumber") }, this.callbackDetail)
    }
  };
  onDateChange = (e) => {
    e.preventDefault();
    const data = { ...this.state.data };
    data.dob = e.target.value;
    this.setState({ data });
  };
  handleCheckBoxChange = () => {
    this.setState({
      terms: !this.state.terms,
    });
  };
  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    if (e.target.value.length === 6) {
      const data = { ...this.state.data };
      data.pincode = e.target.value;
      this.setState({ data });
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callbackPin);
    }
  };
  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data.success === false) {
        errors.pincode = res.data.message;
        this.setState({ errors });
      } else if (res.data.success === true) {
        errors.pincode = "";
        this.setState({ errors });
      }
    }
  };
  onChangeGender = (e) => {
    if (e) {
      if (e.target.value === "1") {
        this.setState({ gender: "Male" });
      } else if (e.target.value === "2") {
        this.setState({ gender: "Female" });
      }
    }
  };
  closeOTPModal = () => {
    this.setState({
      openOtp: false,
      data: {
        ...this.state.data,
        email: localStorage.getItem("email"),
        mobile: localStorage.getItem("mobilenumber"),
      },
    });
  };
  render() {
    const { loading, loadingVerify } = this.props.getpanName;
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            {this.props.loadingCheck ||
              loadingVerify ||
              loading ||
              this.state.loadingView ? (
              <BackDropComponent />
            ) : (
              ""
            )}
            <Row>
              <Col sm={12} md={3}>
                <DashBoardAside />
              </Col>
              <Col sm={12} md={9}>
                {/* <div className="col-sm12">
              <Back
                onClick={(e) => {
                  e.preventDefault();
                  this.props.history.push("/products");
                }}
              />
            </div> */}

                {!this.state.loadingView && (
                  <div
                    className=" insideFormBlock"
                    style={{ marginBottom: "30px" }}
                  >
                    <div className="col-sm-12">
                      <div>
                        <img
                          alt=""
                          src="/Bg.png"
                          style={{ marginBottom: "20px" }}
                        />
                      </div>
                      <form>
                        <div>
                          <div className="row">
                            <div className="col-sm-6">
                              <PersonalInput
                                value={this.state.data.pan}
                                __handleChange={this.__handlePANChange}
                                error={this.state.errors.pan}
                                icon={<CardMembershipIcon />}
                                label="PAN Number"
                                readOnly={this.props.getCustomerDetail?.pancard_status__c ?? false}
                              />
                            </div>

                            <div className="col-sm-6">
                              <PersonalInput
                                value={this.state.data.fullName}
                                error={this.state.errors.fullName}
                                icon={<PersonIcon />}
                                label="Full Name as per PAN "
                                readOnly={true}
                              />
                            </div>

                            <div className="col-sm-6">
                              <Date
                                value={this.state.data.dob}
                                onDateChange={this.onDateChange}
                                error={this.state.errors.dob}
                                label="Date of Birth"
                              />
                            </div>
                            <div className="col-sm-6">
                              <Pincode
                                value={this.state.data.pincode}
                                __handlePinCode={this.__handlePinCode}
                                error={this.state.errors.pincode}
                              />
                            </div>
                            <div className="col-sm-6">
                              {this.renderInput(
                                "mobile",
                                "Phone Number",
                                <LocalPhoneIcon />,
                                true,
                                10,
                                10
                              )}
                            </div>
                            <div className="col-sm-6">
                              {this.renderEmail(
                                "email",
                                "Email ID",
                                <EmailIcon />,
                                false
                              )}
                            </div>
                            <div className="col-sm-12">
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  name="checkedG"
                                  id="checkedG"
                                  onChange={this.handleCheckBoxChange}
                                  checked={this.state.terms}
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor="checaakedG"
                                >
                                  You hereby consent to Neotec being appointed
                                  as your authorised representative to receive
                                  your Credit Information from Experian on an
                                  ongoing basis until the purpose of monitoring
                                  credit healths and providing financial offers
                                  (“End Use Purpose”) is satisfied or expiry of
                                  6 months from date the consent is collected;
                                  whichever is earlier. You hereby agree
                                  to&nbsp;
                                  <a
                                    href="https://www.bankse.in/experian-tnc.html"
                                    target="_blank"
                                    rel="noreferrer"
                                  >
                                    Terms and Conditions
                                  </a>
                                </label>
                              </div>

                              <div className="agreeTxt"></div>
                            </div>
                            <div className="col-sm-12 text-center">
                              {this.state.terms === true ? (
                                <button
                                  type="submit"
                                  onClick={this.handleSubmit}
                                  variant="contained"
                                  className="nextButton"
                                >
                                  Next
                                </button>
                              ) : (
                                <button
                                  type="submit"
                                  onClick={this.handleSubmit}
                                  variant="contained"
                                  className="nextButton"
                                  disabled
                                  style={{
                                    opacity: "0.5",
                                    cursor: "not-allowed",
                                  }}
                                >
                                  Next
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                )}

                {this.state.openOtp === true && (
                  <OTPModal
                    show={this.state.openOtp}
                    handleCloseOTP={this.closeOTPModal}
                    mobile={this.state.data.mobile}
                    stgOneHitId={this.state.stgOneHitId}
                    stgTwoHitId={this.state.stgTwoHitId}
                    data={this.state.data}
                    cibil={this.state.cibil}
                  />
                )}
              </Col>
            </Row>
          </Container>
        </section>
        <CreditFooter />
      </>
    );
  }
}
function reverseDateString(str) {
  var splitString = str.split("-");
  var reverseArray = splitString.reverse();
  var joinArray = reverseArray.join("-");
  joinArray = joinArray + "T00:00:00.000Z";
  return joinArray;
}
const mapStateToProps = (state) => ({
  getpanName: getpanName(state),
  getpinCode: getpinCode(state),
  getAccount: getAccount(state),
  experian: getExperian(state).accountData,
  loadingCheck: getExperian(state).loadingCheck,
  getCustomerDetail: getAccount(state).customerDetail
});
const mapDispatchToProps = (dispatch) => ({
  loadPanName: (params, callback) => dispatch(loadPanName(params, callback)),
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(PanVerify)
);
