export const monthDiff = (dt1, dt2) => {
  var diffMonth = (dt2.getTime() - dt1.getTime()) / 1000;
  diffMonth /= 60 * 60 * 24 * 7 * 4;
  return Math.abs(Math.round(diffMonth));
};
export const getWords = (monthCount) => {
  const getPlural = (number, word) => {
    return (number === 1 && word.one) || word.other;
  };

  var months = { one: "month", other: "m" },
    years = { one: "year", other: "yrs" },
    m = monthCount % 12,
    y = Math.floor(monthCount / 12),
    result = [];

  y && result.push(y + " " + getPlural(y, years));
  m && result.push(m + " " + getPlural(m, months));
  return result.join(" and ");
};
