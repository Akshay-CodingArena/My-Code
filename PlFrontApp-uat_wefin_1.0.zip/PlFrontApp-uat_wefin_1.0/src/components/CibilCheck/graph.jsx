import React, { Component } from "react";
import {
  VictoryLine,
  VictoryScatter,
  VictoryAxis,
  VictoryChart,
  VictoryTheme,
  VictoryTooltip,
} from "victory";
import moment from "moment";
class TrendGraph extends Component {
  render() {
    let data = [];
    if (this.props.graphData) {
      for (let i = 0; i < this.props.graphData.length; i++) {
          const time = moment(this.props.graphData[i].bureau_date_time).format(
            "MMM YY'"
          );
          const score = this.props.graphData[i].bureau_score;
          data.push({ time: time, score: score });
      }
    }
    const dataItem = data.reverse();
    return (
      <div>
        <VictoryChart
          minDomain={{ y: 300 }}
          domainPadding={20}
          theme={VictoryTheme.material}
          width={1200}
          height={400}
        >
          <VictoryAxis fixLabelOverlap />
          <VictoryAxis
            dependentAxis
            tickValues={[300, 400, 500, 600, 700, 800, 900]}
            maxDomain={{ y: 900 }}
            minDomain={{ y: 300 }}
            fixLabelOverlap
          />
          <VictoryLine
            data={dataItem}
            x="time"
            y="score"
            style={{
              data: { stroke: "#2e0080", opacity: 0.5, strokeWidth: "5px" },
              labels: { fontSize: 12 },
              parent: { border: "1px solid #2e0080" },
            }}
          />
          <VictoryScatter
            style={{ data: { fill: "#2e0080" } }}
            size={7}
            data={dataItem}
            x="time"
            y="score"
            labels={({ datum }) => `Score: ${datum.score}`}
            labelComponent={<VictoryTooltip pointerLength={20} />}
          />
        </VictoryChart>
      </div>
    );
  }
}
export default TrendGraph;
