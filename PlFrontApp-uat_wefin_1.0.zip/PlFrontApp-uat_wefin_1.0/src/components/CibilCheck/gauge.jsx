import React, { useEffect } from "react";
import ReactSpeedometer from "react-d3-speedometer";

const Gauger = (props) => {
  let [currentGaugeVal, setCurrentGaugeVal] = React.useState(0);

  useEffect(() => {
    setCurrentGaugeVal(props.cibilScore);
  });
  return (
    <div className="gaudgeBox">
      <ReactSpeedometer
        fluidWidth={true}
        minValue={0}
        maxValue={900}
        value={currentGaugeVal}
        customSegmentStops={[0, 300, 630, 690, 720, 900]}
        segmentColors={["#e2211d", "#fa7200", "#febd00", "#c6da00", "#79be24"]}
        needleColor="steelblue"
        textColor="#2e0080"
        currentValueText={
          currentGaugeVal > 0
            ? "Current Value: ${value}"
            : "Current Value: No Score"
        }
        valueTextFontSize={"13px"}
        needleTransitionDuration={3000}
        needleHeightRatio={0.8}
      />
    </div>
  );
};

export default Gauger;
