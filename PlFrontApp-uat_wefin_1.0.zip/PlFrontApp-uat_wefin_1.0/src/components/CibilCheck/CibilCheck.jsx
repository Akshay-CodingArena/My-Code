import React, { Component } from "react";
import Gauger from "./gauge";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import TrendGraph from "./graph";
import {
  getExperian,
  loadExperianCheck,
  loadExperianGraph,
} from "../../store/experian";
import moment from "moment";
import { ReactComponent as HomeLoanIcon } from "./icons/home-loan-icon.svg";
import { ReactComponent as OverdueIcon } from "./icons/overdue.svg";
import { ReactComponent as DeleaydIcon } from "./icons/deleayd.svg";
import { ReactComponent as TickIcon } from "./icons/tick.svg";
import { ReactComponent as DotsIcon } from "./icons/dots.svg";
import { ReactComponent as OnTimePaymentIcon } from "./icons/ontime-payment.svg";
import { ReactComponent as CreditAgeIcon } from "./icons/credit-age.svg";
import { ReactComponent as CreditMixIcon } from "./icons/credit-mix.svg";
import { ReactComponent as NewCreditAccountIcon } from "./icons/new-credit-ac.svg";
import { ReactComponent as TotalAccountIcon } from "./icons/total-ac.svg";
import { getAccountType, accountStatus, existMonth } from "./accountType";
import { numberFormat } from "../../Utils/numberFormat";
import DashBoardAside from "../../common/dashboardAside";
import TopNavBar from "../../common/TopNavBar";
import { Container, Row, Col } from "react-bootstrap";
import { monthDiff, getWords } from "./creditHelper";
import CreditFooter from "../cibilFlow/footer";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import DownloadNew from "../../include/assets/download_new_2.0.svg";
import CcToolTip from "../creditCard/toolTip";
// import _ from "lodash";
import "react-accessible-accordion/dist/fancy-example.css";
import BackDropComponent from "../../common/BackDropComponent";
class CibilCheck extends Component {
  state = {
    cibilScore: "",
    graphData: [],
    error: "",
    accountNumber: "",
    Identification_Number: "",
    trendHistory: false,
    creditScore: true,
    cs_pdfpath: "",
    currentBalanceAccountSummary: false
  };

  openPdf = () => {
    window.open(this.state.cs_pdfpath)
  }
  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackVerify);
    this.props.loadExperianGraph(
      { mobile: localStorage.getItem("mobilenumber") },
      this.callBackGraph
    );
  };
  callBackGraph = (res) => {
    if (res?.data?.success) {
      this.setState({ graphData: res.data.scoreData });
    } else {
    }
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error") {
          this.setState({ error: "Something went wrong!!" });
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          this.setState({
            cibilScore: res.data.cibilData.experianData.SCORE.BureauScore[0],
            cs_pdfpath: res.data.cibilData.cs_pdfpath,
            currentBalanceAccountSummary: res.data?.cibilData?.experianData?.currentBalanceAccountSummary
          });
        }
      }
    }
  };
  trendHistoryShow = () => {
    this.setState({ trendHistory: true, creditScore: false });
  };
  creditScoreShow = () => {
    this.setState({ trendHistory: false, creditScore: true });
  };
  render() {
    const { userData } = this.props;
    let accountHistory = [];
    // let SCORE = [];
    let creditEnquiries = [];
    let totalAccountSummary = [];
    if (this.props.experian) {
      accountHistory = this.props.experian.accountHistory;
      // SCORE = this.props.experian.data;
      creditEnquiries = this.props.experian.creditEnquiries;
      totalAccountSummary = this.props.experian.totalAccountSummary;
    }

    const creditAge =
      Array.isArray(accountHistory) &&
      accountHistory.slice().sort((a, b) => {
        var da = new Date(moment(a.Open_Date?.[0]).format("YYYY-MM-DD"));
        var db = new Date(moment(b.Open_Date?.[0]).format("YYYY-MM-DD"));
        return da - db;
      });

    const creditAgeDiff = monthDiff(
      new Date(moment(new Date()).format("YYYY-MM-DD")),
      new Date(moment(creditAge?.[0]?.Open_Date?.[0]).format("YYYY-MM-DD"))
    );
    const data = Array.isArray(accountHistory) && accountHistory;
    var onTime = 0;
    var Late = 0;
    var highestCredit = 0;
    var totalLimitUsed = 0;
    var overdue = 0;
    var m = new Map();
    var arrayList = {};
    var dpdReport = [];
    if (data) {
      let newArr = [];
      dpdReport = [];
      data.map((value) => {
        if (accountStatus[value.Account_Status] === 'ACTIVE') {
          newArr.unshift(value);
          const paymenthistorylength = value.Payment_History_Profile.length <= 3 ? value.Payment_History_Profile.length - 1 : 2
          console.log('ddp report', paymenthistorylength)
          for (let i = 0; i <= paymenthistorylength; i++) {
            if (value?.Payment_History_Profile[i]?.Days_Past_Due[0] > '0') {
              dpdReport.push(value)
              continue
            }
          }
        }
        else {
          newArr.push(value)
        };
      })
      console.log('ddp report', dpdReport)

      accountHistory = newArr;

      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j <= data[i].Payment_History_Profile.length; j++) {
          if (
            data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !==
            "null" &&
            data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !== ""
          ) {
            if (
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] === "0"
            ) {
              onTime++;
            } else if (
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] > 0
            ) {
              Late++;
            }
          } else if (
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "?" ||
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "N" ||
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "S"
          ) {
            onTime++;
          } else if (
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] >
            0 ||
            data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
            "L"
          ) {
            Late++;
          }
        }
      }
    }
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (
          data[i]?.Account_Type?.[0] === "10" &&
          data[i]?.AccountStatus?.[0] !== "13"
        ) {
          highestCredit =
            parseInt(highestCredit) +
            parseInt(data[i].Highest_Credit_or_Original_Loan_Amount);
        }
        if (
          data[i]?.Account_Type?.[0] === "10" &&
          data[i]?.AccountStatus?.[0] !== "13" &&
          data[i].Amount_Past_Due?.[0] !== ""
        ) {
          totalLimitUsed =
            totalLimitUsed +
            parseInt(data[i].Amount_Past_Due?.[0]) +
            parseInt(data[i].Current_Balance?.[0]);
        }
      }
    }
    const totalPayment = onTime + Late;
    const paymentParcent = Math.round((onTime / totalPayment) * 100);
    const creditUtilization = Math.round(
      (totalLimitUsed / highestCredit) * 100
    );
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (
          this.state.accountNumber === data[i].Account_Number &&
          this.state.Identification_Number === data[i].Identification_Number
        ) {
          for (
            let j = 0;
            j <= data[i].Payment_History_Profile.length - 1;
            j++
          ) {
            arrayList = m[data[i]?.Payment_History_Profile[j]?.Year[0]];
            var element = data[i]?.Payment_History_Profile[j]?.Month[0];
            if (arrayList == null || arrayList.length < 12) {
              arrayList = {
                "01": "0",
                "02": "0",
                "03": "0",
                "04": "0",
                "05": "0",
                "06": "0",
                "07": "0",
                "08": "0",
                "09": "0",
                10: "0",
                11: "0",
                12: "0",
              };
            }
            arrayList[element] = 1;
            m.set(data[i]?.Payment_History_Profile[j]?.Year[0], arrayList);

            if (
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !==
              "null" &&
              data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] !== ""
            ) {
              if (
                data[i]?.Payment_History_Profile[j]?.Days_Past_Due?.[0] === "0"
              ) {
                m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
              } else {
                arrayList[element] = -1;
                m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
                overdue++;
              }
            } else if (
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "?" ||
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "N" ||
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "S"
            ) {
              m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
            } else if (
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] >
              0 ||
              data[i]?.Payment_History_Profile[j]?.Asset_Classification?.[0] ===
              "L"
            ) {
              arrayList[element] = -1;
              m[data[i]?.Payment_History_Profile[j]?.Year[0]] = arrayList;
              overdue++;
            }
          }
        }
      }
    }
    console.log("dpd report is", dpdReport)

    const monthMap = (month) => {
      let label = existMonth.find(({ value }) => value == month)
      console.log('data of month', month, label)
      return label.label
    }
    return (
      <>
        {this.props.loadingCheck ?
          (
            <BackDropComponent />
          ) : (
            ""
          )}

        <TopNavBar />
        <section className="bs-cs-section bs-cibil-section">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <DashBoardAside />
              </Col>
              <Col sm={12} md={9}>
                <div className="bs-cs-box">
                  <div className="bs-cs-header">
                    <span>{userData?.[0]?.name.toLowerCase()}</span>, here’s
                    your score for&nbsp;
                    {moment(userData?.[0]?.created_on).format("DD-MMM-YYYY")}
                  </div>
                  <div className="row align-items-center">
                    <Col sm={12}>
                      {this.state.trendHistory ? (
                        <TrendGraph graphData={this.state.graphData} />
                      ) : (
                        ""
                      )}
                    </Col>
                    {this.state.creditScore ? (
                      <>
                        {" "}
                        <div className="col-md-5">
                          <div className="bs-cs-circle">
                            {" "}
                            <Gauger
                              cibilScore={this.state.cibilScore}
                              error={this.state.error}
                            />
                          </div>
                        </div>
                        <div className="col-md-7">
                          <div className="bs-cs-information">
                            <h4>What does credit score mean?</h4>
                            <p>
                              It is a report based on your performance on loans.
                              It ranges between 300 and 900 and summarizes your
                              credit report, history, and rating. Banks & NBFCs uses
                              this information as one of the primary criteria for assessing your loan application.
                            </p>
                            {/* <button>Refresh Score</button> */}
                          </div>
                        </div>

                        {this.state.cs_pdfpath && <div className="col-md-12 text-right " >
                          <div className="csTooltip"><a
                            href={this.state.cs_pdfpath}
                            className="downloadBtnCreditReport"
                            download>
                            <img src={DownloadNew} />
                            Download
                          </a>
                            <CcToolTip desc={"The password to open downloaded credit report is your PAN number"} />
                          </div></div>}
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="bs-cs-logo">
                    <img src="/experian.png" alt="" width="200" height="65" />
                  </div>
                </div>
                {this.state.graphData.length > 1 && (
                  <Row className="bsGraphSection">
                    <Col className="text-center">
                      <div>
                        <h5>Know what changed in your Report</h5>
                        <a onClick={this.creditScoreShow}>
                          Check Report Changes
                        </a>
                      </div>
                    </Col>
                    <Col className="text-center">
                      <div>
                        <h5>Check your Credit History</h5>
                        <a onClick={this.trendHistoryShow}>View Score Trend</a>
                      </div>
                    </Col>
                  </Row>
                )}
                <div className="row">
                  <div className="col-sm-12">
                    <div className="bs-cs-al-cf-header">
                      <h2>Outstanding Balance</h2>
                    </div>
                    <div className="row">
                      <div className="col-sm-4">
                        <div className="outBox">
                          <p>Outstanding Bal. Secured
                            {this.state.currentBalanceAccountSummary[0]?.Outstanding_Balance_Secured?.map(data => <strong>{numberFormat(data)}</strong>)}</p>
                        </div>
                      </div>
                      <div className="col-sm-4">  <div className="outBox"><p>Outstanding Bal. UnSecured {this.state.currentBalanceAccountSummary[0]?.Outstanding_Balance_UnSecured?.map(data => <strong>{numberFormat(data)}</strong>)}</p>
                      </div> </div>
                      <div className="col-sm-4"> <div className="outBox"> <p>Outstanding Bal. All  {this.state.currentBalanceAccountSummary[0]?.Outstanding_Balance_All?.map(data => <strong>{numberFormat(data)}</strong>)}</p>
                      </div></div>

                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-sm-12">
                    <div className="bs-cs-al-cf-header">
                      <h2>Your Credit Activity</h2>
                    </div>

                    <Accordion allowZeroExpanded>
                      {Array.isArray(accountHistory) &&
                        accountHistory.map((data) => {
                          // const category = (item) => item.Year;
                          // const result = _.groupBy(
                          //   data.Payment_History_Profile,
                          //   category
                          // );
                          // const groupArrays = Object.keys(result).map(
                          //   (category) => {
                          //     return {
                          //       category,
                          //       doc: result[category],
                          //     };
                          //   }
                          // );
                          return (
                            <AccordionItem
                              onClick={() =>
                                this.setState({
                                  accountNumber: data.Account_Number,
                                  Identification_Number:
                                    data.Identification_Number,
                                })
                              }
                            >
                              <AccordionItemHeading>
                                <AccordionItemButton>
                                  <div className="row g-0 bs-cs-acl-box">
                                    <div className="col-12 col-sm-6 col-md-4">
                                      <div className="bs-cs-acl-card">
                                        <HomeLoanIcon />
                                        <div>
                                          <h4>{data.Identification_Number}</h4>
                                          <span>
                                            {" "}
                                            <small>
                                              {
                                                getAccountType[
                                                data.Account_Type
                                                ]
                                              }
                                            </small>
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="col-12 col-md-3">
                                      <h4>Loan Number</h4>
                                      <p>{data.Account_Number}</p>
                                    </div>
                                    <div className="col-8 col-sm-6 col-md-4">
                                      <h4>Loan Amount</h4>
                                      <p>
                                        {numberFormat(
                                          data.Highest_Credit_or_Original_Loan_Amount
                                        )}
                                      </p>
                                    </div>
                                    <div className="col-4 col-sm-6 col-md-1">
                                      <h4>Status</h4>
                                      <p className="text-success">
                                        {" "}
                                        {accountStatus[data.Account_Status] ? accountStatus[data.Account_Status] : "N/A"}
                                      </p>
                                    </div>
                                  </div>
                                </AccordionItemButton>
                              </AccordionItemHeading>
                              <AccordionItemPanel>
                                <div className="container bs-cibil-details-box">
                                  <div className="row bs-cs-acl-box bs-cibil-row">
                                    <div className="col-7 col-sm-8 col-md-10">
                                      <div>
                                        <h4>Payment History</h4>
                                      </div>
                                    </div>
                                    <div className="col-5 col-sm-2 col-md-2">
                                      <div className="btn-overdue">
                                        {overdue} Overdue
                                      </div>
                                    </div>
                                  </div>{" "}
                                  <div className="row bs-cs-acl-box bs-cibil-row">
                                    <div className="col-12 col-sm-12 col-md-12">
                                      <table className="bs-cibil-table">
                                        <tr>
                                          <th>&nbsp;</th>
                                          {existMonth.map((e1, i) => (
                                            <th>{e1.label}</th>
                                          ))}
                                        </tr>
                                        {m.size > 0 &&
                                          Object.entries(m).map(
                                            ([key, value]) => (
                                              <>
                                                <tr>
                                                  <td>{key} </td>
                                                  {Object.entries(value)
                                                    .sort()
                                                    .map(([key, value]) => (
                                                      <td key={key}>
                                                        {value === 1 ? (
                                                          <TickIcon />
                                                        ) : value === -1 ? (
                                                          <DeleaydIcon />
                                                        ) : (
                                                          <DotsIcon />
                                                        )}
                                                      </td>
                                                    ))}
                                                </tr>
                                              </>
                                            )
                                          )}
                                      </table>
                                      <hr />
                                      <div className="bs-cibil-status">
                                        <div className="bs-cibil-status-box">
                                          <TickIcon /> On Time Payment
                                        </div>
                                        <div className="bs-cibil-status-box">
                                          <DeleaydIcon /> Delayed
                                        </div>
                                        <div className="bs-cibil-status-box">
                                          <OverdueIcon />
                                          Overdue
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </AccordionItemPanel>
                            </AccordionItem>
                          );
                        })}
                    </Accordion>
                  </div>
                </div>

                <div className="row">
                  <div className="col-sm-12">
                    <div className="bs-cs-al-cf-header">
                      <h2>Credit Factors</h2>
                      <p>See the factors affecting your score</p>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-sm-6">
                    <div className="row g-0 bs-cs-acl-box cf">
                      <div className="col-7 col-sm-7">
                        <div className="bs-cs-acl-card">
                          <OnTimePaymentIcon />

                          <div>
                            <h4>Payments on time</h4>
                            <span>High Impact</span>
                          </div>
                        </div>
                      </div>

                      {paymentParcent ? (
                        <div className="col-5 col-sm-5">
                          <h4>{paymentParcent}%</h4>
                          {paymentParcent > 90 && (
                            <p className="text-success">Very Good</p>
                          )}
                          {paymentParcent > 70 && paymentParcent < 90 && (
                            <p className="text-success">Good</p>
                          )}
                          {paymentParcent < 70 && (
                            <p className="text-danger">Very poor</p>
                          )}
                        </div>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="row g-0 bs-cs-acl-box cf">
                      <div className="col-7 col-sm-7 ">
                        <div className="bs-cs-acl-card">
                          <CreditAgeIcon />

                          <div>
                            <h4>Credit History</h4>
                            <span>Medium Impact</span>
                          </div>
                        </div>
                      </div>

                      <div className="col-5 col-sm-5 ">
                        <h4> {getWords(creditAgeDiff)}</h4>
                        <p className="text-secondary">Age of account </p>
                      </div>
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="row g-0 bs-cs-acl-box cf">
                      <div className="col-7 col-sm-7 ">
                        <div className="bs-cs-acl-card">
                          <NewCreditAccountIcon />

                          <div>
                            <h4>Credit Card Utilization</h4>
                            <span>High Impact</span>
                          </div>
                        </div>
                      </div>

                      {creditUtilization ? (
                        <div className="col-5 col-sm-5">
                          <h4>{creditUtilization}%</h4>
                          <p className="text-success">Good</p>
                        </div>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="row g-0 bs-cs-acl-box cf">
                      <div className="col-7 col-sm-7">
                        <div className="bs-cs-acl-card">
                          <CreditMixIcon />

                          <div>
                            <h4>Credit Enquiry</h4>
                            <span>Low Impact</span>
                          </div>
                        </div>
                      </div>

                      <div className="col-5 col-sm-5">
                        <h4>
                          {
                            creditEnquiries?.CAPS_Summary?.[0]
                              ?.CAPSLast30Days?.[0]
                          }
                        </h4>
                        <p className="text-secondary">In Last 30 days</p>
                      </div>
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="row g-0 bs-cs-acl-box cf">
                      <div className="col-7 col-sm-7">
                        <div className="bs-cs-acl-card">
                          <TotalAccountIcon />

                          <div>
                            <h4>Total Account</h4>
                            <span>Low Impact</span>
                          </div>
                        </div>
                      </div>

                      <div className="col-5 col-sm-5">
                        <h4>
                          {totalAccountSummary?.[0]?.CreditAccountActive?.[0]}
                        </h4>
                        <p className="text-success">Active Account</p>
                      </div>
                    </div>
                  </div>
                </div>
                {dpdReport.length > 0 ? <div className="row">
                  <div className="col-sm-12">
                    <div className="bs-cs-al-cf-header">
                      <h2>DPD</h2>
                      <p>Last 90 days</p>
                    </div>
                  </div>
                </div> : ''}

                <div>
                  <div className="dpdBlock">
                    {dpdReport.map((value) => (
                      <div className="row g-0 bs-cs-acl-box">
                        <div className="col-sm-4">

                          {value.Identification_Number}
                          <span>{
                            getAccountType[value.Account_Type]
                          }</span>
                        </div>
                        <div className="col-sm-8">
                          <div className="row g-0">
                            {value?.Payment_History_Profile?.slice(0, 3).map((history, index) => (
                              <div className="col-sm-4">
                                {(index == 0 || index == 1 || index == 2) ? <div>
                                  {monthMap(history.Month[0])}  {history.Year[0]} {history.Days_Past_Due[0] > 0 ? <span className="text-danger">{history.Days_Past_Due[0]} Days</span> : <span>{history.Days_Past_Due[0]} Days</span>}
                                </div> : null}
                              </div>
                            ))}</div></div>
                      </div>

                    ))} <div className="col-sm-3"></div>
                    <div className="col-sm-3"></div>
                    <div className="col-sm-3"></div>
                    {/* <div className="col-sm-3"><p>Status</p>
                      <p>{dpdReport.length > 0 ? "Active" : "Close"}</p>
                     <p>{dpdReport[0]?.Identification_Number}</p> </div>*/}
                  </div>





                </div>
              </Col>
            </Row>

          </Container>
        </section>

        <CreditFooter />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  experian: getExperian(state).accountData,
  loadingCheck: getExperian(state).loadingCheck,
  userData: getExperian(state).userData,
  graphData: getExperian(state).graphData,
});
const mapDispatchToProps = (dispatch) => ({
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  loadExperianGraph: (params, callback) =>
    dispatch(loadExperianGraph(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CibilCheck)
);