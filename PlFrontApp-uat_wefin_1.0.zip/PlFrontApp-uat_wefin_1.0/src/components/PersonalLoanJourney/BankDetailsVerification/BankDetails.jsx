import { Container, Row, Col, Card, Modal } from "react-bootstrap";
import TopNavBar from "../../../common/TopNavBar";
import BackDropComponent from "../../../common/BackDropComponent";
import LeftMenuDecider from "../../../common/leftMenuContent";
import BankDetailsInput from "./BankDetailsInput";
import Messag from "../../../include/assets/twoWheelerLogo/mssgs.png";
import { ReactComponent as BankPlaceIcon } from "../../../include/assets/icons/bank_ac.svg";
import { ReactComponent as MatchIcon } from "../../../include/assets/icons/matchIcon.svg";
import CardMembershipIcon from "../../../include/assets/panIcon.svg";

import {
  getIfscDetails,
  saveBankDetailsInfo,
  saveBankDetailsInfoCreditSaison,
  pennyDrop,
  bankDetailsData,
} from "../../../store/bankdetails";
import Swal from "sweetalert2";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import Form from "../../../components/common/form";
import { decryptStore } from "../../../Utils/store";
import PATH from "../../../paths/Paths";
import Joi from "joi-browser";
import CONSTANTS from "../../../constants/Constants";
import { moneyplusRevoltEmandate, mandateData } from "../../../store/mandatedetails";
import ASMNavBar from "../../ASM/ASMNavBar";
import { send_link_type } from "../../common/dropdownValues";
import SelectSearch from "../../common/select";
import { ReactComponent as Money } from "../../../include/assets/money.svg";
import { getAccountInfo, getAccount } from "../../../store/account";



class BankDetails extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      branchDetails: {},
      loading: false,
      bank: {},
      emandatePopupIsOpenRevolt: false,
      emandate_url_revolt: "",
      emandatePopupIsOpenSmsTypeRevolt: false,
      data1: {
        smsTypeRevolt: send_link_type[0]
      },
    };
  }
  schema = {

    accNo: Joi.string()
      .min(10)
      .max(20)
      .required()
      .label("Enter bank account number")
      .error(() => {
        return { message: "Bank Account Number field is required." };
      }),
    reAccNo: Joi.string()
      .required()
      .label(
        "Re-enter bank account number"
      )
      .valid(Joi.ref("accNo"))
      .options({
        language: {
          any: {
            allowOnly: "!!Bank Account Number is not matched.",
          },
        },
      }).error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Re-enter bank account number field is required";
              break;
            default:
              break;
          }
        });
        return errors;
      }),
    ifscCode: Joi.string()
      .max(11)
      .required()
      .label("Enter IFSC Code")
      .error(() => {
        return { message: "IFSC Code field is required." };
      }),

  };

  componentDidMount = () => {
    let RevoltObj = this.props?.location?.state;

    if (RevoltObj?.lender === "Money Plus" && RevoltObj?.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (RevoltObj?.loanStage === "NSTP Approved" || RevoltObj?.loanStage === "Hard Approved")) {
      if (RevoltObj?.mandate_url)
        this.setState({ emandatePopupIsOpenRevolt: true, emandate_url_revolt: RevoltObj?.mandate_url });
      else {
        this.setState({ emandatePopupIsOpenSmsTypeRevolt: true })
      }
    }
    window.scrollTo(0, 0);
    document.body.classList.add("NoScrool");
    document.body.classList.remove("variantScroll");

  };

  closeModalRevolt = () => {
    this.setState({ emandatePopupIsOpenRevolt: true })

    let formData = {
      mobile: localStorage.getItem("mobilenumber")
    }
    this.props.getAccountInfo(formData, this.callbackGetAccountDetails);
  }

  callbackGetAccountDetails = (res) => {

    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
    console.log(this.props.getAccountDetail);
    let data = this.props?.getAccountDetail[0]?.tw_loans?.filter((value, index) => value.loanName === decryptedData.loanName)

    if (data[0].loanStage === "E-Mandate Completed") {
      ////send for E agreement/////////
      this.props.history.push({
        pathname: PATH.PRIVATE.PERSONAL_DETAIL,
        state:
        {
          bike: this.props.location.state.bike,
          step: CONSTANTS.RENDER_ESIGN_AGREEMENT_REVOLT
        }
      });

    } else {
      //////////////show swal for return after some time/////
      Swal.fire({
        icon: "warning",
        title: "Process will take some time.Please come back after some time...",
        confirmButtonText: "Ok",
        confirmButtonColor: "#d63031",
      }).then((res) => {
        if (res.isConfirmed) {
          if (localStorage.getItem("isASM")) {
            this.props.history.push(PATH.PRIVATE.ASM_DASHBOARD);
          } else {
            this.props.history.push(PATH.PRIVATE.PRODUCTS);
          }
        }
      });
    }
  }


  closeModalSmsTypeRevolt = () => {
    this.setState({ emandatePopupIsOpenSmsTypeRevolt: false })
  }

  callbackEmandateRevolt = (res) => {

    if (res?.data?.success) {
      this.setState({ emandatePopupIsOpenSmsTypeRevolt: false, emandatePopupIsOpenRevolt: true, emandate_url_revolt: res.data.emandate.short_url });
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res?.data?.description ? res.data.description : "Some error occured",
        showConfirmButton: false,
        timer: 1800,
      });
    }
  }


  _handleIFSC = (e) => {
    let v = e.target.value.toUpperCase();
    if (e.target.value.length <= 11) {
      this.setState((p) => ({
        ...p,
        data: { ...p.data, ifscCode: v },
        errors: { ...p.errors, ifscCode: "" },
      }));
      if (e.target.value.length === 11) {

        let formData = {
          ifsc: v
        };
        this.setState({ loading: true });
        this.props.getIfscDetails(formData, this.submitIFSCCallback);
      }
    }
  };
  submitIFSCCallback = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        this.setState({ branchDetails: r.data, loading: false });
      } else {
        throw new Error(r.data.message);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        icon: "warning",
        title: e.message.toString(),
      });
    }
  };

  callBackPennyDrop = (res) => {
    if (res) {
      let mobile = localStorage.getItem("mobilenumber")
      let { loanType, lenderName, loanStage } = decryptStore(mobile)
      if (res.data.success) {
        this.props.history.push({
          pathname: PATH.PRIVATE.PERSONAL_DETAIL,
          state: { bike: this.props.location.state.bike, step: CONSTANTS.RENDER_WAITING_SCREEN_REVOLT, loanType: loanType, lender: lenderName, loanStage: "Bank Detail Validated" }
        })
      }
      else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res?.data?.message ? res.data.message : "Some error occured",
          showConfirmButton: false,
          timer: 1800,
        });
      }
    }
  }

  doSubmit = () => {

    this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid, loanId, loanType, manufacturer, lenderId, loanSfid } = decryptStore(mobile);
    let branchData = { ...this.state.branchDetails };
    if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && manufacturer === "REVOLT") {
      let formData = {
        mobile: mobile,
        ifscCode: this.state.data.ifscCode,
        loanId: loanId ? loanId : localStorage.getItem("loansfid"),
        loanSfid: loanSfid,
        bankAccNo: this.state.data.reAccNo,
        lenderId: lenderId,
        accountSfid: localStorage.getItem("accsfid") || ""
      };
      this.props.pennyDrop(formData, this.callBackPennyDrop)
    } else {
      let formData = {
        branchCode: branchData.branchCode,
        mobile: mobile,
        ifscCode: this.state.data.ifscCode,
        branch: branchData.branch,
        branchAddress: branchData.address,
        loanId: loansfid ? loansfid : localStorage.getItem("loansfid"),
        bankAccNo: this.state.data.reAccNo,
        bankName: branchData.bankName,
      };
      this.setState({ loading: true });
      this.props.saveBankDetailsInfoCredit(
        formData,
        this.saveAccInfoCallBackCredit
      );
    }
  };


  saveAccInfoCallBackCredit = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        this.setState({ loading: false });
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType } = decryptedData;
        if (parseInt(this.state.bank.appliedLoanAmount) > 100000) {
          this.props.history.push({
            pathname: `${PATH.PRIVATE.VERIFY_INCOME_PERFIOS}/${loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank
              ? this.state.bank
              : this.props.location.state,
          });

        } else {
          this.setState({ loading: false });
          this.props.history.push({
            pathname: `${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}/${loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank
              ? this.state.bank
              : this.props.location.state,
          });
        }
      } else {
        throw r?.data?.description;
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: false,
        timer: 1800,
      });
    }
  };


  handleSubmitSMSType = () => {
    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

    let formData =
    {
      name: localStorage.getItem("fullName") || "",
      email: localStorage.getItem("email") || "",
      mobile: localStorage.getItem("mobilenumber") || "",
      loanId: decryptedData.loanId,
      loanName: decryptedData.loanName,
      accountSfid: localStorage.getItem("accsfid") || "",
      sms: this.state.data1.smsTypeRevolt.value === 0 ? '1' : '0',
      esms: this.state.data1.smsTypeRevolt.value === 1 ? '1' : '0',
      loanAmount: decryptedData.appliedLoanAmount || 100000
    }

    this.props.moneyplusRevoltEmandate(formData, this.callbackEmandateRevolt)

  }

  render() {
    console.log("------TESTING-----");
    //    console.log(bankDetailsData)
    let accStatusSuccess

    if (this.state.data.accNo && this.state.data.reAccNo) {
      if (this.state.data.accNo === this.state.data.reAccNo) {
        accStatusSuccess = true
      }
    } return (
      <>
        {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
        {this.props.loadingLogin || this.props.loadingSaveBankDetails || this.props.loadingRevoltEmandate || this.props.loadingGetAccountDetail ? <BackDropComponent /> : ""}
        <section className="bs-main-section bsBankDetails">
          <Container>
            <Row>
              {decryptStore(localStorage.getItem("mobilenumber")).loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
                <Col xs="12" sm="3">
                  <LeftMenuDecider activeStep={this.props?.location?.state.loanStage === "Hard Approved" || this.props?.location?.state.loanStage === "NSTP Approved" ? 4 : 3} />
                </Col> :
                <Col xs="12" sm="3">
                  <LeftMenuDecider activeStep={4} />
                </Col>
              }

              <Col xs="12" sm="9">
                <Card>
                  {this.state.loading ? <BackDropComponent /> : ""}
                  <Card.Header className="text-center">
                    <h5>Bank Detail Verification</h5>
                  </Card.Header>

                  <Card.Body className="insideFormBlock">
                    <div className="text-center headerTxt">
                      Enter Your Salary Bank Account Details
                    </div>
                    <form className="panVeryfyForm">
                      <Row className="g-0 panFormFields">
                        <Col sm={12}>
                          {this.renderInput(
                            "accNo",
                            "Enter bank account number",
                            <BankPlaceIcon />,
                            false,
                            20,
                            9,
                            "password"
                          )}
                          {accStatusSuccess &&
                            <small
                              className={
                                accStatusSuccess
                                  ? "make-success match-sucess"
                                  : "make-danger"
                              }
                            >
                              <MatchIcon />
                            </small>}
                        </Col>
                        <Col sm={12}>
                          {this.renderInput(
                            "reAccNo",
                            "Re-enter bank account number",
                            <BankPlaceIcon />,
                            false,
                            20,
                            9
                          )}

                          {accStatusSuccess &&
                            <small
                              className={
                                accStatusSuccess
                                  ? "make-success match-sucess"
                                  : "make-danger"
                              }
                            >
                              <MatchIcon />
                            </small>}
                        </Col>
                        <Col sm={12}>
                          <BankDetailsInput
                            value={this.state.data.ifscCode}
                            __handleChange={this._handleIFSC}
                            error=""
                            icon={
                              <img
                                src={CardMembershipIcon}
                                alt={"bankIFSCIcon"}
                                width="21"
                                height="20"
                              />
                            }
                            label="Enter IFSC Code"
                            required={true}
                            setMaxLength={11}
                          />
                          {this.state.errors.ifscCode && (
                            <p className="bsInputErr">
                              {this.state.errors.ifscCode}
                            </p>
                          )}
                        </Col>
                        <Col sm={12} className="bsBankAddress">
                          {" "}
                          <div className="label">
                            Branch Address
                          </div>
                          <textarea
                            rows={3}
                            disabled={true}
                            value={this.state.branchDetails.address}
                            required={true}
                            isDisabled={true}
                          />
                        </Col>
                        <Col className="text-center">
                          <button
                            type="submit"
                            onClick={this.handleSubmit}
                            variant="contained"
                            className="nextButton"
                          >
                            Next
                          </button>
                        </Col>
                      </Row>
                    </form>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </Container>

          <Modal
            className="bsMoneyPlusModal"
            show={this.state.emandatePopupIsOpenSmsTypeRevolt}
            closeButton={true}
            onHide={this.closeModalSmsTypeRevolt}
          >
            <Modal.Body className="text-center">

              <div className="row insideFormBlock ml-3 mr-3 mt-3">
                <div className="col-sm-12">
                  <form className="panVeryfyForm">
                    <div className="panFormFields">
                      <div className="row">
                        <div className="col-sm-12 text-center">
                          <div className="bsFormHeader">
                            <h1>E-mandate Details</h1>
                          </div>
                        </div>
                        <div className="col-sm-12 ">
                          <SelectSearch
                            style={{ margin: "15px 8px 20px" }}
                            placeholderValue={"Select SMS Type"}
                            label={"SMS Type"}
                            value={this.state.data1.smsTypeRevolt}
                            page="personal"
                            setSelectedOption={(e) => {
                              const data = { ...this.state.data1 };
                              if (e) {
                                data.smsTypeRevolt = e;
                                this.setState({ data1: data });
                              }
                            }}
                            dropDownOptions={send_link_type}
                            icon={
                              <img src={Messag} alt="" width="" height="" />
                            }
                          ></SelectSearch>
                        </div>

                        <div className="col-sm-12 text-center">
                          <button
                            type="button"
                            onClick={this.handleSubmitSMSType}
                            variant="contained"
                            className="nextButton"
                          >
                            Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </Modal.Body>
          </Modal>

          <Modal
            className="bsMoneyPlusModal bsEmandateModal"
            show={this.state.emandatePopupIsOpenRevolt}
            closeButton={true}
            onHide={this.closeModalRevolt}
          >
            <Modal.Body className="text-center">
              <div className="container-iframe">
                <iframe class="responsive-iframe" src={this.state.emandate_url_revolt}></iframe>
              </div>
            </Modal.Body>
          </Modal>
        </section>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  loadingSaveBankDetails: bankDetailsData(state).loadingSaveBankDetails,
  loadingRevoltEmandate: mandateData(state).loadingRevoltEmandate,
  loadingGetAccountDetail: getAccount(state).loading,
  getAccountDetail: getAccount(state).getAccountDetail
});
const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  pennyDrop: (params, callBack) =>
    dispatch(pennyDrop(params, callBack)),
  getIfscDetails: (params, callBack) =>
    dispatch(getIfscDetails(params, callBack)),
  saveBankDetailsInfo: (params, callBack) =>
    dispatch(saveBankDetailsInfo(params, callBack)),
  saveBankDetailsInfoCredit: (params, callBack) =>
    dispatch(saveBankDetailsInfoCreditSaison(params, callBack)),
  moneyplusRevoltEmandate: (params, callBack) =>
    dispatch(moneyplusRevoltEmandate(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(BankDetails)
);
