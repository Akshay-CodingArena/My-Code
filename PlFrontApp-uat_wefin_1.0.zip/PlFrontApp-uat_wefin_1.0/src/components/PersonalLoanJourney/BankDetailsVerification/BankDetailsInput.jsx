import React from "react";
const BankDetailsInput = (props) => {
  return (
    <div className="form-group">
      <label htmlFor={props.label}>
        {props.label}
        {props.required === true ? (
          <span style={{ color: "#FF4C30" }}>*</span>
        ) : (
          ""
        )}{" "}
      </label>
      <input
        className="form-control"
        placeholder={props.label}
        value={props.value ? props.value : ""}
        onChange={(e) => props.__handleChange(e)}
        maxLength={props.setMaxLength}
        minLength={props.setMinLength}
        disabled={props.isDisabled ? props.isDisabled : false}
        id={props._id}
      />

      <span className="input-icon">{props.icon}</span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default BankDetailsInput;
