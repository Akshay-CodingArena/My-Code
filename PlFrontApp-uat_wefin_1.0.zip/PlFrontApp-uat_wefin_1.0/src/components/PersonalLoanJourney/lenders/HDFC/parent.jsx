import React, { useEffect, useState } from "react";
import LeftMenuDecider from "../../../../common/leftMenuContent";
import TopNavBar from "../../../../common/TopNavBar";
import CONSTANTS from "../../../../constants/Constants";
import { Container, Row, Col } from "react-bootstrap";
import { useLocation } from "react-router";
import CreditFooter from "../../../cibilFlow/footer";
import AdditionalDetails from "./AdditionalDetails";
import AdditionalInfo from "../../bankVerification/additionalInformation";
import HomeLoanAdditionalInfo from "../../../HomeLoanJourney/BankDetailsVerification/HomeOffer";
import OfficeAddress from "../../bankVerification/officeAddress";
import PrimaryRefDetail from "../../bankVerification/PrimaryRefDetail";
import ReferenceDetails from "./ReferenceDetails";
import CongratulationsHDFC from "./Congratulations";
import UploadDocs from "./UploadDocs";
import Reject from "./Rejected";
const HdfcBank = (props) => {
    const location = useLocation();
    const [step, setStep] = useState(CONSTANTS.UPLOAD_DOCUMENT_HDFC);
    //  let [data, setData] = useState({});
    const [stepperData, setStepperData] = useState({});
    const [data, setData] = useState({});
    let [stepperStep, setStepperStep] = useState(3);
    let [dropOffData, setDropoffData] = useState({})


    const updateStep = (e, page) => {

        if (e) e.preventDefault();
        localStorage.setItem("step", page);


        if (page === CONSTANTS.CONGRATULATIONS_HDFC) {
            setStep(page);
            localStorage.setItem("stepperStep", 6)
            setStepperStep(6);
        } else if (page === CONSTANTS.REFERENCE_DETAILS_HDFC) {
            setStep(page);
            localStorage.setItem("stepperStep", 4)
            setStepperStep(4);
        } else if (page === CONSTANTS.UPLOAD_DOCUMENT_HDFC) {
            setStep(page);
            localStorage.setItem("stepperStep", 5)
            setStepperStep(5);
        }

        else {
            setStep(page);
        }

    };


    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        ///////////////update step and data///////////
        let step = location.state?.step;
        let stepperData = location.state?.stepperData;
        let stepperStepLocal = location.state.stepperStep ? location.state.stepperStep : stepperStep

        if (isNaN(parseInt(localStorage.getItem("step")))) {
            localStorage.setItem("step", step)
        }

        if (!localStorage.getItem("loanInfo")) {
            localStorage.setItem("loanInfo", JSON.stringify(stepperData))
        }

        if (!localStorage.getItem("uploadDocInfo")) {
            localStorage.setItem("uploadDocInfo", JSON.stringify(data))
        }

        if (!localStorage.getItem("stepperStep")) {
            localStorage.setItem("stepperStep", JSON.stringify(stepperStepLocal))
        }

        setStep(parseInt(localStorage.getItem("step")));
        setStepperData(JSON.parse(localStorage.getItem("loanInfo")));
        setData(JSON.parse(localStorage.getItem("uploadDocInfo")));
        setStepperStep(JSON.parse(localStorage.getItem("stepperStep")));
        setDropoffData(location.state.dropoffData ? location.state.dropoffData : {})

        return () => {
            localStorage.removeItem("step");
            localStorage.removeItem("loanInfo");
            localStorage.removeItem("uploadDocInfo");
            localStorage.removeItem("stepperStep")
        }
    }, []);



    const leftSideStep = () => {
        switch (step) {
            case CONSTANTS.ADDITIONAL_INFO_HDFC_PL:
                return (
                    <AdditionalDetails
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                );
            case CONSTANTS.RESIDENCE_ADDRESS_HDFC:
                return (
                    <HomeLoanAdditionalInfo
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                );
            case CONSTANTS.OFFICE_ADDRESS_HDFC:
                return (
                    <OfficeAddress
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                );
            case CONSTANTS.REFERENCE_DETAILS_HDFC:
                return (
                    <ReferenceDetails
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                )
            case CONSTANTS.CONGRATULATIONS_HDFC:
                return (
                    <CongratulationsHDFC
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                )
            case CONSTANTS.UPLOAD_DOCUMENT_HDFC:
                return (
                    <UploadDocs
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                )
            case CONSTANTS.FAILED_SCREEN_HDFC:
                return (
                    <Reject
                        updateStep={updateStep}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                        data={data}
                        setData={setData}
                        dropoffData={dropOffData}
                    />
                )
        }
    };

    return (
        <>
            <TopNavBar />
            <section className="bs-main-section">
                <Container>
                    <Row>
                        <Col sm={12} md={3}>
                            <LeftMenuDecider activeStep={stepperStep} stepperData={stepperData} />
                        </Col>
                        <Col sm={12} md={9}>
                            {leftSideStep()}
                        </Col>
                    </Row>
                </Container>
            </section>
            <CreditFooter />
        </>
    );
};

export default HdfcBank;
