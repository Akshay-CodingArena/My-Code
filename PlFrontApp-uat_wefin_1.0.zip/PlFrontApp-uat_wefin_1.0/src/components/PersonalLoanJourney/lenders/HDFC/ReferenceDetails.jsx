import React from "react";
import Joi from "joi-browser";
import Form from "../../../common/form";
import { ReactComponent as AddressLine1Icon } from "../../../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as LandlineIcon } from "../../../../include/assets/fullertonLogos/Group 20283.svg";
import CONSTANTS from "../../../../constants/Constants";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import PersonalInput from "../../../common/personalInput";
import { ReactComponent as PersonIcon } from "../../../../include/assets/Profile.svg";
import BackDropComponent from "../../../../common/BackDropComponent";
import { decryptStore, encryptStore } from "../../../../Utils/store";
import { hdfcPL, hdfcReference } from "../../../../store/personalLoan/hdfc";
import Swal from "sweetalert2";


class ReferenceDetails extends Form {
    state = {
        data: {},
        errors: {},
        loading: false
    };
    schema = {
        phone: Joi.number()
            .required()
            .label("Phone No.")
            .error(() => {
                return { message: "Phone No. must be a number." };
            }),
        firstName: Joi.string()
            .required()
            .label("First Name")
            .error(() => {
                return { message: "First Name field is required." };
            }),
        lastName: Joi.string()
            .required()
            .label("First Name")
            .error(() => {
                return { message: "Last Name field is required." };
            })
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.add("NoScrool");
        document.body.classList.remove("variantScroll");

        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

        if (decryptedData.isDropoff && decryptedData.lenderName === "HDFC") {
            let dropOffData = this.props.dropoffData;
            let data = { ...this.state.data };
            data.phone = dropOffData.ref1mobile ? dropOffData.ref1mobile : "";
            data.firstName = dropOffData.ref1firstname ? dropOffData.ref1firstname : "";
            data.lastName = dropOffData.ref1lastname ? dropOffData.ref1lastname : "";

            this.setState({ data })
        }
    };

    doSubmit = () => {
        this.hdfcReferenceFunc();
    };


    hdfcReferenceFunc = () => {
        if (localStorage.getItem("mobilenumber") === this.state.data.phone) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "Reference mobile number must be different.",
                showConfirmButton: false,
                timer: 1800,
            });
        } else if (localStorage.getItem("fullName").toLowerCase() === (this.state.data.firstName.toLowerCase() + " " + this.state.data.lastName.toLowerCase())) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "Please enter the another valid reference's name, not your own.",
                showConfirmButton: false,
                timer: 1800,
            });
        } else {
            let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
            let formData = {
                lenderId: decryptedData.lenderId,
                loanName: decryptedData.loanName,
                sfid: decryptedData.sfid,
                applicationId: decryptedData.applicationId,
                ref1FirstName: this.state.data.firstName,
                ref1LastName: this.state.data.lastName,
                ref1Mobile: this.state.data.phone,
                deviceId: decryptedData.deviceId,
                platform: "Website"
            }
            this.props.hdfcReference(formData, this.callbackReferenceHdfc)
        }
    }

    callbackReferenceHdfc = (res) => {
        if (res.data.success) {
            encryptStore(localStorage.getItem("mobilenumber"), { reqId: res.data.response.AddReferenceResponse.AddReferenceResult.reqId });
            let docArr = res.data.response.AddReferenceResponse.AddReferenceResult.ParentDocMaster.Parent_Doc.length ? res.data.response.AddReferenceResponse.AddReferenceResult.ParentDocMaster.Parent_Doc : [];
            docArr = docArr.filter((value, index) => {
                /////////////////remove optional paramters//////////////
                if (value.Parent_Doc_Desc === "VCIP" || value.Parent_Doc_Desc === "DIGITAL-VIDEO KYC P SAL" || value.Parent_Doc_Desc === "VIDEO KYC" || value.Parent_Doc_Desc === "APPLICATION FORM") {
                    return false
                }
                return true;
            })
            localStorage.setItem("uploadDocInfo", JSON.stringify({ docData: docArr }))

            this.props.setData({ ...this.props.data, docData: docArr })

            this.props.updateStep(null, CONSTANTS.UPLOAD_DOCUMENT_HDFC);
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.message,
                showConfirmButton: false,
                timer: 1800,
            });
        }
    }


    __handleFirstNameChange = (e) => {
        let letters = /^[A-Za-z\s]+$/;
        if (e.target.value !== "" && e.target.value.match(letters)) {
            this.setState((p) => ({
                ...p,
                data: { ...p.data, firstName: e.target.value },
                errors: { ...p.errors, firstName: "" },
            }));
        } else {
            this.setState((p) => ({
                ...p,
                data: { ...p.data, firstName: "" },
                errors: {
                    ...p.errors,
                    firstName: "Only alphabets are allowed the in Name Field",
                },
            }));
        }
    };


    __handleLastNameChange = (e) => {
        let letters = /^[A-Za-z\s]+$/;
        if (e.target.value !== "" && e.target.value.match(letters)) {
            this.setState((p) => ({
                ...p,
                data: { ...p.data, lastName: e.target.value },
                errors: { ...p.errors, lastName: "" },
            }));
        } else {
            this.setState((p) => ({
                ...p,
                data: { ...p.data, lastName: "" },
                errors: {
                    ...p.errors,
                    lastName: "Only alphabets are allowed the in Name Field",
                },
            }));
        }
    };




    __handlePhoneNumber = (e) => {
        let value = e.target.value.replace(/[A-Za-z]/ig, "");
        let data = { ...this.state.data };
        data.phone = value;
        let errors = { ...this.state.errors };
        if (value.length < 10) {
            errors.phone = "Phone number must be 10 digits long."
            this.setState({ data, errors })
        } else if (value.length === 10) {
            errors.phone = "";
            this.setState({ data, errors })
        }
    }

    render() {
        return (
            <div className="row insideFormBlock">
                <div className="col-sm-12 text-center">
                    <div className="bsFormHeader">
                        <h1> Reference Information </h1>
                    </div>
                </div>
                <div className="col-sm-12">
                    <form className="panVeryfyForm">
                        <div className="row">
                            {this.props.loadingPinCode || this.props.loadingReferenceDetailsHdfc ? <BackDropComponent /> : ""}
                            <div className="col-sm-6">
                                {" "}
                                <PersonalInput
                                    value={this.state.data.firstName}
                                    __handleChange={this.__handleFirstNameChange}
                                    error={this.state.errors.firstName}
                                    icon={<PersonIcon />}
                                    label="First Name"
                                    readOnly={false}
                                />
                            </div>

                            <div className="col-sm-6">
                                {" "}
                                <PersonalInput
                                    value={this.state.data.lastName}
                                    __handleChange={this.__handleLastNameChange}
                                    error={this.state.errors.lastName}
                                    icon={<PersonIcon />}
                                    label="Last Name"
                                    readOnly={false}
                                />
                            </div>

                            <div className="col-sm-6">
                                <PersonalInput
                                    value={this.state.data.phone}
                                    __handleChange={this.__handlePhoneNumber}
                                    error={this.state.errors.phone}
                                    icon={<PersonIcon />}
                                    label="Phone Number"
                                    readOnly={false}
                                />
                            </div>


                            <div className="col-sm-12 text-center">
                                <button
                                    type="submit"
                                    onClick={this.handleSubmit}
                                    variant="contained"
                                    className="nextButton"
                                >
                                    Next
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    loadingReferenceDetailsHdfc: hdfcPL(state).loadingReferenceDetailsHdfc
});
const mapDispatchToProps = (dispatch) => ({
    hdfcReference: (params, callback) => dispatch(hdfcReference(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ReferenceDetails)
);
