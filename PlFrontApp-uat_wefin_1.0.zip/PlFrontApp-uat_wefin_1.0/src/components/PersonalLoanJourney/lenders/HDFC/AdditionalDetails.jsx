import React from "react";

import { ReactComponent as PersonIcon } from "../../../../include/assets/Profile.svg";
import Dependent from "../../../../include/assets/personalLoan/dependent.svg";
import SelectSearch from "../../../common/select";
import Form from "../../../common/form";
import Joi from "joi-browser";
import CONSTANTS from "../../../../constants/Constants";
import { decryptStore } from "../../../../Utils/store";
import { HDFC_Educational_Qualification_Dropdown, qualificationField } from "../../../common/dropdownValues";
import Qualification from "../../../../include/assets/personalLoan/qualification.svg";
import Radio from "../../../common/Radio";


const optionsDependent = [
    { value: "0", label: "None" },
    { value: "1", label: "1" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
    { value: "5", label: "5" },

];
class AdditionalDetails extends Form {
    state = {
        data: {
            salaryAccount: false
        }, errors: {}
    };
    schema = {
        dependent: Joi.object()
            .required()
            .error(() => {
                return { message: "Dependent is required." };
            }),
        qualification: Joi.object()
            .required()
            .error(() => {
                return { message: "Qualification is required." };
            }),
        salaryAccount: Joi.boolean().required()


        // loanPupose: Joi.object()
        //     .required()
        //     .error(() => {
        //         return { message: "Loan Purpose field is required." };
        //     }),
    };

    doSubmit = () => {
        this.props.setStepperData((prevState) => ({
            ...prevState,
            // maritalStatus: this.state.data.maritalStatus.value,
            dependent: this.state.data.dependent.value,
            salaryAccount: this.state.data.salaryAccount,
            qualification: this.state.data.qualification
            // loanPupose: this.state.data.loanPupose.value,
        }));

        let tempData = {
            ...this.props.stepperData,
            dependent: this.state.data.dependent.value,
            salaryAccount: this.state.data.salaryAccount,
            qualification: this.state.data.qualification
        }

        localStorage.setItem("loanInfo", JSON.stringify(tempData));

        this.props.updateStep(null, CONSTANTS.RESIDENCE_ADDRESS_HDFC);

    };
    componentDidMount = () => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        if (decryptedData.isDropoff) {
            let dropOffData = this.props.dropoffData;
            let data = { ...this.state.data };
            data.dependent = optionsDependent.filter((data, index) => data.value === dropOffData.number_of_dependents)[0];
            data.salaryAccount = dropOffData.have_sal_acc === "true" ? true : false
            data.qualification = HDFC_Educational_Qualification_Dropdown.filter((data, index) => data.value == dropOffData.education_qualification)[0]

            this.setState({ data })
        }
    }

    handleSalaryAcc = (value) => {
        console.log(value)
        this.setState({ ...this.state, data: { ...this.state.data, salaryAccount: value } })
    }
    render() {
        // let mobile = localStorage.getItem("mobilenumber");
        // let decryptedData = decryptStore(mobile);
        // let { loanType } = decryptedData;
        return (
            <>
                {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_PERSONAL_DETAIL);
          }}
        /> */}
                <div className="row insideFormBlock">
                    <div className="col-sm-12 text-center">
                        <div className="bsFormHeader">


                            <h1> Additional Information </h1>
                        </div>
                    </div>

                    <div className="col-sm-12">
                        <form className="panVeryfyForm">
                            <ul className="nav nav-pills bs-form-tab">
                                <li>
                                    <a className="active">Personal Details</a>
                                </li>
                            </ul>
                            <div className="tab-content clearfix">
                                <div className="row">
                                    <div className="col-sm-6">
                                        <SelectSearch
                                            placeholderValue={"Qualification"}
                                            label={"Qualification"}
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.qualification = e;
                                                    errors.qualification = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={
                                                HDFC_Educational_Qualification_Dropdown
                                            }
                                            error={this.state.errors.qualification}
                                            value={this.state.data.qualification}
                                            icon={
                                                <img src={Qualification} width="" height="" />
                                            }
                                        ></SelectSearch>
                                    </div>
                                    <div className="col-sm-6">
                                        <SelectSearch
                                            placeholderValue={"Select"}
                                            label={"No. of Dependent"}
                                            value={this.state.data.dependent}
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.dependent = e;
                                                    errors.dependent = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={optionsDependent}
                                            error={this.state.errors.dependent}
                                            icon={
                                                <img src={Dependent} width="" height="" />
                                            }
                                        ></SelectSearch>
                                    </div>
                                    <div className="col-sm-6">
                                        <p className="mb-2">Do you have a salary account?<span style={{ color: "red" }}>*</span></p>
                                        <Radio label="Yes" value={true} groupValue={this.state.data.salaryAccount} onClick={() => this.handleSalaryAcc(true)} />
                                        <Radio label="No" value={false} groupValue={this.state.data.salaryAccount} onClick={() => this.handleSalaryAcc(false)} />
                                    </div>
                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Next
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </>
        );
    }
}


export default (AdditionalDetails)

