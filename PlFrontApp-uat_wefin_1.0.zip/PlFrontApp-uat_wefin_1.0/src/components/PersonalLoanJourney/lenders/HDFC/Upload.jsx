import { useState } from "react";
import CustomUpload from "../../../ExternalVerifier/components/CustomUpload"
import SelectSearch from "../../../common/select";
import { ReactComponent as PersonIcon } from "../../../../include/assets/Profile.svg";


const Upload = ({ title, id }) => {
    const [state, setState] = useState({ data: { relationship: "male" }, errors: { relationship: false } })

    return (<>

    </>
    )
}

export default Upload