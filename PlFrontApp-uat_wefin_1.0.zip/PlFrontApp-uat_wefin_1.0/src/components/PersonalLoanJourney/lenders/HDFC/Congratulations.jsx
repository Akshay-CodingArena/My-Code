import React from "react";
import CONSTANTS from "../../../../constants/Constants";
import ReactLottie from "../../../common/reactLotte";
import HorizontalTimeline from './HorizontalTimeline';
import { Component } from "react";
import { decryptStore } from "../../../../Utils/store";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { hdfcPL, hdfcStatus } from "../../../../store/personalLoan/hdfc";
import BackDropComponent from "../../../../common/BackDropComponent";
import Swal from "sweetalert2";

const events = [
    {
        date: 'January 2023',
        description: 'Event 1 description...',
    },
    {
        date: 'March 2023',
        description: 'Event 2 description...',
    },
    // Add more events here...
];





const list =
    [
        { value: "Quick Data Entry", label: "Case Initiated", activeStep: 0 },
        { value: "SAS", label: "Under Process", activeStep: 1 },
        { value: "Cibil Process", label: "Under Process", activeStep: 1 },
        { value: "DDEBRE", label: "Under Process", activeStep: 1 },
        { value: "In-Principle Approval", label: "Under Process", activeStep: 1 },
        { value: "DUP", label: "Under Process", activeStep: 1 },
        { value: "Detail Data Entry", label: "Under Process", activeStep: 1 },
        { value: "In-Principle Approval2", label: "Under Process", activeStep: 1 },
        { value: "Dedupe Referral", label: "Under Process", activeStep: 1 },
        { value: "Ric Scoring", label: "Under Process", activeStep: 1 },

        { value: "Underwriting AUTO or Underwriting", label: "Decision Awaited", activeStep: 3 },
        { value: "Underwriting AUTO", label: "Decision Awaited", activeStep: 3 },
        { value: "Underwriting", label: "Decision Awaited", activeStep: 3 },

        { value: "Template Approval", label: "Approved", activeStep: 4 },
        { value: "Post Sanc Doc", label: "Approved", activeStep: 4 },

        { value: "END", label: "Disbursed", activeStep: 4 },
        { value: "DID", label: "Disbursed", activeStep: 4 },


        { value: "FI Completion", label: "Verification Pending", activeStep: 2 },
        { value: "FI Initiation", label: "Verification Pending", activeStep: 2 },
        { value: "FI Verification Detail", label: "Verification Pending", activeStep: 2 },


        { value: "Mini Dedupe Referral", label: "Duplicate case", activeStep: "N/A" },
        { value: "Document Collection", label: "Pre-Sanction Document Check", activeStep: "N/A" },


        { value: "Rejection Activity ", label: "Reject", activeStep: "N/A" },
        { value: "CANCEL", label: "Cancelled", activeStep: "N/A" },

        { value: "Rejection Activity ", label: "Reject", activeStep: "N/A" },
        { value: "CANCEL", label: "Cancelled", activeStep: "N/A" },
        { value: "UND Pending", label: "Additional Documents / Check pending", activeStep: "N/A" },

    ]
class CongratulationsHDFC extends Component {

    state = {
        hdfcStatus: ""
    };

    checkStatus = () => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        const formData = {
            "lenderId": decryptedData.lenderId,
            "loanName": decryptedData.loanName,
            "sfid": decryptedData.sfid,
            "filler1": decryptedData.Filler1,
            "filler4": decryptedData.Filler4,
            "platform": "Website",
            "deviceId": decryptedData.deviceId,
            "mobileNumber": localStorage.getItem("mobilenumber"),
            "applicationId": decryptedData.applicationId
        }
        this.props.hdfcStatus(formData, this.callbackStatusHdfc)
    }



    componentDidMount = () => {
        this.checkStatus();
    }

    callbackStatusHdfc = (res) => {
        if (res.data.success) {
            let status = res.data.response.getStatusEnquiryResponse.getStatusEnquiryResult.status.split(" , ")[0];
            if (status?.length) {
                this.setState({ hdfcStatus: status })
            } else {
                this.setState({ hdfcStatus: "" })
            }
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: false,
                timer: 1800,
            });
        }
    }


    render() {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        return (

            <div className="col-sm-12" >
                {this.props.loadingHdfcStatus ? <BackDropComponent /> : ""}
                <div className="CongratsContainer backImage hdfc_congratulations">

                    <div className="CongratsMain">
                        <div className="mt-3" style={{ margin: "auto", width: "95%" }}>
                            <div>
                                <div
                                    style={{
                                        padding: "10px 20px 0px 20px",
                                        marginBottom: "30px",
                                        textAlign: "center",
                                        color: "#2E0080",
                                        fontWeight: "400",
                                        fontSize: "20px",
                                    }}
                                >
                                    <p>Thank You for applying for HDFC personal loan offer. Your HDFC loan application ID is</p>
                                    <b>{decryptedData.applicationId ? decryptedData.applicationId : "N/A"}</b>

                                    <p className="mb-3">Loan Application No : <b>{decryptedData.loanName}</b></p>

                                    <hr style={{ backgroundColor: 'black', height: '2px', margin: '15px 15px' }} />


                                    <b>Application Status :</b>

                                    <div className="hdfc_status">
                                        {(this.state.hdfcStatus.label !== "Duplicate Case") || (this.state.hdfcStatus.label !== "Reject") ? <HorizontalTimeline data={this.state.hdfcStatus} /> :
                                            <div style={{ margin: "5px 0px 15px 0px" }}>
                                                <b className={this.state.data.label === "Reject" ? "text-danger" : ""}>
                                                    {
                                                        (this.state.hdfcStatus.label !== "Duplicate Case") ? "Your application has been rejected.Please try another offer from your dashboard." : "We have received your application.Please contact HDFC bank for further detail"
                                                    }
                                                </b>
                                            </div>}
                                    </div>

                                    <button onClick={this.checkStatus} style={{ backgroundColor: '#5200bb', color: 'white', padding: '0px 10px', borderRadius: '5px' }}>Refresh Status</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div >

        )

    }
}

const mapStateToProps = (state) => ({
    loadingHdfcStatus: hdfcPL(state).loadingHdfcStatus
});

const mapDispatchToProps = (dispatch) => ({
    hdfcStatus: (params, callback) => dispatch(hdfcStatus(params, callback)),

});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(CongratulationsHDFC)
);