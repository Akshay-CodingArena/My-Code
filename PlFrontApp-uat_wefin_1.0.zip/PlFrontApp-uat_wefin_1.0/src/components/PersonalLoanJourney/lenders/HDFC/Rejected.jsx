import React, { Component } from "react";
import CONSTANTS from "../../../../constants/Constants";
import ReactLottie from "../../../common/reactLotte";
import { useHistory } from "react-router-dom";
import PATH from "../../../../paths/Paths";

const RejectedHDFC = () => {
    const history = useHistory()
    return (
        <div className="col-12">
            <div className="CongratsContainer backImage">
                <div className="mt-3" style={{ position: "absolute" }}>
                    {/* <ReactLottie keyIndex={1} /> */}
                </div>

                <div className="CongratsMain">
                    <div className="mt-3" style={{ margin: "auto", width: "95%" }}>
                        <div>
                            <div
                                style={{
                                    padding: "40px 20px 0px 20px",
                                    marginBottom: "30px",
                                    textAlign: "center",
                                    color: "#2E0080",
                                    fontWeight: "400",
                                    fontSize: "20px",
                                }}
                            >
                                <p>Thank You for applying for HDFC personal loan offer. Your HDFC loan application ID is</p>
                                <p>LA-1234324</p>
                                <hr style={{ backgroundColor: 'black', height: '2px', margin: '15px 15px' }} />
                                <b>Application Status :</b>
                                <p style={{ fontSize: "20px" }}>Your Application has been rejected.</p>
                                <p style={{ fontSize: "20px" }}>Please try another offer from your dashboard.</p>
                                <button
                                    onClick={(e) => {
                                        history.push({
                                            pathname:
                                                !localStorage.getItem("ASM_Id")
                                                    ? `${PATH.PRIVATE.PRODUCTS}` :
                                                    `${PATH.PRIVATE.ASM_DASHBOARD}`, state: {

                                                    }
                                        })
                                    }}
                                    style={{ backgroundColor: '#5200bb', color: 'white', padding: '0px 10px', borderRadius: '5px' }}
                                >Back to Home</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}
export default RejectedHDFC