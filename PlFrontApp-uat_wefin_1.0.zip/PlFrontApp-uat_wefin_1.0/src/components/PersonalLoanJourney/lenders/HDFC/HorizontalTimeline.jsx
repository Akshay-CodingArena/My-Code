import React, { useEffect } from 'react';
import { useState } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
// import './HorizontalTimeline.css'; // Import your custom CSS
import Stepper from 'react-stepper-horizontal';
import { getOS } from '../../../../Utils/device_function';

const TimelineComponent = ({ data }) => {

    let [activeStep, setActiveStep] = useState(-1);

    const steps = [
        { title: 'Case Initiated' },
        { title: 'Under Process' },
        { title: 'Verification Pending' },
        { title: 'Decision Awaited' },
        { title: 'Approved' },
        { title: 'Disbursed' }
    ];

    useEffect(() => {
        let activeStep = -1;
        for (let i = 0; i < steps.length; ++i) {
            if (steps[i].title == data) {
                activeStep = i;
                break;
            }
        }
        setActiveStep(activeStep);
    }, [data])


    const customStepRenderer = ({ title }) => (
        <div className="custom-step">
            <span>Lol</span>
        </div>
    );
    return (
        <div className="container mb-4 horizontalTimeline" style={{ fontSize: "5px" }}>
            {/* data */}
            <Stepper circleFontColor="rgb(224, 224, 224)" titleFontSize={getOS() === "android" || getOS() === "ios" ? 10 : 13} activeStep={activeStep} size={getOS() === "android" || getOS() === "iosS" ? 20 : 25} steps={steps} defaultFontColor="green" activeColor="green" completeColor="green" customRenderer={customStepRenderer} />
        </div>
    );

};

export default TimelineComponent;