import CustomUpload from "../../../ExternalVerifier/components/CustomUpload";
import Form from "../../../common/form";
import { ReactComponent as PersonIcon } from "../../../../include/assets/Profile.svg";
import SelectSearch from "../../../common/select";
import React from "react";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { hdfcFileUpload, hdfcPL, hdfcFileUploadComplete, hdfcStatus } from "../../../../store/personalLoan/hdfc";
import BackDropComponent from "../../../../common/BackDropComponent";
import { decryptStore, encryptStore } from "../../../../Utils/store";
import Swal from "sweetalert2";
import CONSTANTS from "../../../../constants/Constants";

class UploadDocs extends Form {

    state = {
        data: {},
        files: {},
        uploads: {},
        errors: {},
        currentTitle: "",
        loading: false
    };





    handleFileUpload = (e, title) => {

        this.setState({ loading: true })

        const selectedFile = e.target.files[0];
        if (selectedFile) {
            const fileSizeInBytes = selectedFile.size;
            console.log(selectedFile)
            const fileSizeInMb = fileSizeInBytes / (1024 * 1024);
            if (fileSizeInMb < 3) {
                const ob = {}
                ob[title] = selectedFile;
                let newFiles = { ...this.state.files };
                newFiles[title] = e.target.files[0];

                this.setState({ files: newFiles })
            }
            else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: "Please Select a file with less than 3MB",
                    showConfirmButton: false,
                    timer: 1800,
                });
            }
        }

        setTimeout(() => {
            this.setState({ loading: false })
        }, 1500)
    }


    uploadFile = (data) => {
        if (!this.state.data[data.Parent_Doc_Desc]) {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Please Select Document Type",
                showConfirmButton: false,
                timer: 1800,
            });
        } else if (!this.state.files[data.Parent_Doc_Desc]) {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Please Select File",
                showConfirmButton: false,
                timer: 1800,
            });
        }
        else {
            let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
            const formData = new FormData();
            formData.append("file", this.state.files[data.Parent_Doc_Desc]);
            formData.append("lenderId", decryptedData.lenderId);
            formData.append("loanName", decryptedData.loanName);
            formData.append("sfid", decryptedData.sfid);
            formData.append("applicationId", decryptedData.applicationId)
            formData.append("reqId", decryptedData.reqId);
            formData.append("filler1", decryptedData.Filler1);
            formData.append("filler4", decryptedData.Filler4);
            formData.append("platform", "Website");
            formData.append("deviceId", decryptedData.deviceId);
            formData.append("parentDocId", data.Parent_Doc_Id);
            formData.append("childDocId", this.state.data[data.Parent_Doc_Desc].value);
            this.setState({ currentTitle: data.Parent_Doc_Desc });
            this.props.hdfcFileUpload(formData, this.callbackUploadFile);
        }
    }

    callbackUploadFile = (res) => {
        if (res.data.success) {
            let allUploads = { ...this.state.uploads };
            allUploads[this.state.currentTitle] = "File Uploaded Successfully.";
            this.setState({ uploads: allUploads })
            Swal.fire({
                position: "center",
                icon: "success",
                title: "File Uploaded Successfully.",
                showConfirmButton: false,
                timer: 1800,
            });
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.message,
                showConfirmButton: false,
                timer: 1800,
            });
        }
    }



    uploadCompleteDocuments = () => {
        if ((Object.keys(this.state.files).length === this.props.data?.docData?.length)
            ||
            (Object.keys(this.state.files).length === this.props.data?.docData?.length - 1
                &&
                !this.state.files["LOAN TRANSFER DOCUMENTS(ONLY FOR LOAN TRANSFER APPLICANTS)"])
        ) {
            let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
            const formData = {
                "lenderId": decryptedData.lenderId,
                "loanName": decryptedData.loanName,
                "sfid": decryptedData.sfid,
                "filler1": decryptedData.Filler1,
                "filler4": decryptedData.Filler4,
                "platform": "Website",
                "deviceId": decryptedData.deviceId,
                "reqId": decryptedData.reqId
            }
            this.props.hdfcFileUploadComplete(formData, this.callbackCompleteUploadFiles);
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Please upload all documents.",
                showConfirmButton: false,
                timer: 1800,
            });

        }
    }



    callbackCompleteUploadFiles = (res) => {
        if (res.data.success) {
            if (res.data.response.doCompleteDocumentUploadResponse.doCompleteDocumentUploadResult.response_status.toUpperCase() === "FAILURE") {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: res.data.response.doCompleteDocumentUploadResponse.doCompleteDocumentUploadResult.error_msg,
                    showConfirmButton: false,
                    timer: 1800,
                });
            } else {
                encryptStore(localStorage.getItem("mobilenumber"), { applicationId: res.data?.response?.doCompleteDocumentUploadResponse?.doCompleteDocumentUploadResult?.applicationId ? res.data.response.doCompleteDocumentUploadResponse.doCompleteDocumentUploadResult.applicationId : "" })
                this.props.updateStep(null, CONSTANTS.CONGRATULATIONS_HDFC);
            }
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.message,
                showConfirmButton: false,
                timer: 1800,
            });
        }
    }



    render() {
        return (
            < div className="row hdfc" >
                {this.props.loadingFileHdfc || this.props.loadingFileCompleteHdfc || this.props.loadingHdfcStatus || this.state.loading ? <BackDropComponent /> : ""}
                <div className="col-sm-12 text-center h4">
                    <b>Upload documents</b>
                </div>
                <div className="col-sm-12">
                    <form className="panVeryfyForm">
                        <div className="panFormFields">
                            <div className="row">

                                <div className="col-sm-12 note">
                                    <b>Note:</b>
                                    <p>{"-> Only JPEG, JPG and PDF files are accepted. Max. File size: 3MB"}</p>
                                    <p>{"-> Merge documents into a single PDF file before uploading, if they belong to the same category (like Salary Slip and Form 16)."}</p>
                                </div>

                                {this.props.data?.docData?.map((value, index) => {
                                    return <>
                                        <div className="col-sm-12">
                                            <SelectSearch
                                                placeholderValue={value.Parent_Doc_Desc}
                                                label={value.Parent_Doc_Desc}
                                                value={this.state.data[value.Parent_Doc_Desc]}
                                                page="personal"
                                                setSelectedOption={(e) => {
                                                    const data = { ...this.state.data };
                                                    const errors = { ...this.state.errors };
                                                    const uploads = { ...this.state.uploads };
                                                    const files = { ...this.state.files }
                                                    if (e) {
                                                        data[value.Parent_Doc_Desc] = e;
                                                        errors[value.Parent_Doc_Desc] = "";
                                                        this.setState({ data, errors, uploads, files });
                                                    }
                                                }}
                                                dropDownOptions={value.ChildDocMaster.Child_Doc.length ? value.ChildDocMaster.Child_Doc.map((v, index) => {
                                                    return { value: v.Child_Doc_Id, label: v.Child_Doc_Desc }
                                                }) : []}
                                                error={this.state.errors?.[value.Parent_Doc_Desc]}
                                                icon={<PersonIcon style={{ marginLeft: "15px" }} />}
                                                required={value.Parent_Doc_Desc === "LOAN TRANSFER DOCUMENTS(ONLY FOR LOAN TRANSFER APPLICANTS)" ? false : true}
                                            ></SelectSearch>
                                        </div>
                                        <div className="col-sm-12">
                                            <div className="d-flex justify-content-between">
                                                <input type="file" id="file-input" name="myfile" accept=".pdf, .xls, .xlsm" onChange={(e) => this.handleFileUpload(e, value.Parent_Doc_Desc)} />
                                                <button type="button" className="uploadBtn" onClick={(e) => { this.uploadFile(value) }}>Upload</button>
                                            </div >
                                        </div>


                                        <div className="col-sm-12 mb-3">
                                            <b className="text-success">{this.state.uploads[value.Parent_Doc_Desc] ? "File Uploaded Successfully" : ""}</b>
                                        </div>
                                    </>
                                })}

                                <div className="col-sm-12 text-center">
                                    <button
                                        type="button"
                                        onClick={this.uploadCompleteDocuments}
                                        variant="contained"
                                        className="nextButton"
                                    >
                                        Submit
                                    </button>

                                </div>
                            </div>



                        </div>
                    </form>
                </div>
            </div >
        )
    }
}


const mapStateToProps = (state) => ({
    loadingFileHdfc: hdfcPL(state).loadingFileHdfc,
    loadingFileCompleteHdfc: hdfcPL(state).loadingFileCompleteHdfc,
    loadingHdfcStatus: hdfcPL(state).loadingHdfcStatus
});

const mapDispatchToProps = (dispatch) => ({
    hdfcFileUpload: (params, callback) => dispatch(hdfcFileUpload(params, callback)),
    hdfcFileUploadComplete: (params, callback) => dispatch(hdfcFileUploadComplete(params, callback)),
    hdfcStatus: (params, callback) => dispatch(hdfcStatus(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(UploadDocs)
);
