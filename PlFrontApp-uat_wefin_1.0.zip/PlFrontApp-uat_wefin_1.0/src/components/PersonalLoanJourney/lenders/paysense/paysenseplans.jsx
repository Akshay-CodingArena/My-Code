import React, { Component } from "react";
import { Container, Row, Col, Card, Figure } from "react-bootstrap";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import BackDropComponent from "../../../../common/BackDropComponent";
import { numberFormat } from "../../../../Utils/numberFormat";
import Slider from "react-rangeslider";
import "react-rangeslider/lib/index.css";
import { decryptStore } from "../../../../Utils/store";
import { paysensePL, paysenseReApplyGetPlans, paysenseFinalApplyGetPlans } from "../../../../store/personalLoan/paysense";
import Radio from "../../../common/Radio";
import Check from "../../../../include/assets/icons/tick.png";
import NonCheck from "../../../../include/assets/icons/circle.png"
import Swal from "sweetalert2";
import CONSTANTS from "../../../../constants/Constants";

class PaysenseGetPlans extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loanAmount: 0,
            planInfoIndex: 0,
            plans: [],
            pfDetails: {}
        }
    };

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        let loanData = this.props.data;
        this.setState({ loanAmount: loanData.amount ? loanData.amount : 0, plans: loanData.plans, pfDetails: loanData.processing_fee })
        this.changeStepperData(0, loanData.plans, loanData.amount, loanData.processing_fee)
    }


    handleSubmit = () => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        let formData = {
            loanName: decryptedData.loanName,
            plan: this.state.plans[this.state.planInfoIndex].plan_id,
            amount: this.state.loanAmount,
            tenure: this.state.plans[this.state.planInfoIndex]?.tenure ? this.state.plans[this.state.planInfoIndex].tenure : "",
            emi: this.state.plans[this.state.planInfoIndex]?.emi ? this.state.plans[this.state.planInfoIndex].emi : "",
            intrest: this.state.plans[this.state.planInfoIndex]?.annual_interest_rate_pct ? this.state.plans[this.state.planInfoIndex].annual_interest_rate_pct : "",
            pf: this.props?.data?.processing_fee.total ? this.props.data.processing_fee.total : "",
        }

        this.props.paysenseFinalApplyGetPlans(formData, this.callbackFinalApply)
    }


    callbackFinalApply = (res) => {
        if (res.data.success) {
            this.props.updateStep(null, CONSTANTS.CONGRATS_SCREEN_PAYSENSE)
            localStorage.setItem("step", CONSTANTS.CONGRATS_SCREEN_PAYSENSE)
            localStorage.setItem("stepperStep", 4);
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.message,
                position: "center",
                showConfirmButton: true,
            })
        }

    }


    reApplyPlans = (value) => {
        this.setState({ loanAmount: value });


        let loanData = this.props.data;

        if (value < loanData.min_amount) {
            this.setState({ loanAmount: loanData.min_amount })
        } else if (value > loanData.max_amount) {
            this.setState({ loanAmount: loanData.max_amount })
        } else {
            let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
            let formData = {
                loanName: decryptedData.loanName,
                lenderId: decryptedData.lenderId,
                amount: value
            }
            this.props.paysenseReApplyGetPlans(formData, this.callbackReApplyGetPlans);

        }


    }
    callbackReApplyGetPlans = (res) => {
        if (res.data.success) {
            this.setState({ planInfoIndex: 0, plans: res.data.response.plans, pfDetails: res.data.response.processing_fee })
            this.changeStepperData(0, res.data.response.plans, this.state.loanAmount, res.data.response.processing_fee)
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.message,
                position: "center",
                showConfirmButton: true,
            })
        }
    }

    changeStepperData = (index, plans, amount, pfDetails) => {
        this.setState({ planInfoIndex: index });
        let loanData = this.props.data;
        let currentPlan = plans.filter((value, i) => index === i)[0];

        let tempData = {
            ...this.props.stepperData,
            emi: currentPlan.emi,
            pl_applied_tenure__c: currentPlan.tenure,
            IRR: currentPlan.annual_interest_rate_pct,
            appliedLoanAmount: amount,
            PF: pfDetails.total
        }

        if (tempData.hasOwnProperty("pl_revised_emi__c")) {
            tempData.pl_revised_emi__c = currentPlan.emi;
        }


        this.props.setStepperData(tempData)
    }


    render() {

        let loanData = this.props.data;

        return (
            <>
                <Container>
                    {this.props.loadingReApplyGetPlans || this.props.loadingFinalApplyPlans ? <BackDropComponent /> : ""}
                    <Row className="insideFormBlock ksfDetails">
                        <Col sm={12} md={12}>
                            <div className="row">
                                <div className="col-sm-12">
                                    <div className="bsEmiCalcBox">
                                        <div className="bsEmiCalcSlider">
                                            <div style={{ display: "flex", justifyContent: "center" }}>
                                                <div className="col-sm-6">
                                                    Loan Amount:{" "}
                                                    <strong>
                                                        {" "}
                                                        {numberFormat(
                                                            this.state.loanAmount
                                                        )}
                                                    </strong>
                                                </div>
                                                <div className="col-sm-6 text-right">
                                                    <div className="bsSliderInpitBox ">
                                                        <span>₹</span>
                                                        <input
                                                            className="text-center"
                                                            type="text"
                                                            pattern="[0-9]*"
                                                            id="principal"
                                                            maxLength="7"
                                                            name="principal"
                                                            value={this.state.loanAmount}
                                                            onChange={(e) => {
                                                                this.setState({ loanAmount: e.target.value })
                                                            }}
                                                            onBlur={(e) => {
                                                                this.reApplyPlans(this.state.loanAmount)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-sm-12">
                                                <Slider
                                                    className="bsEmiSlider"
                                                    key={`slider-${0}`}
                                                    min={this.props.data?.min_amount ? this.props.data.min_amount : 0}
                                                    tooltip={false}
                                                    max={this.props.data?.max_amount ? this.props.data.max_amount : 0}
                                                    step={500}
                                                    labels={{
                                                        minLoanAmount:
                                                            "Min: " + numberFormat(this.props.data?.min_amount ? this.props.data.min_amount : 0),
                                                        2000000: "Max: " + numberFormat(this.props.data?.max_amount ? this.props.data.max_amount : 0),
                                                    }}
                                                    value={this.state.loanAmount}
                                                    aria-label="Default"
                                                    valueLabelDisplay="on"
                                                    onChange={(v) => { this.setState({ loanAmount: v }) }}
                                                    onChangeComplete={(v) => {
                                                        this.reApplyPlans(this.state.loanAmount)
                                                    }}
                                                />
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                {this.state.plans.length ? <div className="col-sm-12 mb-3">
                                    <b className="mt-3 h5">Limited Time Offers</b>
                                    <hr className="mb-3 mt-1" />
                                </div> : ""}


                                {this.state.plans.map((value, index) => {
                                    return <div className="col-sm-6 col-xs-12 " onClick={(e) => {
                                        this.setState({ planInfoIndex: index })
                                        this.changeStepperData(index, this.state.plans, this.state.loanAmount, this.state.pfDetails);
                                    }}>
                                        <div className="paysenseRadioBox">
                                            <div className="paysenseHeader">

                                                <Figure>
                                                    <img
                                                        src={this.state.planInfoIndex === index ? Check : NonCheck}
                                                        style={{ height: "25px", width: "25px", marginRight: "5px" }}
                                                    />
                                                </Figure>
                                                <h5>₹{`${Number(value.emi).toLocaleString('en-IN')} EMI x ${Number(value.tenure).toLocaleString('en-IN')} months`}  <span>{value.annual_interest_rate_pct}% pa</span></h5>


                                            </div>
                                            <div className="paysenseBody">
                                                <div className="paysenseBodyCell">
                                                    <h5>Processing Fees</h5>
                                                    <p>{numberFormat(this.state?.pfDetails?.total)}</p>
                                                </div>
                                                <div className="paysenseBodyCell">
                                                    <h5>Total Interest</h5>
                                                    <p>₹ {Number(value.total_interest).toLocaleString('en-IN')}</p>
                                                </div>
                                                <div className="paysenseBodyCell">
                                                    <h5>Total EMI Cost</h5>
                                                    <p>₹ {Number(value.emi * value.tenure).toLocaleString('en-IN')}</p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                })}

                            </div>

                            {this.state.plans.length ? <div className="col-sm-12 text-center">
                                <button
                                    type="submit"
                                    onClick={this.handleSubmit}
                                    variant="contained"
                                    className="nextButton"
                                >
                                    Submit
                                </button>

                            </div> : <p>No Plans</p>}
                        </Col>
                    </Row >
                </Container >
            </>
        )
    }
}
const mapStateToProps = (state) =>
({
    loadingReApplyGetPlans: paysensePL(state).loadingReApplyGetPlans,
    loadingFinalApplyPlans: paysensePL(state).loadingFinalApplyPlans
});
const mapDispatchToProps = (dispatch) => ({
    paysenseReApplyGetPlans: (params, callback) =>
        dispatch(paysenseReApplyGetPlans(params, callback)),
    paysenseFinalApplyGetPlans: (params, callback) =>
        dispatch(paysenseFinalApplyGetPlans(params, callback))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(PaysenseGetPlans)
);