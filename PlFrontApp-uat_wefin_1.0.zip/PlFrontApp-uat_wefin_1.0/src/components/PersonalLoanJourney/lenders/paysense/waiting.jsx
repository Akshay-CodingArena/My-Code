import React from "react";
import CONSTANTS from "../../../../constants/Constants";
import { Component } from "react";
import { decryptStore } from "../../../../Utils/store";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import BackDropComponent from "../../../../common/BackDropComponent";
import Swal from "sweetalert2";
import { paysensePL, paysenseStatus } from "../../../../store/personalLoan/paysense";

class StatusScreenPaysense extends Component {

    state = {
        loanStatus: ""
    };

    checkStatus = () => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        let formData = {
            loanName: decryptedData.loanName
        }
        this.props.paysenseStatus(formData, this.callbackStatus)
    }

    callbackStatus = (res) => {
        if (res.data.success) {
            this.setState({ loanStatus: res.data.response.status })
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.message,
                position: "center",
                showConfirmButton: true,
            })
        }
    }

    componentDidMount = () => {
        this.checkStatus();
    }




    render() {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        return (

            <div className="col-sm-12" >
                {this.props.loadingPaysenseGetStatus ? <BackDropComponent /> : ""}
                <div className="CongratsContainer backImage">

                    <div className="CongratsMain">
                        <div className="mt-3" style={{ margin: "auto", width: "95%" }}>
                            <div>
                                <div
                                    style={{
                                        padding: "10px 20px 0px 20px",
                                        marginBottom: "30px",
                                        textAlign: "center",
                                        color: "#2E0080",
                                        fontWeight: "400",
                                        fontSize: "20px",
                                    }}
                                >
                                    <p>{`Thank You for applying for ${decryptedData.lenderName} personal loan offer.`}</p>


                                    <p className="mb-3">Loan Application No : <b>{decryptedData.loanName}</b></p>

                                    <hr style={{ backgroundColor: 'black', height: '2px', margin: '15px 15px' }} />


                                    <b>Application Status :</b>

                                    <div style={{ margin: "5px 0px 15px 0px" }}>
                                        <b style={{ textTransform: "capitalize", color: this.state.loanStatus ? "green" : "red" }}>
                                            {this.state.loanStatus ? this.state.loanStatus : "No Status Found"}
                                        </b>
                                    </div>

                                    <button onClick={this.checkStatus} style={{ backgroundColor: '#5200bb', color: 'white', padding: '0px 10px', borderRadius: '5px' }}>Refresh Status</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div >

        )

    }
}

const mapStateToProps = (state) => ({
    loadingPaysenseGetStatus: paysensePL(state).loadingPaysenseGetStatus,
});

const mapDispatchToProps = (dispatch) => ({
    paysenseStatus: (params, callback) =>
        dispatch(paysenseStatus(params, callback))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(StatusScreenPaysense)
);