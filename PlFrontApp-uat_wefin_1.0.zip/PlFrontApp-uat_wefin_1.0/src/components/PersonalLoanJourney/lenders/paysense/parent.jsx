import React, { useEffect, useState } from "react";
import LeftMenuDecider from "../../../../common/leftMenuContent";
import TopNavBar from "../../../../common/TopNavBar";
import CONSTANTS from "../../../../constants/Constants";
import { Container, Row, Col } from "react-bootstrap";
import { useLocation } from "react-router";
import CreditFooter from "../../../cibilFlow/footer";
import PaysenseGetPlans from "./paysenseplans";
import StatusScreenPaysense from "./waiting";

const Paysense = (props) => {
    const location = useLocation();
    const [step, setStep] = useState(1001);
    const [stepperData, setStepperData] = useState({});
    const [data, setData] = useState({});
    let [stepperStep, setStepperStep] = useState(3);


    const updateStep = (e, page) => {
        if (e) e.preventDefault();
        setStep(page);
        if (page === CONSTANTS.CONGRATS_SCREEN_PAYSENSE) {
            setStepperStep(4)
        }
    };



    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        ///////////////update step and data///////////
        let step = location.state?.step;

        let dataLocal = location.state.data ? location.state.data : {}

        let stepperStepLocal = location.state.stepperStep ? location.state.stepperStep : stepperStep;
        let stepperDataLocal = location.state.stepperData ? location.state.stepperData : {};

        if (isNaN(parseInt(localStorage.getItem("step")))) {
            localStorage.setItem("step", step)
        }

        if (!localStorage.getItem("loanInfo")) {
            localStorage.setItem("loanInfo", JSON.stringify(dataLocal))
        }

        if (!localStorage.getItem("stepperStep")) {
            localStorage.setItem("stepperStep", JSON.stringify(stepperStepLocal))
        }

        if (!localStorage.getItem("stepperData")) {
            localStorage.setItem("stepperData", JSON.stringify(stepperDataLocal))
        }

        setStep(parseInt(localStorage.getItem("step")));
        setData(JSON.parse(localStorage.getItem("loanInfo")));
        setStepperStep(JSON.parse(localStorage.getItem("stepperStep")));
        setStepperData(JSON.parse(localStorage.getItem("stepperData")))
        return () => {
            localStorage.removeItem("step");
            localStorage.removeItem("loanInfo");
            localStorage.removeItem("stepperStep");
            localStorage.removeItem("stepperData")
        }
    }, []);




    const leftSideStep = () => {
        switch (step) {
            case CONSTANTS.GET_PLANS_SCREEN_PAYSENSE:
                return (
                    <PaysenseGetPlans
                        updateStep={updateStep}
                        data={data}
                        setData={setData}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                    />
                );
                break;
            case CONSTANTS.CONGRATS_SCREEN_PAYSENSE:
                return (
                    <StatusScreenPaysense
                        updateStep={updateStep}
                        data={data}
                        setData={setData}
                        stepperData={stepperData}
                        setStepperData={setStepperData}
                    />
                );
                break;
        }
    };

    return (
        <>
            <TopNavBar />
            <section className="bs-main-section">
                <Container>
                    <Row>
                        <Col sm={12} md={3}>
                            <LeftMenuDecider
                                activeStep={stepperStep}
                                stepperData={stepperData} />
                        </Col>
                        <Col sm={12} md={9}>
                            {leftSideStep()}
                        </Col>
                    </Row>
                </Container>
            </section>
            <CreditFooter />
        </>
    );
};

export default Paysense;
