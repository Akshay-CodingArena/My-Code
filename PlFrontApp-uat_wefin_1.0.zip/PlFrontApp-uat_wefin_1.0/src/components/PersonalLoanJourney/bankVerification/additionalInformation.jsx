import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";
import CONSTANTS from "../../../constants/Constants";
import {
  accomodation_type,
  loan_purpose_acc,
  designation,
} from "../../common/dropdownValues";
import { ReactComponent as Accommodation } from "../../../include/assets/personalLoan/acco.svg";
import Dependent from "../../../include/assets/personalLoan/dependent.svg";
import Marriage from "../../../include/assets/personalLoan/marriage.svg";
import Joi from "joi-browser";
import Form from "../../../components/common/form";
import SelectSearch from "../../../components/common/select";
// import Back from "../../common/back";
import {
  marital_status,
  accomodationField,
  loan_purpose,
} from "../../common/fullerTonDropdown";
import { ReactComponent as HomeIcon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import { decryptStore } from "../../../Utils/store";
import { ReactComponent as PersonIcon } from "../../../include/assets/Profile.svg";

const optionsDependent = [
  { value: "1", label: "1" },
  { value: "2", label: "2" },
  { value: "3", label: "3" },
  { value: "4", label: "4" },
  { value: "5", label: "5" },
];
class AdditionalInfo extends Form {
  state = { data: {}, errors: {} };
  schema = {
    maritalStatus: Joi.object()
      .required()
      .error(() => {
        return { message: "Marital Status field is required." };
      }),
    accommodation: Joi.object()
      .required()
      .error(() => {
        return { message: "Accommodation Type field is required." };
      }),
    dependent: Joi.object()
      .required()
      .error(() => {
        return { message: "Dependent field is required." };
      }),
    loanPupose: Joi.object()
      .required()
      .error(() => {
        return { message: "Loan Purpose field is required." };
      }),
  };

  doSubmit = () => {
    this.props.setpLData((prevState) => ({
      ...prevState,
      accommodation: this.state.data.accommodation.value,
      maritalStatus: this.state.data.maritalStatus.value,
      dependent: this.state.data.dependent.value,
      loanPupose: this.state.data.loanPupose.value,
    }));
    this.props.updateStep(null, CONSTANTS.RENDER_PERSONAL_ADDRESS);
  };
  componentDidMount = () => {
    if (this.props.populateData) {
      this.setState({ ...this.state, data: { ...this.state.data, ...this.props.populateData } })
    }
  }

  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_PERSONAL_DETAIL);
          }}
        /> */}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information </h1>
            </div>
          </div>

          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Personal Details</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Select Marital Status"}
                      label={"Marital Status"}
                      value={this.state.data.maritalStatus}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.maritalStatus = e;
                          errors.maritalStatus = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={marital_status}
                      error={this.state.errors.maritalStatus}
                      icon={
                        <img src={Marriage} width="" height="" />

                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Select"}
                      label={"No. of Dependent"}
                      value={this.state.data.dependent}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.dependent = e;
                          errors.dependent = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={optionsDependent}
                      error={this.state.errors.dependent}
                      icon={
                        <img src={Dependent} width="" height="" />
                      }
                    ></SelectSearch>
                  </div>

                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Select Accommodation Type"}
                      label={"Accommodation Type"}
                      value={this.state.data.accommodation}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.accommodation = e;
                          errors.accommodation = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={
                        this.props.location.state &&
                          this.props.location.state.lenderName ===
                          "Fullerton India Credit"
                          ? accomodationField
                          : accomodation_type
                      }
                      error={this.state.errors.accommodation}
                      icon={
                        <Accommodation
                          style={{
                            marginRight: "5px",
                            marginTop: "3px",
                          }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN ? (
                      <SelectSearch
                        placeholderValue={"Designation"}
                        label={"Designation"}
                        value={this.state.data.loanPupose}
                        setSelectedOption={(e) => {
                          const data = { ...this.state.data };
                          const errors = { ...this.state.errors };
                          if (e) {
                            data.loanPupose = e;
                            errors.loanPupose = "";
                            this.setState({ data, errors });
                          }
                        }}
                        dropDownOptions={designation}
                        error={this.state.errors.loanPupose}
                        icon={
                          <PersonIcon
                            style={{
                              marginRight: "5px",
                              marginTop: "2px",
                            }}
                          />
                        }
                      ></SelectSearch>
                    ) : (
                      <SelectSearch
                        placeholderValue={"Loan Purpose"}
                        label={"Loan Purpose"}
                        value={this.state.data.loanPupose}
                        setSelectedOption={(e) => {
                          const data = { ...this.state.data };
                          const errors = { ...this.state.errors };
                          if (e) {
                            data.loanPupose = e;
                            errors.loanPupose = "";
                            this.setState({ data, errors });
                          }
                        }}
                        dropDownOptions={
                          this.props.location.state &&
                            this.props.location.state.lenderName ===
                            "Fullerton India Credit"
                            ? loan_purpose
                            : loan_purpose_acc
                        }
                        error={this.state.errors.loanPupose}
                        icon={
                          <HomeIcon
                            style={{
                              marginRight: "5px",
                              marginTop: "3px",
                            }}
                          />
                        }
                      ></SelectSearch>
                    )}{" "}
                  </div>
                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}


export default (AdditionalInfo)

