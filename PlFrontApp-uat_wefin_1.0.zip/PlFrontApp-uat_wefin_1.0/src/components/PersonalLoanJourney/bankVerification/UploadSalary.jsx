import React from "react";
import TopNavBar from "../../../common/TopNavBar";
import { Container, Row, Col } from "react-bootstrap";
import { PLAttachContainerCellPdf } from "../../../common/helperCells";
import { connect } from "react-redux";
import BackDropComponent from "../../../common/BackDropComponent";
import { decryptStore } from "../../../Utils/store";
import Joi from "joi-browser";
import Form from "../../common/form";
import Swal from "sweetalert2";
import { asmDocUpload, getUpload, uploadSalary } from "../../../store/upload";
import { withRouter } from "react-router";
import CreditFooter from "../../cibilFlow/footer";
import LeftMenuDecider from "../../../common/leftMenuContent";
import PATH from "../../../paths/Paths";
import { loadLoanDetail } from "../../../store/applyLoan";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
import AddPrimaryReference from "./AddPrimaryReference";
import ASMNavBar from "../../ASM/ASMNavBar";
import { bankDetailsData, financialEmploymentCheck } from "../../../store/bankdetails";
import PdfViewer from "../../../common/PdfViewer";

class UploadSalary extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        salary1: null,
      },
      preview: {
        salary1: null,
        salary2: null,
        salary3: null
      },
      pdf: null,
      errors: {},
      loading: false,
      bank: {},
      counter: 5,
      stepperStep: 3
    };
  }

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.add("NoScrool");
    document.body.classList.remove("variantScroll");
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanName } = decryptedData;


    if (decryptedData.lender === "Money Plus" && decryptedData.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
      this.setState({ stepperStep: 3 })
    }


    const formdata = {
      consentName: "CONSENT_FILE",
      consentType: "VIEW",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"

          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formdata, this.consentCallback);
  };

  schema = this.props?.location?.state?.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
    {
      salary1: Joi.object()
        .label("Salary Slip 1")
        .required()
        .error(() => {
          return { message: "Salary Slip is required." };
        }),
      salary2: Joi.object()
        .label("Salary Slip 2")
        .allow("")
        .error(() => {
          return { message: "Salary Slip is required." };
        }),
      salary3: Joi.object()
        .label("Salary Slip 3")
        .allow("")
        .error(() => {
          return { message: "Salary Slip is required." };
        }),
    } :
    {
      salary1: Joi.object()
        .label("Salary Slip 1")
        .required()
        .error(() => {
          return { message: "Salary Slip is required." };
        }),
    };

  salary1Upload = (e) => {
    if (e.target.files[0].type !== "application/pdf") {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Only PDF files are allowed to upload",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size <= 0) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size is should be greater than zero",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size > 5000000) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size should not be greater than 5Mb ",
        showConfirmButton: true,
      });
    } else {
      const preview = { ...this.state.preview }
      preview.salary1 = e.target.files[0]
      const data = { ...this.state.data };
      data.salary1 = new File([e.target.files[0]], e.target.files[0].name);
      this.setState({ data, preview });
    }
  };

  salary2Upload = (e) => {
    if (e.target.files[0].type !== "application/pdf") {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Only PDF files are allowed to upload",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size <= 0) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size is should be greater than zero",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size > 5000000) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size should not be greater than 5Mb ",
        showConfirmButton: true,
      });
    } else {
      const preview = { ...this.state.preview }
      preview.salary2 = e.target.files[0]
      const data = { ...this.state.data };
      data.salary2 = new File([e.target.files[0]], e.target.files[0].name);
      this.setState({ data, preview });
    }
  };

  salary3Upload = (e) => {
    if (e.target.files[0].type !== "application/pdf") {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Only PDF files are allowed to upload",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size <= 0) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size is should be greater than zero",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size > 5000000) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size should not be greater than 5Mb ",
        showConfirmButton: true,
      });
    } else {
      const preview = { ...this.state.preview }
      preview.salary3 = e.target.files[0]
      const data = { ...this.state.data };
      data.salary3 = new File([e.target.files[0]], e.target.files[0].name);
      this.setState({ data, preview });
    }
  };
  doSubmit = () => {

    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);

    let { loanId, loansfid, loanType, loanSfid } = decryptedData;

    if (loanType === "TW_Loan") {
      const { salary1, salary2, salary3 } = this.state.data;
      this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));
      const formData = new FormData();
      formData.append("file1", salary1, "salaryslip.pdf");
      if (salary2) { formData.append("file2", salary2, "salaryslip.pdf"); }
      if (salary3) { formData.append("file3", salary3, "salaryslip.pdf"); }
      formData.append("docType", "salarySlip");
      formData.append("mobile", mobile);
      formData.append("loanSfid", loanSfid)
      formData.append(
        "loanId",
        this.props.location.state.loanId
          ? this.props.location.state.loanId
          : loanId
      );
      //   this.setState({ loading: true });
      this.props.asmDocUpload(formData, this.callBack);
    } else {
      const { salary1 } = this.state.data;
      this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));
      const formData = new FormData();
      formData.append("file", salary1, "salaryslip.pdf");
      formData.append("docType", "salarySlip");
      formData.append("mobile", mobile);
      formData.append(
        "lenderId",
        this.props.location.state.lender_id__c
          ? this.props.location.state.lender_id__c
          : this.state.bank.lender_id__c
      );
      formData.append(
        "offerId",
        this.props.location.state.id
          ? this.props.location.state.id
          : this.props.location.state.offerId
            ? this.props.location.state.offerId
            : this.state.bank.id
              ? this.state.bank.id
              : this.state.bank.offerId
      );
      formData.append(
        "loanId",
        this.props.location.state.loanId
          ? this.props.location.state.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid")
      );
      this.setState({ loading: true });
      this.props.uploadSalary(formData, this.callBack);
    }
  };
  consentCallback = (res) => {
    if (res) {
      //console.log(res)
    }
  };
  getLoadCallback = async (res) => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType } = decryptedData;
      let r = await res;
      this.setState((p) => ({ ...p, counter: p.counter - 1 }));
      if (r.data.success) {
        if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "soft approved"
        ) {
          this.setState({ loading: false });
          this.props.history.push({
            pathname: `${PATH.PRIVATE.AADHAR_DETAILS}/${loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank
              ? this.state.bank
              : this.props.location.state,
          });
        } else if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "declined"
        ) {
          this.setState({ loading: false });
          this.props.history.push({
            pathname: `${PATH.PRIVATE.LOAN_APP_FAILED}`,
            state: this.state.bank
              ? this.state.bank
              : this.props.location.state,
          });
        } else {
          setTimeout(() => {
            this.callGetLoanDetails();
          }, 20000);
        }
      } else {
        throw new Error(r);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  callGetLoanDetails = () => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType, loansfid } = decryptedData;
      let getBankData = {
        loanId: this.props.location.state.loanId
          ? this.props.location.state.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
        loanType: loanType,
      };
      if (this.state.counter > 0) {
        this.setState({ loading: true });
        this.props.getLoadLoanDetail(getBankData, this.getLoadCallback);
      } else {
        throw new Error(
          "It is taking longer than usual… requesting your kind patience",
          { cause: "pending" }
        );
      }
    } catch (e) {

      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Something went wrong.",
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  callBackFinancialDocUpload = (res) => {
    if (res.data?.success) {
      this.props.history.push({ pathname: PATH.PRIVATE.ADD_PRIMARY_REFERENCE, state: this.props?.location?.state });
    } else {
      Swal.fire({
        position: "center",
        icon: "error",
        title: "Financial Check Failed",
        showConfirmButton: true,
        timer: 5000,
      });
    }
  }
  callBack = (res) => {

    try {
      if (this.props?.location?.state?.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
        if (res.data.success) {
          let { loanName } = decryptStore(localStorage.getItem("mobilenumber"))
          let accSfid = localStorage.getItem("accsfid")
          let formData = {
            loanName, accSfid
          }
          this.props.financialDocUpload(formData, this.callBackFinancialDocUpload)
        }
        else {
          Swal.fire({
            position: "center",
            icon: "error",
            title: "Error Occured While Uploading",
            showConfirmButton: false,
            timer: 1000,
          })
        }

      }
      else {
        let r = res;
        if (r.data.success) {


          this.callGetLoanDetails();
        } else {
          throw new Error(r);
        }
      }

    } catch (e) {

      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Something went wrong.",
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  previewPdf = (i) => {

    const link = URL.createObjectURL(this.state?.preview[`salary${i}`])
    this.setState({ ...this.state, pdf: link })
  }
  render() {
    const { loading } = this.props;
    console.log(this.state)
    return (
      <>
        <PdfViewer link={this.state.pdf} closeViewer={() => this.setState({ ...this.state, pdf: false })} />
        <>
          {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
          <section className="bs-main-section" >
            <Container>
              <Row>
                <Col sm={12} md={3}>
                  {this.props.location.state ? <LeftMenuDecider activeStep={this.state.stepperStep} state={this.props.location.state} /> : <LeftMenuDecider activeStep={3} />}
                </Col>
                <Col sm={12} md={9}>
                  {this.props.bankDetailsData || loading || this.state.loading ? <BackDropComponent /> : ""}
                  <div className="container">
                    <div className="row">
                      <div className="col-sm-12 text-center">
                        <div className="bsFormHeader upload_header">
                          {/* <div className="bsFormHeaderIcon">
                  <img alt="" src={USER_ICON} />
                </div> */}
                          <h1>Additional Information</h1>
                          {this.props?.location?.state?.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
                            <h6>Upload your last 3 months salary slip</h6> : <h6>Upload your last month salary slip</h6>}
                        </div>
                      </div>
                      <div className="col-sm-12">
                        <form>
                          <div className="row justify-content-center">
                            {this.props?.location?.state?.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
                              [1, 2, 3].map(i => (
                                < div key={i} className="col-sm-4">
                                  <PLAttachContainerCellPdf
                                    required={i === 1 ? true : false}
                                    position={`${i}`}
                                    uploadText={`Add Your salary slip ${i}`}
                                    dataTip={
                                      "Please upload PDF file only with file size of less than 5 MB"
                                    }
                                    fileUpload={this[`salary${i}Upload`]}
                                    doc={this.state.data[`salary${i}`]}
                                    error={this.state.errors[`salary${i}`]}
                                    previewPdf={() => this.previewPdf(i)}
                                  />
                                </div>
                              ))
                              :
                              < div className="col-sm-5">
                                <PLAttachContainerCellPdf
                                  position={`0`}
                                  uploadText={"Add Your salary slip"}
                                  dataTip={
                                    "Please upload PDF file only with file size of less than 5 MB"
                                  }
                                  fileUpload={this.salary1Upload}
                                  doc={this.state.data.salary1}
                                  error={this.state.errors.salary1}
                                />
                              </div>
                            }
                          </div>
                          <div className="SalaryUploadLabel"> <label
                            className="form-check-label"
                            htmlFor="checkedG"

                          >
                            We collect one-time access to the media to allow you to upload documents for the loan application.
                          </label></div>
                          <div className="row">
                            <div className="col-sm-12 text-center bsBtnMargin30">
                              <button
                                type="submit"
                                variant="contained"
                                onClick={this.handleSubmit}
                                className="nextButton"
                              >
                                Next
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
          </section >
          <CreditFooter />
        </>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  uploadSalary: getUpload(state).uploadSalary,
  bankDetailsData: bankDetailsData(state).loadingSaveBankDetails,
  loading: getUpload(state).loadingSalary,
});
const mapDispatchToProps = (dispatch) => ({
  financialDocUpload: (params, callBack) => dispatch(financialEmploymentCheck(params, callBack)),
  asmDocUpload: (params, callBack) => dispatch(asmDocUpload(params, callBack)),
  uploadSalary: (params, callBack) => dispatch(uploadSalary(params, callBack)),
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(UploadSalary)
);