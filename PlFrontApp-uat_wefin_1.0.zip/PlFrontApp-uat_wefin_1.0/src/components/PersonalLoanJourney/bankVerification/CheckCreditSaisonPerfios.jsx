import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import BackDropComponent from "../../../common/BackDropComponent";
import Form from "../../common/form";
import Swal from "sweetalert2";
import { withRouter } from "react-router";
// import CreditFooter from "../../cibilFlow/footer";
import PATH from "../../../paths/Paths";
import { decryptStore } from "../../../Utils/store";
import { loadLoanDetail } from "../../../store/applyLoan";
import { connect } from "react-redux";
class CheckCreditSaisonPerfios extends Form {
  constructor(props) {
    super(props);
    this.state = {
      isPerfiosCompleted: false,
      isEmandateCompleted: false,
      loading: false,
      counter: 5,
      bank: {}
    };
  }

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.add("NoScrool");
    document.body.classList.remove("variantScroll");
    this.checkPerfiosStatus();
  };

  schema = {};

  checkPerfiosStatus = () => {
    this.setState({ loading: true });
    if (
      new URLSearchParams(this.props.location.search).get("q") ===
      "perfiosCompleted"
    ) {
      this.setState({ isPerfiosCompleted: true });
      this.callGetLoanDetails();

    } else if (
      new URLSearchParams(this.props.location.search).get("q") === "emandateCompleted"
    ) {
      this.setState({ isEmandateCompleted: true });
      this.callGetLoanDetails();


    } else {
      this.setState({ isPerfiosCompleted: false });
      this.setState({ isEmandateCompleted: false });
      Swal.fire({
        icon: "warning",
        title: "This page is only for response time",
        customClass: "alertBoxWarning",
        showCancelButton: false,
        confirmButtonText: "OK",
        confirmButtonColor: "#2e0080",
        cancelButtonColor: "#2e0080",
      });
    }
  };

  callGetLoanDetails = () => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loansfid, loanType, bank } = decryptedData;
      let getBankData = {
        loanId: bank.loanId ?
          bank.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
        loanType: loanType,
      };
      if (this.state.counter > 0) {
        this.setState({ loading: true });
        this.props.getLoadLoanDetail(getBankData, this.getLoadCallback);
      } else {
        throw new Error(
          "It is taking longer than usual… requesting your kind patience",
          { cause: "pending" }
        );
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          window.opener.location = PATH.PRIVATE.PRODUCTS;
          window.close();
        }
      });
    }
  };

  getLoadCallback = async (res) => {
    // console.log(res)
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType, lenderName, bank } = decryptedData;
      let r = await res;
      this.setState((p) => ({ ...p, counter: p.counter - 1 }));
      if (r.data.success) {
        //  console.log(`${PATH.PRIVATE.ADD_PRIMARY_REFERENCE
        //     }/${loanType.split(/\s/).join("-")}/${lenderName ? lenderName : bank.lenderName.split(/\s/).join("-")
        //     }`)
        if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "perfios completed"
        ) {
          this.setState({ loading: false });

          window.opener.location = `${PATH.PRIVATE.ADD_PRIMARY_REFERENCE
            }/${loanType.split(/\s/).join("-")}/${bank.lenderName.split(/\s/).join("-")
            }`;
          window.close();

        } else if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "declined"
        ) {
          this.setState({ loading: false });
          window.opener.location = `${PATH.PRIVATE.LOAN_APP_FAILED}`;
          window.close();

        } else if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "perfios rejected"
        ) {
          this.setState({ loading: false });
          Swal.fire({
            icon: "warning",
            title: "Perfios Rejected",
            customClass: "alertBoxWarning",
            showCancelButton: false,
            confirmButtonText: "OK",
            confirmButtonColor: "#2e0080",
            cancelButtonColor: "#2e0080",
          }).then((res) => {
            if (res.isConfirmed) {
              window.opener.location.reload();
              window.close();
            }
          });

        } else {
          setTimeout(() => {
            this.callGetLoanDetails();
          }, 20000);
        }
      } else {
        throw new Error(r);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          window.opener.location = PATH.PRIVATE.PRODUCTS;
          window.close();
        }
      });
    }
  };



  render() {
    return (
      <>
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col sm={12} md={9}>
                {this.state.loading ? <BackDropComponent /> : ""}
              </Col>
            </Row>
          </Container>
        </section>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  // uploadSalary: getUpload(state).uploadSalary,
  // loading: getUpload(state).loading,
});
const mapDispatchToProps = (dispatch) => ({
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CheckCreditSaisonPerfios)
);
