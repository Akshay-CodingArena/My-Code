import React, { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import { decryptStore } from "../../../Utils/store";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../../cibilFlow/footer";
import PATH from "../../../paths/Paths";
import CONSTANTS from "../../../constants/Constants";
import ASMNavBar from "../../ASM/ASMNavBar";
const Failed = () => {
  let location = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  });
  document.body.classList.add("NoScrool");
  document.body.classList.remove("variantScroll");
  let mobile = localStorage.getItem("mobilenumber");
  let decryptedData = decryptStore(mobile);
  let { loanType, loanName, manufacturer } = decryptedData;
  // let lenderName=props.location.state && props.location.state.lenderName;
  let name = localStorage.getItem("firstName");
  let CCRN = localStorage.getItem("CCRN") === null;
  name = name.split(" ")[0] + "!";

  let twMessage = `Dear ${localStorage.getItem("fullName")}, We could not offer you a loan currently!!`;

  if (manufacturer === "REVOLT" && localStorage.getItem("isASM")) {
    twMessage = `Dear ${localStorage.getItem("fullName").split(" ").map((word) => {
      return word[0].toUpperCase() + word.substring(1).toLowerCase();
    }).join(" ")}, ${location.state.failedMessage}`;
  }

  return (
    <>
      {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
      <section className="bs-main-section">
        <Container>
          <Row>
            <Col sm={12} md={3}>
              <LeftMenuDecider activeStep={2} />
            </Col>
            <Col sm={12} md={9}>
              <div className="CongratsContainer backImage">
                <div className="Congrats">
                  <div className="CongratsMain">
                    <div style={{ margin: "auto", width: "80%" }}>
                      <div className="UserIconContainer">
                        <div className="cs_fail_name">
                          Sorry, {name ? name.toLowerCase() : ""}
                        </div>
                      </div>
                      {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
                        <div
                          className="text-center h5"
                        >
                          <p className="text-danger mt-3 mb-3">{twMessage}</p>

                          <p> Please try again after a few days.</p>

                        </div>
                      )}
                      {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
                        <div>
                          <div className="cc_message_fail text-center">
                            Dear {localStorage.getItem("firstName")}{" "}
                            Unfortunately, your credit card application could not
                            <br />
                            processed !! Please try with our other partner Banks.
                          </div>
                          <div className="cs_messsage_application_no text-center">
                            <strong>Application No: </strong>
                            {localStorage.getItem("CCLA")}
                          </div>
                          {CCRN && (
                            <div className="cs_messsage_refrence_no text-center">
                              <strong>Reference No: </strong>
                              {localStorage.getItem("CCRN")}
                            </div>
                          )}
                        </div>
                      )}
                      {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
                        <div
                          style={{
                            textAlign: "center",
                            color: "#4E4E4E",
                            fontWeight: "400",
                            fontSize: "22px",
                          }}
                        >
                          We regret to inform you that we couldn't proceed with
                          your loan application {loanName}.
                          <br />
                          <br />
                          Not to worry.. you may proceed with other partner
                          banks available on wefin platform.
                        </div>
                      )}
                      {localStorage.getItem("isASM") ? <Link
                        to={PATH.PRIVATE.ASM_DASHBOARD}
                        className="failedLoanBtn"
                      >
                        Go Back to Home Page
                      </Link> :
                        <Link
                          to={PATH.PRIVATE.PRODUCTS}
                          className="failedLoanBtn"
                        >
                          Go Back to Home Page
                        </Link>
                      }
                    </div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      <CreditFooter />
    </>
  );
};
export default Failed;
