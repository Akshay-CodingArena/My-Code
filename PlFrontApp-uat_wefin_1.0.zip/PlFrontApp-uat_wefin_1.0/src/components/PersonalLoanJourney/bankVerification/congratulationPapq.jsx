import React, { useEffect } from "react";

import { Link, useLocation } from "react-router-dom";
import TopNavBar from "../../../common/TopNavBar";
// import LeftMenuDecider from "../../../common/leftMenuContent";
import ReactLottie from "../../common/reactLotte";
import PATH from "../../../paths/Paths";
import { cleanObject } from "../../../common/helperCells";
import { useState } from "react";
import Congurats_success from "../../../include/assets/congurats-success.svg";
import Footer from "../../cibilFlow/footer";

const PAPQCongratulation = () => {
  const location = useLocation();
  const [loanId, setLoanId] = useState();

  useEffect(() => {
    // window.scrollTo(0, 0);
    setLoanId(location.state.loanId);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  }, [location]);

  const userName = localStorage.getItem("firstName");
  const userMobile = localStorage.getItem("mobilenumber");

  const bool = cleanObject(userName);
  return (
    <>
      {/* <div
        style={{
          background: "#e5f6fd",
          height: "100 vh",
          width: " 5%",
          "overflow-y": "scroll",
        }}
      ></div> */}
      <TopNavBar />
      <div>
        <div className="LoginMainContainer">
          {/* <div
          style={{
            backgroundSize: "contain",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center bottom",
            backgroundColor: "none",
            width: "27.6%",
          }}
          className="LoginLeftContainer"
        >
          <div className="LoginLeftMainMenu">
            <div style={{ display: "block", height: "98%" }}>
              <LeftMenuDecider activeStep={3} />
            </div>
          </div>
        </div> */}

          <div
            className="CongratsContainer congurats_backImage"
            style={{ height: "100%" }}
          >
            <div style={{ position: "absolute" }}>
              <ReactLottie keyIndex={1} />
            </div>
            <div className="papqCongrats">
              <div className="CongratsMain">
                {" "}
                <div style={{ margin: "auto", width: "80%" }}>
                  <div className="UserIconContainer">
                    <div
                      style={{
                        padding: "40px 20px 0px 20px",
                        textAlign: "center",
                        color: "#2E0080 ",
                        fontWeight: "600",
                        fontSize: "34px",
                      }}
                    >
                      Thank You!
                      {/* {bool === false ? userMobile : userName} */}
                    </div>
                    <div
                      style={{
                        padding: "0px 20px 20px 20px",
                        textAlign: "center",
                        color: "#2E0080 ",
                        fontWeight: "600",
                        fontSize: "34px",
                      }}
                    >
                      {/* Thank You! */}
                      {bool === false ? userMobile : userName}
                    </div>
                    <div
                      style={{
                        marginBottom: "15px",
                        textAlign: "center",
                        color: "#2E0080 ",
                        fontWeight: "500",
                        fontSize: "24px",
                      }}
                    >
                      Application No: {loanId}
                    </div>
                  </div>

                  <div
                    style={{
                      marginBottom: "40px",
                      textAlign: "center",
                      color: "#4E4E4E",
                      fontWeight: "400",
                      fontSize: "20px",
                    }}
                  >
                    You will shortly receive a call from the bank to complete
                    your loan disbursal.
                  </div>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <img
                      src={Congurats_success}
                      alt="congratulation_tickmark"
                    />
                  </div>

                  <Link to={PATH.PRIVATE.PRODUCTS}>
                    <h2
                      style={{
                        // padding: "40px 20px 0px 20px",
                        marginTop: "40px",
                        marginBottom: "20px",
                        textAlign: "center",
                        color: "#2E0080 ",
                        fontSize: "21px",
                        lineHeight: "0px",
                        textDecoration: "underline",
                      }}
                    >
                      Go to Home
                    </h2>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
};
export default PAPQCongratulation;
