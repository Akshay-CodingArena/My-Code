import React, { useEffect } from "react";
import CONSTANTS from "../../../constants/Constants";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import { Container, Row, Col } from "react-bootstrap";
import { useLocation } from "react-router";
import CreditFooter from "../../cibilFlow/footer";
import PrimaryRefDetail from "./PrimaryRefDetail";
import SecondaryRefDetail from "./SecondaryRefDetail";
import ASMNavBar from "../../ASM/ASMNavBar";
import { useState } from "react";
import { decryptStore } from "../../../Utils/store";

const AddPrimaryReference = ({ pLData, setpLData }) => {
  let location = useLocation();
  const [step, setStep] = React.useState(
    CONSTANTS.RENDER_PRIMARY_REFERENCE_DETAIL
  );
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };

  const [stepperStep, setStepperStep] = useState(4);
  useEffect(() => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");

    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"))
    if (decryptedData.lender === "Money Plus" && decryptedData.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
      setStepperStep(3)
    }

  });

  const leftSideStep = () => {
    switch (step) {
      case CONSTANTS.RENDER_PRIMARY_REFERENCE_DETAIL:
        return (
          <PrimaryRefDetail
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
          />
        );
      case CONSTANTS.RENDER_SECONDARY_REFERENCE_DETAIL:
        return (
          <SecondaryRefDetail
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            pLData={pLData}
          />
        );
      default:
        break;
    }
  };
  return (
    <>
      {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
      <section className="bs-main-section">
        <Container>
          <Row>
            <Col sm={12} md={3}>
              <LeftMenuDecider activeStep={stepperStep} />
            </Col>
            <Col sm={12} md={9}>
              <div className="row insideFormBlock">
                <div className="col-sm-12 text-center">
                  <div className="bsFormHeader">
                    <h1> Additional Information </h1>
                  </div>
                </div>
                <div className="col-sm-12">
                  <form className="panVeryfyForm">
                    <ul className="nav nav-pills bs-form-tab">
                      <li>
                        <a className={step === CONSTANTS.RENDER_PRIMARY_REFERENCE_DETAIL ? "active" : ""} href="javascript:void(0)">
                          Primary Reference
                        </a>
                      </li>
                      <li>
                        <a className={step === CONSTANTS.RENDER_SECONDARY_REFERENCE_DETAIL ? "active" : ""} href="javascript:void(0)">
                          Secondary Reference
                        </a>
                      </li>
                    </ul>
                    <div className="tab-content clearfix">{leftSideStep()}</div>
                  </form>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      <CreditFooter />
    </>
  );
};

export default AddPrimaryReference;
