import React from "react";
import Joi from "joi-browser";
import Swal from "sweetalert2";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";

import { ReactComponent as EmailIcon } from "../../../include/assets/emailIcon.svg";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import CONSTANTS from "../../../constants/Constants";
import { decryptStore, encryptStore } from "../../../Utils/store";
// import Back from "../../common/back";
import { other_doc_type } from "../../../components/common/dropdownValues";
import { ReactComponent as Document } from "../../../include/assets/personalLoan/doc.svg";
import Form from "../../../components/common/form";
import SelectSearch from "../../../components/common/select";
import DateComp from "../../../components/common/date";
import { getBankOffer, setBankOfferList } from "../../../store/bankOffer";
import BackDropComponent from "../../../common/BackDropComponent";
import { getAccount, getAccountInfo } from "../../../store/account";
import { cleanObject } from "../../../common/helperCells";
import PATH from "../../../paths/Paths";

class OtherDetail extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      pan: "",
    };
  }

  schema = {
    offEmail: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Office Email field is required";
              break;

            case "string.email":
              err.message = "Office Email field is invalid";
              break;
            case "string.max":
              err.message = "Office Email field is invalid";
              break;
            default:
              break;
          }
        });
        return errors;
      }),
    docNumber: Joi.string()
      .required()
      .error(() => {
        return { message: "Document Number field is required." };
      }),
    docType: Joi.object()
      .required()
      .error(() => {
        return { message: "Document Type field is required." };
      }),
    docExp: Joi.string()
  };

  doSubmit = () => {
    if (
      (this.state.data.docType &&
        this.state.data.docType.value === "passport") ||
      (this.state.data.docType &&
        this.state.data.docType.value === "drivingLicence")
    ) {
      if (
        this.state.data.docExp === null ||
        this.state.data.docExp === undefined ||
        this.state.data.docExp === "undefined"
      ) {
        const errors = { ...this.state.errors };
        errors.docExp = "Document Expiry date field is required.";
        this.setState({ errors });
      } else {
        let currDate = new Date()
        let exp = this.state.data.docExp
        let expDate = new Date(exp.slice(6) + "-" + exp.slice(3, 5) + "-" + exp.slice(0, 2))
        console.log("Current Date", currDate, "Expiry Date", expDate, this.state.data.docExp)
        if (expDate > currDate) {
          const errors = { ...this.state.errors };
          errors.docExp = "";
          this.setState({ errors });
          this.formSubmit();
        } else {
          const errors = { ...this.state.errors };
          errors.docExp = "Document has already expired";
          this.setState({ errors });
        }
      }
    } else {
      if (this.state.data.docType) {
        this.formSubmit();
      }
    }
  };
  formSubmit = async () => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanType } = decryptedData;
    const pLData = { ...this.props.pLData };
    var setDetailsData;
    //console.log("card data is on other details", this.props)
    if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {

      setDetailsData = {
        mobile: mobile,
        loanType: loanType,
        lenderId: this.props.location.state.lender_sfid__c ?? this.props.location.state.lender_sfid ?? localStorage.getItem("lenderId"),
        loanId: loansfid ? loansfid : localStorage.getItem("loansfid"),
        maritalStatus: pLData.maritalStatus,
        CurrentEMI: this.props.location.state.emi,
        docType: this.state.data.docType.value,
        docNo: this.state.data.docNumber,
        offerId: this.props.location.state.offerId
          ? this.props.location.state.offerId.toString()
          : this.props.location.state.id &&
          this.props.location.state.id.toString(),
        docExpDate: this.state.data.docExp
          ? reverseDateString(this.state.data.docExp)
          : "",
        offEmail: this.state.data.offEmail,
        loanMailingAddress: pLData.mailingAdd,
        permAddress1: pLData.address1PA,
        permAddress2: pLData.address2PA,
        permLandmark: pLData.landmarkPA,
        permPincodeSfid: pLData.perPinSfid,
        permCitySfid: pLData.perCitySfid,
        permStateSfid: pLData.perStateSfid,
        resAddress1: pLData.address1CA,
        resAddress2: pLData.address2CA,
        resLandmark: pLData.landmarkCA,
        resPincodeSfid: pLData.currpinSfid,
        resCitySfid: pLData.currcitySfid,
        resStateSfid: pLData.currstateSfid,
        offAddress1: pLData.officeAdd1,
        officeLandline: pLData.officeLandline,
        offAddress2: pLData.officeAdd2,
        offLandmark: pLData.officeLandmark,
        offPincodeSfid: pLData.offPinsfid,
        offCitySfid: pLData.offCitysfid,
        offStateSfid: pLData.offStatesfid,
        offLandLineNo: parseInt(pLData.officeLandline),
        permAddrSameAsResAddr: pLData.permAddrSameAsResAddr,
        existingRelationship: "yes",
        title: pLData.title,
        firstName: pLData.firstName,
        middleName: pLData.middleName,
        lastName: pLData.lastName,
        gender: pLData.gender,
        qualification: pLData.qualification,
        occupation: pLData.occupation,
        numOfDependents: pLData.dependent,
        workType: pLData.workType,
        resType: pLData.residentTypeCA && pLData.residentTypeCA.value,
        permResType: pLData.residentTypePA,
        resAccoType: pLData.accommodation,
        PAN: this.state.pan,
        companyName: pLData.employerName && pLData.employerName.label,
        companyCode: pLData.employerName && pLData.employerName.value,
        industry: pLData.industry,
        industryIsic: pLData.industryIsic,
        relationshipType: pLData.relationShip,
        resCityCode: pLData.resCityCode,
        permCityCode: pLData.perCityCode,
        offCityCode: pLData.offCityCode,
        designation: pLData.loanPupose,
      };

      let storeData = {
        loanType: CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN,
        loansfid: loansfid ? loansfid : localStorage.getItem("loansfid"),
      };
      encryptStore(mobile, storeData);
    } else {
      setDetailsData = {
        mobile: mobile,
        loanType: loanType,
        lenderId: this.props.location.state.lender_id__c ?? localStorage.getItem("lenderId"),
        loanId: loansfid ? loansfid : localStorage.getItem("loansfid"),
        maritalStatus: pLData.maritalStatus,
        CurrentEMI: this.props.location.state.emi,
        loanAmount: this.props.location.state.appliedLoanAmount,
        offerId: this.props.location.state.offerId
          ? this.props.location.state.offerId.toString()
          : this.props.location.state.id.toString(),
        tenureMonths: this.props.location.state.max_tenure,
        IRR: this.props.location.state.IRR,
        procFee: this.props.location.state.PF,
        docType: this.state.data.docType.value,
        docNo: this.state.data.docNumber,
        docExpDate: this.state.data.docExp
          ? reverseDateString(this.state.data.docExp)
          : "",
        offEmail: this.state.data.offEmail,
        loanMailingAddress: pLData.mailingAdd,
        permAddress1: pLData.address1PA,
        permAddress2: pLData.address2PA,
        permLandmark: pLData.landmarkPA,
        permPincodeSfid: pLData.perPinSfid,
        permCitySfid: pLData.perCitySfid,
        permStateSfid: pLData.perStateSfid,
        resAddress1: pLData.address1CA,
        resAddress2: pLData.address2CA,
        resLandmark: pLData.landmarkCA,
        resPincodeSfid: pLData.currpinSfid,
        resCitySfid: pLData.currcitySfid,
        resStateSfid: pLData.currstateSfid,
        offAddress1: pLData.officeAdd1,
        officeLandline: pLData.officeLandline,
        offAddress2: pLData.officeAdd2,
        offLandmark: pLData.officeLandmark,
        offPincodeSfid: pLData.offPinsfid,
        offCitySfid: pLData.offCitysfid,
        offStateSfid: pLData.offStatesfid,
        offLandLineNo: parseInt(pLData.officeLandline),
        permAddrSameAsResAddr: pLData.permAddrSameAsResAddr,
        existingRelationship: "yes",
        title: pLData.title,
        firstName: pLData.firstName,
        middleName: pLData.middleName,
        lastName: pLData.lastName,
        gender: pLData.gender,
        qualification: pLData.qualification,
        occupation: pLData.occupation,
        numOfDependents: pLData.dependent,
        workType: pLData.workType,
        resType: pLData.residentTypeCA && pLData.residentTypeCA.value,
        permResType: pLData.residentTypePA,
        resAccoType: pLData.accommodation,
        PAN: localStorage.getItem("pan") ?? this.state.pan,
        companyName: pLData.employerName && pLData.employerName.label,
        companyCode: pLData.employerName && pLData.employerName.value,
        industry: pLData.industry,
        industryIsic: pLData.industryIsic,
        relationshipType: pLData.relationShip,
        resCityCode: pLData.resCityCode,
        permCityCode: pLData.perCityCode,
        offCityCode: pLData.offCityCode,
        loanPurpose: pLData.loanPupose,
      };
    }

    this.props.setBankOfferList(setDetailsData, this.callBack);
  };
  callBack = (res) => {
    if (res) {
      // console.log("response is", res)
      localStorage.setItem("CCRN", res.data.standCharData?.INRefNumber)
      if (res.status === 503) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: "Unfortunately, your application could not processed !! Please try with our other partner Banks.",
          showConfirmButton: true,
        }).then(() => {
          this.props.history.push("/products");
        });
      }
      else if (res.data.errorDetails?.errorMessage?.length) {
        if (
          res.data.errorDetails?.errorMessage ===
          "DUPLICATE APPLICATION (ANOTHER SOURCE)"
        ) {
          this.props.history.push(PATH.PRIVATE.LOAN_APP_FAILED);
        } else {
          this.props.history.push(PATH.PRIVATE.LOAN_APP_FAILED);
          // Swal.fire({
          //   position: "center",
          //   icon: "warning",
          //   title: "Unfortunately, your application could not processed !! Please try with our other partner Banks.",
          //   showConfirmButton: true,
          // }).then(() => {
          //   this.props.history.push("/products");
          // });
        }
      } else if (res.data.standCharData?.Status === "1") {
        this.props.updateStep(null, CONSTANTS.RENDER_CONGRALUTION);
      } else if (
        res.data.standCharData?.Status === "3" ||
        res.data.standCharData?.Status === "0"
      ) {
        this.props.history.push(PATH.PRIVATE.LOAN_APP_FAILED);
      } else if (!res.data.standCharData) {
        this.props.updateStep(null, CONSTANTS.RENDER_CONGRALUTION);
      }
    }
  };
  onDateChange = (e) => {
    e.preventDefault();
    const data = { ...this.state.data };
    data.docExp = e.target.value;
    this.setState({ data });
  };
  componentDidMount = () => {
    let mobile = localStorage.getItem("mobilenumber");
    if (this.props.customerDetail) {
      if (!this.state.offEmail && this.props.populateData.offEmail) {
        const offEmail = this.props.populateData.offEmail
        this.setState({ ...this.state, data: { ...this.state.data, offEmail } })
      }
    } else {
      this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
    }
  };

  componentDidUpdate = (prevProps, prevState) => {
    if (!this.props.loading && this.props.loading !== prevProps.loading) {
      const { panNumber } = this.props.customerDetail;
      const pan = localStorage.getItem("pan");
      const bool = cleanObject(pan);
      if (bool === false) {
        this.setState({ pan: panNumber });
      } else {
        this.setState({ pan: pan });
      }
    }
  };
  render() {
    const { loadingBank } = this.props;
    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_OFFICE_DETAIL);
          }}
        /> */}
        {loadingBank ? <BackDropComponent /> : ""}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information</h1>
            </div>
          </div>
          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Office Detail</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    {this.renderEmail(
                      "offEmail",
                      "Office Email ID ",
                      <EmailIcon />,
                      false
                    )}
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={" Document Type"}
                      label={" Document Type"}
                      value={this.state.data.docType}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.docType = e;
                          errors.docType = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={other_doc_type}
                      error={this.state.errors.docType}
                      icon={
                        <Document
                          style={{
                            marginRight: "5px",
                            marginTop: "3px",
                          }}
                        />
                      }
                    ></SelectSearch>
                  </div>

                  <div className="col-sm-6">
                    {this.renderInput(
                      "docNumber",
                      "Document Type Number",
                      <Document />,
                      false,
                      20,
                      20
                    )}
                  </div>
                  <div className="col-sm-6">
                    {(this.state.data.docType &&
                      this.state.data.docType.value === "passport") ||
                      (this.state.data.docType &&
                        this.state.data.docType.value === "drivingLicence") ? (
                      <DateComp
                        value={this.state.data.docExp}
                        onDateChange={this.onDateChange}
                        error={this.state.errors.docExp}
                        label="Document Expiry Date"
                      />
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingBank: getBankOffer(state).loadingBank,
  setBankOffer: getBankOffer(state).setBankOffer,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OtherDetail)
);

function reverseDateString(str) {
  var splitString = str.split("-");
  var reverseArray = splitString.reverse();
  var joinArray = reverseArray.join("-");
  joinArray = joinArray + "T00:00:00.000Z";

  return joinArray;
}
