import React from "react";
import TopNavBar from "../../../common/TopNavBar";
import { Container, Row, Col } from "react-bootstrap";
import { PLAttachContainerCellPdf } from "../../../common/helperCells";
import { connect } from "react-redux";
import BackDropComponent from "../../../common/BackDropComponent";
import { decryptStore } from "../../../Utils/store";
import Joi from "joi-browser";
import Form from "../../common/form";
import Swal from "sweetalert2";
import { asmDocUpload, getUpload, uploadSalary } from "../../../store/upload";
import { withRouter } from "react-router";
import CreditFooter from "../../cibilFlow/footer";
import LeftMenuDecider from "../../../common/leftMenuContent";
import PATH from "../../../paths/Paths";
import { loadLoanDetail } from "../../../store/applyLoan";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
import AddPrimaryReference from "./AddPrimaryReference";
import ASMNavBar from "../../ASM/ASMNavBar";
import { financialEmploymentCheck } from "../../../store/bankdetails";
import { asmStateUpload } from "../../../store/asm";
import { pdfjs } from "react-pdf";
import PdfViewer from "../../../common/PdfViewer";

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
class UploadSalary extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        salary2: null,
        salary3: null
      },
      pdf: null,
      password: "",
      errors: {},
      loading: false,
      bank: {},
      counter: 5,
      showPassword: false,
      passwordStatus: 0
    };
  }

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.add("NoScrool");
    document.body.classList.remove("variantScroll");
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanName } = decryptedData;

    const formdata = {
      consentName: "CONSENT_FILE",
      consentType: "VIEW",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"

          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formdata, this.consentCallback);
  };

  // componentDidUpdate = (prevProp, prevState) => {
  //   if (prevState?.data?.salary1?.name != this.state?.data?.salary1?.name) {
  //     this.checkPassword(this.state.data?.salary1, this.state?.password)
  //   } else if (prevState?.data?.salary2?.name != this.state?.data?.salary2?.name) {
  //     this.checkPassword(this.state.data?.salary2, this.state?.password2)
  //   } else if (prevState?.data?.salary3?.name != this.state?.data?.salary3?.name) {
  //     this.checkPassword(this.state.data?.salary3, this.state?.password3)
  //   }
  // }

  schema = {
    salary1: Joi.object()
      .label("Bank Statement 1")
      .required()
      .error(() => {
        return { message: "Bank Statement is required." };
      }),
    salary2: Joi.object()
      .allow(null),
    salary3: Joi.object()
      .allow(null)
  };

  checkPassword = async function (file, password) {
    // Load the PDF file using PDF.js

    if (!file) {
      return true
    }

    let buffer = await file.arrayBuffer()
    const pdfData = new Uint8Array(buffer);

    try {
      const pdf = await pdfjs.getDocument({ data: pdfData, password: password }).promise;
      console.log("correct password")
      if (password === "") {
        this.setState({ ...this.state, showPassword: false, loading: false })
      } else {
        this.setState({ ...this.state, passwordStatus: 2, loading: false })
      }
      return true
    }
    // Try accessing a page to see if the password is correct
    catch (e) {

      if (password === "") {
        this.setState({ ...this.state, showPassword: true, passwordStatus: 0, loading: false })
      } else {
        this.setState({ ...this.state, showPassword: true, passwordStatus: 1, loading: false })
      }
      console.log("Password is incorrect")
      return false
      //  return false; // Password is incorrect
    }
  }

  salary1Upload = (e) => {
    if (e.target.files[0].type !== "application/pdf") {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Only PDF files are allowed to upload",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size <= 0) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size is should be greater than zero",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size > 5000000) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size should not be greater than 5Mb ",
        showConfirmButton: true,
      });
    } else {

      //this.checkPassword(e.target.files[0], "testing")
      const data = { ...this.state.data };
      data.salary1 = new File([e.target.files[0]], e.target.files[0].name);
      this.setState({ data, password: "", salary1: e.target.files[0] });
    }
  };

  salary2Upload = (e) => {
    if (e.target.files[0].type !== "application/pdf") {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Only PDF files are allowed to upload",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size <= 0) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size is should be greater than zero",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size > 5000000) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size should not be greater than 5Mb ",
        showConfirmButton: true,
      });
    } else {
      const data = { ...this.state.data };
      data.salary2 = new File([e.target.files[0]], e.target.files[0].name);
      this.setState({ data, password: "", salary2: e.target.files[0] });
    }
  };

  salary3Upload = (e) => {

    if (e.target.files[0].type !== "application/pdf") {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Only PDF files are allowed to upload",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size <= 0) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size is should be greater than zero",
        showConfirmButton: true,
      });
    } else if (e.target.files[0].size > 5000000) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: "PDF file size should not be greater than 5Mb ",
        showConfirmButton: true,
      });
    } else {
      const data = { ...this.state.data };
      data.salary3 = new File([e.target.files[0]], e.target.files[0].name);
      this.setState({ data, password: "", salary3: e.target.files[0] });
    }
  };

  callBackStateUpload = (res) => {
    if (res.data.success) {
      this.props.history.push({
        pathname: PATH.PRIVATE.UPLOAD_BANK_SALARY,
        state: { ...this.props.location.state, loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN },
      })
    }
    else {
      Swal.fire({
        position: "center",
        icon: "error",
        title: "Error Occured While Uploading Bank Statement",
        showConfirmButton: false,
        timer: 1000,
      })
    }


  }

  doSubmit = async () => {

    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanType, loanId, loanSfid } = decryptedData;
    const { salary1, salary2, salary3 } = this.state.data;
    let status = (await this.checkPassword(salary1, this.state.password) && await this.checkPassword(salary2, this.state.password) && await this.checkPassword(salary3, this.state.password))

    if (status) {
      this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));
      const formData = new FormData();
      if (salary1) formData.append("file1", salary1, 'application/pdf', "salaryslip.pdf");
      if (salary2) formData.append("file2", salary2, 'application/pdf', "salaryslip.pdf");
      if (salary3) formData.append("file3", salary3, 'application/pdf', "salaryslip.pdf");
      formData.append("docType", "bankStatement");
      formData.append("mobile", mobile);
      formData.append("loanId", loanId)
      formData.append("loanSfid", loanSfid)
      if (this.state.showPassword) {
        formData.append("statementPassword", this.state.password)
        this.setState({ loading: true });

        this.props.asmStateUpload(formData, this.callBackStateUpload);
      }
      else {
        this.setState({ loading: true });
        this.props.asmStateUpload(formData, this.callBackStateUpload);
      }
    } else {
      if (this.state.password != "") {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: "Please Enter the Correct Bank Statement Password",
          showConfirmButton: false,
          timer: 1800,
        });
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: "Please Enter Bank Statement Password",
          showConfirmButton: false,
          timer: 1800,
        });
      }
    }
  };

  consentCallback = (res) => {
    if (res) {
      //console.log(res)
    }
  };
  getLoadCallback = async (res) => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType } = decryptedData;
      let r = await res;
      this.setState((p) => ({ ...p, counter: p.counter - 1 }));
      if (r.data.success) {
        if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "soft approved"
        ) {
          this.setState({ loading: false });
          this.props.history.push({
            pathname: `${PATH.PRIVATE.AADHAR_DETAILS}/${loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank
              ? this.state.bank
              : this.props.location.state,
          });
        } else if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "declined"
        ) {
          this.setState({ loading: false });
          this.props.history.push({
            pathname: `${PATH.PRIVATE.LOAN_APP_FAILED}`,
            state: this.state.bank
              ? this.state.bank
              : this.props.location.state,
          });
        } else {
          setTimeout(() => {
            this.callGetLoanDetails();
          }, 20000);
        }
      } else {
        throw new Error(r);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  callGetLoanDetails = () => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType, loansfid } = decryptedData;
      let getBankData = {
        loanId: this.props.location.state.loanId
          ? this.props.location.state.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
        loanType: loanType,
      };
      if (this.state.counter > 0) {
        this.setState({ loading: true });
        this.props.getLoadLoanDetail(getBankData, this.getLoadCallback);
      } else {
        throw new Error(
          "It is taking longer than usual… requesting your kind patience",
          { cause: "pending" }
        );
      }
    } catch (e) {

      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Something went wrong.",
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  callBackFinancialDocUpload = (res) => {
    if (res.data?.success) {
      this.props.history.push({ pathname: PATH.PRIVATE.ADD_PRIMARY_REFERENCE, state: this.props?.location?.state });
    }
  }
  callBack = (res) => {
    try {
      if (this.props?.location?.state?.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
        let { loanName } = decryptStore(localStorage.getItem("mobilenumber"))
        let accSfid = localStorage.getItem("accsfid")
        let formData = {
          loanName, accSfid
        }
        this.props.financialDocUpload(formData, this.callBackFinancialDocUpload)
      }
      else {
        let r = res;
        if (r.data.success) {


          this.callGetLoanDetails();
        } else {
          throw new Error(r);
        }
      }
    } catch (e) {

      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: "Something went wrong.",
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  previewPdf = (pdf) => {
    this.setState({ ...this.state, pdf: URL.createObjectURL(pdf) })
  }
  render() {
    const { loading } = this.props;
    console.log(this.state)
    return (
      <>
        <PdfViewer link={this.state.pdf} closeViewer={() => this.setState({ ...this.state, pdf: false })} />
        <>
          {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
          <section className="bs-main-section" >
            <Container>
              <Row>
                <Col sm={12} md={3}>
                  {this.props.location.state ? <LeftMenuDecider activeStep={3} state={this.props.location.state} /> : <LeftMenuDecider activeStep={3} />}
                </Col>
                <Col sm={12} md={9}>
                  {loading || this.state.loading ? <BackDropComponent /> : ""}
                  <div className="container">
                    <div className="row">
                      <div className="col-sm-12 text-center">
                        <div className="bsFormHeader upload_header">
                          {/* <div className="bsFormHeaderIcon">
                  <img alt="" src={USER_ICON} />
                </div> */}
                          <h1>Additional Information</h1>
                          <h6>Upload your Bank Statement</h6>
                        </div>
                      </div>
                      <div className="col-sm-12">
                        <form>
                          <div className="row justify-content-center">
                            < div className="col-sm-4">
                              <PLAttachContainerCellPdf
                                uploadText={"Add Your Bank Statement"}
                                dataTip={
                                  "Please upload PDF file only with file size of less than 5 MB"
                                }
                                fileUpload={this.salary1Upload}
                                doc={this.state.data.salary1}
                                error={this.state.errors.salary1}
                                required={true}
                                previewPdf={() => this.previewPdf(this.state.salary1)}
                                required={true}
                              />
                            </div>
                            < div className="col-sm-4">
                              <PLAttachContainerCellPdf
                                uploadText={"Add Your Bank Statement"}
                                dataTip={
                                  "Please upload PDF file only with file size of less than 5 MB"
                                }
                                fileUpload={this.salary2Upload}
                                doc={this.state.data.salary2}
                                error={this.state.errors.salary2}
                                previewPdf={() => this.previewPdf(this.state.salary2)}
                              />
                            </div>
                            < div className="col-sm-4">
                              <PLAttachContainerCellPdf
                                uploadText={"Add Your Bank Statement"}
                                dataTip={
                                  "Please upload PDF file only with file size of less than 5 MB"
                                }
                                fileUpload={this.salary3Upload}
                                doc={this.state.data.salary3}
                                error={this.state.errors.salary3}
                                previewPdf={() => this.previewPdf(this.state.salary3)}
                              />
                            </div>
                          </div>
                          {this.state.showPassword ? (
                            < div className="row justify-content-center">
                              <div className="col-sm-5">
                                <div className="form-group">
                                  <input value={this.state.password} onChange={(e) => this.setState({ ...this.state, password: e.target.value })} type="text" className="form-control" placeholder="Bank Statement Password" />
                                  {this.state.passwordStatus > 0 ? (
                                    this.state.passwordStatus === 1 ? <p className="bsInputErr">Password does not match</p>
                                      : <p className="bsInputSuccess">Password matched</p>) : null}
                                </div>
                              </div>
                            </div>) : null}
                          <div className="SalaryUploadLabel" style={{ marginTop: '20px' }}> <label
                            className="form-check-label"
                            htmlFor="checkedG"

                          >
                            We collect one-time access to the media to allow you to upload documents for the loan application.
                          </label></div>
                          <div className="row">
                            <div className="col-sm-12 text-center bsBtnMargin30">
                              <button
                                type="submit"
                                variant="contained"
                                onClick={this.handleSubmit}
                                className="nextButton"
                              >
                                Next
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container >
          </section >
          <CreditFooter />
        </>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  uploadSalary: getUpload(state).uploadSalary,
  loading: getUpload(state).loading,
});
const mapDispatchToProps = (dispatch) => ({
  asmStateUpload: (params, callBack) =>
    dispatch(asmStateUpload(params, callBack)),
  asmDocUpload: (params, callBack) => dispatch(asmDocUpload(params, callBack)),
  uploadSalary: (params, callBack) => dispatch(uploadSalary(params, callBack)),
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(UploadSalary)
);