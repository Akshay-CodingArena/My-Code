import React from "react";
import CONSTANTS from "../../../constants/Constants";

import { Link } from "react-router-dom";
import ReactLottie from "../../common/reactLotte";
let CCRN = localStorage.getItem("CCRN") === null;
const Congralution = ({ updateStep, location }) => {
  return (
    <div className="CongratsContainer backImage">
      <div style={{ position: "absolute" }}>
        <ReactLottie keyIndex={1} />
      </div>
      <div className="Congrats">
        <div className="CongratsMain">
          <div style={{ margin: "auto", width: "80%" }}>
            <div className="UserIconContainer">
              <div
                style={{
                  padding: "40px 20px 0px 20px",
                  marginBottom: "30px",
                  textAlign: "center",
                  color: "#2E0080 ",
                  fontWeight: "600",
                  fontSize: "30px",
                }}
              >
                Congratulations {localStorage.getItem("firstName")}!
              </div>
            </div>
            {location.state &&
              location.state.lenderName === "Fullerton India Credit" ? (
              <div
                style={{
                  textAlign: "center",
                  color: "#4E4E4E",
                  fontWeight: "400",
                  fontSize: "22px",
                }}
              >
                Dear {localStorage.getItem("firstName")}, Your loan application
                has been
                <br />
                approved Complete Your KYC for Disbursal.
              </div>
            ) : location.state.card &&
              location.state.card.bank_name === "SCB" ? (
              <div>
                <div className="cs_messsage_application_no text-center">
                  Application No: {localStorage.getItem("CCLA")}
                </div>
                {CCRN && (
                  <div className="cs_messsage_refrence_no text-center">
                    <strong>Reference No: </strong>
                    {localStorage.getItem("CCRN")}
                  </div>
                )}
                <div className="cc_message_fail text-center">
                  Dear {localStorage.getItem("firstName")}, Your Credit Card
                  application has been approved !!
                  <br />
                  You will shortly receive a call from the bank to complete your
                  process to issue your Card.
                </div>
              </div>
            ) : location.state &&
              location.state.lenderName === "Standard Chartered" ? (
              <div
                style={{
                  textAlign: "center",
                  color: "#4E4E4E",
                  fontWeight: "400",
                  fontSize: "22px",
                }}
              >
                Dear {localStorage.getItem("firstName")}, Your Loan Application
                has been approved !!
                <br />
                You will shortly receive a call from the bank to complete your
                loan disbursal.
              </div>
            ) : (
              <div
                style={{
                  textAlign: "center",
                  color: "#4E4E4E",
                  fontWeight: "400",
                  fontSize: "22px",
                }}
              >
                Dear {localStorage.getItem("firstName")}, Your Loan Application
                has been submitted !!
                <br />
                You will shortly receive a call from the bank to complete your
                loan disbursal.
              </div>
            )}

            {location.state &&
              location.state.lenderName === "Fullerton India Credit" ? (
              <h2
                onClick={(e) => {
                  updateStep(e, CONSTANTS.RENDER_UPLOAD_DOCUMENTS);
                }}
              >
                Upload Your Documents
              </h2>
            ) : (
              <Link to={"/products"}>
                <h2
                  style={{
                    padding: "40px 20px 0px 20px",
                    marginBottom: "20px",
                    textAlign: "center",
                    color: "#2E0080 ",
                    fontSize: "21px",
                    lineHeight: "0px",
                    textDecoration: "underline",
                  }}
                >
                  Go Back to Home
                </h2>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Congralution;
