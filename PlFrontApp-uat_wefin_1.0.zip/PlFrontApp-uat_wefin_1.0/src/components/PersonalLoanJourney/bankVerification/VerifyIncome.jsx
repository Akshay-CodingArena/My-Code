import React from "react";
import TopNavBar from "../../../common/TopNavBar";
import { Container, Row, Col } from "react-bootstrap";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";
import { LoginBank } from "../../../common/helperCells";
import { connect } from "react-redux";
import BackDropComponent from "../../../common/BackDropComponent";
import { decryptStore, encryptStore } from "../../../Utils/store";
// import Joi from "joi-browser";
import Form from "../../common/form";
import Swal from "sweetalert2";
import {
  getUpload,
} from "../../../store/upload";
import { withRouter } from "react-router";
import CreditFooter from "../../cibilFlow/footer";
import LeftMenuDecider from "../../../common/leftMenuContent";
import PATH from "../../../paths/Paths";
import { getPerfiosDetails } from "../../../store/perfios";
import { loadLoanDetail } from "../../../store/applyLoan";
import bankIcon from "./../../../include/assets/icons/bankIcon.svg";
import UploadDoc from "./../../../include/assets/icons/UploadDoc.svg";
import CONSTANTS from "../../../constants/Constants";
import { asmStateUpload } from "../../../store/asm";

class VerifyIncome extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        salary1: null,
      },
      bank: {},
      perfiosData: {},
      popUp: {},
      errors: {},
      loading: false,
    };
  }

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.add("NoScrool");
    document.body.classList.remove("variantScroll");
    this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));

  };

  schema = {};

  callBackStateUpload = () => {
    this.props.history.push({
      pathname: PATH.PRIVATE.UPLOAD_BANK_SALARY,
      state: { ...this.props.state, loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN },
    })
  }

  handlePerfiosCall = (type) => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanId, loansfid, manufacturer } = decryptedData;

    let storeData = {
      bank: this.props.location.state,
    };
    encryptStore(mobile, storeData);
    if (manufacturer === "REVOLT") {
      let formData = { mobile: localStorage.getItem("mobilenumber"), loanId, docType: "bankStatement", }
      this.props.asmStateUpload(formData, this.callBackStateUpload)
    }
    else {
      const data = {
        mobile: mobile,
        returnUrl: `${window.location.origin}${PATH.PUBLIC.CREDIT_SAISON_PERFIOS_COMPLETE}?q=perfiosCompleted`,
        loanId: loansfid
          ? loansfid
          : localStorage.getItem("loansfid")
            ? localStorage.getItem("loansfid")
            : this.props.location.state.loanId,
        lenderId: this.props.location.state.lender_id__c,
        type: type,
      };
      this.setState({ loading: true });
      this.props.getPerfiosDetails(data, this.perfiosCallBack);
    }
  };

  perfiosCallBack = async (res) => {
    try {
      let r = await res;
      if (r.data.success && r.data.status === 200) {
        this.setState({ loading: false });
        if (r.data.csPerfiosData) {
          this.setState((p) => ({
            ...p,
            perfiosData: { ...r.data.csPerfiosData },
          }));

          const winUrl = URL.createObjectURL(
            new Blob([this.state.perfiosData.htmlSnippet], {
              type: "text/html",
            })
          );
          let perPopUp = window.open(winUrl, "", "width=800,height=800");

        }
      } else {
        throw new Error(r.data.description);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e.toString(),
        showConfirmButton: true,
      });
    }
  };



  render() {
    const { loading } = this.props;
    let { manufacturer } = decryptStore(localStorage.getItem("mobilenumber"))
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <LeftMenuDecider activeStep={4} />
              </Col>
              <Col sm={12} md={9}>
                {loading || this.state.loading ? <BackDropComponent /> : ""}
                <div className="container">
                  <div className="row">
                    <div className="col-sm-12 text-center">
                      <div className="bsFormHeader bankHeader">

                        <h1>Verify Your Income</h1>
                        <h6>{ }</h6>
                      </div>
                    </div>
                    <div className="col-sm-12">
                      <form>
                        {manufacturer === "REVOLT" ? <div className="row justify-content-center"> <div className="col-sm-5">
                          <a
                            href="javascript:void(0)"
                            onClick={() =>
                              this.handlePerfiosCall("statement")
                            }
                            className="bankLoginUpload"
                          >
                            <LoginBank
                              uploadText={"Upload your Salary Bank Statement"}
                              dataTip={"Upload Bank Statement"}
                              icon={UploadDoc}

                            />
                          </a>
                        </div>
                        </div> : <div className="row justify-content-center">
                          <div className="col-sm-5">
                            <a
                              href="javascript:void(0)"
                              onClick={() =>
                                this.handlePerfiosCall("netbanking")
                              }
                              className="bankLoginUpload"
                            >
                              <LoginBank
                                uploadText={"Login to your Salary Bank Account "}
                                dataTip={"Login bank"}
                                icon={bankIcon}

                              />
                            </a>
                          </div>
                          <div className="col-sm-5">
                            <a
                              href="javascript:void(0)"
                              onClick={() =>
                                this.handlePerfiosCall("statement")
                              }
                              className="bankLoginUpload"
                            >
                              <LoginBank
                                uploadText={"Upload your Salary Bank Statement"}
                                dataTip={"Upload Bank Statement"}
                                icon={UploadDoc}

                              />
                            </a>
                          </div>
                        </div>
                        }
                      </form>
                    </div>
                  </div>
                  <div></div>
                </div>
              </Col>
            </Row>
          </Container>
        </section >

        <CreditFooter />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  uploadSalary: getUpload(state).uploadSalary,
  loading: getUpload(state).loading,
});
const mapDispatchToProps = (dispatch) => ({
  asmStateUpload: (params, callBack) =>
    dispatch(asmStateUpload(params, callBack)),
  getPerfiosDetails: (params, callBack) =>
    dispatch(getPerfiosDetails(params, callBack)),
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(VerifyIncome)
);
