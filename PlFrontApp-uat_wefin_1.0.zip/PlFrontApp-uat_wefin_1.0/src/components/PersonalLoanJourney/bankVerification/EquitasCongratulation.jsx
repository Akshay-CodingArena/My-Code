import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import ReactLottie from "../../common/reactLotte";
import CongratulationImg from "../../../include/assets/congratulation.svg";
import Swal from "sweetalert2";
import { decryptStore } from "../../../Utils/store";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import {prePaymentData } from "../../../store/mandatedetails";
import BackDropComponent from "../../../common/BackDropComponent";
class EquitasCongratulation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      mandateData: {},
      loading: false,
    };
  }

  componentDidMount = () => {
    this.setPageLayout();
    this.fetchMandateData();
  };

  fetchMandateData = async () => {
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid } = decryptStore(mobile);
    let data = {
      processType: "emandate",
      mobile: mobile,
      paymentAmount: "0",
      loanId: this.props.location.state.loanId
        ? this.props.location.state.loanId
        : this.state.bank.loanId
          ? this.state.bank.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
    };
    this.setState({ loading: true });
    this.props.prePaymentData(data, this.handleCallback);
  };

  handleCallback = async (res) => {
    try {
      let r = await res.data;
      if (r.success) {
        this.setState({ loading: false });
        this.setState({ mandateData: r.tecDetails ? { ...r.tecDetails } : {} });
      } else {
        throw new Error(r.message);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        icon: "warning",
        title: e.message.toString(),
      });
    }
  };

  setPageLayout = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  };

  render() {
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col xs={12} sm={3}>
                <LeftMenuDecider activeStep={6} />
              </Col>
              <Col xs={12} sm={9}>
                <div className="bsCongratsSection backImage">
                  <Card>
                    {this.state.loading ? <BackDropComponent /> : ""}
                    <div className="bsPsnAbs">
                      <ReactLottie keyIndex={1} />
                    </div>
                    <Card.Header className="text-center">
                      Congratulations{" "}
                      {localStorage.getItem("firstName").toUpperCase()}!
                    </Card.Header>
                    <Card.Body className="text-center">
                      <strong>
                        Your loan application is complete!!
                        <br /> Money transfer request to your account will be initiated soon.
                        {/* {this.state.mandateData.revisedLoanAmount
                          ? numberFormat(
                              this.state.mandateData.revisedLoanAmount
                            )
                          : 0}
                        &nbsp; is ready for disbursal */}
                      </strong>
                      <br />
                      <p className="text-center">
                        Application No: {this.props.location.state.loanName}
                      </p>
                      <figure>
                        {" "}
                        <img
                          alt="Congratulation Screen"
                          src={CongratulationImg}
                        />
                      </figure>
                    </Card.Body>
                    <Card.Footer className="text-center">
                      <Link to="/products">Go Back to Homepage</Link>
                    </Card.Footer>
                  </Card>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
        <footer />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  // mandateDetails: mandateData(state).prePayement,
});
const mapDispatchToProps = (dispatch) => ({
  prePaymentData: (params, callBack) =>
    dispatch(prePaymentData(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(EquitasCongratulation)
);
