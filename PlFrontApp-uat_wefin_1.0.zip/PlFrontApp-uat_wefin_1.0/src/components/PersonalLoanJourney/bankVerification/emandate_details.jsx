import React, { Component } from "react";
import TopNavBar from "../../../common/TopNavBar";
import { Container, Row, Col, Card } from "react-bootstrap";
import StepperComponent from "../Stepper/StepperComponent";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { decryptStore } from "../../../Utils/store";
import {
  getKsfData,
  getKsf,
  setKsfData,
} from "../../../store/ksfData";
import PATH from "../../../paths/Paths";
import CreditFooter from "../../cibilFlow/footer";
import BackDropComponent from "../../../common/BackDropComponent";
import Swal from "sweetalert2";
import { numberFormat } from "../../../Utils/numberFormat";
import {
  loadCreditSaisonMandateData,
} from "../../../store/mandatedetails";
import {
  loadLoanDetail,
} from "../../../store/applyLoan";
import moment from "moment";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
class KSFDetails extends Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      bank: {},
      buttonEnable: false,
      terms: false,
    };
  }
  componentDidMount = () => {
    this.setPageLayout();
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanName, loansfid } = decryptedData;
    this.setState({ bank: this.props.location.state });

    const formData = {
      mobile: mobile,
      loanName: this.props.location.state.loanName ? this.props.location.state.loanName : loanName,
      loanId: this.props.location.state.loanId
        ? this.props.location.state.loanId
        : this.state.bank.loanId
          ? this.state.bank.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid")
    }
    this.props.getKsfData(formData);
  }
  setPageLayout = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    if (this.props.location.state.loanStage === "Set Consent") {
      this.setState({ terms: true, buttonEnable: true })
    }
  };
  ksfsetData = () => {
    this.setState({ loading: true });
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanName, loansfid } = decryptedData;
    const formData = {
      mobile: mobile,
      loanName: this.props.location.state.loanName ? this.props.location.state.loanName : loanName,
      loanId: this.props.location.state.loanId
        ? this.props.location.state.loanId
        : loansfid
          ? loansfid
          : localStorage.getItem("loansfid"),
    }
    this.props.setKsfData(formData, this.callbackSetksf);

  }
  callbackSetksf = async (res) => {
    try {
      let r = await res.data;
      if (r.status === 200) {
        this.setState({
          buttonEnable: true,
          terms: true,
          loading: false
        })
      }
      else {
        this.setState({ loading: false });
        throw new Error(r.message);
      }
    }
    catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        icon: "warning",
        title: e.message.toString(),
      });
    }
  }
  handleCheckBoxChange = () => {
    this.ksfsetData()
  };
  submitEmandate = () => {
    this.setState({ loading: true });
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanName } = decryptedData;
    const formData = {
      consentName: "CONSENT_KSF",
      consentType: "BTN",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"
          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formData, this.consentCallback);
    let data = {
      mobile: mobile,
      loanId: this.props.location.state.loanId
        ? this.props.location.state.loanId
        : loansfid
          ? loansfid
          : localStorage.getItem("loansfid"),
      lenderId: this.state.bank.lender_id__c,
    };
    this.props.getLoadCreditSaisonMandateData(
      data,
      this.handleCreditSaisonDataLoad
    );

  }
  consentCallback = (res) => {
    if (res) {
      //  console.log(res);
    }
  };
  handleCreditSaisonDataLoad = async (res) => {
    try {
      let r = await res.data;
      if (r.success && r.status === 200) {
        let temp = r.csEmandateData.htmlSnippet.replace("\n", "");
        temp = temp.replace("https://apiuat.wefin.in", window.location.origin)
        temp += `<head><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'><style>button,button::before{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}body{width:100%;height:100vh;position:relative;overflow:hidden}button{font-size:0px;width:180px;height:50px;background-color:#2e0080;margin:auto;border:0;text-align:center;cursor:pointer;color:#2e0080;border-radius:5px}button::before{content:"Continue";color:#fff;font-size:20px}</style></head>
        <script>
        window.addEventListener("load", (event) => {
          document.getElementById("rzp-button1").click();
          if(document.getElementById('modal-close').clicked == true)
          {
            window.close();
          }
          if(rzp1.closed){
            window.close();
          }
          
        });
        
        
        
        if(document.getElementById('modal-close').clicked == true)
          {
            window.close();
          }
        
        if(rzp1.closed){
          window.close();
        }
      </script>`;
        let html = URL.createObjectURL(
          new Blob([temp], {
            type: "text/html",
          })
        );
        let perPopUp = window.open(html, "", "width=800,height=800");
        if (perPopUp && !perPopUp.closed) {
          var inter = setInterval(() => {
            //   console.log(perPopUp.location.href);

            if (perPopUp.closed) {
              clearInterval(inter);
            }
            if (!perPopUp.closed && perPopUp.location.href.includes('/cs/callback')) {
              this.callGetLoanDetails();
              clearInterval(inter);
              perPopUp.close();

            }
          }, 1500);
        }
        if (perPopUp && !perPopUp.closed) {
          this.setState({ loading: false });
          perPopUp.focus();
        }
        if (perPopUp.closed) {
          this.setState({ loading: false });
          clearInterval(inter);
        }
      }

    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        icon: "warning",
        title: e.message.toString(),
      });
    }
  };

  callGetLoanDetails = () => {
    var myinterval = setInterval(async () => {
      let mobile = localStorage.getItem("mobilenumber");
      let { loansfid, loanType, lenderName } = decryptStore(mobile);
      let getBankData = {
        loanId: this.props.location.state
          ? this.props.location.state.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
        loanType: loanType,
      };
      let lenderN = lenderName ? lenderName : this.props.location.state.lenderName;
      const getLoadCallback = async (res) => {
        try {
          let r = await res;
          if (r.data.success) {
            if (
              r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
              "perfios completed"
            ) {
              this.setState({ loading: false });
              clearInterval(myinterval);
              this.props.history.push({
                pathname: `${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}/${loanType
                  .split(/\s/)
                  .join("-")}/${lenderN.split(/\s/).join("-")
                  }`,
                state: this.props.location.state,
              });
            } else if (
              r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
              "perfios rejected"
            ) {
              this.setState({ loading: false });
              clearInterval(myinterval);
              Swal.fire({
                icon: "info",
                title: "Perfios Rejected !",
                confirmButtonColor: "#2e0080",
                timer: 1800
              }).then((res) => {
                if (res.isConfirmed) {
                  window.location.reload();
                }
              });
            }
            else if (
              r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
              "e-mandate completed"
            ) {
              this.setState({ loading: false });
              clearInterval(myinterval);
              this.props.history.push({
                pathname: `${PATH.PRIVATE.ESIGN_AGREEMENT}/${loanType
                  .split(/\s/)
                  .join("-")}/${lenderN.split(/\s/).join("-")
                  }`,
                state: this.props.location.state,
              });
            }
            else if (
              r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
              "declined"
            ) {
              this.setState({ loading: false });
              clearInterval(myinterval);
              this.props.history.push({

                pathname: `${PATH.PRIVATE.LOAN_APP_FAILED}/${loanType
                  .split(/\s/)
                  .join("-")}/${lenderN.split(/\s/).join("-")
                  }`,
                state: this.props.location.state,
              });
            }
          }
        } catch (e) {
          this.setState({ loading: false });
          Swal.fire({
            position: "center",
            icon: "info",
            title: e?.message ? e.message.toString() : e.toString(),
            showConfirmButton: true,
          });
        }
      };
      this.setState({ loading: true });
      this.props.getLoadLoanDetail(getBankData, getLoadCallback);
      // }
    }, 5000);
  };
  render() {
    const { creditSaisonData
    } = this.props.ksfData

    return (
      <>

        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            <Row className="insideFormBlock ksfDetails">
              <Col sm={12} md={3}>
                <StepperComponent activeStep={5} />
              </Col>
              {this.props.loading ? <BackDropComponent /> :
                <Col sm={12} md={9}>
                  {this.state.loading && <BackDropComponent />}
                  <Card>
                    <Card.Header className="text-center">

                      <p>By Clicking on Proceed for e-Mandate, You will be redirected to e-Mandate registration</p>
                    </Card.Header>
                    <Card.Body>
                      <div className="sub-header"><h3>Approved Loan Amount</h3>
                        <h4> {numberFormat(creditSaisonData?.loanAmount)}</h4>
                        <p>KISETSU SAISON FINANCE (INDIA) PRIVATE LIMITED</p>
                        <small className="text-right">{moment().format("Do-MMM-YY")}</small>
                      </div>
                      <div className="sub-body">
                        <table className="table">
                          <tr>
                            <td>Total interest charge during the entire tenure of the loan (BPI Inclusive)</td>
                            <td>{numberFormat(creditSaisonData?.totalInterest)}</td>
                          </tr>
                          <tr>
                            <td>Broken Period Interest (BPI)
                            </td>
                            <td> {numberFormat(creditSaisonData?.bpiAmount)}</td>
                          </tr>
                          <tr>
                            <td className="table-headline" colSpan="3">
                              Other up-front charges (break-up of each component to be given below)
                            </td>
                          </tr>
                          <tr className="sub-table">
                            <td colSpan="3">
                              <table className="table">
                                <tr><td>Processing fees</td>
                                  <td>{numberFormat(creditSaisonData?.processingFee)}</td></tr>
                                <tr><td>Insurance charges</td>
                                  <td>NA</td></tr>
                                <tr><td>Others (if any)</td>
                                  <td>NA</td></tr>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td>Net disbursed amount
                            </td>
                            <td>{numberFormat(creditSaisonData?.netDisbursalAmount)}</td>
                          </tr>
                          <tr>
                            <td>Total amount to be paid by the borrower
                            </td>
                            <td>{numberFormat(creditSaisonData?.totalAmountToBePaidByBorrower)}</td>
                          </tr>
                          <tr>
                            <td>Interest rate (in percentage)
                            </td>
                            <td>{creditSaisonData?.interestRate}%</td>
                          </tr>
                          <tr>
                            <td>Annual Percentage Rate (APR) - Effective annualized interest rate
                            </td>
                            <td>{creditSaisonData?.apr}%</td>
                          </tr>
                          <tr>
                            <td>Tenure of the Loan (in months)
                            </td>
                            <td>{creditSaisonData?.tenure} Months</td>
                          </tr>
                          <tr>
                            <td>Repayment frequency by the borrower
                            </td>
                            <td>Monthly</td>
                          </tr>
                          <tr>
                            <td>Number of installments of repayment
                            </td>
                            <td>{creditSaisonData?.noOfInstalments}</td>
                          </tr>
                          <tr>
                            <td>Amount of each installment of repayment
                            </td>
                            <td>{numberFormat(creditSaisonData?.emi)}</td>
                          </tr>

                          <tr>
                            <td className="table-headline" colSpan="3">
                              Details about Contingent Charges
                            </td>
                          </tr>
                          <tr className="sub-table">
                            <td colSpan="3">
                              <table className="table">
                                <tr><td>Full Prepayment Charges</td>
                                  <td>5% of O/S Amount</td></tr>
                                <tr><td>Part Prepayment Charges</td>
                                  <td>Not Allowed</td></tr>

                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              Rate of annualized penal charges in case of delayed payments

                            </td>
                            <td>36% per annum</td>
                          </tr>
                          <tr>
                            <td>Rate of annualized other panel charges if any; (details to be provided)
                            </td>
                            <td>NA</td>
                          </tr>
                          <tr>
                            <td>NACH registration failure charges
                            </td>
                            <td>NA</td>
                          </tr>
                          <tr>
                            <td>NACH/e-mandate bounce charges
                            </td>
                            <td>₹450</td>
                          </tr>
                          <tr>
                            <td>SOA charges, if applicable
                            </td>
                            <td>NA</td>
                          </tr>
                          <tr>
                            <td>Swap charges
                            </td>
                            <td>₹250 + taxes</td>
                          </tr>

                          <tr>
                            <td className="table-headline" colSpan="3">
                              Other disclosures
                            </td>
                          </tr>
                          <tr className="sub-table">
                            <td colSpan="3">
                              <table className="table">
                                <tr><td>Cooling-off/look-off period (The Borrower can within the cooling-off/ look-up period exits the loan by paying the principal and the proportionate APR without any penality).</td>
                                  <td>3 days</td></tr>
                                <tr><td>Details of RE acting as recovery agent and
                                  authorized to approach the borrower</td>
                                  <td>KISETSU SAISON FINANCE (INDIA) PRIVATE LIMITED</td></tr>
                              </table>
                            </td>
                          </tr>

                          <tr><td colSpan="3" className="text-left">Fintech/digital lending related companies issues</td></tr>
                        </table>
                      </div>

                      <Row>

                        <Col xs={12} sm={6}>
                          <div className="GRODetails text-left">
                            <h5>BankSe Grievance Redressal Officer
                            </h5>
                            <div className="info">Grievance Officer Name- <span>Rishikesh Kumar

                            </span></div>

                            <div className="info">Contact:&nbsp;<span>9873004772</span></div>
                            <div className="info">Email:&nbsp;<span>  rishikesh.kumar@rattanindia.com,</span>
                            </div>
                            <div className="info">Address:&nbsp;
                              <span>Worldmark1, 5th floor Tower B Aerocity New Delhi- 110037</span></div>
                          </div>
                        </Col>
                        <Col xs={12} sm={6}>
                          <div className="GRODetails text-left">
                            <h5>Grievance Redressal Officer</h5>
                            <div className="info">Grievance Officer Name- <span>Ms. Preethi Nair</span></div>
                            <div className="info">Contact:&nbsp;<span>9962003070</span></div>
                            <div className="info">Email:&nbsp;<span> grievance@creditsaison-in.com,</span><span> preethi.nair@creditsaison-in.com</span></div>
                            <div className="info">Address:&nbsp;
                              <span>IndiQube Lexington Tower, First Floor, Tavarekere Main Rd, Tavarekere, S.G. Palya, Bengaluru, Karnataka 560029</span></div>
                          </div>
                        </Col>
                      </Row>
                      <div className="DrcDetails">
                        <h3>Detailed Repayment Charges</h3>
                        <table className="table">
                          <tr>
                            <th>Installment No.</th>
                            <th>Principal</th>
                            <th>Interest</th>
                            <th>Installment</th>
                            <th>Outstanding Principal </th>
                          </tr>
                          <tr className="spacer">
                            <td colspan="5">&nbsp;</td>
                          </tr>
                          {creditSaisonData?.schedules && creditSaisonData.schedules.map((e) => (
                            <>
                              <tr>
                                <td>{e.instalmentNo}</td>
                                <td>{numberFormat(e.principal)}</td>
                                <td>{numberFormat(e.interest)}</td>
                                <td>{numberFormat(e.instalment)}</td>
                                <td>{numberFormat(e.outstandingPrincipal)}</td>
                              </tr>
                              <tr className="spacer">
                                <td colspan="5">&nbsp;</td>
                              </tr>
                            </>
                          ))}
                        </table></div>
                      <div className="DisclaimerBlock text-left">
                        <p><strong>Disclaimer:</strong> The KSF And Repayment Schedule is created taking Date of Disbursal as the Date mentioned above and may change if the Date of Disbursal changes.
                        </p>
                        <h4>Recovery Mechanism:</h4>
                        <ol>
                          <li> The collection, recovery activities shall be carried on by Lender in accordance with the Collection Code of Conduct prescribed by the Lender. </li>

                          <li>The Borrower shall note that the account shall be classified as Non-Performing Asset (NPA) as
                            per the extant RBI Circulars/Regulations when the payment of Loan Installment (principal and/or interest) remains overdue for more than 90 days, that is,
                            the account will be marked as NPA on the 91st day of continuous default from the original due date.
                          </li></ol>
                      </div>
                    </Card.Body>
                    <div className="col-sm-12">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          name="checkedG"
                          id="checkedG"
                          onClick={this.handleCheckBoxChange}
                          checked={this.state.terms}
                        />
                        <label
                          className="form-check-label"
                          htmlFor="checkffedG"
                          style={{ fontSize: "12px", paddingBottom: "10px", textAlign: "left" }}
                        >
                          By Clicking on Proceed for E Mandate, Sanction Letter will be sent on User's SMS & Email
                        </label>
                      </div>

                      <div className="agreeTxt"></div>
                    </div>
                    <Card.Footer className="text-center">
                      {this.state.buttonEnable ? <button onClick={this.submitEmandate}>Procced for e-Mandate</button> : <button style={{
                        opacity: "0.5",
                        cursor: "not-allowed",
                      }}>Procced for e-Mandate</button>}

                    </Card.Footer>
                  </Card>
                </Col>}
            </Row>
          </Container>
        </section>
        <CreditFooter />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  ksfData: getKsf(state).ksfDetail,
  loading: getKsf(state).loadingKsf,

});
const mapDispatchToProps = (dispatch) => ({
  getKsfData: (params) =>
    dispatch(getKsfData(params)),
  setKsfData: (params, callback) => dispatch(setKsfData(params, callback)),
  getLoadCreditSaisonMandateData: (params, callBack) =>
    dispatch(loadCreditSaisonMandateData(params, callBack)),
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(KSFDetails)
);
