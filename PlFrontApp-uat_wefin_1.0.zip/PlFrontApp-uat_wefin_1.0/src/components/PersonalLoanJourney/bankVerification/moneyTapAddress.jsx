import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";

import Joi from "joi-browser";
import Form from "../../../components/common/form";
import SelectSearch from "../../../components/common/select";
import Pincode from "../../common/pincode";
import { ReactComponent as AddressLine1Icon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as LocationIcon } from "../../../include/assets/fullertonLogos/Places.svg";
import CONSTANTS from "../../../constants/Constants";
import { residence_type } from "../../common/fullerTonDropdown";
// import Back from "../../common/back";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import { connect } from "react-redux";
import { withRouter } from "react-router";

const months = [
  {
    value: "1",
    label: "1",
  },
  {
    value: "2",
    label: "2",
  },
  {
    value: "3",
    label: "3",
  },
  {
    value: "4",
    label: "4+",
  },
];
class MoneyTapAddress extends Form {
  state = {
    data: {},
    errors: {},
    pinSfid: "",
    stateSfid: "",
    citySfid: "",
  };
  schema = {
    add1: Joi.string()
      .required()
      .label("Address Line 1 ")
      .error(() => {
        return { message: "Address Line 1 field is required." };
      }),
    add2: Joi.string()
      .required()
      .label("Address Line 2")
      .error(() => {
        return { message: "Address Line 2 field is required." };
      }),
    residence: Joi.object()
      .required()
      .label("Residence Type ")
      .error(() => {
        return { message: "Residence Type field is required." };
      }),
    monthsCurrent: Joi.object()
      .required()
      .label("No. of Months")
      .error(() => {
        return { message: "No. of Months field is required." };
      }),
    pincode: Joi.number()
      .required()
      .label("Pin Code")
      .error(() => {
        return { message: "Pincode field is required." };
      }),

    city: Joi.string().label("City"),
    state: Joi.string().label("State"),
  };
  doSubmit = () => {
    const data = { ...this.state.data };
    this.props.setpLData((prevState) => ({
      ...prevState,
      address1CA: data.add1,
      residence: data.residence,
      cityCA: data.city,
      stateCA: data.state,
      address2CA: data.add2,
      postalCodeCA: data.pincode,
      currpinSfid: this.state.pinSfid,
      currcitySfid: this.state.citySfid,
      currstateSfid: this.state.stateSfid,
      monthsAtCurrentAddress: data.monthsCurrent,
    }));
    this.props.updateStep(null, CONSTANTS.RENDER_OFFICE_ADDRESS);
  };
  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    if (e.target.value && !/^[0-9]+$/.test(e.target.value)) {
      if (e.target.value.length === 6) {
        const errors = { ...this.state.errors };
        errors.pincode = "Pincode must be number";
        this.setState({ errors });
      } else {
        const errors = { ...this.state.errors };
        errors.pincode = "";
        this.setState({ errors });
      }
    } else {
      if (e.target.value.length === 6) {
        const data = { ...this.state.data };
        const errors = { ...this.state.errors };
        data.pincode = e.target.value;
        errors.pincode = "";
        this.setState({ data, errors });
        let formData = { mobile: mobile, pincode: e.target.value };
        this.props.loadPinCode(formData, this.callbackPin);
      }
    }
  };
  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data?.success === true) {
        const errors = { ...this.state.errors };
        const data = { ...this.state.data };
        data.city = res.data.data.cityname;
        data.state = res.data.data.statename;
        errors.pincode = "";
        this.setState({
          data,
          errors,
          pinSfid: res.data.data.sfid,
          stateSfid: res.data.data.state__c,
          citySfid: res.data.data.city__c,
        });
      } else {
        errors.pincode = res.data.message;
        this.setState({ errors });
      }
    }
  };
  render() {
    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_ADDITIONAL_INFO);
          }}
        /> */}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information </h1>
            </div>
          </div>

          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Current Address</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    {" "}
                    {this.renderInput(
                      "add1",
                      "Address Line 1",
                      <AddressLine1Icon />
                    )}
                  </div>
                  <div className="col-sm-6">
                    {this.renderInput(
                      "add2",
                      "Address Line 2",
                      <AddressLine1Icon />
                    )}
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue="Residence Type"
                      label="Residence Type"
                      value={this.state.data.residence}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.residence = e;
                          errors.residence = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={residence_type}
                      error={this.state.errors.residence}
                      icon={
                        <AddressLine1Icon
                          style={{
                            marginRight: "5px",
                            marginTop: "3px",
                          }}
                        />
                      }
                    ></SelectSearch>
                  </div>

                  <div className="col-sm-6">
                    <Pincode
                      value={this.state.data.pincode}
                      __handlePinCode={this.__handlePinCode}
                      error={this.state.errors.pincode}
                    />
                  </div>

                  <div className="col-sm-3">
                    {this.renderInput("city", "City", <LocationIcon />, true)}
                  </div>

                  <div className="col-sm-3">
                    {this.renderInput("state", "State", <LocationIcon />, true)}
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue="No of Years at Current Address"
                      label="No. of Years"
                      value={this.state.data.monthsCurrent}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.monthsCurrent = e;
                          errors.monthsCurrent = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={months}
                      error={this.state.errors.monthsCurrent}
                      icon={
                        <AddressLine1Icon
                          style={{
                            marginRight: "5px",
                            marginTop: "3px",
                          }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  getpinCode: getpinCode(state),
});
const mapDispatchToProps = (dispatch) => ({
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(MoneyTapAddress)
);
