import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";
import { ReactComponent as EmailIcon } from "../../../include/assets/emailIcon.svg";
import CONSTANTS from "../../../constants/Constants";
import { decryptStore } from "../../../Utils/store";
// import Back from "../../common/back";
import SelectSearch from "../../common/select";
import {
  organization_type,
  industry_type,
} from "../../common/fullerTonDropdown";
import Joi from "joi-browser";
import Form from "../../common/form";
import Swal from "sweetalert2";
import { ReactComponent as EmployerNameIcon } from "../../../include/assets/fullertonLogos/Group 20218.svg";
import { ReactComponent as Industry } from "../../../include/assets/personalLoan/industry.svg";
import { getCompanyDetail, getEmployer } from "../../../store/employer";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { loadLoanDetail, getApplyLoan } from "../../../store/applyLoan";
import BackDropComponent from "../../../common/BackDropComponent";
import { getBankOffer, setBankOfferList } from "../../../store/bankOffer";
import PATH from "../../../paths/Paths";
class FullerTonDetail extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      characterEntered: "",
      errors: {},
      setLoading: false,
    };
  }
  schema = {
    offEmail: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Office Email field is required";
              break;

            case "string.email":
              err.message = "Office Email field is invalid";
              break;
            case "string.max":
              err.message = "Office Email field is invalid";
              break;
            default:
              break;
          }
        });
        return errors;
      }),
    employerName: Joi.object()
      .required()
      .label("Employer Name")
      .error(() => {
        return { message: "Employer Name field is required." };
      }),
    industry: Joi.object()
      .required()
      .label("Industry")
      .error(() => {
        return { message: "Industry field is required." };
      }),
    organization: Joi.object()
      .required()
      .label("Organization")
      .error(() => {
        return { message: "Organization field is required." };
      }),
  };

  doSubmit = () => {
    this.formSubmit();
  };
  formSubmit = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid } = decryptedData;

    const pLData = { ...this.props.pLData };
    let setDetailsData = {
      mobile: mobile,
      loanType: this.props.location.state.loanType,
      lenderId: this.props.location.state.lender_id__c,
      offerId: this.props.location.state.offerId
        ? this.props.location.state.offerId.toString()
        : this.props.location.state.id.toString(),
      loanId: loansfid
        ? loansfid
        : localStorage.getItem("loansfid")
          ? localStorage.getItem("loansfid")
          : this.props.location.state.loanId,
      maritalStatus: pLData.maritalStatus,
      CurrentEMI: this.props.location.state.emi,
      loanAmount: this.props.location.state.appliedLoanAmount,
      tenureMonths: this.props.location.state.max_tenure,
      IRR: this.props.location.state.IRR,
      procFee: this.props.location.state.PF,
      offEmail: this.state.data.offEmail,
      permAddress1: pLData.address1PA,
      permAddress2: pLData.address2PA,
      permLandmark: pLData.landmarkPA,
      permPincodeSfid: pLData.perPinSfid,
      permCitySfid: pLData.perCitySfid,
      permStateSfid: pLData.perStateSfid,
      resAddress1: pLData.address1CA,
      resAddress2: pLData.address2CA,
      resLandmark: pLData.landmarkCA,
      resPincodeSfid: pLData.currpinSfid,
      resCitySfid: pLData.currcitySfid,
      resStateSfid: pLData.currstateSfid,
      offAddress1: pLData.officeAdd1,
      offAddress2: pLData.officeAdd2,
      offLandmark: pLData.officeLandmark,
      offPincodeSfid: pLData.offPinsfid,
      offCitySfid: pLData.offCitysfid,
      offStateSfid: pLData.offStatesfid,
      offLandLineNo: pLData.officeLandline,
      permAddrSameAsResAddr:
        pLData.permAddrSameAsResAddr === "Y" ? "Yes" : "No",
      title: pLData.title,
      firstName: pLData.firstName,
      middleName: pLData.middleName,
      lastName: pLData.lastName,
      gender: pLData.gender,
      qualification: pLData.qualification,
      numOfDependents: pLData.dependent,
      permResType: pLData.residentTypePA,
      resAccoType: pLData.accommodation,
      PAN: "AZVPP2249Q",
      companyName: this.state.data.employerName.label,
      companyCode: this.state.data.employerName.value,
      industry: this.state.data.industry.value,
      organizationType: this.state.data.organization.value,
      monthsAtCurrentAddress: pLData.residentTypeCA.value,
      loanPurpose: pLData.loanPupose,
    };

    this.props.setBankOfferList(setDetailsData, this.callBack);
  };
  callBack = (res) => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanType } = decryptedData;
    if (res) {
      if (res.data.success) {
        this.setState({ setLoading: true });
        let getBankData = {
          mobile: mobile,
          loanId: loansfid
            ? loansfid
            : localStorage.getItem("loansfid")
              ? localStorage.getItem("loansfid")
              : this.props.location.state.loanId,
          getOffer: true,
          loanType: loanType,
        };
        let count = 0;
        var interval = setInterval(() => {
          count = count + 1;
          this.props.loadLoanDetail(getBankData, this.callBackLoan);

          if (this.props.loanDetail.success) {
            let detail = this.props.loanDetail.getLoanDetails.filter(
              (lists) => lists.lenderName === "Fullerton India Credit"
            );
            if (
              detail?.length > 0 &&
              detail[0].status__c === "Pending Documents"
            ) {
              clearInterval(interval);
              this.setState({ setLoading: false });
              this.props.updateStep(null, CONSTANTS.RENDER_CONGRALUTION);
            }
          }
        }, 8000);
      } else {
        Swal.fire({
          position: "center",
          icon: "info",
          title: res.data.description
            ? res.data.description
            : "Sorry!! Bank services are down at this time. We will update you once your application is processed.",
          showConfirmButton: true,
        }).then((res) => {
          if (res.isConfirmed) {
            this.props.history.push(PATH.PRIVATE.PRODUCTS);
          }
        });
      }
    }
  };
  callBackLoan = (res) => {
    if (res) {
      if (res.data.success) {
        this.setState({ count: this.state.count + 1 });
      }
    }
  };
  getAllCompany = (character) => {
    let mobile = localStorage.getItem("mobilenumber");
    const data = "mobile=" + mobile + "&companyStr=" + character;
    this.props.getCompanyDetail(data);
  };
  componentDidMount() {
    this.getAllCompany("");
  }

  handleInputChange = (character) => {
    this.setState((prevState) => {
      return {
        characterEntered: prevState.characterEntered,
      };
    });
    if (this.state.characterEntered !== character) {
      this.getAllCompany(character);
    }
  };
  render() {
    const { company, loadingDetail, loadingBank } = this.props;

    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_OFFICE_DETAIL);
          }}
        /> */}
        {loadingDetail || loadingBank || this.state.setLoading ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information</h1>
            </div>
          </div>
          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Other Detail</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    {this.renderEmail(
                      "offEmail",
                      "Office Email ID",
                      <EmailIcon />,
                      false
                    )}
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Employer Name"}
                      label={"Employer Name"}
                      value={this.state.data.employerName}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.employerName = e;
                          errors.employerName = "";
                          this.setState({ data, errors });
                        }
                      }}
                      onInputChange={this.handleInputChange}
                      dropDownOptions={company.map((item) => ({
                        label: item.companyName,
                        value: item.compCode,
                      }))}
                      error={this.state.errors.employerName}
                      icon={
                        <EmployerNameIcon
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Industry Type"}
                      label={"Industry Type"}
                      value={this.state.data.industry}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.industry = e;
                          errors.industry = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={industry_type}
                      error={this.state.errors.industry}
                      icon={
                        <Industry
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Organization Type"}
                      label={"Organization Type"}
                      value={this.state.data.organization}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.organization = e;
                          errors.organization = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={organization_type}
                      error={this.state.errors.organization}
                      icon={
                        <Industry
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  company: getEmployer(state).company,
  loanDetail: getApplyLoan(state).loanDetail,
  loadingDetail: getApplyLoan(state).loadingDetail,
  loadingBank: getBankOffer(state).loadingBank,
  setBankOffer: getBankOffer(state).setBankOffer,
});
const mapDispatchToProps = (dispatch) => ({
  getCompanyDetail: (params) => dispatch(getCompanyDetail(params)),
  loadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(FullerTonDetail)
);
