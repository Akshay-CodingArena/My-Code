import React, { Component } from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import TopNavBar from "../../../common/TopNavBar";
import BackDropComponent from "../../../common/BackDropComponent";
import LeftMenuDecider from "../../../common/leftMenuContent";
import AggrementPdf from "../../../include/assets/pdfDefaultImage.png";
import { decryptStore, encryptStore } from "../../../Utils/store";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import {
  getLoanAgreementDataCreditSaison,
  updateESignAgreementDataCreditSaison,
} from "../../../store/eSignAgreement";
import Swal from "sweetalert2";
import AllPagesPDFViewer from "../../../common/pdf/AllPagesPDFViewer";
import {
  getApplyLoan,
  loadApprovalDetail,
  loadLoanDetail,
} from "../../../store/applyLoan";
import { loadConsents } from "../../../store/consent";
import PATH from "../../../paths/Paths";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";

class ESignAgreement extends Component {
  state = {
    loading: false,
    pdfLoaded: false,
    terms: false,
    digioScript: null,
    loanData: {},
    bank: {},
    csAgreementData: {},
    count: 0,
  };

  componentDidMount = () => {
    let loanType = this.props.match.params.loantype
    this.setPageLayout();
    this.fetchAgreementData();
    let mobile = localStorage.getItem("mobilenumber");
    let { loanName } = decryptStore(mobile);
    console.log(loanType)
    if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {

    }
    else {
      const formData = {
        consentName: "CONSENT_ESIGN",
        consentType: "VIEW",
        consentStatus: "true",
        accountName: localStorage.getItem("accsfid"),
        loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
        platform: getOS() === "ios"
          ? "web_ios"
          : getOS() === "android"
            ? "web_android"
            : "web",
      };
      this.props.loadConsents(formData, this.consentCallback);
    }
  };

  setPageLayout = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  };

  fetchAgreementData = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid } = decryptStore(mobile);
    this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));


    let data = {
      mobile: mobile,
      lenderId: this.props.location.state?.lender_id__c,
      loanId: this.props.location.state?.loanId
        ? this.props.location.state?.loanId
        : this.state.bank.loanId
          ? this.state.bank.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
      loanType: this.props.location.state?.loanType,
    };
    this.setState({ loading: true });
    this.props.getLoanAgreementDataCreditSaison(
      data,
      this.handleCreditSaisonAgreementCallback
    );

  };
  consentCallback = (res) => {
    if (res) {
      // console.log(res);
    }
  };
  doSubmit = () => {
    this.setState({ loading: true });
    const script = document.createElement("script");
    script.id = "digioScriptId";
    script.src = "https://app.digio.in/sdk/v8/digio.js";
    script.async = true;
    script.onload = () => this.digioScriptLoaded();
    document.body.appendChild(script);
    this.setState({ digioScript: script.id });
  };

  digioScriptLoaded() {
    var options = {
      // environment: 'sandbox',
      environment: "production",
      callback: (res) => {
        this.setState({ loading: true });
        this.handleDigioSignInCallBack(res);
      },
      logo: "http://www.rattanindia.com/wp-content/themes/rattanindia/images/rattanindia_logo.jpg",
      theme: {
        primaryColor: "#028855",
        secondaryColor: "#ffffff",
      },
    };

    var digio = new window.Digio(options);
    this.setState({ loading: false });

    digio.init();
    digio.submit(
      this.state.csAgreementData.agreementId,
      this.state.csAgreementData.identifier
    );
  }

  callGetLoanDetails = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid } = decryptStore(mobile);
    const loanType = this.props.match.params.loantype
    const bankName = this.props.match.params.bankName
    const storeData = {
      loanType,
      bankName,
      loansfid,
      manufacturer: "REVOLT"
    }
    encryptStore(mobile, storeData)
    console.log(bankName)
    var myinterval = setInterval(() => {
      if (this.state.count <= 12) {
        let getBankData = {
          loanId: this.props.location.state
            ? this.props.location.state.loanId
            : this.state.bank.loanId
              ? this.state.bank.loanId
              : loansfid
                ? loansfid
                : localStorage.getItem("loansfid"),
          loanType: loanType,
        };
        var interval = setInterval(() => {
          this.setState({ count: this.state.count + 1 });
          if (this.state.count <= 12) {
            this.props.getLoadLoanDetail(getBankData, this.getLoadCallback);
          } else {
            clearInterval(interval);
          }
        }, 15000);
        this.setState({ loading: true });
      } else {
        clearInterval(myinterval);
        throw new Error(
          "It is taking longer than usual… requesting your kind patience"
        );
      }
    }, 15000);
  };
  getLoadCallback = (res) => {
    if (res?.data?.success) {
      this.setState({ loanData: { ...res.data.getLoanDetails } });
      let loanStage =
        res?.data?.getLoanDetails[0]?.loanDetails?.loanStage.toLowerCase();
      if (
        loanStage === "disbursement" ||
        loanStage === "pre-disbursement"
      ) {
        this.setState({ loading: false, count: 13 });
        this.props.history.push({
          pathname: `${PATH.PRIVATE.EQUITAS_CONGRATULATION}/${this.props.location.state.loanType
            .split(/\s/)
            .join("-")}/${this.props.location.state.lenderName.split(/\s/).join("-")}`,
          state: this.props.location.state,
        });
      } else if (loanStage === "e-sign rejected") {
        this.setState({ loading: false, count: 13 });
        throw new Error(
          "Loan Booking has been failed due to some technical reason.Will update you in a while"
        );
      }
    } else {
      this.setState({ loading: false, count: 13 });
      Swal.fire({
        position: "center",
        icon: "info",
        title: "It is taking longer than usual… requesting your kind patience",
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      })
    }
  }

  handleDigioSignInCallBack = async (res) => {
    try {
      let r = await res;
      let mobile = localStorage.getItem("mobilenumber");
      let { loansfid, lenderName } = decryptStore(mobile);
      let lenderN = lenderName ? lenderName : this.props.location.state.lenderName;
      if (r["error_code"] || r["code"]) {
        if (lenderN.toLowerCase() === "credit saison") {
          let digioData = {
            documentId: r.digio_doc_id,
            code: r.code,
            response: "response",
            status: "failure",
          };
          let data = {
            mobile: mobile,
            loanId: this.props.location.state
              ? this.props.location.state.loanId
              : this.state.bank.loanId
                ? this.state.bank.loanId
                : loansfid
                  ? loansfid
                  : localStorage.getItem("loansfid"),
            digioResponse: digioData,
          };
          this.props.updateLoanAgreement(
            data,
            this.digioCallback
          );
        } else {
          this.setState({ loading: false });
          throw new Error(
            "Loan Booking has been failed due to some technical reason.Will update you in a while"
          );
        }
      } else {
        if (lenderN.toLowerCase() === "credit saison") {
          let digioData = {
            documentId: r.digio_doc_id,
            message: r.message,
            status: "success",
          };
          let data = {
            mobile: mobile,
            loanId: this.props.location.state
              ? this.props.location.state.loanId
              : this.state.bank.loanId
                ? this.state.bank.loanId
                : loansfid
                  ? loansfid
                  : localStorage.getItem("loansfid"),
            digioResponse: JSON.stringify(digioData),
          };
          this.props.updateLoanAgreement(
            data,
            this.updateESignAgreementData
          );
        } else {
          this.callGetLoanDetails();
        }
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      });
    }
  };

  updateESignAgreementData = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        let agreeStatus = r.data.updateEsignResult;
        if (agreeStatus.eSignSuccess && agreeStatus.success) {
          this.callGetLoanDetails();
        } else {
          throw new Error(agreeStatus.message);
        }
      } else {
        throw new Error(r.data.description);
      }
    }
    catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      });
    }
  }
  handleCreditSaisonAgreementCallback = (res) => {
    if (res) {
      if (res.data?.success && res.data?.status === 200) {
        this.setState({ csAgreementData: res.data.csAgreementData });
        let pdf = res.data.csAgreementData.loanAgreementDocument;
        this.setState({ loading: false, pdfLoaded: true, generatePdf: pdf });
      } else {
        throw new Error(res.data.description);
      }
    }
  };


  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid, loanType } = decryptStore(mobile);
    let pdf =
      this.state.csAgreementData.loanAgreementDocument;
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section readAgrrement">
          {this.state.setLoading ? <BackDropComponent /> : ""}
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <LeftMenuDecider activeStep={5} />
              </Col>
              <Col sm={12} md={9}>
                <h5 className="text-center">Read Agreement</h5>
                <h6 className="text-center">By Clicking on Sign Loan Agreement, You will be redirected to sign the agreement</h6>
                <Card>
                  {this.state.loading ? <BackDropComponent /> : ""}
                  <Card.Header className="text-center">
                    {/* {this.state.pdfLoaded && (
                      <div className="text-right ag_download_btn_block">
                        <a
                          className="ag_download_btn"
                          href={`data:application/octet-stream;base64,${pdf}`}
                          download={"eSignAgreement.pdf"}
                        >
                          Download
                        </a>
                      </div>
                    )} */}
                  </Card.Header>
                  <Card.Body>
                    <p>
                      {" "}
                      Copy of the agreement will be sent via email and post.
                    </p>
                    <div>
                      {this.state.pdfLoaded ? (
                        <div className="all-page-container">
                          <AllPagesPDFViewer
                            pdf={`data:application/pdf;base64,${pdf}`}
                          />
                        </div>
                      ) : (
                        <div className="all-page-container">
                          <img
                            src={AggrementPdf}
                            alt={"pdficon"}
                            width="500"
                            height="500"
                          />
                        </div>
                      )}
                    </div>
                  </Card.Body>
                  <Card.Footer className="text-center">

                    <button
                      className="nextButton"
                      type="submit"
                      onClick={this.doSubmit}
                    >
                      Sign Loan Agreement
                    </button>

                  </Card.Footer>
                </Card>
              </Col>
            </Row>
          </Container>
        </section>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  loadApproval: getApplyLoan(state).loadingApproval,
});
const mapDispatchToProps = (dispatch) => ({

  loadApprovalDetail: (params, callBack) =>
    dispatch(loadApprovalDetail(params, callBack)),
  getLoanAgreementDataCreditSaison: (params, callBack) =>
    dispatch(getLoanAgreementDataCreditSaison(params, callBack)),
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  updateLoanAgreement: (params, callBack) =>
    dispatch(updateESignAgreementDataCreditSaison(params, callBack)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ESignAgreement)
);
