import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";

import { ReactComponent as EmailIcon } from "../../../include/assets/emailIcon.svg";
// import Back from "../../common/back";
import SelectSearch from "../../common/select";
import { money_organization_type } from "../../common/fullerTonDropdown";
import Joi from "joi-browser";
import Form from "../../common/form";
import { ReactComponent as BusinessIcon } from "../../../include/assets/homepageIcons/bank-icon.svg";
import { ReactComponent as Industry } from "../../../include/assets/personalLoan/industry.svg";
import { loadEmployerDetail, getEmployer } from "../../../store/employer";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import CreatableSelect from "react-select/creatable";
import BackDropComponent from "../../../common/BackDropComponent";
import { getBankOffer, setBankOfferList } from "../../../store/bankOffer";
import { decryptStore } from "../../../Utils/store";
import PATH from "../../../paths/Paths";

class MoneyTapDetail extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      characterEntered: "",
      errors: {},
      setLoading: false,
    };
  }

  schema = {
    offEmail: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Office Email field is required";
              break;

            case "string.email":
              err.message = "Office Email field is invalid";
              break;
            case "string.max":
              err.message = "Office Email field is invalid";
              break;
            default:
              break;
          }
        });
        return errors;
      }),
    employer: Joi.object()
      .required()
      .label("Name of Company ")
      .error(() => {
        return { message: "Name of Company field is required." };
      }),
    organization: Joi.object()
      .required()
      .label("Organization")
      .error(() => {
        return { message: "Organization field is required." };
      }),
  };
  customStyles = {
    control: (provided) => ({
      ...provided,
      height: "40px",
      paddingLeft: "25px",
      borderColor: "#E0E0E0",
      borderWidth: "1px",
      boxShadow: "0 0 0 0px #2e0080",
      width: "100%",
      "&:hover": {
        borderColor: "#2e0080",
        borderWidth: "1px",
      },
      "&:focus": {
        borderColor: "#2e0080",
        borderWidth: "1px",
      },
    }),
    option: (provided, state) => ({
      ...provided,
      borderBottom: "0.5px solid rgba(46, 0, 128, 0.5)",
      textAlign: "left",
      fontSize: "15px",
      padding: "7px 10px",
      width: "100% !important",
      maxWidth: "100% !important",
      backgroundColor: state.isSelected
        ? "#2e0080"
        : state.isFocused
          ? "rgba(46, 0, 128, 0.12)"
          : "#eae4f9",
    }),
    menu: (provided) => ({
      ...provided,
      borderRadius: "5px",
      color: "#5E5E5E",
      background: "#eae4f9",
      zIndex: 12,
      width: "100%",
    }),
    dropdownIndicator: (base) => ({
      ...base,
      marginTop: "6px",
    }),
  };
  doSubmit = () => {
    this.formSubmit();
  };
  formSubmit = () => {
    let errors = { ...this.state.errors };
    if (!(/^[A-Za-z0-9 .]*$/.test(this.state.data.employer.label))) {
      errors.employer = "Invalid Name of Company format.";
      this.setState({ errors });
      return;
    }

    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid } = decryptStore(mobile);

    const pLData = { ...this.props.pLData };
    let setDetailsData = {
      companyName: this.state.data.employer.label,
      gender: pLData.gender,
      IRR: this.props.location.state.IRR,
      emi: this.props.location.state.emi,
      lenderId: this.props.location.state.lender_id__c,
      loanAmount: this.props.location.state.appliedLoanAmount,
      loanId: loansfid ? loansfid : localStorage.getItem("loansfid"),
      loanType: this.props.location.state.loanType,
      maritalStatus: pLData.qualification,
      mobile: mobile,
      monthsAtCurrentAddress: pLData.monthsAtCurrentAddress.value,
      offAddress1: pLData.officeAdd1,
      offAddress2: pLData.officeAdd2,
      offEmail: this.state.data.offEmail,
      offLandLineNo: pLData.officeLandline,
      offLandmark: pLData.officeLandmark,
      offPincodeSfid: pLData.offPinsfid,
      offCitySfid: pLData.offCitysfid,
      offStateSfid: pLData.offStatesfid,
      offerId: this.props.location.state.offerId
        ? this.props.location.state.offerId.toString()
        : this.props.location.state.id.toString(),
      organizationType: this.state.data.organization.value,
      resAddress1: pLData.address1CA,
      resAddress2: pLData.address2CA,
      resCitySfid: pLData.currcitySfid,
      resPincodeSfid: pLData.currpinSfid,
      resStateSfid: pLData.currstateSfid,
      title: pLData.title,
      resType: pLData.residence.value,
      procFee: this.props.location.state.PF,
      offPin: pLData.officePin,
      resPin: pLData.postalCodeCA,
      tenureMonths: this.props.location.state.max_tenure,
    };

    this.props.setBankOfferList(setDetailsData, this.callBack);
  };
  callBack = (res) => {
    if (res?.data?.success) {
      this.props.history.push(PATH.PRIVATE.FULLERTON_CONGRATULATION);
    } else {
      this.props.history.push(PATH.PRIVATE.LOAN_APP_FAILED);
    }
  };
  formatCreate = (inputValue) => {
    return <p> Add: {inputValue}</p>;
  };
  componentDidMount = () => {
    let mobile = localStorage.getItem("mobilenumber");
    this.props.loadEmployerDetail({ mobile: mobile, companyStr: "" });
  };
  handleInputChange = (character) => {
    let mobile = localStorage.getItem("mobilenumber");
    this.setState((prevState) => {
      return {
        characterEntered: prevState.characterEntered,
      };
    });
    if (character && this.state.characterEntered !== character) {
      this.props.loadEmployerDetail({ mobile: mobile, companyStr: character });
    }
  };
  render() {
    const { employerDetail, loadingDetail, loadingBank } = this.props;
    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_OFFICE_DETAIL);
          }}
        /> */}
        {loadingDetail || loadingBank || this.state.setLoading ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information</h1>
            </div>
          </div>
          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Other Detail</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    {this.renderEmail(
                      "offEmail",
                      "Office Email ID",
                      <EmailIcon />,
                      false
                    )}
                  </div>
                  <div className="col-sm-6">
                    {" "}
                    <div className="form-group">
                      <label htmlFor="employer">
                        Name of Company
                        <span style={{ color: "#FF4C30" }}>*</span>
                      </label>
                      <CreatableSelect
                        style={{ color: "#f00" }}
                        isClearable
                        styles={this.customStyles}
                        name="employer"
                        onChange={(e) => {
                          if (e) {
                            if (e.__isNew__) {
                              const data = { ...this.state.data };
                              const errors = { ...this.state.errors };
                              errors.employer = "";
                              data.employer = e;
                              this.setState({ errors, data, value: e.value });
                            } else {
                              const data = { ...this.state.data };
                              const errors = { ...this.state.errors };
                              errors.employer = "";
                              data.employer = e;
                              this.setState({
                                data,
                                errors,
                                employerName: e.value,
                              });
                            }
                          }
                          if (e === null) {
                            const data = { ...this.state.data };
                            data.employer = "";
                            this.setState({
                              data,
                              employerName: {},
                              value: "",
                            });
                          }
                        }}
                        onInputChange={this.handleInputChange}
                        options={employerDetail.map((item) => ({
                          label: item.name,
                          value: item,
                        }))}
                        placeholder="Select Company Name"
                        formatCreateLabel={this.formatCreate}
                        value={
                          this.state.data.employer &&
                          this.state.data.employer.label &&
                          this.state.data.employer
                        }
                      />
                      <span className="dropIcon">
                        <BusinessIcon
                          style={{ marginBottom: "-6px", marginRight: "5px" }}
                        />
                      </span>
                      {this.state.errors.employer && (
                        <p className="bsInputErr">
                          {this.state.errors.employer}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={"Organization Type"}
                      label={"Organization Type"}
                      value={this.state.data.organization}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.organization = e;
                          errors.organization = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={money_organization_type}
                      error={this.state.errors.organization}
                      icon={
                        <Industry
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingBank: getBankOffer(state).loadingBank,
  setBankOffer: getBankOffer(state).setBankOffer,
  employerDetail: getEmployer(state).employerDetail,
  loadingDetail: getEmployer(state).loadingDetail,
});
const mapDispatchToProps = (dispatch) => ({
  loadEmployerDetail: (params) => dispatch(loadEmployerDetail(params)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(MoneyTapDetail)
);
