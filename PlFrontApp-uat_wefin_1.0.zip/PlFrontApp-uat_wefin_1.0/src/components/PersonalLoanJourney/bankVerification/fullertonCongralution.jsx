import React, { useEffect } from "react";

import { Link } from "react-router-dom";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import ReactLottie from "../../common/reactLotte";
import PATH from "../../../paths/Paths";
import { cleanObject } from "../../../common/helperCells";
import Footer from "../../cibilFlow/footer";


const FullertonCongralution = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  });

  const userName = localStorage.getItem("firstName");

  const bool = cleanObject(userName);
  return (
    <>
      <div
        style={{
          background: "#e5f6fd",
          height: "100 vh",
          width: " 5%",
          "overflow-y": "hidden",
        }}
      ></div>
      <TopNavBar />
      <div className="LoginMainContainer">
        <div
          style={{
            backgroundSize: "contain",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center bottom",
            backgroundColor: "none",
            width: "27.6%",
          }}
          className="LoginLeftContainer"
        >
          <div className="LoginLeftMainMenu">
            <div style={{ display: "block", height: "98%" }}>
              <LeftMenuDecider activeStep={6} />
            </div>
          </div>
        </div>

        <div className="CongratsContainer backImage">
          <div style={{ position: "absolute" }}>
            <ReactLottie keyIndex={1} />
          </div>
          <div className="Congrats">
            <div className="CongratsMain">
              {" "}
              <div style={{ margin: "auto", width: "80%" }}>
                <div className="UserIconContainer">
                  <div
                    style={{
                      padding: "40px 20px 0px 20px",
                      marginBottom: "30px",

                      textAlign: "center",
                      color: "#2E0080 ",
                      fontWeight: "600",
                      fontSize: "30px",
                    }}
                  >
                    Congratulations{" "}
                    {bool === false ? "" : userName.toLowerCase()}!
                  </div>
                </div>

                <div
                  style={{
                    textAlign: "center",
                    color: "#4E4E4E",
                    fontWeight: "400",
                    fontSize: "22px",
                  }}
                >
                  Dear {bool === false ? "" : userName.toLowerCase()}! , Your
                  Loan Application has been approved !!
                  <br />
                  You will shortly receive a call from the bank to complete your
                  loan disbursal.
                </div>

                <Link to={PATH.PRIVATE.PRODUCTS}>
                  <h2
                    style={{
                      padding: "40px 20px 0px 20px",
                      marginBottom: "20px",
                      textAlign: "center",
                      color: "#2E0080 ",
                      fontSize: "21px",
                      lineHeight: "0px",
                      textDecoration: "underline",
                    }}
                  >
                    Go Back to Home
                  </h2>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};
export default FullertonCongralution;
