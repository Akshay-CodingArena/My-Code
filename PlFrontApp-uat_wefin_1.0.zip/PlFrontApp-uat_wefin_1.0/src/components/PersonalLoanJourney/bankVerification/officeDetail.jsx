import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";

import CONSTANTS from "../../../constants/Constants";
// import Back from "../../common/back";
import { ReactComponent as EmployerNameIcon } from "../../../include/assets/personalLoan/empTypeIcon.svg";
import { ReactComponent as WorkType } from "../../../include/assets/personalLoan/workType.svg";
import { ReactComponent as Relationship } from "../../../include/assets/personalLoan/relationship.svg";
import { ReactComponent as Industry } from "../../../include/assets/personalLoan/industry.svg";
import { ReactComponent as Occupation } from "../../../include/assets/personalLoan/occupation.svg";
import { ReactComponent as EmailIcon } from "../../../include/assets/emailIcon.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { decryptStore } from "../../../Utils/store";
import Joi from "joi-browser";
import Form from "../../../components/common/form";
import SelectSearch from "../../../components/common/select";
import {
  mailing,
  workTypeField,
  relationship_type,
  industryField,
  occupationField,
  industryIsicField,
} from "../../../components/common/dropdownValues";
import { getCompanyDetail, getEmployer } from "../../../store/employer";
import CreatableSelect from "react-select/creatable";
class OfficeDetail extends Form {
  state = { data: {}, characterEntered: "", errors: {} };
  schema = {
    mailingAdd: Joi.object()
      .required()
      .label("Loan Mailing Address")
      .error(() => {
        return { message: " Mailing Address Type field is required." };
      }),
    workType: Joi.object()
      .required()
      .label("Work Type")
      .error(() => {
        return { message: "Work Type field is required." };
      }),
    relationShip: Joi.object()
      .required()
      .label("RelationShip")
      .error(() => {
        return { message: "RelationShip field is required." };
      }),
    employerName: Joi.object()
      .required()
      .label("Employer Name")
      .error(() => {
        return { message: "Employer Name field is required." };
      }),
    industry: Joi.object()
      .required()
      .label("Industry")
      .error(() => {
        return { message: "Industry field is required." };
      }),
    industryIsic: Joi.object()
      .required()
      .label("Industry Isic")
      .error(() => {
        return { message: "Industry Isic field is required." };
      }),
    occupation: Joi.object()
      .required()
      .label("Occupation")
      .error(() => {
        return { message: "Occupation field is required." };
      }),
  };

  doSubmit = () => {
    const errors = { ...this.state.errors };
    if (!(/^[A-Za-z0-9 .]*$/.test(this.state.data.employerName.label))) {
      errors.employerName = "Invalid Name of Company format.";
      this.setState({ errors })
      return;
    }
    const data = { ...this.state.data };
    this.props.setpLData((prevState) => ({
      ...prevState,
      mailingAdd: data.mailingAdd.value,
      workType: data.workType.value,
      relationShip: data.relationShip.value,
      employerName: data.employerName,
      industry: data.industry.value,
      industryIsic: data.industryIsic.value,
      occupation: data.occupation.value,
    }));
    this.props.updateStep(null, CONSTANTS.RENDER_OTHER_DETAIL);
  };

  getAllCompany = (character) => {
    let mobile = localStorage.getItem("mobilenumber");
    const data = "mobile=" + mobile + "&companyStr=" + character;
    this.props.getCompanyDetail(data);
  };
  componentDidMount() {
    this.getAllCompany("");

    if (this.props?.industry) {
      if (Object.keys(this.props?.populateData?.industry).length) {
        const industry = this.props?.populateData?.industry
        this.setState({ ...this.state, data: { ...this.state.data, industry } })
      }
    } else {
      this.setState({ ...this.state })
    }
  }

  componentDidUpdate = () => {
    console.log(this.props?.populateData?.industry, this.state.data)
    if (this.props?.populateData?.industry && Object.keys(this.props?.populateData?.industry).length && !this.state.data?.industry) {
      const industry = this.props?.populateData?.industry
      const industryIsic = this.props?.populateData?.industryIsic
      this.setState({ ...this.state, data: { ...this.state.data, industry, industryIsic } })
    }
  }

  handleInputChange = (character) => {
    this.setState((prevState) => {
      return {
        characterEntered: prevState.characterEntered,
      };
    });
    if (this.state.characterEntered !== character) {
      //     this.state.companyDetails(character)
      this.getAllCompany(character);
    }
  };
  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    const { company } = this.props;
    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_OFFICE_ADDRESS);
          }}
        /> */}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1>Additional Information </h1>
            </div>
          </div>
          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Office Detail</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    <SelectSearch
                      placeholderValue={
                        loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
                          ? "Card Mailing Address Type"
                          : "Loan Mailing Address Type"
                      }
                      label={
                        loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
                          ? "Card Mailing Address"
                          : "Loan Mailing Address"
                      }
                      value={this.state.data.mailingAdd}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.mailingAdd = e;
                          errors.mailingAdd = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={mailing}
                      error={this.state.errors.mailingAdd}
                      icon={
                        <EmailIcon
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    {" "}
                    <SelectSearch
                      placeholderValue={"Work Type"}
                      label={"Work Type"}
                      value={this.state.data.workType}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.workType = e;
                          errors.workType = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={workTypeField}
                      error={this.state.errors.workType}
                      icon={
                        <WorkType
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    {" "}
                    <SelectSearch
                      placeholderValue={"Relationship Type"}
                      label={"Relationship Type"}
                      value={this.state.data.relationShip}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.relationShip = e;
                          errors.relationShip = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={relationship_type}
                      error={this.state.errors.relationShip}
                      icon={
                        <Relationship
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <label htmlFor="employer">
                        Name of Company
                        <span style={{ color: "#FF4C30" }}>*</span>
                      </label>
                      <CreatableSelect
                        style={{ color: "#f00" }}
                        isClearable
                        styles={this.customStyles}
                        name="employerName"
                        onChange={(e) => {
                          if (e) {
                            if (e.__isNew__) {
                              const data = { ...this.state.data };
                              const errors = { ...this.state.errors };
                              errors.employerName = "";
                              data.employerName = {
                                label: e.label,
                                value: "99999",
                              };
                              this.setState({ errors, data, value: e.value });
                            } else {
                              const data = { ...this.state.data };
                              const errors = { ...this.state.errors };
                              errors.employerName = "";
                              data.employerName = e;
                              this.setState({
                                data,
                                errors,
                              });
                            }
                          }
                          if (e === null) {
                            const data = { ...this.state.data };
                            data.employerName = "";
                            this.setState({
                              data,
                            });
                          }
                        }}
                        onInputChange={this.handleInputChange}
                        options={company.map((item) => ({
                          label: item.companyName,
                          value: item.compCode,
                        }))}
                        placeholder="Select Company Name"
                        formatCreateLabel={this.formatCreate}
                        value={this.state.data.employerName}
                      />
                      <span className="dropIcon">
                        <EmployerNameIcon
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      </span>
                      {this.state.errors.employerName && (
                        <p className="bsInputErr">
                          {this.state.errors.employerName}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="col-sm-4">
                    <SelectSearch
                      placeholderValue={"Industry"}
                      label={"Industry"}
                      value={this.state.data.industry}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.industry = e;
                          errors.industry = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={industryField}
                      error={this.state.errors.industry}
                      icon={
                        <Industry
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-4">
                    <SelectSearch
                      placeholderValue={"Industry ISIC"}
                      label={"Industry ISIC"}
                      value={this.state.data.industryIsic}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.industryIsic = e;
                          errors.industryIsic = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={industryIsicField}
                      error={this.state.errors.industryIsic}
                      icon={
                        <Industry
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-4">
                    <SelectSearch
                      placeholderValue={"Occupation"}
                      label={"Occupation"}
                      value={this.state.data.occupation}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.occupation = e;
                          errors.occupation = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={occupationField}
                      error={this.state.errors.occupation}
                      icon={
                        <Occupation
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  company: getEmployer(state).company,
  loadingCompany: getEmployer(state).loadingCompany,
});
const mapDispatchToProps = (dispatch) => ({
  getCompanyDetail: (params) => dispatch(getCompanyDetail(params)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OfficeDetail)
);
