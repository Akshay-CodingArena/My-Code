import React from "react";
import Joi from "joi-browser";
import Form from "../../../components/common/form";
import SelectSearch from "../../../components/common/select";
import {
  credit_qualification_type,
  credit_marital_status,
  credit_loan_purpose,
  myprofile_marital_status,
} from "../../common/fullerTonDropdown";
import CONSTANTS from "../../../constants/Constants";
import { ReactComponent as PersonIcon } from "../../../include/assets/Profile.svg";
import Qualification from "../../../include/assets/personalLoan/qualification.svg";
import { ReactComponent as HomeIcon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as Marriage } from "../../../include/assets/personalLoan/marriage.svg";
// import Back from "../../common/back";
import { withRouter } from "react-router";
import { ReactComponent as EmailIcon } from "../../../include/assets/emailIcon.svg";
import Swal from "sweetalert2";
import Gender from "../../common/gender";
import PersonalInput from "../../common/personalInput";
import { loadConsents } from "../../../store/consent";
import { connect } from "react-redux";
import { getOS } from "../../../Utils/device_function";
import { decryptStore } from "../../../Utils/store";
import mapGender from "../../common/mapGender";
import BackDropComponent from "../../../common/BackDropComponent";
class CreditPersonalDetail extends Form {
  state = {
    data: {},
    loading: true,
    errors: {},
    gender: "1",
    terms: false,
    loaded: false
  };
  schema = {
    fatherName: Joi.string()
      .required()
      .label("Father's Name")
      .error(() => {
        return { message: "Father's Name field is required." };
      }),
    maritalStatus: Joi.object()
      .required()
      .label("Marital Status")
      .error(() => {
        return { message: "Marital Status field is required." };
      }),
    offEmail: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Office Email field is required.";
              break;

            case "string.email":
              err.message = "Office Email field is invalid";
              break;
            case "string.max":
              err.message = "Office Email field is invalid";
              break;
            default:
              break;
          }
        });
        return errors;
      }),
    loanPupose: Joi.object()
      .required()
      .error(() => {
        return { message: "Loan Purpose field is required." };
      }),
    qualification: Joi.object()
      .required()
      .label("Qualification")
      .error(() => {
        return { message: "This field is required." };
      }),
  };
  doSubmit = () => {
    let tempEmail = this.state.data.offEmail.toLowerCase();

    if (tempEmail.includes("@gmail.com") || tempEmail.includes("@outlook.com") || tempEmail.includes("@hotmail.com") || tempEmail.includes("@yahoo.com") || tempEmail.includes("@aol.com") || tempEmail.includes("@rediffmail.com")) {
      let tempErrors = this.state.errors;
      tempErrors.offEmail = 'Invalid Office Email format.';
      this.setState({ errors: tempErrors })
      return;
    }
    let regEmail = localStorage.getItem("email");
    if (regEmail === this.state.data.offEmail) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: "Office email should not be same as personal email",
        showConfirmButton: true,
      }).then(() => {
        this.setState((p) => ({ ...p, data: { ...p.data, offEmail: "" } }));
      });
    } else {
      let storeData = {
        fatherName: this.state.data.fatherName,
        gender: this.state.gender === "1" ? "M" : "F",
        qualification: this.state.data.qualification.value,
        loanPupose: this.state.data.loanPupose.value,
        maritalStatus: this.state.data.maritalStatus.value,
        offEmail: this.state.data.offEmail,
      };
      this.props.setpLData(storeData);
      this.props.updateStep(null, CONSTANTS.RENDER_PERSONAL_ADDRESS);
    }
  };
  componentDidMount = () => {
    window.scrollTo(0, 0);
    if (this.props.populateData && !this.props.populateData.loading) {
      const details = this.props.populateData
      this.setState({ ...this.state, gender: details?.gender ? mapGender(details.gender) : "", data: { ...this.state.data, offEmail: this.props.populateData?.offEmail, maritalStatus: myprofile_marital_status?.filter((data, index) => details?.maritalStatus === data.value)[0] } })
    }
  };
  componentDidUpdate = () => {
    window.scrollTo(0, 0);
    if (this.props.populateData && (!this.props.populateData.loading && this.state.loading)) {
      const details = this.props.populateData
      this.setState({ ...this.state, loading: false, gender: details?.gender ? mapGender(details.gender) : "", data: { ...this.state.data, offEmail: this.props.populateData?.offEmail, maritalStatus: myprofile_marital_status?.filter((data, index) => details?.maritalStatus === data.value)[0] } })
    }
  }

  onChangeGender = (e) => {
    if (e) {
      this.setState({ gender: e.target.value });
    }
  };
  handleCheckBoxChange = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let { loanName } = decryptStore(mobile);
    const formData = {
      consentName: "CONSENT_BUREAU",
      consentType: "CB",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: loanName,
      platform:
        getOS() === "ios"
          ? "web_ios"
          : getOS() === "android"
            ? "web_android"
            : "web",
    };
    this.props.loadConsents(formData, this.consentCallback);
  }
  __handleNameChange = (e) => {
    let letters = /^[A-Za-z\s]+$/;
    if (e.target.value !== "" && e.target.value.match(letters)) {
      this.setState((p) => ({
        ...p,
        data: { ...p.data, fatherName: e.target.value },
        errors: { ...p.errors, fatherName: "" },
      }));
    } else {
      this.setState((p) => ({
        ...p,
        data: { ...p.data, fatherName: "" },
        errors: {
          ...p.errors,
          fatherName: "Only alphabets are allowed the in Name Field",
        },
      }));
    }
  };
  consentCallback = (res) => {
    if (res) {
      this.setState({
        terms: true,
      });
    }
  };
  render() {
    return (
      <>
        {this.props.populateData.loading ? <BackDropComponent /> : null}
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information </h1>
            </div>
          </div>

          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Personal Details</a>
                </li>
              </ul>

              <div className="tab-content clearfix">
                <div className="tab-pane active" id="1a">
                  <div className="row">
                    <div className="col-sm-6">
                      <PersonalInput
                        value={this.state.data.fatherName}
                        __handleChange={this.__handleNameChange}
                        error={this.state.errors.fatherName}
                        icon={<PersonIcon />}
                        label="Father's Name"
                        readOnly={false}
                      />
                    </div>
                    <div className="col-sm-6">
                      <SelectSearch
                        placeholderValue={"Qualification"}
                        label={"Qualification"}
                        setSelectedOption={(e) => {
                          const data = { ...this.state.data };
                          const errors = { ...this.state.errors };
                          if (e) {
                            data.qualification = e;
                            errors.qualification = "";
                            this.setState({ data, errors });
                          }
                        }}
                        dropDownOptions={credit_qualification_type}
                        error={this.state.errors.qualification}
                        value={this.state.data.qualification}
                        icon={

                          <img src={Qualification} width="" height="" />

                        }

                      ></SelectSearch>
                    </div>
                    <div className="col-sm-6">
                      <SelectSearch
                        placeholderValue={"Select Marital Status"}
                        label={"Marital Status"}
                        value={this.state.data.maritalStatus}
                        setSelectedOption={(e) => {
                          const data = { ...this.state.data };
                          const errors = { ...this.state.errors };
                          if (e) {
                            data.maritalStatus = e;
                            errors.maritalStatus = "";
                            this.setState({ data, errors });
                          }
                        }}
                        dropDownOptions={credit_marital_status}
                        error={this.state.errors.maritalStatus}
                        icon={
                          <Marriage
                            style={{
                              marginRight: "5px",
                              marginTop: "3px",
                            }}
                          />
                        }
                      ></SelectSearch>
                    </div>
                    <div className="col-sm-6">
                      {this.renderEmail(
                        "offEmail",
                        "Office Email ID ",
                        <EmailIcon />,
                        false
                      )}
                    </div>
                    <div className="col-sm-6">
                      <SelectSearch
                        placeholderValue={"Loan Purpose"}
                        label={"Loan Purpose"}
                        value={this.state.data.loanPupose}
                        setSelectedOption={(e) => {
                          const data = { ...this.state.data };
                          const errors = { ...this.state.errors };
                          if (e) {
                            data.loanPupose = e;
                            errors.loanPupose = "";
                            this.setState({ data, errors });
                          }
                        }}
                        dropDownOptions={credit_loan_purpose}
                        error={this.state.errors.loanPupose}
                        icon={
                          <HomeIcon
                            style={{
                              marginRight: "5px",
                              marginTop: "3px",
                            }}
                          />
                        }
                      ></SelectSearch>
                    </div>
                    <div className="col-sm-6">
                      <Gender
                        onChangeGender={this.onChangeGender}
                        error={this.state.errors.pincode}
                        value={this.state.gender}
                      />
                    </div>
                    <div
                      className="aadhar_check_box"
                      style={{ paddingLeft: "14px" }}
                    >
                      <div className="form-check">
                        <input
                          type="checkbox"
                          name="checkedG"
                          id="checkedG"
                          onChange={this.handleCheckBoxChange}
                          checked={this.state.terms}
                        />
                        <label className="form-check-label" htmlFor="checkedG">
                          I confirm that the PAN number shared belongs to me and
                          authorize wefin to share my personal information with
                          Kisetsu Saison Finance (India) Private Limited and
                          authorize Kisetsu Saison Finance (India) Private
                          Limited to pull my record from NSDL and run credit
                          bureau checks on my behalf to obtain my credit report.
                        </label>
                      </div>
                    </div>
                    <div className="col-sm-12 text-center">
                      {this.state.terms === true ? (
                        <button
                          type="submit"
                          onClick={this.handleSubmit}
                          variant="contained"
                          className="nextButton"
                        >
                          Next
                        </button>
                      ) : (
                        <button
                          variant="contained"
                          className="nextButton"
                          disabled
                          style={{
                            opacity: "0.5",
                            cursor: "not-allowed",
                          }}
                        >
                          Next
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),
});

export default withRouter(
  connect(null, mapDispatchToProps)(CreditPersonalDetail)
);
