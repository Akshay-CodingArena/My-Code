import React from "react";

// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";
import { PLAttachContainerCell } from "../../../common/helperCells";
import { connect } from "react-redux";
import BackDropComponent from "../../../common/BackDropComponent";
import { decryptStore } from "../../../Utils/store";
import Joi from "joi-browser";
import Form from "../../../components/common/form";
import Swal from "sweetalert2";
import { uploadFullerton, getUpload } from "../../../store/upload";
import { withRouter } from "react-router";
import PATH from "../../../paths/Paths";

class UploadDoc extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        idProof: "",
        addressProof: "",
        incomeProof: "",
        businessProof: "",
      },
      errors: {},
    };
  }

  schema = {
    idProof: Joi.object()
      .label("Id Proof")
      .required()
      .error(() => {
        return { message: "Id Proof field is required." };
      }),
    addressProof: Joi.object()
      .label("Address Proof")
      .required()
      .error(() => {
        return { message: "Address Proof field is required." };
      }),
    incomeProof: Joi.object()
      .label("Income Proof")
      .required()
      .error(() => {
        return { message: "Income Proof field is required." };
      }),
    businessProof: Joi.object()
      .label("Business Proof")
      .required()
      .error(() => {
        return { message: "Business Proof field is required." };
      }),
  };
  idUpload = (e) => {
    const data = { ...this.state.data };
    const proof1 = e.target.files[0].name.split(".");
    const myRenamedFile = new File([e.target.files[0]], "610." + proof1[1]);
    data.idProof = myRenamedFile;
    this.setState({ data });
  };
  addressUpload = (e) => {
    const data = { ...this.state.data };
    const proof2 = e.target.files[0].name.split(".");
    const myRenamedFile = new File([e.target.files[0]], "611." + proof2[1]);
    data.addressProof = myRenamedFile;
    this.setState({ data });
  };
  incomeUpload = (e) => {
    const data = { ...this.state.data };
    const proof3 = e.target.files[0].name.split(".");
    const myRenamedFile = new File([e.target.files[0]], "23." + proof3[1]);
    data.incomeProof = myRenamedFile;
    this.setState({ data });
  };
  businessUpload = (e) => {
    const data = { ...this.state.data };
    const proof4 = e.target.files[0].name.split(".");
    const myRenamedFile = new File([e.target.files[0]], "195." + proof4[1]);
    data.businessProof = myRenamedFile;
    this.setState({ data });
  };
  doSubmit = async () => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid } = decryptedData;
    const { idProof, addressProof, incomeProof, businessProof } =
      this.state.data;
    const formData = new FormData();
    formData.append("file", idProof);
    formData.append("file", addressProof);
    formData.append("file", incomeProof);
    formData.append("file", businessProof);
    formData.append("mobile", mobile);
    formData.append(
      "loanId",
      loansfid ? loansfid : localStorage.getItem("loansfid")
    );
    this.props.uploadFullerton(formData, this.callBack);
  };
  callBack = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push(PATH.PRIVATE.FULLERTON_CONGRATULATION);
      } else {
        Swal.fire({
          position: "center",
          icon: "info",
          title:
            "Sorry!! Bank services are down at this time. We will update you once your application is processed.",
          showConfirmButton: true,
        }).then((res) => {
          if (res.isConfirmed) {
            this.props.history.push(PATH.PRIVATE.PRODUCTS);
          }
        });
      }
    }
  };
  render() {
    const { loading } = this.props;
    return (
      <>
        {loading ? <BackDropComponent /> : ""}
        <div className="container">
          <div className="row">
            <div className="col-sm-12 text-center">
              <div className="bsFormHeader">
                {/* <div className="bsFormHeaderIcon">
                  <img alt="" src={USER_ICON} />
                </div> */}
                <h1>Document Verification</h1>
              </div>
            </div>
            <div className="col-sm-12">
              <form>
                <div className="row">
                  <div className="col-sm-6">
                    <PLAttachContainerCell
                      uploadText={"Upload your Id Proof"}
                      fileUpload={this.idUpload}
                      doc={this.state.data.idProof}
                      error={this.state.errors.idProof}
                    />
                  </div>

                  <div className="col-sm-6">
                    <PLAttachContainerCell
                      uploadText={"Upload your Address Proof"}
                      fileUpload={this.addressUpload}
                      doc={this.state.data.addressProof}
                      error={this.state.errors.addressProof}
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-sm-6">
                    <PLAttachContainerCell
                      fileUpload={this.incomeUpload}
                      uploadText={"Upload your Income Proof"}
                      doc={this.state.data.incomeProof}
                      error={this.state.errors.incomeProof}
                    />
                  </div>
                  <div className="col-sm-6">
                    <PLAttachContainerCell
                      fileUpload={this.businessUpload}
                      uploadText={"Upload your Business Proof"}
                      doc={this.state.data.businessProof}
                      error={this.state.errors.businessProof}
                      dataTip="
                <ul>
                  <li>Office ID Card</li>
                 <li>3 Months Pay Slip</li>
                </ul>"
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-sm-12 text-center bsBtnMargin30">
                    <button
                      type="submit"
                      variant="contained"
                      onClick={this.handleSubmit}
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  fullerton: getUpload(state).fullerton,
  loading: getUpload(state).loading,
});
const mapDispatchToProps = (dispatch) => ({
  uploadFullerton: (params, callBack) =>
    dispatch(uploadFullerton(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(UploadDoc)
);
