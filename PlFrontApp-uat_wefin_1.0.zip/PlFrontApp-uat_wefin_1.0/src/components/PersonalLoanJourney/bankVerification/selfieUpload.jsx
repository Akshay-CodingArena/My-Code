import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import Swal from "sweetalert2";
import { decryptStore } from "../../../Utils/store";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import { getUpload, uploadPic } from "../../../store/upload";
import Form from "../../common/form";
import WebcamCapture from "../../common/webcamCapture";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import BackDropComponent from "../../../common/BackDropComponent";
import PATH from "../../../paths/Paths";
import Footer from "../../cibilFlow/footer";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
import { uploadAadhaarSelfie } from "../../../store/kyc";
import CONSTANTS from "../../../constants/Constants";
class SelfieUpload extends Form {
  constructor(props) {
    super(props);
    this.state = {
      selectedImg: null,
      selectedImgBase64: null,
      loading: false,
      geoLocation: {},
      terms: false,
    };
  }

  componentWillMount = () => {
    this.setState({ loading: true });
  };

  componentDidMount = () => {
    this.setState({ loading: false });
    this.setPageLayout();
    this.getGeoLocation();
    let mobile = localStorage.getItem("mobilenumber");
    let { loanName } = decryptStore(mobile);
    const formdata = {
      consentName: "CONSENT_CAMERA",
      consentType: "BTN",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"
          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formdata, this.consentCallback2);
  };

  setPageLayout = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  };

  getCurrentPosition() {
    return new Promise((res, rej) => {
      navigator.geolocation.getCurrentPosition(res, rej);
    });
  }

  getGeoLocation = async () => {
    try {
      let cord = await this.getCurrentPosition();
      cord && this.setState({ geoLocation: cord });
    } catch (e) {
    }
  };

  callBackSelfieUpload = (res) => {
    if (res.data.success) {

      this.props.history.push({
        pathname: PATH.PRIVATE.PERSONAL_DETAIL,
        state: { bike: this.props.location.state.bike },
      });
    }
  }

  doSubmit = async () => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let { loansfid, loanName } = decryptStore(mobile);

      const formdata = {
        consentName: "CONSENT_LOCATION",
        consentType: "BTN",
        consentStatus: "true",
        accountName: localStorage.getItem("accsfid"),
        loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
        platform: getOS() === "ios"
          ? "web_ios"
          : getOS() === "android"
            ? "web_android"
            : "web",
      };
      this.props.loadConsents(formdata, this.consentCallback);
      const formData = new FormData();
      formData.append("mobile", mobile);
      formData.append("file", this.state.selectedImg, "userProfile.jpg");
      this.setState({ loading: true });

      let { loanType, loanId, loanSfid } = decryptStore(mobile)
      if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
        formData.append("loanId", loanSfid)
        formData.append("loan_pl_sync_id", loanId)
        this.props.uploadAadhaarSelfie(formData, this.callBackSelfieUpload)
      }
      else {
        formData.append(
          "loanId",
          this.props.location.state.loanId
            ? this.props.location.state.loanId
            : loansfid
              ? loansfid
              : localStorage.getItem("loansfid"),
        );
        formData.append("docType", "selfie");
        formData.append(
          "latitude",
          this.state.geoLocation.coords.latitude.toString()
        );
        formData.append(
          "longitude",
          this.state.geoLocation.coords.longitude.toString()
        );
        formData.append(
          "offerId",
          this.props.location.state.offerId
            ? this.props.location.state.offerId.toString()
            : this.props.location.state.id.toString()
        );
        formData.append("lenderId", this.props.location.state.lender_id__c);
        this.props.uploadPicData(formData, this.callBackPic);
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: false,
        timer: 1800,
      })
    }
  };
  handleCheckBoxChange = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanName } = decryptedData;
    const formdata = {
      consentName: "CONSENT_MEDIA",
      consentType: "CB",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.props.location.state ? this.props.location.state.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"
          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formdata, this.consentCallback);
  };
  consentCallback = (res) => {
    if (res) {
      this.setState({
        terms: true,
      });
    }
  };
  callBackPic = async (res) => {
    try {
      if (await res) {
        if (res.data.success) {
          let mobile = localStorage.getItem("mobilenumber");
          let decryptedData = decryptStore(mobile);
          let { loanType } = decryptedData;
          this.props.history.push({
            pathname: `${PATH.PRIVATE.VERIFY_BANK_DETAILS}/${loanType
              .split(/\s/)
              .join("-")}/${this.props.location.state.lenderName
                .split(/\s/)
                .join("-")}`,
            state: this.props.location.state,
          });
        } else {
          throw res.data.message;
        }
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        icon: "warning",
        title: "Oops...",
        text: e.errorDetails.errorMessage,
      });
    }
  };

  render() {
    return (
      <>
        {" "}
        <TopNavBar />
        <section className="bs-main-section photoUploadSection">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <LeftMenuDecider activeStep={decryptStore(localStorage.getItem("mobilenumber")).loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ? 2 : 4} />
              </Col>
              <Col xs={12} sm={9}>
                <Card>
                  {this.state.loading ? <BackDropComponent /> : ""}
                  <Card.Header className="text-center header">
                    {/* <script
                      type="text/javascript"
                      src="https://app.digio.in/sdk/v9/digio.js"
                    ></script> */}
                    <h2>Get quick KYC</h2>
                    {this.state.filePreview ? (
                      <>
                        <p>Complete your KYC by clicking a photo or Upload a Photo</p>
                      </>
                    ) : this.state.selfieScreen ? (
                      <p>Complete your KYC by clicking a photo or Upload a Photo</p>
                    ) : (
                      <p>Complete your KYC by clicking a photo or Upload a Photo</p>
                    )}
                  </Card.Header>
                  <Card.Body>
                    <div>
                      <WebcamCapture
                        recievedBlobFile={async (file) =>
                          this.setState({ selectedImg: file })
                        }
                        terms={this.state.terms}
                        handleCheckBoxChange={this.handleCheckBoxChange}
                        recieveFileType={""}

                      />
                    </div>
                    {this.state.selectedImg ? (

                      <>
                        {this.state.terms === true ? (
                          <div className="uploadBtn">
                            <button
                              type="submit"
                              onClick={this.doSubmit}
                              variant="contained"
                              className="nextButton"
                            >
                              Next
                            </button>
                          </div>
                        ) : (
                          <div className="uploadBtn">
                            <button
                              type="submit"
                              style={{
                                opacity: "0.5",
                                cursor: "not-allowed",
                              }}
                              variant="contained"
                              className="nextButton"
                            >
                              Next
                            </button>
                          </div>
                        )}

                      </>
                    ) : (
                      ""
                    )}
                  </Card.Body>
                  <Card.Footer>
                    <p> We collect one-time access to your device's location in order to service your loan application and provide customized offers. </p>
                    <p>We collect one-time access to the camera allows you to capture images of documents and pictures for the loan application.</p>

                  </Card.Footer>
                </Card>
              </Col>
            </Row>
          </Container>
        </section>
        <Footer />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  uploadSelfie: getUpload(state).uploadSelfie,
});
const mapDispatchToProps = (dispatch) => ({
  uploadAadhaarSelfie: (params, callBack) =>
    dispatch(uploadAadhaarSelfie(params, callBack)),
  uploadPicData: (params, callBack) => dispatch(uploadPic(params, callBack)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SelfieUpload)
);