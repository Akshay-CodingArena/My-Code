import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";

import Joi, { errors } from "joi-browser";
import Form from "../../../components/common/form";
import Pincode from "../../common/pincode";
import { ReactComponent as LandlineIcon } from "../../../include/assets/fullertonLogos/Group 20283.svg";
import { ReactComponent as LocationIcon } from "../../../include/assets/fullertonLogos/Places.svg";
import { ReactComponent as EmployerNameIcon } from "../../../include/assets/fullertonLogos/Group 20218.svg";
import CONSTANTS from "../../../constants/Constants";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { cityField } from "../../common/dropdownValues";
import { decryptStore, encryptStore } from "../../../Utils/store";
import { hdfcApplyForLoan, hdfcPL, validatePartner, getEmploersForHdfc } from "../../../store/personalLoan/hdfc";
import BackDropComponent from "../../../common/BackDropComponent";
import { getAccountInfo, getAccount } from "../../../store/account";
import Swal from "sweetalert2";
import SelectSearch from "../../common/select";
// import Back from "../../common/back";

class OfficeAddress extends Form {

  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      pinSfid: "",
      stateSfid: "",
      citySfid: "",
      cityCode: "",
      employerData: [],
      HDFC: {
        consent1: false,
        consent2: false,
        consent3: false
      }
    };
  }

  callbackGetEmployers = (res) => {
    if (res.data.success) {

      this.setState({ employerData: res.data.data })

      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

      if (decryptedData.isDropoff && decryptedData.lenderName === "HDFC") {
        let dropOffData = this.props.dropoffData;
        let data = { ...this.state.data };
        data.add1 = dropOffData.address1work ? dropOffData.address1work : "";
        data.add2 = dropOffData.address2work ? dropOffData.address2work : "";
        data.pincode = dropOffData.office_pincode ? dropOffData.office_pincode : "";
        data.city = dropOffData.city_work ? dropOffData.city_work : "";
        data.state = dropOffData.state_work ? dropOffData.state_work : "";
        data.companyCode = { value: res.data.data[0].employer_id, label: res.data.data[0].employer_name }
        data.street = "";
        data.landline = dropOffData.email ? dropOffData.email : "";
        this.setState({ data })
      }
    };
  }
  schema = {
    companyCode: decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC" ? Joi.object()
      .required()
      .error(() => {
        return { message: "Company Name is required" };
      }) : Joi.string().allow(""),
    add1: Joi.string()
      .required()
      .label("Address Line 1")
      .error(() => {
        return { message: "Office Address Line 1 field is required." };
      }),
    add2: Joi.string()
      .required()
      .label("Address Line 2")
      .error(() => {
        return { message: "Office Address Line 2 field is required." };
      }),
    street: Joi.string()
      .required()
      .label("Street/Landmark")
      .error(() => {
        return { message: "Street/Landmark field is required." };
      }),
    pincode: Joi.number()
      .required()
      .label("Pin Code")
      .error(() => {
        return { message: "Pincode field is required." };
      }),
    landline: decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC" ? Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Office Email field is required";
              break;

            case "string.email":
              err.message = "Office Email field is invalid";
              break;
            case "string.max":
              err.message = "Office Email field is invalid";
              break;
            default:
              err.message = "Office Email field is invalid";
          }
        });
        return errors;
      }) : Joi.number()
        .required()
        .label("Landline No.")
        .error(() => {
          return { message: "Landline No. must be a number." };
        }),
    city: Joi.string().label("City"),
    state: Joi.string().label("State"),
  };

  callBackValidatePartner = (res) => {
    /////filler from response////
    if (res.data.success) {
      const { loanName, sfid, lenderId, loansfid } = decryptStore(localStorage.getItem("mobilenumber"))
      console.log("store items", decryptStore(localStorage.getItem("mobilenumber")), this.props.stepperData)
      const data = this.props.stepperData;

      let prefilledData = this.props.customerDetail;
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

      encryptStore(localStorage.getItem("mobilenumber"), {
        deviceId: res.data.request.ToValidatePartner.deviceId,
        Filler1: res.data.response.ToValidatePartnerResponse.ToValidatePartnerResult.Filler1,
        Filler4: res.data.request.ToValidatePartner.Filler4
      })



      const formData = {
        lenderId,
        loansfid,
        sfid,
        loanName,
        loanAmount: decryptedData.loanAmount,
        proposedEmi: decryptedData.proposedEmi,
        deviceId: res.data.request.ToValidatePartner.deviceId,
        filler1: res.data.response.ToValidatePartnerResponse.ToValidatePartnerResult.Filler1,
        firstName: prefilledData.firstname ? prefilledData.firstname : "",
        lastName: prefilledData.lastname ? prefilledData.lastname : "",
        ////gender we have to check M or F///// 
        gender: prefilledData.gender.toLowerCase() === "male" ? "M" : prefilledData.gender.toLowerCase() === "female" ? "F" : "O",
        dateOfBirth: prefilledData.dob ? prefilledData.dob.split("T")[0] : "",
        panNumber: prefilledData.panNumber ? prefilledData.panNumber : "",
        mobile: prefilledData.pl_mobile_no__c ? prefilledData.pl_mobile_no__c : "",
        email: data.offEmail ? data.offEmail : "",
        addressFromYear: data.data.stayingSince,
        cityFromYear: data.data.stayingInCitySince,
        numberOfDependents: data.dependent,
        address1Resi: data.data.add1,
        address2Resi: data.data.add2,
        address3Resi: "",
        residencePincode: data.data.pincode,
        mobile: localStorage.getItem('mobilenumber'),
        address1Work: data.officeAdd1,
        address2Work: data.officeAdd2,
        officePincode: data.officePin,
        platform: 'Website',
        haveSalAcc: data.salaryAccount,
        educationQualification: data.qualification.value,
        tenure: decryptedData.tenure,
        monthlySalary: decryptedData.monthlySalary,
        employmentType: "S",
        /////////////////Name of the Employer//////////
        employerNameCode: this.state.data.companyCode.value,
        employerName: this.state.data.companyCode.label,
        stateWork: this.state.data.state,
        stateResidence: data.data.propertyState,
        cityResidence: data.propertyCity,
        cityWork: this.state.data.city,
        accountSfid: localStorage.getItem("accsfid"),
        userConsent1: `HDFC_PRIVACY_POLICY,${this.state.HDFC.consent1.toString()}`,
        userConsent2: `HDFC_REQUESTED_PRODUCTS,${this.state.HDFC.consent2.toString()}`,
        userConsent3: `HDFC_OTHER_PRODUCTS,${this.state.HDFC.consent3.toString()}`,
        asm_id: localStorage.getItem("ASM_Id") ? localStorage.getItem("ASM_Id") : undefined
      }
      this.props.hdfcApplyForLoan(formData, this.callBackHdfcApplyLoan)
    }
  }

  callBackHdfcApplyLoan = (res) => {
    if (res.data.success) {
      encryptStore(localStorage.getItem("mobilenumber"), {
        applicationId: res.data.response.applyLoanResponse.applyLoanResult.applicationId
      });
      this.props.updateStep(null, CONSTANTS.REFERENCE_DETAILS_HDFC);
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res.data.message,
        timer: 1800,
      })
    }
  }
  doSubmit = () => {
    if (decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC") {

      let tempEmail = this.state.data.landline.toLowerCase();

      if (tempEmail.includes("@gmail.com") || tempEmail.includes("@outlook.com") || tempEmail.includes("@hotmail.com") || tempEmail.includes("@yahoo.com") || tempEmail.includes("@aol.com") || tempEmail.includes("@rediffmail.com")) {
        let tempErrors = this.state.errors;
        tempErrors.landline = 'Invalid Office Email format.';
        this.setState({ errors: tempErrors })
        return;
      }

      const data = { ...this.state.data };
      this.props.setStepperData((prevState) => ({
        ...prevState,
        officeAdd1: data.add1,
        officeLandmark: data.street,
        officeCity: data.city,
        officeState: data.state,
        officeAdd2: data.add2,
        officePin: data.pincode,
        offEmail: data.landline,
      }));

      const mobileNumber = localStorage.getItem('mobilenumber')
      const { lenderId, sfid, loanName } = decryptStore(mobileNumber)
      const formData = {
        lenderId,
        sfid,
        mobileNumber,
        loanName,
        platform: "Website"
      }
      this.props.validatePartner(formData, this.callBackValidatePartner)

    } else {
      // console.log("office form city code", this.state)
      const data = { ...this.state.data };
      this.props.setpLData((prevState) => ({
        ...prevState,
        officeAdd1: data.add1,
        officeLandmark: data.street,
        officeCity: data.city,
        officeState: data.state,
        officeAdd2: data.add2,
        officePin: data.pincode,
        offPinsfid: this.state.pinSfid,
        offCitysfid: this.state.citySfid,
        offStatesfid: this.state.stateSfid,
        /////////////send Delhi Offcity Code in case did not find any city which is 318/////////////
        offCityCode: this.state.cityCode ? this.state.cityCode : "318",
        officeLandline: data.landline,
      }));
      if (
        this.props.location.state &&
        this.props.location.state.lenderName === "Fullerton India Credit"
      ) {
        this.props.updateStep(null, CONSTANTS.RENDER_FULLERTON_DETAIL);
      } else if (
        this.props.location.state &&
        this.props.location.state.lenderName === "MoneyTap"
      ) {
        this.props.updateStep(null, CONSTANTS.RENDER_MONEY_TAP_DETAIL);
      } else {
        this.props.updateStep(null, CONSTANTS.RENDER_OFFICE_DETAIL);
      }
    };
  }
  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    if (e.target.value && !/^[0-9]+$/.test(e.target.value)) {
      if (e.target.value.length === 6) {
        const errors = { ...this.state.errors };
        errors.pincode = "Pincode must be number";
        this.setState({ errors });
      } else {
        const errors = { ...this.state.errors };
        errors.pincode = "";
        this.setState({ errors });
      }
    } else {
      if (e.target.value.length === 6) {
        const data = { ...this.state.data };
        const errors = { ...this.state.errors };
        data.pincode = e.target.value;
        errors.pincode = "";
        this.setState({ data, errors });
        let formData = { mobile: mobile, pincode: e.target.value };
        this.props.loadPinCode(formData, this.callbackPin);
      }
      else {
        let data = { ...this.state.data };
        data.city = "";
        data.state = "";
        this.setState({ data });
      }
    }
  };
  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data?.success === false) {
        //  console.log("city name not generated")
        errors.pincode = res.data.message;
        this.setState({ errors });
      } else if (res.data?.success === true) {
        let card = this.props.location?.state.card ?? this.props.location?.state
        if (card?.lender_name__c === "SCB" || card?.lenderName === "Standard Chartered") {
          // console.log("City name from response", res, res.data.data.cityname.toUpperCase())
          let city = cityField.filter(
            (a) =>
              a.label.toUpperCase() === res.data.data.cityname.toUpperCase()
          );

          if (city.length > 0) {
            const errors = { ...this.state.errors };
            const data = { ...this.state.data };
            data.city = res.data.data.cityname;
            data.state = res.data.data.statename;
            errors.pincode = "";
            this.setState({
              data,
              loading: false,
              errors,
              pinSfid: res.data.data.sfid,
              stateSfid: res.data.data.state__c,
              cityCode: city[0].value,
              citySfid: res.data.data.city__c,
            });
          } else {
            const errors = { ...this.state.errors };
            const data = { ...this.state.data };
            errors.pincode =
              "Currently we are not providing servicing in your city.";
            data.city = "";
            data.state = "";
            this.setState({
              loading: false,
              data,
              errors,
            });
          }
        } else {
          let city = cityField.filter(
            (a) =>
              a.label.toUpperCase() === res.data.data.cityname.toUpperCase()
          );
          const errors = { ...this.state.errors };
          const data = { ...this.state.data };
          data.city = res.data.data.cityname;
          data.state = res.data.data.statename;
          let cityCode = city[0]?.value
          errors.pincode = "";
          this.setState({
            data,
            cityCode,
            errors,
            pinSfid: res.data.data.sfid,
            stateSfid: res.data.data.state__c,
            citySfid: res.data.data.city__c,
          });
        }
      }
    }
  };

  componentDidMount = () => {
    window.scrollTo(0, 0);
    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
    if (decryptedData.lenderName === "HDFC") {
      this.setState({ data: { ...this.state.data, companyCode: "" } })
      this.props.getEmploersForHdfc({
        companyStr: decryptedData.isDropoff ? this.props.dropoffData.employer_name : ""
      }, this.callbackGetEmployers)
    }
    if (this.props.populateData?.officeAddress) {
      const officeAddress = this.props.populateData.officeAddress
      const landLine = this.props.populateData?.landline
      this.setState({
        ...this.state, data: {
          landline: landLine,
          add1: officeAddress?.pl_address_line1__c,
          add2: officeAddress?.pl_address_line_2__c,
          pincode: officeAddress?.pincode,
        },
      })
    }

    let formData = {
      mobile: localStorage.getItem('mobilenumber')
    }
    this.props.getAccountInfo(formData, this.callbackDetail);
  }

  callbackDetail = (res) => { }

  componentDidUpdate = () => {
    if (this.state.data.pincode && !this.state.data?.city && !this.state.loading && !Object.keys(this.state.errors).length) {
      let formData = { mobile: localStorage.getItem('mobilenumber'), pincode: this.state.data?.pincode };
      this.setState({ loading: true });
      this.props.loadPinCode(formData, this.callbackPin);
    }
  }

  handleCheckBoxChange = (consent) => {
    let values = { ...this.state.HDFC };
    switch (consent) {
      case "consent1":
        values.consent1 = !values.consent1;
        this.setState({ HDFC: values })
        break;
      case "consent2":
        values.consent2 = !values.consent2;
        this.setState({ HDFC: values })
        break;
      case "consent3":
        values.consent3 = !values.consent3;
        this.setState({ HDFC: values })
        break;
    }
  }

  render() {
    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"))
    return (
      <>
        {/* <Back
          onClick={(e) => {
            this.props.updateStep(e, CONSTANTS.RENDER_PERMANENT_ADDRESS);
          }}
        /> */}
        {this.props.hdfcLoadingStatus || this.props.loading || this.props.pinCodeLoading || this.props.loadingGetEmployers ? <BackDropComponent /> : null}
        <div className="row insideFormBlock">
          <form className="panVeryfyForm">
            <div className="col-sm-12 text-center">
              <div className="bsFormHeader">
                {/* <div className="bsFormHeaderIcon">
                  <img alt="" src={USER_ICON} />
                </div> */}

                <h1>Additional Information </h1>
              </div>
            </div>
            <div className="col-sm-12">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Office Address</a>
                </li>
              </ul>
              <div className="tab-content clearfix">
                <div className="row">
                  <div className="col-sm-6">
                    {this.renderInput(
                      "add1",
                      "Office Address Line 1",
                      <EmployerNameIcon />
                    )}
                  </div>
                  <div className="col-sm-6">
                    {this.renderInput(
                      "add2",
                      "Office Address Line 2",
                      <EmployerNameIcon />
                    )}
                  </div>
                  <div className="col-sm-6">
                    {this.renderInput(
                      "street",
                      "Street/Landmark",
                      <LocationIcon />
                    )}
                  </div>
                  <div className="col-sm-6">
                    <Pincode
                      value={this.state.data.pincode}
                      __handlePinCode={this.__handlePinCode}
                      error={this.state.errors.pincode}
                    />
                  </div>
                  <div className="col-sm-3">
                    {this.renderInput("city", "City", <LocationIcon />, true)}
                  </div>
                  <div className="col-sm-3">
                    {this.renderInput("state", "State", <LocationIcon />, true)}
                  </div>

                  <div className="col-sm-6">
                    {decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC" ?
                      this.renderInput(
                        "landline",
                        "Work Email Id",
                        <LandlineIcon />,
                        false,
                        35,
                        8,
                        "text",
                        true,
                        true
                      ) : this.renderInput(
                        "landline",
                        "Landline No.",
                        <LandlineIcon />,
                        false,
                        15,
                        15
                      )}
                  </div>

                  {decryptedData.lenderName === "HDFC" ? <div className="col-sm-12">
                    <SelectSearch
                      style={{ margin: "15px 8px 20px" }}
                      placeholderValue={"Select Company Name"}
                      label={"Company Name"}
                      value={this.state.data.companyCode}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.companyCode = e;
                          errors.companyCode = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={this.props.employerData.map((value, index) => {
                        return {
                          label: value.employer_name,
                          value: value.employer_id
                        }
                      })}
                      error={this.state.errors.companyCode}
                      icon={
                        <EmployerNameIcon
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div> : ""
                  }

                  {decryptedData.lenderName === "HDFC" ?
                    <div>
                      <div className="aadhar_check_box">
                        <div className="form-check">
                          <input
                            type="checkbox"
                            name="checkedG"
                            id="checkedG"
                            onChange={() => {
                              this.handleCheckBoxChange("consent1")
                            }}
                            checked={this.state.HDFC.consent1}
                          />
                          <label
                            className="form-check-label check_pl"
                            htmlFor="checkedG"
                          >
                            I have read, understood and hereby accept the <a href="https://wefin.in/hdfc/privacy_policy.pdf" target="_blank">customized Privacy Policy for Neotec Enterprises Limited in relation to collection of information for HDFC Bank.</a>
                          </label>
                        </div>

                      </div>

                      <div className="aadhar_check_box">
                        <div className="form-check">
                          <input
                            type="checkbox"
                            name="checkedG"
                            id="checkedG2"
                            onChange={() => {
                              this.handleCheckBoxChange("consent2")
                            }
                            }
                            checked={this.state.HDFC.consent2}
                          />
                          <label
                            className="form-check-label check_pl"
                            htmlFor="checkedG2"
                          >
                            I/we hereby give the <a href="https://wefin.in/hdfc/consent-for-requested-products.pdf" target="_blank"> consent (V.1.0) in relation to Requested Products.</a>
                          </label>
                        </div>
                      </div>


                      <div className="aadhar_check_box">
                        <div className="form-check">
                          <input
                            type="checkbox"
                            name="checkedG"
                            id="checkedG3"
                            onChange={() => {
                              this.handleCheckBoxChange("consent3")
                            }
                            }
                            checked={this.state.HDFC.consent3}
                          />
                          <label
                            className="form-check-label check_pl"
                            htmlFor="checkedG3"
                          >
                            I/we hereby give the
                            <a href="https://wefin.in/hdfc/consent_for_other_products.pdf" target="_blank"> consent (V.2.0) in relation to Other Products.</a>

                          </label>
                        </div>
                      </div>


                      <div className="aadhar_check_box hdfc_calculator_link">
                        APR calculator: <a href="https://www.hdfcbank.com/personal/tools-and-calculators#/Footer" target="_blank">https://www.hdfcbank.com/personal/tools-and-calculators#/Footer</a>
                      </div>

                    </div>


                    : ""
                  }
                  <div className="col-sm-12 text-center">
                    {(decryptStore(localStorage.getItem("mobilenumber")).lenderName !== "HDFC")
                      ||
                      (
                        decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC" &&
                        (this.state.HDFC.consent1) && (this.state.HDFC.consent2)
                      ) ?
                      <button
                        type="submit"
                        onClick={this.handleSubmit}
                        variant="contained"
                        className="nextButton"
                      >
                        Next
                      </button> :
                      <button
                        variant="contained"
                        className="nextButton"
                        disabled
                        style={{
                          opacity: "0.5",
                          cursor: "not-allowed",
                        }}
                      >
                        Next
                      </button>}
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  getpinCode: getpinCode(state),
  hdfcLoadingStatus: hdfcPL(state).hdfcLoadingStatus,
  loading: getAccount(state).loading,
  customerDetail: getAccount(state).customerDetail,
  pinCodeLoading: getpinCode(state).loading,
  employerData: hdfcPL(state).employerData,
  loadingGetEmployers: hdfcPL(state).loadingGetEmployers
});
const mapDispatchToProps = (dispatch) => ({
  validatePartner: (params, callback) => dispatch(validatePartner(params, callback)),
  hdfcApplyForLoan: (params, callback) => dispatch(hdfcApplyForLoan(params, callback)),
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),

  getEmploersForHdfc: (params, callbackDetail) =>
    dispatch(getEmploersForHdfc(params, callbackDetail))
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OfficeAddress)
);
