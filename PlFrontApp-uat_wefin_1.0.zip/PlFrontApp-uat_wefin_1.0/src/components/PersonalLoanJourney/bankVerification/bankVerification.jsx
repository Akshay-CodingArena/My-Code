import React, { useEffect, useState } from "react";
import CONSTANTS from "../../../constants/Constants";
import AdditionalInfo from "./additionalInformation";
import PersonalAddress from "./personalAddress";
import OfficeAddress from "./officeAddress";
import UploadDoc from "./uploadDoc";
import OtherDetail from "./otherDetail";
import OfficeDetail from "./officeDetail";
import PersonalDetail from "./personalDetail";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import PermanentAddress from "./permanentAddress";
import { Container, Row, Col } from "react-bootstrap";
import Congralution from "./congralution";
import FullerTonDetail from "./fullertonDetail";
import MoneyTapAddress from "./moneyTapAddress";
import MoneyTapDetail from "./moneyTapDetail";
import CreditPersonalDetail from "./creditPersonalDetial";
import { useLocation } from "react-router";
import CreditFooter from "../../cibilFlow/footer";
import { useDispatch, useSelector } from "react-redux";
import { getAccountInfo } from "../../../store/account";
import { myprofile_marital_status } from "../../common/fullerTonDropdown";
import { designation, industryField, industryIsicField } from "../../common/dropdownValues";
import ASMNavBar from "../../ASM/ASMNavBar";

const BankVerification = ({ pLData, setpLData, lo }) => {
  const location = useLocation();
  const [details, setDetails] = useState(useSelector(state => state.entities.account.customerDetail))
  const [loading, setLoading] = useState(true);
  const fetchDetails = useDispatch()
  const [step, setStep] = React.useState(
    location.state && (location.state.lender_name__c ?? location.state.lenderName) === "Credit Saison"
      ? CONSTANTS.RENDER_CREDIT_PERSONAL_DETAIL
      : CONSTANTS.RENDER_PERSONAL_DETAIL
  );

  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };

  const callBackDetails = (res) => {
    if (res) {
      setDetails(res.data.customer)
      setLoading(false)
    }
  }

  useEffect(() => {
    if (Object.keys(details).length) {
      setLoading(false)
      console.log("details are", details)

    } else {
      fetchDetails(getAccountInfo({ mobile: localStorage.getItem("mobilenumber") }, callBackDetails))
    }
  }, [])
  useEffect(() => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
    // console.log("state is", useSelector(state => state))
  });
  const leftSideStep = () => {
    //  console.log("step is", step)
    switch (step) {
      case CONSTANTS.RENDER_PERSONAL_DETAIL:
        return (
          <PersonalDetail
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            hideOther={true}
            populateData={{
              name: details?.name,
              gender: details?.gender,
              title: details?.title,
              qualification: details?.qualification__c,
              dependents: details?.no_of_dependents__c
            }}

          />
        );
      case CONSTANTS.RENDER_CREDIT_PERSONAL_DETAIL:
        return (
          <CreditPersonalDetail
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              maritalStatus: details?.maritalstatus,
              gender: details?.gender,
              loading: loading,
              offEmail: details?.offEmail
            }}
          />
        );

      case CONSTANTS.RENDER_ADDITIONAL_INFO:
        return (
          <AdditionalInfo
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              dependent: details?.no_of_dependents__c ? { value: details?.no_of_dependents__c, label: details?.no_of_dependents__c } : null,
              loanPupose: details?.designation__c ? designation.find((designation) => designation.label === details?.designation__c) : null,
              maritalStatus: details?.maritalstatus ? myprofile_marital_status?.filter((data, index) => details?.maritalstatus === data.value)[0] : {}
            }}
          />
        );

      case CONSTANTS.RENDER_PERSONAL_ADDRESS:
        return (
          <PersonalAddress
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              currentAddress: details.currAddrDetails,
            }}
          />
        );
      case CONSTANTS.RENDER_MONEYTAP_PERSONAL_ADDRESS:
        return (
          <MoneyTapAddress
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
          />
        );
      case CONSTANTS.RENDER_MONEY_TAP_DETAIL:
        return (
          <MoneyTapDetail
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
          />
        );
      case CONSTANTS.RENDER_PERMANENT_ADDRESS:
        return (
          <PermanentAddress
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            step={step}
            populateData={{
              permanentAddress: details?.resAddrDetails
            }}
          />
        );
      case CONSTANTS.RENDER_OFFICE_DETAIL:
        return (
          <OfficeDetail
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              industry: industryField?.find(ind => ind.label === details?.industry__c),
              industryIsic: industryIsicField?.find(ind => ind.label === details?.industryisic__c)
            }}
          />
        );
      case CONSTANTS.RENDER_OTHER_DETAIL:
        return (
          <OtherDetail
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              offEmail: details?.offEmail
            }}
          />
        );
      case CONSTANTS.RENDER_FULLERTON_DETAIL:
        return (
          <FullerTonDetail
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
          />
        );

      case CONSTANTS.RENDER_OFFICE_ADDRESS:
        return (
          <OfficeAddress
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              officeAddress: details?.employerAddrDetails,
              landline: details?.off_landline__c
            }}
          />
        );
      case CONSTANTS.RENDER_CONGRALUTION:
        return <Congralution updateStep={updateStep} location={location} />;

      case CONSTANTS.RENDER_UPLOAD_DOCUMENTS:
        return <UploadDoc updateStep={updateStep} />;
      default:
        break;
    }
  };

  return (
    <>
      {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
      <section className="bs-main-section">
        <Container>
          <Row>
            <Col sm={12} md={3}>
              <LeftMenuDecider activeStep={3} />
            </Col>
            <Col sm={12} md={9}>
              {leftSideStep()}
            </Col>
          </Row>
        </Container>
      </section>

      <CreditFooter />
    </>
  );
};

export default BankVerification;
