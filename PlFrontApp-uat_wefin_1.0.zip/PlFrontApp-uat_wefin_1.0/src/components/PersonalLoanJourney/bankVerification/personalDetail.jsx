import React from "react";
// import USER_ICON from "../../../include/assets/1/smartphone@2x.png";

import Joi from "joi-browser";
import Form from "../../../components/common/form";
import SelectSearch from "../../../components/common/select";
import { titleFields, qualificationField } from "../../common/dropdownValues";
import {
  qualification_type,
  marital_status_moneytap,
} from "../../common/fullerTonDropdown";
import CONSTANTS from "../../../constants/Constants";
import { ReactComponent as PersonIcon } from "../../../include/assets/Profile.svg";
import Qualification from "../../../include/assets/personalLoan/qualification.svg";
import { ReactComponent as Title } from "../../../include/assets/personalLoan/title.svg";
import { ReactComponent as Marriage } from "../../../include/assets/personalLoan/marriage.svg";
// import Back from "../../common/back";
import { withRouter } from "react-router";
import { getAccount, getAccountInfo } from "../../../store/account";
import { connect } from "react-redux";
import Swal from "sweetalert2";
import Gender from "../../common/gender";
import PATH from "../../../paths/Paths";
import mapGender from "../../common/mapGender";
class PersonalDetail extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      gender: "Male",
      firstName: "",
      lastName: "",
      middleName: "",
    };
  }

  schema = {
    fullName: Joi.string()
      .required()
      .label("Full Name")
      .error(() => {
        return { message: "FullName field is required." };
      }),
    title: Joi.object()
      .required()
      .label("Title")
      .error(() => {
        return { message: "Title field is required." };
      }),

    qualification: Joi.object()
      .required()
      .label("Qualification")
      .error(() => {
        return { message: "This field is required." };
      }),
  };
  doSubmit = () => {
    let storeData = {
      title: this.state.data.title.value,
      firstName: this.state.firstName
        ? this.state.firstName
        : this.props.customerDetail.firstname,
      middleName: this.state.middleName
        ? this.state.middleName
        : this.props.customerDetail.middlename,
      lastName: this.state.lastName
        ? this.state.lastName
        : this.props.customerDetail.lastname,
      gender: this.state.gender,
      qualification: this.state.data.qualification.value,
    };
    this.props.setpLData(storeData);
    if (this.props.location.state.lenderName === "MoneyTap") {
      this.props.updateStep(
        null,
        CONSTANTS.RENDER_MONEYTAP_PERSONAL_ADDRESS
      );
    } else {
      this.props.updateStep(null, CONSTANTS.RENDER_ADDITIONAL_INFO);
    }
  };
  componentDidMount = () => {
    document.body.classList.remove("TwScrool");
    document.body.classList.add("variantScroll");
    let mobile = localStorage.getItem("mobilenumber");
    console.log(this.props.customerDetail)
    // const userName = isNaN(localStorage.getItem("lastName"))
    //   ? localStorage.getItem("fullName")
    //   : localStorage.getItem("firstName");
    // // const { name, title, firstname, lastname } = this.props.customerDetail;
    const userName = this.props.populateData.name
    const namee = userName?.split(" ");
    const data = { ...this.state.data };
    data.fullName = this.props.populateData?.name;
    data.title = this.props.customerDetail?.title ? { label: this.props.customerDetail?.title, value: this.props.customerDetail?.title.toUpperCase() } : null
    if (namee?.length > 2) {
      this.setState({
        firstName: namee[0],
        lastName: namee[2],
        middleName: namee[1],
        gender: mapGender(this.props.gender) ?? mapGender(this.state.gender),
        data,
      });
    } else {
      this.setState({ data, firstName: namee ? namee[0] : "", lastName: namee ? namee[1] : "", gender: mapGender(this.props.gender) ?? mapGender(this.state.gender) });
    }
  }


  componentDidUpdate = (prevProps, prevState) => {
    console.log(this.state.data)
    if (!this.props.loading && this.props.loading !== prevProps.loading) {
      const userName = isNaN(localStorage.getItem("lastName"))
        ? localStorage.getItem("fullName")
        : localStorage.getItem("firstName");
      // const { name, title, firstname, lastname } = this.props.customerDetail;
      const namee = userName.split(" ");
      const data = { ...this.state.data };
      data.fullName = userName;
      data.title = this.props.customerDetail?.title ? { label: this.props.customerDetail?.title, value: this.props.customerDetail?.title.toUpperCase() } : ""
      console.log("populate", this.props.customerDetail.title)
      if (namee.length > 2) {
        this.setState({
          firstName: namee[0],
          lastName: namee[2],
          middleName: namee[1],
          gender: mapGender(this.props.customerDetail?.gender) ?? this.state.gender,
          data: { ...data },
        });
      } else {
        this.setState({ data: { ...data }, firstName: namee[0], lastName: namee[1], gender: mapGender(this.props.customerDetail?.gender) ?? this.state.gender });
      }
    }
  };
  callbackDetail = (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };
  onChangeGender = (e) => {
    if (e) {
      console.log(e.target.value)
      this.setState({ gender: e.target.value });
    }
  };
  render() {
    // console.log("Personal Details")
    return (
      <>
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              {/* <div className="bsFormHeaderIcon">
                <img alt="" src={USER_ICON} />
              </div> */}

              <h1> Additional Information </h1>
            </div>
          </div>

          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a href="/#" className="active">Personal Details</a>
                </li>
              </ul>

              <div className="tab-content clearfix">
                <div className="tab-pane active" id="1a">
                  <div className="row">
                    <div className="col-sm-6">
                      <SelectSearch
                        placeholderValue={"Title"}
                        label={"Title"}
                        value={this.state.data.title}
                        setSelectedOption={(e) => {
                          const data = { ...this.state.data };
                          const errors = { ...this.state.errors };
                          if (e) {
                            data.title = e;
                            errors.title = "";
                            this.setState({ data, errors });
                          }
                        }}
                        dropDownOptions={titleFields}
                        error={this.state.errors.title}
                        icon={
                          <Title
                            style={{ marginRight: "5px", marginTop: "2px" }}
                          />
                        }
                      ></SelectSearch>
                    </div>
                    <div className="col-sm-6">
                      {this.renderInput(
                        "fullName",
                        "Full Name",
                        <PersonIcon />,
                        false
                      )}
                    </div>
                    <div className="col-sm-6">
                      <Gender
                        onChangeGender={this.onChangeGender}
                        value={this.state.gender}
                        hideOther={this.props.hideOther}
                      />
                    </div>
                    <div className="col-sm-6">
                      {this.props.location.state.lenderName === "MoneyTap" ? (
                        <SelectSearch
                          placeholderValue={"Select Marital Status"}
                          label={"Marital Status"}
                          value={this.state.data.qualification}
                          setSelectedOption={(e) => {
                            const data = { ...this.state.data };
                            const errors = { ...this.state.errors };
                            if (e) {
                              data.qualification = e;
                              errors.qualification = "";
                              this.setState({ data, errors });
                            }
                          }}
                          dropDownOptions={marital_status_moneytap}
                          error={this.state.errors.qualification}
                          icon={
                            <Marriage
                              style={{
                                marginRight: "5px",
                                marginTop: "3px",
                              }}
                            />
                          }
                        ></SelectSearch>
                      ) : (
                        <SelectSearch
                          placeholderValue={"Qualification"}
                          label={"Qualification"}
                          setSelectedOption={(e) => {
                            const data = { ...this.state.data };
                            const errors = { ...this.state.errors };
                            if (e) {
                              data.qualification = e;
                              errors.qualification = "";
                              this.setState({ data, errors });
                            }
                          }}
                          dropDownOptions={
                            this.props.location &&
                              this.props.location.state.lenderName ===
                              "Fullerton India Credit"
                              ? qualification_type
                              : qualificationField
                          }
                          error={this.state.errors.qualification}
                          value={this.state.data.qualification}
                          icon={
                            <img src={Qualification} width="" height="" />
                          }
                        ></SelectSearch>
                      )}
                    </div>
                    <div className="col-sm-12 text-center">
                      <button
                        type="submit"
                        onClick={this.handleSubmit}
                        variant="contained"
                        className="nextButton"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(PersonalDetail)
);
