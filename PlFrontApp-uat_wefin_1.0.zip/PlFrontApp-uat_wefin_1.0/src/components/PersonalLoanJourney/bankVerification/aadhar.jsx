import React, { Component } from "react";
import { Container, Row, Form, Col, Card } from "react-bootstrap";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import AADHAR_PHOTO from "../../../include/assets/1/aadhar.png";
// import ArrowForwardIcon from "../../../include/assets/otpArrow.png";
import { decryptStore } from "../../../Utils/store";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  initiateKyc,
  validateKyc,
  initiateCreditKyc,
  validateCreditKyc,
} from "../../../store/kyc";
import BackDropComponent from "../../../common/BackDropComponent";
import Swal from "sweetalert2";
import PATH from "../../../paths/Paths";
import { getOS } from "../../../Utils/device_function";
import { loadConsents } from "../../../store/consent";

let reg = new RegExp("^[0-9]*$");

class Aadhar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      geoLocation: {},
      formFieldSelect: "aadhar",
      otpSeconds: 40,
      showOTPField: false,
      showSubmitAadharButton: true,
      aadhar: "",
      showResendOTPSection: false,
      loading: false,
      showCounter: true,
      showSubmitOTPButton: false,
      otp: "",
      bank: {},
      terms: false,
    };

    this.getGeoLocation = this.getGeoLocation.bind(this);
    this.setPageLayout = this.setPageLayout.bind(this);
    this.handleOTPTimer = this.handleOTPTimer.bind(this);
    this.submitAadhar = this.submitAadhar.bind(this);
    this.handleInitiateAadharCallback =
      this.handleInitiateAadharCallback.bind(this);
  }

  componentDidMount = () => {
    this.getGeoLocation();
    this.setPageLayout();
  };

  componentWillUnmount = () => {
    clearInterval(this.handleOTPTimer);
  };

  submitAadhar = async (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid } = decryptStore(mobile);
    const { state } = this.props.location;
    this.setState(({ bank }) => ({ bank: { ...bank, ...state } }));
    const data = {
      processType: "initiateaadhaar",
      mobile: mobile,
      aadharNo: this.state.aadhar.toString().replace(/\s+/g, ""),
      loanId: this.props.location.state.loanId
        ? this.props.location.state.loanId
        : loansfid
          ? loansfid
          : localStorage.getItem("loansfid"),
      userAgent: window.navigator.userAgent.toString(),
      docType: "aadharXml",
      lenderId: this.props.location.state.lender_id__c,
      offerId: this.props.location.state.offerId
        ? this.props.location.state.offerId.toString()
        : this.props.location.state.id.toString(),
    };
    this.props.setInitiateCreditKyc(
      data,
      this.handleInitiateCreditAadharCallback
    );

    this.setState({
      loading: true,
      showSubmitAadharButton: true,
      showSubmitOTPButton: false,
    });
  };

  handleInitiateCreditAadharCallback = async (res) => {
    try {
      let r = await res;

      if (r?.data?.success) {
        this.setState({ loading: false, showOTPField: true, showSubmitOTPButton: true, showSubmitAadharButton: false });
        this.handleOTPTimer();
      } else {
        throw new Error(
          "It is taking longer than usual… requesting your kind patience",
          { cause: "pending" }
        );
      }
    } catch (e) {
      this.setState({
        loading: false,
        showSubmitAadharButton: true,
        showSubmitOTPButton: false,
        aadhar: "",
      });
      Swal.fire({
        icon: "warning",
        title: "It is taking longer than usual… requesting your kind patience",
      });
    }
  };

  handleInitiateAadharCallback = async (res) => {
    try {
      let r = await res;
      if (await r.data.success) {
        this.setState({ loading: false });
        this.setState({ showOTPField: true });
        this.handleOTPTimer();
      } else {
        throw new Error(r.data.message);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        icon: "warning",
        title: e.message.toString(),
      });
    }
  };

  handleOTPTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.otpSeconds > 0) {
        this.setState((state) => {
          return { otpSeconds: state.otpSeconds - 1 };
        });
      } else {
        this.setState({
          showResendOTPSection: true,
          showCounter: false,
          formFieldSelect: "otp",
        });
        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };

  resendOTP = (e) => {
    e.preventDefault();
    this.setState({
      showCounter: true,
      loading: false,
      formFieldSelect: "aadhar",
      otpSeconds: 40,
      showOTPField: false,
      showSubmitAadharButton: true,
      showResendOTPSection: false,
      showSubmitOTPButton: false,
    });
    this.submitAadhar(e);
  };

  submitOTP = async (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    let { loansfid, loanName } = decryptStore(mobile);
    const formData = {
      consentName: "CONSENT_AADHAAR",
      consentType: "OTP",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.state.bank ? this.state.bank.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"
          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formData, this.consentCallback);
    const data = {
      processType: "validateaadhaar",
      aadharNo: this.state.aadhar.toString().replace(/\s+/g, ""),
      mobile: mobile.toString(),
      otp: this.state.otp.toString(),
      lenderId: this.state.bank.lender_id__c.toString(),
      offerId: this.state.bank.id
        ? this.state.bank.id.toString()
        : this.state.bank.offerId.toString(),
      loanId: this.props.location.state.loanId
        ? this.props.location.state.loanId
        : loansfid
          ? loansfid
          : localStorage.getItem("loansfid")
      ,
      docType: "aadharXml",
    };
    // loanId: this.props.location.state.loanId
    //   ? this.props.location.state.loanId
    //   : loansfid
    //     ? loansfid
    //     : localStorage.getItem("loansfid")
    this.props.setValidateCreditKyc(
      data,
      this.handleValidateCreditAadharCallback
    );

    this.setState({ loading: true });
  };

  handleValidateCreditAadharCallback = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        this.setState({ loading: false });
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SELFIE_UPLOAD
            }/${this.state.bank.loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
          state: this.state.bank,
        });
      } else {
        throw new Error(r.data.message);
      }
    } catch (e) {
      let r = await res;
      this.setState({ loading: false, otp: "" });
      Swal.fire({
        icon: "warning",
        title: "Oops...",
        text: r.data.csXmlData.message,
      });
    }
  };

  setPageLayout = () => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  };

  getCurrentPosition() {
    return new Promise((res, rej) => {
      navigator.geolocation.getCurrentPosition(res, rej);
    });
  }

  getGeoLocation = async () => {
    try {
      let cord = await this.getCurrentPosition();
      cord && this.setState({ geoLocation: cord });
    } catch (e) {
    }
  };
  handleAadharInput = (e) => {
    const inputVal = e.target.value.replace(/ /g, "");
    let inputNumbersOnly = inputVal.replace(/\D/g, "");

    if (inputNumbersOnly.length > 12) {
      inputNumbersOnly = inputNumbersOnly.substr(0, 12);
    }
    const splits = inputNumbersOnly.match(/.{1,4}/g);

    let spacedNumber = "";
    if (splits) {
      spacedNumber = splits.join(" ");
    }
    this.setState({
      aadhar: spacedNumber
    });
  };

  handleCheckBoxChange = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let { loanName } = decryptStore(mobile);
    const formData = {
      consentName: "CONSENT_AADHAAR",
      consentType: "CB",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: this.state.bank ? this.state.bank.loanName : loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"
          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formData, this.consentCallback);
  };
  consentCallback = (res) => {
    if (res) {
      this.setState({
        terms: true,
      });
    }
  };

  render() {

    return (
      <>
        <TopNavBar />
        <section className="bs-main-section AddharDetails">
          <Container>
            <Row>
              <Col xs={12} sm={3}>
                {" "}
                <LeftMenuDecider activeStep={4} />
              </Col>
              <Col xs={12} sm={9}>
                {this.state.loading ? <BackDropComponent /> : ""}
                <Card>
                  <Card.Header className="text-center">
                    <h5>Get Quick KYC</h5>
                  </Card.Header>

                  <Card.Body>
                    <div>
                      <img
                        src={AADHAR_PHOTO}
                        alt={"aadhar_photo"}
                        className="aadharPhoto"
                      />
                    </div>
                    <Form>
                      <div className="form-group">
                        <label htmlFor={"Enter Aadhaar Card No."}>
                          Enter Aadhaar Card No.
                          <span style={{ color: "#FF4C30" }}>*</span>
                        </label>
                        <input
                          className="form-control"
                          placeholder="xxxx xxxx xxxx"
                          value={this.state.aadhar}
                          onKeyPress={this.handleAadharInput}
                          onChange={this.handleAadharInput}
                          autoFocus={this.state.formFieldSelect === "aadhar"}
                        />
                      </div>
                      <div className="aadhar_check_box"> <div className="form-check">
                        <input

                          type="checkbox"
                          name="checkedG"
                          id="checkedG"
                          onChange={this.handleCheckBoxChange}
                          checked={this.state.terms}
                        />
                        <label
                          className="form-check-label"
                          htmlFor="checkedG"

                        >
                          By continuing, I authorize Credit Saison on wefin to fetch my Aadhaar XML record including KYC information through web.
                        </label>
                      </div></div>
                      <div className="col-sm-12">
                        <div className="agreeTxt"></div>
                      </div>
                      {this.state.showOTPField && (
                        <>
                          <div className="LoginFormFields aadharFormFields">
                            <div className="form-group text-center">
                              <input
                                type={"password"}
                                placeholder="******"
                                value={this.state.otp}
                                onChange={(e) => {
                                  if (reg.test(e.target.value) === true) {
                                    this.setState({ otp: e.target.value });

                                  }
                                }}
                                className="addharOtpField"
                                name="addharOtpField"
                                autoFocus={this.state.formFieldSelect === "otp"}
                                maxLength="6"
                              />
                            </div>
                          </div>
                          <Row>
                            <Col sm={12} className={"text-center"}>
                              <div className="bsAadharResendOtp">
                                {this.state.showCounter && (
                                  <>
                                    <p>
                                      {`We have sent you a 6 digit verification code on your registered mobile number.`}

                                    </p>
                                    <br />
                                    <h5>
                                      Resend OTP in 00:
                                      {this.state.otpSeconds.toString().length <
                                        2
                                        ? `0${this.state.otpSeconds}`
                                        : this.state.otpSeconds}{" "}
                                      secs
                                    </h5>
                                  </>
                                )}

                                {this.state.showResendOTPSection && (
                                  <>
                                    <button
                                      disabled={this.state.aadhar.length !== 14}
                                      type="submit"
                                      onClick={this.resendOTP}
                                      variant="contained"
                                      className="nextSmallButton"
                                    >
                                      Resend OTP
                                    </button>
                                  </>
                                )}
                              </div>
                            </Col>
                          </Row>
                        </>
                      )}

                      <Row>
                        <Col sm={12} className="text-center">
                          {this.state.showSubmitAadharButton && (

                            this.state.terms === true ? <button
                              disabled={this.state.aadhar.length !== 14}
                              type="submit"
                              onClick={this.submitAadhar}
                              variant="contained"
                              className="nextButton"

                            >
                              Next
                            </button> : <button
                              variant="contained"
                              className="nextButton"
                              disabled
                              style={{
                                opacity: "0.5",
                                cursor: "not-allowed",
                              }}
                            >
                              Next
                            </button>

                          )}
                          {this.state.showSubmitOTPButton && (

                            this.state.terms === true ? <button
                              type="submit"
                              onClick={this.submitOTP}
                              variant="contained"
                              className="nextButton"
                            >
                              Submit OTP
                            </button>
                              : <button
                                variant="contained"
                                className="nextButton"
                                disabled
                                style={{
                                  opacity: "0.5",
                                  cursor: "not-allowed",
                                }}
                              >
                                Submit OTP
                              </button>

                          )}
                        </Col>
                      </Row>
                    </Form>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </Container>
        </section>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  // kycStatus: getKycStatus(state).kycStatus,
});
const mapDispatchToProps = (dispatch) => ({
  setInitiateKyc: (params, callback) => dispatch(initiateKyc(params, callback)),
  setValidateKyc: (params, callback) => dispatch(validateKyc(params, callback)),
  setInitiateCreditKyc: (params, callback) =>
    dispatch(initiateCreditKyc(params, callback)),
  setValidateCreditKyc: (params, callback) =>
    dispatch(validateCreditKyc(params, callback)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),
});
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Aadhar));
