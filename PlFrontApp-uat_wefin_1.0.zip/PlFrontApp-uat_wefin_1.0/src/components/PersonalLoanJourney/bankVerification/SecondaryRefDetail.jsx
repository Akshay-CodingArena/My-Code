import React from "react";
import Joi from "joi-browser";
import Form from "../../common/form";
import SelectSearch from "../../common/select";
import { ReactComponent as AddressLine1Icon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as LandlineIcon } from "../../../include/assets/fullertonLogos/Group 20283.svg";
import { relation_to_applicant } from "../../common/dropdownValues";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getApplicant, setApplicantReference, setApplicantReferenceASM } from "../../../store/applicantDetail";
import { decryptStore } from "../../../Utils/store";
import Swal from "sweetalert2";
import PATH from "../../../paths/Paths";
import { loadLoanDetail } from "../../../store/applyLoan";
import PersonalInput from "../../common/personalInput";
import { ReactComponent as PersonIcon } from "../../../include/assets/Profile.svg";
import BackDropComponent from "../../../common/BackDropComponent";
import CONSTANTS from "../../../constants/Constants";
import { getAccount, getAccountInfo } from "../../../store/account";
import { getOffer } from "../../../store/bankOffer";
import Pincode from "../../common/pincode";
class SecondaryReference extends Form {
  state = {
    data: { pincode: null, add1: "", add2: "" },
    errors: {},
    bank: {},
    counter: 5,
    loading: false
  };
  schema = decryptStore(localStorage.getItem("mobilenumber")).loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
    {
      phone: Joi.number()
        .required()
        .label("Phone No.")
        .error(() => {
          return { message: "Phone No. must be a number." };
        }),
      fullName: Joi.string()
        .required()
        .label("Full Name")
        .error(() => {
          return { message: "Full Name field is required." };
        }),
      relation: Joi.object()
        .required()
        .label("Relation")
        .error(() => {
          return { message: "Relation field is required." };
        }),
      pincode: Joi.number()
        .required()
        .label("Pin Code")
        .error(() => {
          return { message: "Pincode field is required." };
        }),
      add1: Joi.string()
        .required()
        .label("Address Line 1")
        .error(() => {
          return { message: "Address Line 1 field is required." };
        }),
      add2: Joi.string()
        .required()
        .label("Address Line 2")
        .error(() => {
          return { message: "Address Line 2 field is required." };
        }),
    } : {
      phone: Joi.number()
        .required()
        .label("Phone No.")
        .error(() => {
          return { message: "Phone No. must be a number." };
        }),
      fullName: Joi.string()
        .required()
        .label("Full Name")
        .error(() => {
          return { message: "Full Name field is required." };
        }),
      relation: Joi.object()
        .required()
        .label("Relation")
        .error(() => {
          return { message: "Relation field is required." };
        }),
      add1: Joi.string()
        .allow(""),
      add2: Joi.string()
        .allow("")

    };

  componentDidMount = () => {
    window.scrollTo(0, 0);
    document.body.classList.add("NoScrool");
    document.body.classList.remove("variantScroll");
  };

  callBackGet = (res) => {
    if (res) {
      if (res.data.success) {
        if (res.data.breData[0]?.loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
          this.props.history.push({
            pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
            state: res.data,
          });
        } else if (res.data.breData[0]?.loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
          this.props.history.push({
            pathname: PATH.PRIVATE.HOME_LOAN_OFFERS,
            state: res.data,
          });
        }
      }
    }
  };

  callbackLoanDetail = (res) => {     // MONEY Plus
    const mobile = localStorage.getItem('mobilenumber')
    if (this.props.getAccountDetail[0].pl_loans.length === 1) {
      if (
        this.props.getAccountDetail[0].pl_loans[0].loanStage !==
        "Assigned" ||
        this.props.getAccountDetail[0].pl_loans[0].loanStage !==
        "Soft Approved" ||
        this.props.getAccountDetail[0].pl_loans[0].loanStage !== "Declined"
      ) {
        if (
          this.props.getAccountDetail[0].pl_loans[0].loanStage === "Offers"
        ) {
          let formData =
            "mobile=" +
            mobile +
            "&loanId=" +
            this.props.getAccountDetail[0].pl_loans[0].loanId +
            "&loanType=" +
            this.props.getAccountDetail[0].pl_loans[0].loanType;

          this.props.getOffer(formData, this.callBackGet);
        } else if (
          this.props.getAccountDetail[0].pl_loans[0].loanStage ===
          "Mobile Registered" ||
          this.props.getAccountDetail[0].pl_loans[0].loanStage ===
          "customer details" ||
          this.props.getAccountDetail[0].pl_loans[0].loanStage ===
          "Basic Loan Details" ||
          this.props.getAccountDetail[0].pl_loans[0].loanStage === "Captured"
        ) {
          if (this.props.customerDetail.pan_verified__c === true) {
            this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
          } else {
            this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
          }
        }
      }
    } else {
      this.props.history.push(
        `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`
      );
    }
  }

  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    if (e.target.value && !/^[0-9]+$/.test(e.target.value)) {
      if (e.target.value.length === 6) {
        const errors = { ...this.state.errors };
        errors.pincode = "Pincode must be number";
        this.setState({ errors });
      } else {
        const errors = { ...this.state.errors };
        errors.pincode = "";
        this.setState({ errors });
      }
    } else {
      if (e.target.value.length === 6) {
        const data = { ...this.state.data };
        const errors = { ...this.state.errors };
        data.pincode = e.target.value;
        errors.pincode = "";
        this.setState({ data, errors, loading: true });
        let formData = { mobile: mobile, pincode: e.target.value };
        this.props.loadPinCode(formData, this.callbackPin);
      }
    }
  };
  callbackPin = (res) => {
    if (res) {
      this.setState({ loading: false })
      let errors = { ...this.state.errors };
      if (res.data?.success === false) {
        errors.pincode = res.data.message;
        this.setState({ errors });
      } else if (res.data?.success === true) {
        const errors = { ...this.state.errors };
        const data = { ...this.state.data };
        // data.city = res.data.data.cityname;
        // data.state = res.data.data.statename;
        errors.pincode = "";

        this.setState({
          data,
          errors,
          pinSfid: res.data.data.sfid,
          stateSfid: res.data.data.state__c,
          citySfid: res.data.data.city__c,
          cityname: res.data.data.cityname,
          statename: res.data.data.statename
        });
      }
    }
  };

  doSubmit = () => {
    let errors = { ...this.state.errors };
    if (this.props.pLData.name.toLowerCase() === this.state.data.fullName.toLowerCase()) {
      errors.fullName = "Primary and Secondary Reference Full Name must be different.";
      this.setState({ errors });
      return;
    }
    else if (this.props.pLData.phone === this.state.data.phone) {
      errors.phone = "Primary and Secondary Reference Phone Number must be different.";
      this.setState({ errors });
      return;
    }
    else {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loansfid, loanType, loanId } = decryptedData;

      let formData = {
        pRefName: this.props.pLData.name,
        pRefMobile: this.props.pLData.phone,
        pRefRelation: this.props.pLData.relation.value,
        pRefAddressL1: this.props.pLData.add1,
        pRefAddressL2: this.props.pLData.add2,
        pRefPin: this.props.pLData.pincode,
        sRefPin: this.state.data.pincode,
        pRefCity: this.props.pLData.pRefCity,
        pRefState: this.props.pLData.pRefState,
        sRefName: this.state.data.fullName,
        sRefMobile: this.state.data.phone,
        sRefRelation: this.state.data.relation.value,
        sRefCity: this.state.cityname,
        sRefAddressL1: this.state.data.add1,
        sRefAddressL2: this.state.data.add2,
        sRefState: this.state.statename,
        mobile: mobile,
        type: "reference",
        loanId: this.props.location.state
          ? this.props.location.state.loanId
          : loansfid
            ? loansfid
            : localStorage.getItem("loansfid"),
      };
      if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && decryptedData.manufacturer === "REVOLT") {
        formData.loanId = formData.loanId ? formData.loanId : loanId;
        this.props.setApplicantReferenceASM(formData, this.setApplicantReferenceASMCallback)
      } else {
        this.props.setApplicantReference(formData, this.setAppRefCallBack);
      }
    }
  };

  setApplicantReferenceASMCallback = (res) => {
    if (res.data.success) {
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      this.props.history.push(
        {
          pathname: PATH.PRIVATE.VERIFY_BANK_DETAILS + "/" + CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN + "/" + decryptedData.lender,
          state: { bike: this.props.location.state.bike }
        }
      );
    }
    else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res?.data?.message ? res?.data?.message : "Some Error Occurred...",
        showConfirmButton: false,
        timer: 1800,
      });
    }
  }



  getLoadCallback = async (res) => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType, lenderName, bank } = decryptedData;
      let r = await res;

      this.setState((p) => ({ ...p, counter: p.counter - 1 }));
      if (r.data.success) {
        if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "daas1 initiated"
        ) {
          this.setState({ loading: false })
          Swal.fire({
            position: "center",
            icon: "info",
            title:
              "It is taking longer than usual… requesting your kind patience.",
            showConfirmButton: true,
          }).then((res) => {
            if (res.isConfirmed) {
              this.props.history.push(PATH.PRIVATE.PRODUCTS);
            }
          });
        } else if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "declined"
        ) {
          this.props.setLoading(false);
          this.props.history.push(PATH.PRIVATE.LOAN_APP_FAILED);
        } else if (
          r.data.getLoanDetails[0].loanDetails.loanStage.toLowerCase() ===
          "hard approved"
        ) {
          this.props.setLoading(false);
          this.props.history.push({
            pathname: `${PATH.PRIVATE.EMANDATE_DETAILS}/${loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName ? this.state.bank.lenderName.split(/\s/).join("-") : lenderName
                .split(/\s/).join("-")
              }`,
            state: this.state.bank ? this.state.bank : bank,
          });
        } else {
          setTimeout(() => {
            this.callGetLoanDetails();
          }, 20000);
        }
      } else {
        throw new Error(r);
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  callGetLoanDetails = () => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let { loanType, loansfid, bank } = decryptStore(mobile);
      let getBankData = {
        loanId: bank?.loanId
          ? bank.loanId
          : this.props.location.state
            ? this.props.location.state?.loanId
            : this.state.bank?.loanId
              ? this.state.bank?.loanId
              : loansfid
                ? loansfid
                : localStorage.getItem("loansfid"),
        loanType: loanType,

      };
      if (this.state.counter > 0) {
        this.setState({ loading: true });
        this.props.getLoadLoanDetail(getBankData, this.getLoadCallback);
      } else {
        this.setState({ loading: false });
        Swal.fire({
          position: "center",
          icon: "error",
          title: "It is taking longer than usual… requesting your kind patience",
          showConfirmButton: true,
        }).then((res) => {
          if (res.isConfirmed) {
            this.props.history.push(PATH.PRIVATE.PRODUCTS);
          }
        });
      }
    } catch (e) {
      this.setState({ loading: false });
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  setAppRefCallBack = async (res) => {
    try {
      let r = await res;
      this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));
      if (r.data.success && r.data.status === 200) {
        this.setState({ loading: false })
        this.callGetLoanDetails();
      } else {
        throw new Error(r.data.description);
      }
    } catch (e) {
      this.setState({ loading: false })
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      });

    }
  };

  __handleNameChange = (e) => {
    let letters = /^[A-Za-z\s]+$/;
    if (e.target.value !== "" && e.target.value.match(letters)) {
      this.setState((p) => ({
        ...p,
        data: { ...p.data, fullName: e.target.value },
        errors: { ...p.errors, fullName: "" },
      }));
    } else {
      this.setState((p) => ({
        ...p,
        data: { ...p.data, fullName: "" },
        errors: {
          ...p.errors,
          fullName: "Only alphabets are allowed the in Name Field",
        },
      }));
    }
  };

  render() {
    return (
      <div className="row">
        {this.state.loading || this.props.loadingrAsmReference || this.props.loadingReference ? <BackDropComponent /> : ""}

        <div className="col-sm-6">
          {" "}
          <PersonalInput
            value={this.state.data.fullName}
            __handleChange={this.__handleNameChange}
            error={this.state.errors.fullName}
            icon={<PersonIcon />}
            label="Full Name"
            readOnly={false}
          />
        </div>

        <div className="col-sm-6">
          <SelectSearch
            placeholderValue={"Relation"}
            label={"Relation"}
            value={this.state.data.relation}
            setSelectedOption={(e) => {
              const data = { ...this.state.data };
              const errors = { ...this.state.errors };
              if (e) {
                data.relation = e;
                errors.relation = "";
                this.setState({ data, errors });
              }
            }}
            dropDownOptions={relation_to_applicant}
            error={this.state.errors.relation}
            icon={
              <AddressLine1Icon
                style={{
                  marginRight: "5px",
                  marginTop: "3px",
                }}
              />
            }
          ></SelectSearch>
        </div>
        <div className="col-sm-6">
          {this.renderInput(
            "phone",
            "Phone Number",
            <LandlineIcon />,
            false,
            10,
            10
          )}
        </div>
        {decryptStore(localStorage.getItem("mobilenumber")).loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
          <div className="col-sm-6">
            {" "}
            {this.renderInput("add1", "Address Line 1", <AddressLine1Icon />)}
          </div> : null}
        {decryptStore(localStorage.getItem("mobilenumber")).loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
          <div className="col-sm-6">
            {this.renderInput("add2", "Address Line 2", <AddressLine1Icon />)}
          </div> : null}
        <div className="col-sm-6">
          <Pincode
            value={this.state.data.pincode}
            __handlePinCode={this.__handlePinCode}
            error={this.state.errors.pincode}
          />
        </div>
        <div className="col-sm-12 text-center">
          <button
            type="submit"
            onClick={this.handleSubmit}
            variant="contained"
            className="nextButton"
          >
            Next
          </button>
        </div>
      </div >
    );
  }
}

const mapStateToProps = (state) => ({
  getAccountDetail: getAccount(state).getAccountDetail,
  getpinCode: getpinCode(state),
  customerDetail: getAccount(state).customerDetail,
  loadingrAsmReference: getApplicant(state).loadingrAsmReference,
  loadingReference: getApplicant(state).loading

});
const mapDispatchToProps = (dispatch) => ({
  getOffer: (params, callback) => dispatch(getOffer(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  setApplicantReference: (params, callback) =>
    dispatch(setApplicantReference(params, callback)),
  getLoadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  setApplicantReferenceASM: (params, callBack) =>
    dispatch(setApplicantReferenceASM(params, callBack)),
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback))
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SecondaryReference)
);

