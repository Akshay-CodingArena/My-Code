import React from "react";
import { useLocation } from "react-router";
import { numberFormat } from "../../../Utils/numberFormat";
import { decryptStore } from "../../../Utils/store";
import Card from "react-bootstrap/Card";
import CONSTANTS from "../../../constants/Constants";
function getSteps() {
  let mobile = localStorage.getItem("mobilenumber");
  let decryptedData = decryptStore(mobile);
  let { loanType, manufacturer } = decryptedData;
  switch (loanType) {
    case CONSTANTS.LOAN_TYPE.PERSONAL_LOAN:
      if (decryptedData.lenderName === "HDFC") {
        return ["Getting Started", "Eligibility", "Additional Information", "Reference Details", "Upload Documents", "Loan Status"];
      }
      else if (decryptedData.lenderName === "Pay Sense") {
        return ["Getting Started", "Eligibility", "Additional Information", "Loan Status"];
      }
      return ["Getting Started", "Eligibility", "Additional Information", "KYC", "E-mandate and Agreement", "Disbursed"];

    case CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN:
      if (manufacturer === "REVOLT")
        return ["Bike Selection", "Offers & Eligibility", "KYC", "Additional Information", "E-mandate and Agreement", "Disbursal"]

      return ["Getting Started", "Offers", "Approval", "KYC", "Disbursed"];

    case CONSTANTS.LOAN_TYPE.HOME_LOAN:
      return ["Getting Started", "Offers", "Additional Information", "Submit"];

    default: return ["Select Card", "Getting Started", `Offers`, "Approval", "Dispatch"]
  }

}
// function getStepContent(step) {
//   switch (step) {
//     case 0:
//       return ``;
//     case 1:
//       return "";
//     case 2:
//       return ``;
//     case 3:
//       return ``;
//     case 4:
//       return ``;
//     case 5:
//       return ``;
//     case 6:
//       return ``;
//     default:
//       return "Unknown step";
//   }
// }

export default function StepperComponent({ activeStep, stepperData, state }) {

  // const steppers = state?.bike?.manufacturer__c === "REVOLT" ? ["Bike Selection", "Eligibility", "Additional Information", "KYC", "E-mandate and Agreement"] : getSteps();
  const steppers = getSteps();
  console.log("props", state)
  let location = useLocation();
  //console.log(location);
  let S3_URL = process.env.REACT_APP_S3_URL;
  let mobile = localStorage.getItem("mobilenumber");
  let decryptedData = decryptStore(mobile);
  //console.log("decrypted data is", decryptedData)
  let { bank, loanType } = decryptedData;
  let bankStepper = location.state && location.state.lenderName ? location.state : bank;


  ///////////////////////PAYSENSE//////////////
  if (Object.keys(stepperData ? stepperData : {}).length) {
    bankStepper = stepperData;
  }
  /////////////PAYSENSE END////////////////
  if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
    bankStepper = false
  }


  ///////////////////for hdfc flow/////////////////////
  if (loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && Object.keys(location.state?.appliedLoanInfo ? { ...location.state?.appliedLoanInfo } : {}).length) {
    bankStepper = { ...location.state.appliedLoanInfo }
  }
  ////////////////end for hdfc flow//////////////////
  let loanAmount = "";
  if (bankStepper?.appliedLoanAmount && bankStepper?.loanStage?.toLowerCase() !== "hard approved" && bankStepper?.loanStage?.toLowerCase() !==
    "set consent") {
    loanAmount = numberFormat(bankStepper.appliedLoanAmount);
  }
  else if (bankStepper?.pl_applied_loan_amount__c && bankStepper?.loanStage?.toLowerCase() !== "set consent" && bankStepper?.loanStage?.toLowerCase() !== "hard approved") {
    loanAmount = numberFormat(bankStepper.pl_applied_loan_amount__c);

  }

  else if (
    bankStepper &&
    bankStepper.pl_revised_loan_amount__c &&
    bankStepper.loanStage &&
    bankStepper.loanStage.toLowerCase() === "hard approved" &&
    bankStepper.lenderName &&
    bankStepper.lenderName.toLowerCase() === "credit saison"
  ) {

    loanAmount = numberFormat(bankStepper.pl_revised_loan_amount__c);
  }
  else if (

    bankStepper &&
    bankStepper.loanStage &&
    bankStepper.loanStage.toLowerCase() === "set consent" &&
    bankStepper.lenderName &&
    bankStepper.lenderName.toLowerCase() === "credit saison"
  ) {
    loanAmount = numberFormat(bankStepper.pl_revised_loan_amount__c);
  }
  else if (bankStepper && bankStepper.appliedLoanAmount) {
    loanAmount = numberFormat(bankStepper.appliedLoanAmount);

  }


  let tenture = "";
  if (bankStepper?.appliedTenure && bankStepper?.loanStage?.toLowerCase() !== "hard approved" && bankStepper?.loanStage?.toLowerCase() !==
    "set consent") {
    tenture = bankStepper.appliedTenure;
  }
  else if (bankStepper?.pl_applied_tenure__c && bankStepper?.loanStage?.toLowerCase() !== "set consent" && bankStepper?.loanStage?.toLowerCase() !== "hard approved") {
    tenture = bankStepper.pl_applied_tenure__c;
  }

  else if (
    bankStepper &&
    bankStepper.pl_revised_tenure__c &&
    bankStepper.loanStage &&
    bankStepper.loanStage.toLowerCase() === "hard approved" &&
    bankStepper.lenderName &&
    bankStepper.lenderName.toLowerCase() === "credit saison"

  ) {
    tenture = bankStepper.pl_revised_tenure__c;
  }
  else if (
    bankStepper &&
    bankStepper.pl_revised_tenure__c &&
    bankStepper.loanStage &&
    bankStepper.loanStage.toLowerCase() === "set consent" &&
    bankStepper.lenderName &&
    bankStepper.lenderName.toLowerCase() === "credit saison"
  ) {
    tenture = bankStepper.pl_revised_tenure__c;
  }
  else if (bankStepper && bankStepper.appliedTenure) {
    tenture = bankStepper.appliedTenure
  }
  else if (bankStepper && bankStepper.max_tenure) {
    tenture = bankStepper.max_tenure
  }
  if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
    tenture += " Years";
  } else {
    tenture += " Months";
  }
  return (
    <div className="bsStpperAside">
      {location.state && ((location.state.card) && false) ? (
        <Card className="cs-card-box">
          <Card.Text>
            <img src={location.state.card.card_image__c} alt="" />
            <h3>{location.state.card.card_name__c}</h3>

            <div className="cs-key-card-benifits">
              Key Card Benefits
              <ul className="keyBenefits">
                {location.state.card.cardBenefits.map((e, i) => (
                  <>{i < 2 && <li>{e}</li>}</>
                ))}
              </ul>
            </div>

            <div className="cs-joining-details">
              Joining and Annual Fee
              <ul className="keyBenefits">
                {location.state.card.joinFee.map((e, i) => (
                  <>{i < 2 && <li>{e}</li>}</>
                ))}
              </ul>
            </div>
          </Card.Text>
        </Card>
      ) : (
        <>
          <div className="bs-steppers">
            {steppers.map((label, index) => (
              <div
                className={
                  activeStep >= index + 1 ? "step step-active" : "step"
                }
              >
                <div>
                  <div className="circle">{index + 1}</div>
                </div>
                <div>
                  <div className="title">{label}</div>
                </div>
              </div>
            ))}
          </div>

          <div>
            {bankStepper && bankStepper ? (
              <Card className="loanStapperBox">
                <Card.Text>
                  <ul>
                    <li>
                      {bankStepper.bankImage ? (
                        <img
                          src={bankStepper.bankImage}
                          alt=""
                          style={{ width: "100px" }}
                        />
                      ) : (
                        <img
                          src="/bankLogos/default.svg"
                          alt=""
                          style={{ width: "60px" }}
                        />
                      )}{" "}
                    </li>
                    <li>
                      <h4>Your EMI</h4>
                      <p className="color-blue">
                        {" "}
                        {numberFormat(bankStepper.pl_revised_emi__c ? bankStepper.pl_revised_emi__c : bankStepper.emi)}
                      </p>
                    </li>
                  </ul>
                  <hr />
                  <ul>
                    <li>
                      <h4>Interest Rate</h4>
                      <p>
                        {" "}
                        {bankStepper.pl_approved_interest_rate__c ? bankStepper.pl_approved_interest_rate__c + " %*" : bankStepper.IRR ? bankStepper.IRR + " %*" : bankStepper.pl_roi__c + " %*"}

                      </p>
                    </li>
                    <li>
                      <h4>Loan Amount</h4>
                      <p>
                        {" "}
                        {loanAmount}

                      </p>
                    </li>
                  </ul>
                  <hr />
                  <ul>
                    <li>
                      <h4>Loan Tenure</h4>
                      <p>{tenture}</p>
                    </li>
                    <li>
                      <h4>Processing Fee</h4>
                      <p> {bankStepper.Processing_Fee
                        ? numberFormat(bankStepper.Processing_Fee
                        ) : bankStepper.PF.toString().length > 2 ? numberFormat(bankStepper.PF) : bankStepper.PF + "%"}</p>
                    </li>
                  </ul>
                </Card.Text>
              </Card>
            ) : (
              ""
            )}
            {location.state && location.state.bike ? (
              <Card className="loanStapperBox bikeBox">
                <Card.Text>
                  <h4>
                    {location.state.bike.manufacturer__c}{" "}
                    {location.state.bike.product__c}
                  </h4>
                  <hr />
                  <div>
                    <img
                      src={`${S3_URL}${location.state.bike.product_sku__c}.jpg`}
                      alt=""
                    />
                  </div>
                  <hr />
                  <p>{location.state.bike.product__c === "RV400" ? numberFormat(location.state.bike.onRoadPrice) : numberFormat(parseInt(location.state.bike.bikeshowroomprice) + parseInt(location.state.bike.chargerPrice))} {location.state.bike.manufacturer__c === "REVOLT" ? "" : "onwards"}</p>
                </Card.Text>
              </Card>
            ) : (
              ""
            )}
          </div>
        </>
      )}
    </div>
  );
}
