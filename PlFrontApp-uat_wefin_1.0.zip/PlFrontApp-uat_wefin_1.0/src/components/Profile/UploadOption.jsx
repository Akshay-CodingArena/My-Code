import { Component } from "react"
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Swal from "sweetalert2";
import Form from "../../components/common/form";
import { getAccount, setProfilePhoto, updatePhoto } from "../../store/account";
import SelfieUpload from "./selfieUploadNew";

class UploadOption extends Component {
    constructor(props) {
        super(props)
        this.state = {}
    }

    callBackStatus = (res) => {
        this.setState({ ...this.state, isLoading: false })
        if (res.data.success) {
            this.props.updatePhoto(res.data.Location)
            this.props.handleClose(res.data.Location)
            Swal.fire({
                position: "center",
                icon: "success",
                title: "Profile Photo updated Successfully",
                showConfirmButton: true,
                timer: 1800,
            });
            // this.setState({ ...this.state, readOnly: true })
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Error while updating",
                showConfirmButton: true,
                timer: 1800,
            });
        }
    }

    handleImage = (files) => {
        const formData = new FormData()
        formData.append("file", files[0])
        formData.append("mobile", localStorage.getItem('mobilenumber'))
        formData.append("account_id", this.props.getCustomerDetail?.sfid)
        this.props.setProfilePhoto(formData, this.callBackStatus)
    }

    handleSelfie = () => {
        this.setState({ ...this.state, openWebcam: true })
    }

    render() {
        return (
            <div className="uploadOptionsContainer">
                {this.state?.openWebcam ? <SelfieUpload handleClose={this.props.handleClose} /> : <div className="uploadOptions">
                    <input id="profilePic" name="profilePic" style={{ display: 'none' }} accept="image/png, image/jpeg" type="file" onChange={(e) => this.handleImage(e.target.files)} />
                    <label className="uploadButton" htmlFor="profilePic">Upload</label>
                    <div onClick={this.handleSelfie} className="uploadButton">Take a photo</div>
                </div>}
            </div>
        )
    }

}

const mapStateToProps = (state) => ({
    getCustomerDetail: getAccount(state).customerDetail,
    // getpanName: getpanName(state),
    // getpinCode: getpinCode(state),
    // pinLoading: getpinCode(state).loading,
    // panLoading: getpanName(state).loading,
    // isLoading: getAccount(state).loading,
    // getAccountDetail: getAccount(state).getAccountDetail,
    // getCustomerDetail: getAccount(state).customerDetail
})
const mapDispatchToProps = (dispatch) => ({
    setProfilePhoto: (params, callbackDetail) =>
        dispatch(setProfilePhoto(params, callbackDetail)),
    updatePhoto: (url) => {
        dispatch(updatePhoto(url))
    }
})

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(UploadOption))