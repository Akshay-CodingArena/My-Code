import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import Swal from "sweetalert2";
import { decryptStore } from "../../Utils/store";
import { getUpload, uploadPic } from "../../store/upload";
import Form from "../common/form";
import WebcamCapture from "./webcamCaptureNew";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import BackDropComponent from "../../common/BackDropComponent";
import PATH from "../../paths/Paths";
import { loadConsents } from "../../store/consent";
import { getOS } from "../../Utils/device_function";
import closeIcon from "./../../include/assets/icons/closeIcon.svg";
import { getAccount, getAccountInfo, setProfilePhoto, updatePhoto } from "../../store/account";
import CONSTANTS from "../../constants/Constants";
import { JourneyContinueMoneyplus } from "../TwoWheelerJourney/Revolt/loanStages";
import { uploadAadhaarSelfie } from "../../store/kyc";

class SelfieUpload extends Form {
    constructor(props) {
        super(props);
        this.state = {
            selectedImg: null,
            selectedImgBase64: null,
            loading: false,
            geoLocation: {},
            terms: false,
        };
    }

    componentWillMount = () => {
        //      this.setState({ loading: true });
    };

    componentDidMount = () => {
        this.setState({ loading: false });
        this.setPageLayout();
        this.getGeoLocation();
    };

    setPageLayout = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
    };

    getCurrentPosition() {
        return new Promise((res, rej) => {
            navigator.geolocation.getCurrentPosition(res, rej);
        });
    }

    getGeoLocation = async () => {
        try {
            let cord = await this.getCurrentPosition();
            cord && this.setState({ geoLocation: cord });
        } catch (e) {
        }
    };

    doSubmit = async () => {

        let mobile = localStorage.getItem("mobilenumber");
        let formData = new FormData();
        formData.append("mobile", localStorage.getItem('mobilenumber'))
        formData.append("account_id", this.props.getCustomerDetail?.sfid)
        formData.append("file", this.state.selectedImg);
        this.setState({ loading: true });
        this.props.setProfilePhoto(formData, this.callBackPic)
    };



    callBackPic = (res) => {
        console.log("response is", res)
        if (res?.data?.success) {
            // this.props.changePhoto(res.data.Location)
            this.props.updatePhoto(res.data.Location)
            this.props.handleClose(res.data.Location)

            // this.setState({ ...this.state, readOnly: true })
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Error while uploading",
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };

    render() {
        return (
            <>
                {" "}

                <div className="photoUploadSection"> <div className="profilePicUpload">
                    <Card>
                        {this.state.loading ? <BackDropComponent /> : ""}
                        <Card.Header className="text-center header">
                            {/* <script
                      type="text/javascript"
                      src="https://app.digio.in/sdk/v9/digio.js"
                    ></script> */}
                            <h2>Upload your photo</h2>

                        </Card.Header>
                        <Card.Body>
                            <div>
                                <WebcamCapture key={"Capture" + Math.random()}
                                    recievedBlobFile={(file, image) =>
                                        this.setState({ selectedImg: file, previewImage: image })
                                    }
                                    previewImage={this.state?.previewImage}
                                    recieveFileType={""}

                                />
                            </div>
                            {this.state.selectedImg ? (
                                <>
                                    <div className="uploadBtn">
                                        <button
                                            type="submit"
                                            onClick={this.doSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Next
                                        </button>
                                    </div>


                                </>
                            ) : (
                                ""
                            )}
                        </Card.Body>
                    </Card>
                </div></div>


            </>
        );
    }
}


const mapStateToProps = (state) => ({
    getCustomerDetail: getAccount(state).customerDetail,
});
const mapDispatchToProps = (dispatch) => ({
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    setProfilePhoto: (params, callbackDetail) =>
        dispatch(setProfilePhoto(params, callbackDetail)),
    updatePhoto: (url) => {
        dispatch(updatePhoto(url))
    }

});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(SelfieUpload)
);