import { Component } from 'react'
import TopNavBar from '../../common/TopNavBar'
import PersonalInput from '../common/personalInput'
import { ReactComponent as PersonIcon } from "../../include/assets/Profile.svg";
import { ReactComponent as LocalPhoneIcon } from "../../include/assets/phoneIcon.svg";
import { ReactComponent as EmailIcon } from "../../include/assets/emailIcon.svg";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/panIcon.svg";
import { ReactComponent as IncomeIcon } from "../../include/assets/homepageIcons/monthly-icon.svg"
import { Col, Row, Container, Modal } from 'react-bootstrap';
import DateComponent from "../../components/common/date";
import Form from "../../components/common/form";
import { ReactComponent as AddressLine1Icon } from "../../include/assets/fullertonLogos/Group 16992.svg";
import { ReactComponent as LocationIcon } from "../../include/assets/fullertonLogos/Places.svg";
import EditIcon from "../../include/assets/photoEdit.svg"
import Pincode from "../common/pincode";
import EditIconProfile from "../../include/assets/icons/editIcon.svg";
import Joi from "joi-browser";
import { getAccount, getAccountInfo, setProfileInfo, setProfilePhoto, updatePhoto } from "../../store/account";
import { withRouter } from "react-router";
import { connect } from 'react-redux';
import { getpanName, loadPanName } from '../../store/panName';
import { getpinCode, loadPinCode } from '../../store/pincode';
import { ReactComponent as DocExpiry } from "../../include/assets/homepageIcons/icon-dob.svg";
import Moment from "moment";
import { capitalizeFirstLetter } from "../../common/helperCells";
import CONSTANTS from "../../constants/Constants";
import {
    loadCheckDedupe,
} from "../../store/panName";
import Swal from 'sweetalert2';
import BackDropComponent from '../../common/BackDropComponent';
import SelectSearch from '../common/select';
import { ReactComponent as Marriage } from "../../include/assets/personalLoan/marriage.svg";
import {
    myprofile_marital_status,
} from "../common/fullerTonDropdown";
import CreditFooter from "../cibilFlow/footer";
import UploadOption from "./UploadOption"
import ProfilePhoto from './ProfilePhoto';
import SelfieUpload from './selfieUploadNew';
import { numberFormat } from '../../Utils/numberFormat';
import ValidateAge from '../../common/ValidateAge';
class MyProfile extends Form {
    constructor(props) {
        super(props)
        this.state = {
            data: {},
            errors: {},
            readOnly: true,
            fileImg: false,
            checked: false,
            isLoading: false
        }
    }

    schema = {
        cadd1: Joi.string()
            .required()
            .label("Address Line 1 ")
            .error(() => {
                return { message: "Address Line 1 field is required." };
            }),
        cadd2: Joi.string()
            .required()
            .label("Address Line 2")
            .error(() => {
                return { message: "Address Line 2 field is required." };
            }),
        ccity: Joi.string().label("City"),
        cstate: Joi.string().label("State"),
        padd1: Joi.string()
            .required()
            .label("Address Line 1 ")
            .error(() => {
                return { message: "Address Line 1 field is required." };
            }),
        padd2: Joi.string()
            .required()
            .label("Address Line 2")
            .error(() => {
                return { message: "Address Line 2 field is required." };
            }),
        pcity: Joi.string().label("City"),
        pstate: Joi.string().label("State"),
        fullName: Joi.string()
            .error(() => {
                return { message: "Full Name field is required." };
            }),
        panNumber: Joi.string()
            .min(10)
            .max(10)
            .required()
            .label("PAN Number")
            .error(() => {
                return { message: "PAN Number field is required." };
            }),

        personemail: Joi.string()
            .email()
            .max(50)
            .required()
            .label("Email")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "any.empty":
                            err.message = "Email field is required";
                            break;

                        case "string.email":
                            err.message = "Email field is invalid";
                            break;
                        case "string.max":
                            err.message = "Email field is invalid";
                            break;
                        default:
                            err.message = "Email field is invalid";
                    }
                });
                return errors;
            }),
        maritalStatus: Joi.object()
            .required()
            .label("Marital Status")
            .error(() => {
                return { message: "Marital Status field is required." };
            }),
        ppincode: Joi.number().min(6).required().label("Pincode").error(() => {
            return { message: "Pincode field is required." };
        }),
        cpincode: Joi.number().min(6).required().label("Pincode").error((err) => {
            console.log("error of pincode is ", err, "type", err.type)
            return { message: "Pincode field is required." };
        }),
        monthlysalary: Joi.number().min(4).label("Monthly Salary").required().error(() => {
            return { message: "Monthly Salary field is required." }
        }),
        pl_mobile_no__c: Joi.string(),
        dob: Joi.string()
            .required()
            .label("Date of Birth")
            .error((err) => {
                return { message: "Date of Birth field is required." };
            }),
        gender: Joi.string().label("Gender").required().min(3).error((err) => {
            return { message: "Gender field is required" }
        }),
    };

    // AgeValidate = () => {
    //     var date = new Date(Date.now());
    //     var year = parseInt(date.getFullYear())
    //     var month = parseInt(date.getMonth()) + 1
    //     var day = parseInt(date.getDate())
    //     var dob = this.dateFormatter(this.state.data.dob)
    //     console.log("Validations", parseInt(dob.slice(0, 2)), parseInt(dob.slice(6)), parseInt(dob.slice(3, 5)))
    //     // if (!parseInt(dob.slice(0, 2)) || !parseInt(dob.slice(6)) || !parseInt(dob.slice(3, 5))) {
    //     //     this.setState({ ...this.state, errors: { dob: "Invalid DOB" } })
    //     //     return false
    //     // }
    //     if (parseInt(dob.slice(6)) >= year - 13) {
    //         console.log("year gap", parseInt(dob.slice(6)), year)
    //         console.log("month", parseInt(dob.slice(3, 5)), month)
    //         console.log("day", parseInt(dob.slice(0, 2)), day)

    //         if (parseInt(dob.slice(6, 10)) == year - 13 && parseInt(dob.slice(3, 5)) - month <= 0) {
    //             console.log("year gap", year - 13, parseInt(dob.slice(3, 5)))
    //             console.log("month", parseInt(dob.slice(3, 5)) - month)
    //             if (parseInt(dob.slice(3, 5)) - month === 0 && (parseInt(dob.slice(0, 2)) - day) <= 0) {
    //                 return true
    //             } else {
    //                 return false
    //             }
    //             return false

    //         }
    //         return false
    //     } else {
    //         if (parseInt(dob.slice(6)) - year < 100) {
    //             return true
    //         }
    //         else {
    //             return false
    //         }
    //     }

    // }


    doSubmit = (e) => {
        console.log("form is submititng")
        e.preventDefault()
    }
    callBackCPin = (res) => {
        if (res?.data) {
            console.log("data is", res.data.data)
            let data = res.data.data
            // addline1: this.state.data.padd1,
            // addline2: this.state.data.padd2,
            // pinCodeSfid: this.state.data.pinCodeSfid,
            // stateSfid: this.state.data.stateSfid,
            // citySfid: this.state.data.citySfid,
            console.log("city is", data.cityname)
            if (data.cityname) {
                this.setState({
                    ...this.state, data: {
                        ...this.state.data, ccity: data.cityname, cstate: data.statename, ccitySfid: data.city__c, cstateSfid: data.state__c, cpinCodeSfid: data.sfid,
                    }, errors: { ...this.state.errors, cpincode: "" }
                })
            }
            else {
                this.setState({ ...this.state, data: { ...this.state.data, ccity: "", cstate: "" }, errors: { ...this.state.errors, cpincode: "Please check the pincode" } })
            }
        }
    }

    callBackPPin = (res) => {
        if (res?.data) {
            console.log(res.data.data)
            let data = res.data.data
            // addline1: this.state.data.padd1,
            // addline2: this.state.data.padd2,
            // pinCodeSfid: this.state.data.pinCodeSfid,
            // stateSfid: this.state.data.stateSfid,
            // citySfid: this.state.data.citySfid,
            if (data.cityname) {
                this.setState({
                    ...this.state, data: {
                        ...this.state.data, pcity: data.cityname, pstate: data.statename, pcitySfid: data.city__c, pstateSfid: data.state__c, ppinCodeSfid: data.sfid
                    }, errors: { ...this.state.errors, ppincode: "" }
                })
            } else {
                this.setState({ ...this.state, data: { ...this.state.data, pcity: "", pstate: "" }, errors: { ...this.state.errors, ppincode: "Please check the pincode" } })
            }
        }
    }

    __handlePinCode = (e, pin) => {
        console.log("this pin  is", pin)
        e.preventDefault();
        let mobile = localStorage.getItem("mobilenumber");
        if (pin === "current") {
            if (e.target.value.length === 6) {
                const data = { ...this.state.data };
                data.cpincode = e.target.value;
                this.setState({ data });
                let formData = { mobile: mobile, pincode: e.target.value };
                this.props.loadPinCode(formData, this.callBackCPin);
            } else {
                if (e.target.value.length === 0) {
                    this.setState({ ...this.state, data: { ...this.state.data, cpincode: e.target.value, ccity: "", cstate: "" } })
                }
            }
        } else {
            if (e.target.value.length === 6) {
                const data = { ...this.state.data };
                data.ppincode = e.target.value;
                this.setState({ data });
                let formData = { mobile: mobile, pincode: e.target.value };
                this.props.loadPinCode(formData, this.callBackPPin);
            } else {
                if (e.target.value.length === 0) {
                    this.setState({ ...this.state, data: { ...this.state.data, ppincode: e.target.value, pcity: "", pstate: "" } })
                }
            }
        };
    }


    callBackStatusDetails = (res) => {
        if (res.data.success) {
            Swal.fire({
                position: "center",
                icon: "success",
                title: "Profile Details Updated Successfully",
                showConfirmButton: true,
                timer: 1800,
            });
            localStorage.setItem("email", this.state.data.personemail)
            this.setState({ ...this.state, isLoading: false, readOnly: true })
            this.props.getAccountInfo({ mobile: localStorage.getItem("mobilenumber") });
        } else {
            if (res.data.errorDetails.includes("Email")) {
                this.setState({ ...this.state, isLoading: false, errors: { personemail: "Invalid email address" } })
            }
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Error while updating",
                showConfirmButton: true,
                timer: 1800,
            });
        }
    }

    filterErrors = (errors) => {
        console.log(errors)
        let formFields = ["personemail", "padd1", "padd2", "cadd1", "cadd2", "gender", "maritalStatus", "monthlysalary", "dob", "panNumber", "cpincode", "ppincode"]
        let obj = {}
        formFields.map(field => {
            if (errors[field]) {
                obj[field] = errors[field]
            }
        })
        return obj
        // delete errors.fullName;
        // delete errors.accsfid;
        // delete errors.pan_verified__c
        // delete errors.sfid
        // delete errors.lastname
        // delete errors.ccitySfid
        // delete errors.cpinCodeSfid
        // delete errors.credid
        // delete errors.cstateSfid
        // delete errors.name
        // delete errors.pancard_status__c
        // delete errors.pcitySfid
        // delete errors.photourl
        // delete errors.pl_count_wrong_mpin__c
        // delete errors.pl_otp_pass__c
        // delete errors.pl_otp_timestamp__c
        // delete errors.pl_refer_code__pc
        // delete errors.pl_sync_heroku_id__c
        // delete errors.ppinCodeSfid
        // delete errors.pstateSfid
        // return errors
    }

    handleSubmit = () => {
        const errors = this.filterErrors(this.validate());
        console.log(errors)
        let formData = {
            name: this.state.data.name,
            mobile: this.state.data.pl_mobile_no__c,
            email: this.state.data.personemail,
            pan: this.state.data.panNumber,
            dob: this.dateFormatter(this.state.data.dob),
            maritalStatus: this.state.data?.maritalStatus?.value,
            gender: this.state.data.gender,
            pincode: this.state.data.ppincode,
            cityName: this.state.data.city,
            monthlySalary: this.state.data?.monthlysalary,
            currentAddress: {
                addline1: this.state.data.cadd1,
                addline2: this.state.data.cadd2,
                pinCodeSfid: this.state.data.cpinCodeSfid ?? this.state.data?.currAddrDetails?.pincodesfid,
                stateSfid: this.state.data.cstateSfid ?? this.state.data?.currAddrDetails?.statesfid,
                citySfid: this.state.data.ccitySfid ?? this.state.data?.currAddrDetails?.citysfid,
            },
            permanentAddress: {
                addline1: this.state.data.padd1,
                addline2: this.state.data.padd2,
                pinCodeSfid: this.state.data?.ppinCodeSfid ?? this.state.data?.resAddrDetails?.pincodesfid,
                stateSfid: this.state.data?.pstateSfid ?? this.state.data?.resAddrDetails?.statesfid,
                citySfid: this.state.data?.pcitySfid ?? this.state.data?.resAddrDetails?.citysfid,
            }

        }
        if (Object.keys(errors).length) {
            this.setState({ ...this.state, errors: { ...errors } })
        }
        else if (!ValidateAge(this.state.data.dob, 13) || !this.state.data?.ccity || !this.state.data?.pcity || ValidateAge(this.state.data.dob, 13) === "Invalid DOB") {
            if (!ValidateAge(this.state.data.dob, 13) === true) {
                this.setState({ ...this.state, errors: { ...errors, dob: "Age must be between 13 to 100" } })
            }
        } else {
            console.log(Object.keys(errors).length, errors)
            this.props.setProfileInfo(formData, this.callBackStatusDetails)
            localStorage.setItem("fullName", this.state.data.name);
            localStorage.setItem("firstName", this.state.data.name);
            this.setState({ ...this.state, errors: { ...errors }, isLoading: true })
            //  this.props.
        }

    }

    handleImage = (files) => {
        const formData = new FormData()
        formData.append("file", files[0])
        formData.append("mobile", localStorage.getItem('mobilenumber'))
        formData.append("account_id", this.props.getCustomerDetail?.sfid)
        this.props.setProfilePhoto(formData, this.callBackStatus)
        let validImages = [...files].filter((file) =>
            ["image/jpeg", "image/png", "image/jpg"].includes(file.type)
        );
        validImages.forEach(this.convertFileImageToBase64String);
    }
    readFile = (file, callback) => {
        var reader = new FileReader();
        reader.onload = function (e) {
            callback(reader.result);
        };
        reader.readAsDataURL(file);
    };

    convertFileImageToBase64String = (image) => {
        this.readFile(image, (v) => {
            //     this.sendImgToUpload(image);
            this.setState({ fileImg: v });
        });
    };

    // sendImgToUpload = (img) => {
    //     const formData = new FormData()
    //     formData.append("file", img)
    //     formData.append("mobile", localStorage.getItem('mobilenumber'))
    //     formData.append("account_id", this.props.getCustomerDetail?.accsfid)
    //     console.log("image is", img)
    //     //   let blob = await base64Response.blob();
    //     //   recievedBlobFile(blob);
    // }

    callback = async (res) => {
        try {
            let r = await res;
            if (r.data) {
                if (r.data.success) {
                    if (r.data.name) {
                        localStorage.setItem("pan", this.state.data.panNumber);
                        this.setState((p) => ({
                            ...p,
                            data: {
                                ...p.data,
                                name: r.data.name,
                            },
                            errors: {
                                ...p.errors,
                                pan: "",
                                fullName: "",
                            },
                        }));
                    }
                } else {
                    this.setState({ ...this.state, errors: { ...this.state.errors, panNumber: "Pan Verification failed" } })
                }

            } else {
                throw r.data.message.toString();
            }
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };

    callBackDedeupe = async (res) => {
        try {
            let r = await res;
            if (!r.data.isDuplicate && !r.data.isFinnOneDuplicate) {
                let mobile = localStorage.getItem("mobilenumber");
                let formData = {
                    mobile: mobile,
                    pan: this.state.data.panNumber,
                };
                this.props.loadPanName(formData, this.callback);
            } else {
                throw r.data.message.toString();
            }
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };

    handlePACheckbox = () => {
        if (this.state.checked === true) {
            this.setState({
                ...this.state,
                checked: false,
                data: {
                    ...this.state.data,
                    padd1: "",
                    padd2: "",
                    ppincode: "",
                    pcity: "",
                    pstate: "",
                    ppinCodeSfid: "",
                    pcitySfid: "",
                    pstateSfid: "",
                },
            });
        } else {
            console.log(this.state.data)
            this.setState({
                ...this.state,
                checked: true,
                data: {
                    ...this.state.data,
                    padd1: this.state.data.cadd1,
                    padd2: this.state.data.cadd2,
                    ppinCodeSfid: this.state.data.cpinCodeSfid,
                    pcitySfid: this.state.data.ccitySfid,
                    pstateSfid: this.state.data.cstateSfid,
                    ppincode: this.state.data.cpincode,
                    pcity: this.state.data.ccity,
                    pstate: this.state.data.cstate,
                },
                //   pinSfid: pLData.currpinSfid,
                //   citySfid: pLData.currcitySfid,
                //   stateSfid: pLData.currstateSfid,
                //   cityCode: pLData.resCityCode,
            });

        }
    };

    __handlePANChange = (e) => {
        let panNumber = e.target.value.toUpperCase();
        if (e.target.value.length <= 10) {
            this.setState((p) => ({
                ...p,
                data: { ...p.data, panNumber: panNumber, fullName: "" },
                errors: { ...p.errors, panNumber: "", fullName: "" },
            }));
            if (e.target.value.length === 10) {
                let mobile = localStorage.getItem("mobilenumber");
                let formData = {
                    mobile: mobile,
                    pan: panNumber,
                };
                this.props.loadCheckDedupe(formData, this.callBackDedeupe);
            }
        }
    };

    handleCheckBoxChange = () => {
        this.setState({ ...this.state, terms: true })
    }

    callBackDetails = (res) => {
        if (res) {
            this.setState({ ...this.state, isLoading: false })
            //  res.data.customer.marrital
            //   console.log("response", res.data.customer.maritalstatus)
            let currentAddress = res.data?.customer?.currAddrDetails
            let permanentAddress = res.data?.customer?.resAddrDetails;
            if (currentAddress || permanentAddress) {
                if (currentAddress && permanentAddress) {
                    this.setState({
                        ...this.state, data: {
                            ...this.props.getCustomerDetail,
                            maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail.maritalstatus === data.value)[0],
                            cadd1: currentAddress.pl_address_line1__c,
                            cadd2: currentAddress.pl_address_line_2__c,
                            cpincode: currentAddress.pincode,
                            ccity: currentAddress.cityname,
                            cstate: currentAddress.statename,
                            cpinCodeSfid: currentAddress.pincodesfid,
                            ccitySfid: currentAddress.citysfid,
                            cstateSfid: currentAddress.statesfid,
                            pcity: permanentAddress.cityname,
                            ppinCodeSfid: permanentAddress.pincodesfid,
                            padd1: permanentAddress.pl_address_line1__c,
                            padd2: permanentAddress.pl_address_line_2__c,
                            ppincode: permanentAddress.pincode,
                            pcitySfid: permanentAddress.citysfid,
                            pstateSfid: permanentAddress.statesfid,
                            pstate: permanentAddress.statename
                        }
                    })
                }
                else if (currentAddress) {
                    this.setState({
                        ...this.state, data: {
                            ...res.data.customer,
                            cadd1: currentAddress.pl_address_line1__c,
                            cadd2: currentAddress.pl_address_line_2__c,
                            cpincode: currentAddress.pincode,
                            ccity: currentAddress.cityname,
                            cstate: currentAddress.statename,
                            cpincode: currentAddress.pincode,
                            cpinCodeSfid: currentAddress.pincodesfid,
                            ccitySfid: currentAddress.citysfid,
                            cstateSfid: currentAddress.statesfid,
                        }
                    })
                }
                else {
                    this.setState({
                        ...this.state, data: {
                            ...res.data.customer,
                            padd1: permanentAddress.pl_address_line1__c,
                            padd2: permanentAddress.pl_address_line_2__c,
                            ppincode: permanentAddress.pincode,
                            pcity: permanentAddress.cityname,
                            pstate: permanentAddress.statename,
                            pcitySfid: permanentAddress.citysfid,
                            pstateSfid: permanentAddress.statesfid,
                            ppinCodeSfid: permanentAddress.pincodesfid,
                        }
                    })
                }
            }
            else {
                this.setState({ ...this.state, data: { ...res.data.customer } })
            }
        }
    }
    _handleChangeSalary = (event) => {
        event.preventDefault();
        const salaryMonthly = event.target.value;
        if (salaryMonthly.length <= 16 || salaryMonthly === "") {
            const data = { ...this.state.data };
            // const errors = { ...this.state.errors };
            // errors.monthlysalary = "";
            data.monthlysalary = salaryMonthly.replace(/\D+/g, "");
            this.setState({ data });
        }
    };

    dateFormatter = (date) => {
        if (date?.length > 10) {
            let year = date.slice(0, 4)
            let day = date.slice(8, 10)
            let month = date.slice(5, 7)
            return day + "-" + month + "-" + year
        } else {
            return date
        }
    }

    // salaryFormatter = (salary) => {
    //     if (salary) {
    //         salary = salary?.toString()
    //         let formattedSalary = ""
    //         let length = salary.length
    //         if (salary?.length > 4) {
    //             formattedSalary = "," + salary.slice(length - 3)
    //             let i = 0
    //             while (i > length - 4) {
    //                 formattedSalary += "," + salary.slice(length - (4 + i), length - (4 + i - 2))
    //                 i += 2
    //             }

    //         }
    //         console.log("formatted salary is", salary, formattedSalary)
    //     }
    // }


    componentDidMount() {
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        this.setState({ ...this.state, isLoading: true })
        this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') }, this.callBackDetails)
        // if (JSON.stringify(this.props.getCustomerDetail) === "{}") {
        //     this.setState({ ...this.state, isLoading: true })
        //     this.props.getAccountInfo({ mobile: localStorage.getItem('mobilenumber') }, this.callBackDetails)
        // }
        // else {
        //     let currentAddress = this.props.getCustomerDetail?.currAddrDetails
        //     let permanentAddress = this.props.getCustomerDetail?.resAddrDetails
        //     if (currentAddress || permanentAddress) {
        //         if (currentAddress && permanentAddress) {
        //             this.setState({
        //                 ...this.state, data: {
        //                     ...this.props.getCustomerDetail,
        //                     maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail.maritalstatus === data.value)[0],
        //                     cadd1: currentAddress.pl_address_line1__c,
        //                     cadd2: currentAddress.pl_address_line_2__c,
        //                     cpincode: currentAddress.pincode,
        //                     ccity: currentAddress.cityname,
        //                     cstate: currentAddress.statename,
        //                     cpinCodeSfid: currentAddress.pincodesfid,
        //                     ccitySfid: currentAddress.citysfid,
        //                     cstateSfid: currentAddress.statesfid,
        //                     pcity: permanentAddress.cityname,
        //                     ppinCodeSfid: permanentAddress.pincodesfid,
        //                     padd1: permanentAddress.pl_address_line1__c,
        //                     padd2: permanentAddress.pl_address_line_2__c,
        //                     ppincode: permanentAddress.pincode,
        //                     pcitySfid: permanentAddress.citysfid,
        //                     pstateSfid: permanentAddress.statesfid,
        //                     pstate: permanentAddress.statename
        //                 }
        //             })
        //         }
        //         else if (currentAddress) {
        //             this.setState({
        //                 ...this.state, data: {
        //                     ...this.props.getCustomerDetail,
        //                     maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail.maritalstatus === data.value)[0],
        //                     cadd1: currentAddress.pl_address_line1__c,
        //                     cadd2: currentAddress.pl_address_line_2__c,
        //                     cpincode: currentAddress.pincode,
        //                     ccity: currentAddress.cityname,
        //                     cstate: currentAddress.statename,
        //                 }
        //             })
        //         }
        //         else {
        //             this.setState({
        //                 ...this.state, data: {
        //                     ...this.props.getCustomerDetail,
        //                     maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail.maritalstatus === data.value)[0],
        //                     padd1: permanentAddress.pl_address_line1__c,
        //                     padd2: permanentAddress.pl_address_line_2__c,
        //                     ppincode: permanentAddress.pincode,
        //                     pcity: permanentAddress.cityname,
        //                     pstate: permanentAddress.statename
        //                 }
        //             })
        //         }
        //     }
        //     else {
        //         this.setState({ ...this.state, data: { ...this.props.getCustomerDetail } })
        //     }
        // }

    }

    validate = () => {
        const options = { abortEarly: false };
        const { error } = Joi.validate(this.state.data, this.schema, options);
        if (!error) return null;
        const errors = {};
        for (let item of error.details) errors[item.path[0]] = item.message;
        return errors;
    };

    handleEditClick = () => {
        this.setState({ ...this.state, showEditOptions: true })
    }

    onDateChange = async (e) => {
        let d = await e.target.value;
        if (this.state.data.dob?.length <= 10) {
            this.setState(({ data }) => ({
                data: {
                    ...data,
                    dob: d,
                },
            }));
        } else {
            this.setState(({ data }) => ({
                data: {
                    ...data,
                    dob: d,
                },
            }));
        }
        if (!this.state.data.dob.includes("_")) {
            if (Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "" },
                    btnIsActive: true,
                }));
            } else {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "Date of Birth field is invalid." },
                    btnIsActive: false,
                }));
            }
        } else {
            this.setState({ btnIsActive: false });
        }
    };

    componentDidUpdate() {
        console.log("data is ppincode", this.state.data.ppincode)
        // if (this.props.getpinCode.pincode.cityname && (this.props.getpinCode.pincode.cityname != this.state.data.ccity)) {

        //     this.setState({
        //         ...this.state, data: {
        //             ...this.state.data, ccity: this.props.getpinCode.pincode.cityname, state: this.props.getpinCode.pincode.statename,
        //             citySfid: this.props.getpinCode.pincode.city__c, stateSfid: this.props.getpinCode.pincode.state__c, pinCodeSfid: this.props.getpinCode.pincode.sfid
        //         }
        //     })
        // }
        // if (this.state?.photourl) {
        //     if (this.state?.photourl?.indexOf("http") >= 0) {
        //         this.setState({ ...this.state, data: { ...this.state.data, gender: this.state.data.gender, maritalStatus: "" } })
        //     }
        //     else {
        //         this.setState({ ...this.state, photourl: false, data: { ...this.state.data, gender: this.state.data.gender, maritalStatus: "" } })
        //     }
        // } else {
        //     this.setState({ ...this.state, data: { ...this.state.data, gender: this.state?.data?.gender, maritalStatus: this.state?.data?.maritalStatus } })
        // }


    }

    changePhoto = (file) => {
        this.setState({ ...this.state, ...file })
    }
    handleClose = (url) => {
        if (url) {
            console.log("Url from selfie", url)
            Swal.fire({
                position: "center",
                icon: "success",
                title: "Profile Photo updated Successfully",
                showConfirmButton: true,
                timer: 1800,
            });
            this.props.updatePhoto(url)
            this.setState({ ...this.state, fileImg: url, showEditOptions: false, data: { ...this.state.data, photourl: url } })
            this.props.getAccountInfo({ mobile: localStorage.getItem("mobilenumber") })
        }
        else {
            this.setState({ ...this.state, fileImg: url, showEditOptions: false, data: { ...this.state.data, photourl: url } })
        }

    }



    // onChangeGender = (e) => {
    //     if (e) {
    //         this.setState({ gender: e.target.value });
    //     }
    // };

    render() {
        //  console.log(this.state.data.ppincode)
        //    console.log("img", this.state.fileImg)

        return (
            <>
                <div >
                    <TopNavBar />
                    {this.state.isLoading || this.props.pinLoading || this.props.panLoading ? <BackDropComponent /> : null}
                </div>
                {this.state.showEditOptions ? <Modal handleClose={this.handleClose} show={this.state.showEditOptions} onHide={this.handleClose}><SelfieUpload handleClose={this.handleClose} changePhoto={this.changePhoto} /></Modal> : null}
                <section className="bs-main-section" >
                    <Container>
                        <Row>
                            <Col sm={12} md={3} className="text-center">
                                <div className="profileContainer" >
                                    <div className="imgContainer" >
                                        <ProfilePhoto state={this.state} />
                                        <img className="editIcon" onClick={this.handleEditClick} src={EditIcon} />
                                    </div>
                                    <p>{capitalizeFirstLetter(this.state.data.name)}</p>
                                </div>

                            </Col>
                            <Col sm={12} md={9}>
                                <div
                                    className="row insideFormBlock"
                                    style={{ marginBottom: "30px" }}
                                >
                                    <div className="col-sm-12" >
                                        <div className="panVeryfyForm profile ">
                                            <div className="profileHeader heading"><p>Personal Details</p>
                                                {this.state.readOnly ? <button
                                                    variant="contained"

                                                    onClick={() => this.setState({ ...this.state, readOnly: false })}
                                                >
                                                    <img src={EditIconProfile} width="" height="" />
                                                </button> :
                                                    <button
                                                        variant="contained"
                                                    >
                                                        <img src={EditIconProfile} width="" height="" />
                                                    </button>}


                                            </div>
                                            <div className="panFormFields">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <PersonalInput
                                                            value={this.state.data.panNumber}
                                                            error={this.state.errors.panNumber}
                                                            __handleChange={this.__handlePANChange}
                                                            icon={<CardMembershipIcon />}
                                                            label="PAN Number"
                                                            readOnly={this.state.data.pancard_status__c ? true : this.state.readOnly}
                                                        />
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <PersonalInput
                                                            value={this.state.data.name}
                                                            error={""}
                                                            icon={<PersonIcon />}
                                                            label="Full Name"
                                                            readOnly={true}
                                                        />
                                                    </div>
                                                    {this.state?.readOnly || this.state.data.pancard_status__c ? < div className="col-sm-6">
                                                        <PersonalInput
                                                            icon={<DocExpiry />}
                                                            value={this.state.data.dob ? (this.state.data.dob?.length <= 10 ? this.state.data.dob : this.state.data.dob?.slice(8, 10) + "-" + this.state.data.dob?.slice(5, 7) + "-" + this.state.data?.dob?.slice(0, 4)) : "__-__-____"}
                                                            error={this.state.errors.dob}
                                                            label="Date of Birth"
                                                            readOnly={true}
                                                        />
                                                    </div> :
                                                        < div className="col-sm-6">
                                                            <DateComponent
                                                                value={this.state.data.dob?.length <= 10 ? this.state.data.dob : this.state.data.dob?.slice(8, 10) + "-" + this.state.data.dob?.slice(5, 7) + "-" + this.state.data?.dob?.slice(0, 4)}
                                                                onDateChange={this.onDateChange}
                                                                error={this.state.errors.dob}
                                                                label="Date of Birth"
                                                                readOnly={true}
                                                            />
                                                        </div>
                                                    }
                                                    <div className="col-sm-6">
                                                        {this.renderInput(
                                                            "pl_mobile_no__c",
                                                            "Phone Number",
                                                            <LocalPhoneIcon />,
                                                            true,
                                                            10,
                                                            10
                                                        )}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {this.renderEmail(
                                                            "personemail",
                                                            "Email ID",
                                                            <EmailIcon />,
                                                            this.state.readOnly
                                                        )}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <PersonalInput
                                                            value={this.state.data?.monthlysalary ? numberFormat(this.state.data?.monthlysalary) : ""}
                                                            __handleChange={this._handleChangeSalary}
                                                            error={this.state.errors?.monthlysalary}
                                                            icon={<IncomeIcon />}
                                                            label="Monthly Income"
                                                            readOnly={this.state.readOnly}
                                                        />
                                                    </div>

                                                    <div className="col-sm-6">

                                                        <this.renderPersonInfo
                                                            value={this.state.data?.gender}
                                                            error={this.state.errors?.gender}
                                                            variant={"gender"}
                                                            label={"Gender"}
                                                            readOnly={this.state.readOnly}
                                                        />

                                                        {/* <Gender
                                                            onChangeGender={this.onChangeGender}
                                                            gender={this.state.gender}
                                                        /> */}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {/* <this.renderPersonInfo
                                                            value={this.state.data?.relationship ? this.state.data?.relationship : "Single"}
                                                            error={""}
                                                            variant={"relationship"}
                                                            label="Marital Status"
                                                            readOnly={this.state.readOnly}
                                                        /> */}
                                                        {this.state.readOnly ? <PersonalInput
                                                            value={this.state.data.maritalStatus?.value}
                                                            error={""}
                                                            icon={<Marriage
                                                                style={{
                                                                    marginRight: "5px",
                                                                    marginTop: "3px",
                                                                }} />}
                                                            label="Marital Status"
                                                            readOnly={this.state.readOnly}
                                                        /> :

                                                            <SelectSearch
                                                                placeholderValue={"Select Marital Status"}
                                                                label={"Marital Status"}
                                                                value={this.state.data.maritalStatus}
                                                                setSelectedOption={(e) => {
                                                                    const data = { ...this.state.data };
                                                                    const errors = { ...this.state.errors };
                                                                    if (e) {
                                                                        data.maritalStatus = e;
                                                                        errors.maritalStatus = "";
                                                                        this.setState({ data, errors });
                                                                    }
                                                                }}
                                                                dropDownOptions={myprofile_marital_status}
                                                                error={this.state.errors.maritalStatus}
                                                                icon={
                                                                    <Marriage
                                                                        style={{
                                                                            marginRight: "5px",
                                                                            marginTop: "3px",
                                                                        }}
                                                                    />
                                                                }
                                                            ></SelectSearch>
                                                        }
                                                    </div>
                                                    <div className="col-sm-12 heading">
                                                        <p>Current Address</p>
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {" "}
                                                        {this.renderInput(
                                                            "cadd1",
                                                            "Address Line 1",
                                                            <AddressLine1Icon />,
                                                            this.state.readOnly
                                                        )}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {this.renderInput(
                                                            "cadd2",
                                                            "Address Line 2",
                                                            <AddressLine1Icon />,
                                                            this.state.readOnly
                                                        )}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <Pincode
                                                            value={this.state.data.cpincode}
                                                            __handlePinCode={(e) => this.__handlePinCode(e, "current")}
                                                            error={this.state.errors.cpincode}
                                                            disabled={this.state.readOnly}
                                                        />
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {this.renderInput("ccity", "City", <LocationIcon />, true)}
                                                    </div>

                                                    <div className="col-sm-6">
                                                        {this.renderInput("cstate", "State", <LocationIcon />, true)}
                                                    </div>

                                                    <div className="col-sm-7 heading"> <p> Permanent Address</p>    </div>      <div className="col-sm-5 heading">
                                                        <input
                                                            id="copyaddress"
                                                            type="checkbox"
                                                            checked={this.state.checked}
                                                            onChange={this.handlePACheckbox}
                                                            disabled={this.state.readOnly}
                                                        />
                                                        <label htmlFor="copyaddress">
                                                            &nbsp; Same as Current Address
                                                        </label>
                                                    </div>

                                                    <div className="col-sm-6">
                                                        {" "}
                                                        {/* name={name}
                                                        value={data[name]}
                                                        label={label}
                                                        onChange={this.handleChange}
                                                        error={errors[name]}
                                                        readOnly={readOnly}
                                                        icon={icon}
                                                        max={max}
                                                        min={min}
                                                        type={type}
                                                        required={required} */}
                                                        {this.renderInput(
                                                            "padd1",
                                                            "Address Line 1",
                                                            < AddressLine1Icon />,
                                                            this.state.readOnly ? this.state.readOnly : this.state.checked
                                                        )}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {this.renderInput(
                                                            "padd2",
                                                            "Address Line 2",
                                                            <AddressLine1Icon />,
                                                            this.state.readOnly ? this.state.readOnly : this.state.checked
                                                        )}
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <Pincode
                                                            key={"ppincode"}
                                                            value={this.state.data.ppincode}
                                                            step={this.state.checked ? CONSTANTS.RENDER_PERMANENT_ADDRESS : null}
                                                            __handlePinCode={(e) => this.__handlePinCode(e, "permanent")}
                                                            error={this.state.errors.ppincode}
                                                            disabled={this.state.readOnly ? this.state.readOnly : this.state.checked}
                                                        />
                                                    </div>
                                                    <div className="col-sm-6">
                                                        {this.renderInput("pcity", "City", <LocationIcon />, true)}
                                                    </div>

                                                    <div className="col-sm-6">
                                                        {this.renderInput("pstate", "State", <LocationIcon />, true)}
                                                    </div>
                                                    <div className="col-sm-12 text-center">
                                                        {this.state.readOnly ? <button
                                                            variant="contained"
                                                            className="nextButton"
                                                            onClick={() => this.setState({ ...this.state, readOnly: false })}
                                                        >
                                                            Edit Profile
                                                        </button> :
                                                            <button
                                                                variant="contained"
                                                                className="nextButton"
                                                                onClick={this.handleSubmit}
                                                            >
                                                                Save Changes
                                                            </button>
                                                        }
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>
                <CreditFooter />
            </>
        )
    }
}

const mapStateToProps = (state) => ({
    getpanName: getpanName(state),
    getpinCode: getpinCode(state),
    pinLoading: getpinCode(state).loading,
    panLoading: getpanName(state).loading,
    isLoading: getAccount(state).loading,
    getAccountDetail: getAccount(state).getAccountDetail,
    getCustomerDetail: getAccount(state).customerDetail
})
const mapDispatchToProps = (dispatch) => ({
    loadPanName: (params, callback) => dispatch(loadPanName(params, callback)),
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
    loadCheckDedupe: (params, callback) =>
        dispatch(loadCheckDedupe(params, callback)),
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    setProfileInfo: (params, callbackDetail) =>
        dispatch(setProfileInfo(params, callbackDetail)),
    setProfilePhoto: (params, callbackDetail) =>
        dispatch(setProfilePhoto(params, callbackDetail)),
    updatePhoto: (url) => {
        dispatch(updatePhoto(url))
    }
})

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(MyProfile))
