import { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import UserIcon from "../../include/assets/icons/user.svg";
import { getAccount } from "../../store/account";
class ProfilePhoto extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <img className="userImg" src={this.props.getCustomerDetail.photourl?.indexOf("http") >= 0 ? this.props.getCustomerDetail.photourl + "?" + Math.random().toString() : UserIcon} />
        )
    }
}

const mapStateToProps = (state) => ({
    getCustomerDetail: getAccount(state).customerDetail
})
const mapDispatchToProps = (dispatch) => ({})

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ProfilePhoto))
