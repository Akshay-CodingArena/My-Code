import Loan from "./Loan"
import { useState } from "react"
import Insurance from "./insurance/Insurance";
import CreditCard from "./CreditCard";


const Dashboard = () => {
    const [showInsurance, setShowInsurance] = useState(localStorage.getItem("ASM_Flow_For") ? localStorage.getItem("ASM_Flow_For") : "loans");
    const getComponent = () => {
        switch (showInsurance) {
            case "insurance":
                return <Insurance showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
            case "loans":
                return <Loan showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
            case "credit card":
                return <CreditCard showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
        }
    }
    return (<>
        {getComponent()}
    </>
    )
}

export default Dashboard