import { months } from "../CibilCheck/accountType";

export const getMonthName = (value) => {
    if (months) {
        if (value < 10) {
            value = 0 + value.toString()
            return months[value]
        } else {
            return months[value]
        }
    }
}

export const getFullDay = (value) => {
    if (value < 10) {
        value = 0 + value.toString()
        return value
    } else {
        return value
    }
}
