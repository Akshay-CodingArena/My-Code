import React from "react";
import CreditFooter from "../../../cibilFlow/footer";
import ASMNavBar from "../../ASMNavBar";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import BackDropComponent from "../../../../common/BackDropComponent";
import AllPagesPDFViewer from "../../../../common/pdf/AllPagesPDFViewer";
import AggrementPdf from "../../../../include/assets/twoWheelerLogo/Two-Wheeler-Return-to-Invoice.svg";
import { getICICI, getCertificate } from "../../../../store/iciciinsurancetw";
import Swal from "sweetalert2";
import DownloadNew from "../../../../include/assets/download_new_2.0.svg";

class CongratsScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            details: {},
            login: false,
            pdf: "",
            link: ""

        };
    }


    handleAddCustomer = () => {
        this.setState({ login: false })
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");

        this.setState({
            details: {
                pin: localStorage.getItem("pin"),
                city: localStorage.getItem("city"),
                address: localStorage.getItem("ASM_Address")
            }
        })


        let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
        let formData = { mobile: customerDetails.mobile, id: customerDetails.id, isNonAsm: false };
    

        this.props.getCertificate(formData, this.callbackGetCerificate)
    }


    callbackGetCerificate = (res) => {
        if (res.data.success) {
            this.setState({ pdf: res.data.data.COI, link: res.data.data.coi })
        }
        else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 1800,
            });
        }
    }

    handleDownload = () => {
        window.open(this.state.link, "_blank")
    }

    render() {
        return <React.Fragment>
            {
                (this.props.loadingGetCerticate) ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}

            <section className="bs-main-section asm" >
                <ASMNavBar
                    pin={this.state.details?.pin}
                    address={this.state.details?.address}
                    city={this.state.details?.city}
                    pinError={this.state.details?.pinError}
                    geoError={this.state.details?.geoError}
                    handleAddCustomer={this.handleAddCustomer} />

                <div className="container asm-insurance">
                    <h1 className="main-title">Congratulations</h1>
                    {this.state.link ? <div className="col-md-12 text-right " >
                        <div className="csTooltip"><a
                            href={"javascript:void(0)"}
                            className="downloadBtnCreditReport"
                            onClick={this.handleDownload}
                        >
                            <img src={DownloadNew}

                            />

                            Download
                        </a>
                        </div>
                    </div> : ""}

                    <div className="row d-flex justify-content-center align-items-center">
                        {this.state.pdf ? (
                            <div className="all-page-container" style={{ maxHeight: "400px", overflowY: "scroll" }}>
                                <AllPagesPDFViewer
                                    pdf={`data:application/pdf;base64,${this.state.pdf}`}
                                />
                            </div>
                        ) : (
                            <div className="all-page-container">
                                <img
                                    src={AggrementPdf}
                                    alt={"pdficon"}
                                    width="300"
                                    height="300"
                                />
                            </div>
                        )}


                    </div>
                </div>
                <CreditFooter />
            </section>
        </React.Fragment >
    }
}


const mapStateToProps = (state) => ({
    loadingGetCerticate: getICICI(state).loadingGetCerticate,
});
const mapDispatchToProps = (dispatch) => ({
    getCertificate: (params, callback) => dispatch(getCertificate(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(CongratsScreen)
);