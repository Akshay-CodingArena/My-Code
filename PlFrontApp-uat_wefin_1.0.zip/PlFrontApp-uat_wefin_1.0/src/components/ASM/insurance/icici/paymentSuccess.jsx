import React from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import BackDropComponent from "../../../../common/BackDropComponent";
import { policyStatus } from "../../../../store/iciciinsurancetw";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import PATH from "../../../../paths/Paths";

const ICICIPaymentSuccess = () => {

    const dispatch = useDispatch();
    const history = useHistory();

    useEffect(() => {
        if (localStorage.getItem("customerDetails")) {
            let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
            let formData = { mobile: customerDetails.mobile, id: customerDetails.id, isNonAsm: false };
            dispatch(policyStatus(formData, callbackPolicyStatus))
        }
    }, [])


    const callbackPolicyStatus = (res) => {
        if (res.data.success) {
            history.push(PATH.PRIVATE.ASM_INSURANCE_CONGRATS_SCREEN)
        }
    }

    return <React.Fragment>

        {useSelector(state => (state.entities.icici.loadingPolicyStatus)) ? < BackDropComponent /> : null}

        <div className="icici-payment-container">

            <div className="success-box">
                <p className="success-title">Your payment has been successfull.</p>
            </div>

        </div>
    </React.Fragment>
}
export default ICICIPaymentSuccess;