import React, { useEffect, useState } from "react";
import CreditFooter from "../../../cibilFlow/footer";
import ASMNavBar from "../../ASMNavBar";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import BackDropComponent from "../../../../common/BackDropComponent";
import { getICICI, policyStatus } from "../../../../store/iciciinsurancetw";
import PATH from "../../../../paths/Paths";
import Swal from "sweetalert2";


class WaitingScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {},
            errors: {},
            show: false,
            details: {},
            login: false
        };
    }


    handleAddCustomer = () => {
        this.setState({ login: false })
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");

        this.setState({
            details: {
                pin: localStorage.getItem("pin"),
                city: localStorage.getItem("city"),
                address: localStorage.getItem("ASM_Address")
            }
        })
    }

    handleRefresh = () => {
        let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
        let formData = { mobile: customerDetails.mobile, id: customerDetails.id }
        this.props.policyStatus(formData, this.callbackPolicyStatus)
    }
    callbackPolicyStatus = (res) => {
        if (res.data.success) {

            let status = res.data.data.Status;

            if (status === "ISSUED") {
                this.props.history.push(PATH.PRIVATE.ASM_INSURANCE_CONGRATS_SCREEN)
            } else if (status === "INPROGESS") {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: "Your Two Wheeler Policy status is still in progess.",
                    showConfirmButton: true,
                    timer: 1800,
                });
            } else {
                this.props.history.push(PATH.PRIVATE.ASM_INSURANCE_FAILED_SCREEN)
            }
        }
    }

    render() {
        return <React.Fragment>

            {
                (this.props.loadingPolicyStatus) ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}

            <section className="bs-main-section asm" >
                <ASMNavBar
                    pin={this.state.details?.pin}
                    address={this.state.details?.address}
                    city={this.state.details?.city}
                    pinError={this.state.details?.pinError}
                    geoError={this.state.details?.geoError}
                    handleAddCustomer={this.handleAddCustomer} />

                <div className="row d-flex justify-content-center align-items-center">
                    <div className="col-sm-6 icici-waiting-screen-box">
                        Your insurance application is currently being processed. Please refresh the page for the latest status updates.
                        <div className="refresh" onClick={this.handleRefresh}>
                            Click here to refresh
                        </div>
                    </div>
                </div>
                <CreditFooter />
            </section>
        </React.Fragment >
    }
}


const mapStateToProps = (state) => ({
    loadingPolicyStatus: getICICI(state).loadingPolicyStatus
});
const mapDispatchToProps = (dispatch) => ({
    policyStatus: (params, callback) => dispatch(policyStatus(params, callback))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(WaitingScreen)
);