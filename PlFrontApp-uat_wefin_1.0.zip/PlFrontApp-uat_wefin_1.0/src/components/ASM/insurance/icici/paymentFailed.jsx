import React from "react";

const ICICIPaymentSuccess = () => {

    return <React.Fragment>
        <div className="icici-payment-container">
            <div className="failed-box">
                <p className="failed-title">We regret to inform you that the recent payment attempt for your insurance was unsuccessful.</p>
            </div>

        </div>
    </React.Fragment>
}
export default ICICIPaymentSuccess;