import React, { useEffect, useState } from "react";
import CreditFooter from "../../../cibilFlow/footer";
import ASMNavBar from "../../ASMNavBar";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";


const FailedScreen = () => {
    let [details, setDetails] = useState({});
    let [login, setLogin] = useState(true);
    const history = useHistory()


    const handleAddCustomer = () => {
        setLogin(false);
    }

    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");

        setDetails({
            pin: localStorage.getItem("pin"),
            city: localStorage.getItem("city"),
            address: localStorage.getItem("ASM_Address")
        })
    }, [])

    return <React.Fragment>
        <section className="bs-main-section asm" >


            <ASMNavBar
                pin={details?.pin}
                address={details?.address}
                city={details?.city}
                pinError={details?.pinError}
                geoError={details?.geoError}
                handleAddCustomer={handleAddCustomer} />

            <div className="row d-flex justify-content-center align-items-center">
                <div className="col-sm-6 icici-failed-screen-box">
                    Sorry, you do not qualify for the offer this time.

                    <div className="go-back" onClick={(e) => {
                        history.push("/asm-dashboard")
                    }} >
                        Back to Homepage
                    </div>
                </div>
            </div>
            <CreditFooter />
        </section>
    </React.Fragment>

}

export default FailedScreen;