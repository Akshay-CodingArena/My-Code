import React, { Component } from "react";
import CreditFooter from "../../../cibilFlow/footer";
import ASMNavBar from "../../ASMNavBar";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import BackDropComponent from "../../../../common/BackDropComponent";
import { getICICI, OVDInitiate } from "../../../../store/iciciinsurancetw";
import Swal from "sweetalert2";
import PATH from "../../../../paths/Paths";

class DragDropFiles extends Component {

    constructor(props) {
        super(props);
        this.state = {
            details: {},
            login: false,
            files: null,
        };
        this.inputRef = React.createRef();
    }


    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        this.setState({
            details: {
                pin: localStorage.getItem("pin"),
                city: localStorage.getItem("city"),
                address: localStorage.getItem("ASM_Address")
            }
        })
    }

    handleDragOver = (event) => {
        event.preventDefault();
    };

    handleDrop = (event) => {
        event.preventDefault();
        this.setState({ files: event.dataTransfer.files })
    };

    // send files to the server // learn from my other video
    handleUpload = () => {
        let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
        const formData = new FormData();
        formData.append("file", this.state.files[0]);
        formData.append("mobile", customerDetails.mobile);
        formData.append("chassis_no", JSON.parse(localStorage.getItem("customerDetails")).chassisNumber)
        formData.append("id", customerDetails.id);
        formData.append("isNonAsm", false);
        this.props.OVDInitiate(formData, this.callbackOVDInitiate);
    };

    callbackOVDInitiate = (res) => {
        if (res.data.success) {
            this.props.history.push(PATH.PRIVATE.ASM_INSURANCE_ADDITIONAL_DETAILS_ICICI)
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "Error occurred in OVD INITIATE API..",
                showConfirmButton: true,
                timer: 1800,
            });
        }
    }

    render() {
        return (<React.Fragment>
            {
                (this.props.loadingOVDInitaite) ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}
            <section className="bs-main-section asm" >
                <ASMNavBar
                    pin={this.state.details?.pin}
                    address={this.state.details?.address}
                    city={this.state.details?.city}
                    pinError={this.state.details?.pinError}
                    geoError={this.state.details?.geoError}
                    handleAddCustomer={this.handleAddCustomer} />


                <div className="container">
                    <div
                        className="dropzone"
                        onDragOver={this.handleDragOver}
                        onDrop={this.handleDrop}
                    >
                        <h1>Drag and Drop Adhaar Card here</h1>
                        <h1 className="mb-2"><b>Or</b></h1>
                        <input
                            type="file"
                            multiple
                            onChange={(event) => this.setState({ files: event.target.files })}
                            hidden
                            accept="application/pdf"
                            ref={this.inputRef}
                        />
                        <span onClick={() => this.inputRef.current.click()}>Select File</span>

                        <b className="mt-3 text-success">{this.state.files ? this.state.files[0].name : ""}</b>
                    </div>

                    <div className="col-sm-12 text-center">
                        <button
                            type="button"
                            onClick={this.handleUpload}
                            variant="contained"
                            className="nextButton"
                        >
                            Submit
                        </button>
                    </div>
                </div>

                <CreditFooter />
            </section>
        </React.Fragment>
        );
    }
};


const mapStateToProps = (state) => ({
    loadingOVDInitaite: getICICI(state).loadingOVDInitaite
});
const mapDispatchToProps = (dispatch) => ({
    OVDInitiate: (params, callback) => dispatch(OVDInitiate(params, callback))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(DragDropFiles)
);
