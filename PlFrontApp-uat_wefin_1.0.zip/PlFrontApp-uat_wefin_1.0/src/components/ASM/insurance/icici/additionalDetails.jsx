import React, { Component } from "react";
import { Container } from "react-bootstrap";
import CreditFooter from "../../../cibilFlow/footer";
import Form from "../../../common/form";
import Joi from "joi-browser";
import PersonalInput from "../../../common/personalInput";
import { ReactComponent as LocationIcon } from "../../../../include/assets/homepageIcons/icon-pincode.svg";
import { relation_to_applicant } from "../../../common/dropdownValues";
import SelectSearch from "../../../common/select";
import DateComponent from "../../../../components/common/date"
import Moment from "moment";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import BackDropComponent from "../../../../common/BackDropComponent";
import Swal from "sweetalert2";
import { getICICI, iciciProposal } from "../../../../store/iciciinsurancetw";
import ASMNavBar from "../../ASMNavBar";
import Radio from "../../../common/Radio";
import PersonalAmountInput from "../../../common/personalAmountInput";
import PATH from "../../../../paths/Paths";
import Pincode from "../../../common/pincode";
import { getpinCode, loadPinCode } from "../../../../store/pincode";


class ICICIMain extends Form {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                isVehicleUnderLoan: 'Y',
                financierName: ""
            },
            errors: {},
            show: false,
            details: {},
            login: false
        };
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
        this.setState({
            details: {
                pin: localStorage.getItem("pin"),
                city: localStorage.getItem("city"),
                address: localStorage.getItem("ASM_Address")
            },
            data: {
                ...this.state.data,
                name: customerDetails.name,
                address: customerDetails.address,
                pincode: customerDetails.pincode.trim(),
                chassisNumber: customerDetails.chassisNumber,
                amountCollected: customerDetails.amount ? customerDetails.amount.toString() : "",
                engineNo: customerDetails.engineNo,
                financierName: customerDetails.financierName,
                isVehicleUnderLoan: customerDetails.financierName ? "Y" : "N"
            }
        })
    }

    handleAddCustomer = () => {
        this.setState({ login: false })
    }


    schema = {
        email: Joi.string()
            .required("")
            .error(() => {
                return { message: "Email is required" };
            }),
        name: Joi.string()
            .required("")
            .error(() => {
                return { message: "Name field is required" };
            }),
        address: Joi.string()
            .required("")
            .error(() => {
                return { message: "Address field is required" };
            }),
        pincode: Joi.string()
            .required("")
            .error(() => {
                return { message: "Pincode is required" };
            }),
        nomineeName: Joi.string()
            .required("")
            .error(() => {
                return { message: "Nominee Name field is required" };
            }),
        age: Joi.string()
            .required("")
            .error(() => {
                return { message: "Age field is required" };
            }),
        relationship: Joi.object()
            .required("")
            .error(() => {
                return { message: "Relationship field is required." };
            }),
        dob: Joi.string()
            .required()
            .label("Date of Birth")
            .error((err) => {
                return { message: "Date of Birth field is required." };
            }),
        financierName: Joi.string().allow(""),

        engineNo: Joi.string()
            .required("")
            .error(() => {
                return { message: "Name field is required" };
            }),
        amountCollected: Joi.string()
            .required("")
            .error(() => {
                return { message: "Collected Amount field is required" };
            }),
        isVehicleUnderLoan: Joi.string()
            .required("")
            .error(() => {
                return { message: "This field is required" };
            }),
        chassisNumber: Joi.string()
            .required("")
            .error(() => {
                return { message: "Chassis Number field is required" };
            })
    };

    onDateChange = async (e) => {
        let d = await e.target.value;
        this.setState(({ data }) => ({
            data: {
                ...data,
                dob: d,
            },
        }));
        if (!this.state.data.dob.includes("_")) {
            if (Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "", age: "" },
                }));

                var a = Moment([new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate()])
                var b = Moment([d.split("-")[2], d.split("-")[1], d.split("-")[0]]);

                var years = a.diff(b, 'year');

                this.setState({
                    data: {
                        ...this.state.data,
                        age: years.toString(),
                    }
                });
            } else {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "Date Of Birth field is invalid." },
                }));

                this.setState({ data: { ...this.state.data, age: "" } });
            }
        } else {
            this.setState({ data: { ...this.state.data, age: "" } });
        }
    };

    onChange = (type) => {
        let data = { ...this.state.data };
        data.isVehicleUnderLoan = type;
        this.setState({ data })
    };


    _handleChange = (property, event) => {
        let data = { ...this.state.data };
        let errors = { ...this.state.errors }
        switch (property) {
            case "name":
                const name = event.target.value;
                data = { ...this.state.data };
                errors.name = ""
                data.name = name;
                this.setState({ data, errors });
                break;
            case "address":
                const address = event.target.value;
                data = { ...this.state.data };
                errors.address = ""
                data.address = address;
                this.setState({ data, errors });
                break;
            case "email":
                const email = event.target.value;
                if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
                    errors.email = "";
                    data = { ...this.state.data };
                    data.email = email
                    this.setState({ data, errors })
                } else {
                    errors.email = "Please enter a valid email";
                    data = { ...this.state.data };
                    data.email = email
                    this.setState({ data, errors })
                }
                break;
            case "nomineeName":
                const nomineeName = event.target.value;
                data = { ...this.state.data };
                errors.nomineeName = ""
                data.nomineeName = nomineeName
                this.setState({ data, errors });
                break;
            case 'age':
                const age = event.target.value;
                data = { ...this.state.data };
                data.age = age.replace(/\D+/g, "");
                errors.age = ""
                this.setState({ data, errors });
                break;
            case "financierName":
                const financierName = event.target.value;
                data = { ...this.state.data };
                data.financierName = financierName
                errors.financierName = ""
                this.setState({ data, errors });
                break;
            case "engineNo":
                const engineNo = event.target.value;
                data = { ...this.state.data };
                data.engineNo = engineNo.toUpperCase();
                errors.engineNo = ""
                this.setState({ data, errors });
                break;

        }
    }

    doSubmit = () => {
        console.log("-------------TEST DATA--------");
        console.log(this.state.data)

        if (this.state.data.isVehicleUnderLoan === "Y" && !this.state.data.financierName.trim().length) {
            let errors = { ...this.state.errors };
            errors.financierName = "Financier Name is required."
            this.setState({ errors })
        }
        else {
            let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));

            let formData = {
                "proposerName": this.state.data.name,
                "proposerAddress": this.state.data.address,
                "nomineeName": this.state.data.nomineeName,
                "nomineeAge": parseInt(this.state.data.age),
                "nomineeRelation": this.state.data.relationship.label,
                "engineNo": this.state.data.engineNo,
                "isVehicleUnderloan": this.state.data.isVehicleUnderLoan === "Y" ? true : false,
                "amountCollected": parseInt(this.state.data.amountCollected),
                "mobile": parseInt(customerDetails.mobile),
                "financierName": this.state.data.financierName,
                "proposerEmail": this.state.data.email,
                "id": customerDetails.id,
                "isNonAsm": false,
                "SuccessUrl": window.location.origin + PATH.PUBLIC.ICICI_PAYMENT_SUCCESS,
                "FailureUrl": window.location.origin + PATH.PRIVATE.ASM_INSURANCE_FAILED_SCREEN
            }
            if (this.state.data.isVehicleUnderLoan === "N") {
                delete formData['financierName']
            }
            this.props.iciciProposal(formData, this.callbackProposal)
        }
    }

    callbackProposal = (res) => {
        if (res.data.success) {
            let customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
            localStorage.setItem("customerDetails", JSON.stringify({ ...customerDetails, "PolicyReferenceId": res.data.data.policy_reference_id }))
            window.open(res.data.data.PaymentLink, "_blank")
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 1800,
            });

        }
    }

    __handlePinCode = (e) => {
        e.preventDefault();
        let customerDetail = JSON.parse(localStorage.getItem("customerDetails"));
        if (e.target.value.length === 6) {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            this.setState({ data });
            let formData = { mobile: customerDetail.mobile, pincode: e.target.value };
            if (localStorage.getItem("ASM_Id")) {
                formData['asm_id'] = localStorage.getItem("ASM_Id")
            };
            this.props.loadPinCode(formData, this.callbackPin);
        }
    };

    callbackPin = (res) => {
        if (res) {
            let errors = { ...this.state.errors };
            if (res.data.success === false) {
                errors.pincode = res.data.message;
                this.setState({ errors });
            } else if (res.data.success === true) {
                errors.pincode = "";
                this.setState({ errors });
            }
        }
    };

    render() {
        return <>
            {
                (this.props.loadingProposal || this.props.loading) ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}
            <section className="bs-main-section asm" >

                <ASMNavBar
                    pin={this.state.details?.pin}
                    address={this.state.details?.address}
                    city={this.state.details?.city}
                    pinError={this.state.details?.pinError}
                    geoError={this.state.details?.geoError}
                    handleAddCustomer={this.handleAddCustomer} />
                <Container className="asm-insurance">

                    <h1 className="main-title mt-3">Additional Details</h1>

                    <div className="row insideFormBlock">
                        <div className="col-sm-12">
                            <form className="panVeryfyForm">
                                <div className="row">
                                    <div className="col-sm-12 d-flex justify-content-between mb-3">
                                        <b className="h5">Owner's Details</b>
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.name}
                                            error={this.state.errors.name}
                                            icon={<LocationIcon />}
                                            label="Name"
                                            readOnly={false}
                                            __handleChange={(e) => this._handleChange('name', e)}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <Pincode
                                            value={this.state.data.pincode}
                                            __handlePinCode={this.__handlePinCode}
                                            error={this.state.errors.pincode}
                                            disabled={false}
                                        />
                                        {/* <PersonalInput
                                            value={this.state.data.pincode}
                                            error={this.state.errors.pincode}
                                            icon={<LocationIcon />}
                                            label="Pincode"
                                            readOnly={true}
                                        /> */}
                                    </div>


                                    <div className="col-sm-12">
                                        <PersonalInput
                                            value={this.state.data.address}
                                            error={this.state.errors.address}
                                            icon={<LocationIcon />}
                                            label="Address"
                                            readOnly={false}
                                            __handleChange={(e) => this._handleChange('address', e)}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.email}
                                            error={this.state.errors.email}
                                            icon={<LocationIcon />}
                                            label="Email"
                                            readOnly={false}
                                            __handleChange={(e) => this._handleChange('email', e)}
                                        />
                                    </div>

                                    <div className="col-sm-12 d-flex justify-content-between mt-3 mb-3">
                                        <b className="h5">Nominee Details</b>
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.nomineeName}
                                            error={this.state.errors.nomineeName}
                                            icon={<LocationIcon />}
                                            label="Nominee Name"
                                            readOnly={false}
                                            __handleChange={(e) => this._handleChange('nomineeName', e)}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.age}
                                            error={this.state.errors.age}
                                            icon={<LocationIcon />}
                                            label="Age"
                                            readOnly={true}
                                        />
                                    </div>


                                    <div className="col-sm-6">
                                        <SelectSearch
                                            style={{ margin: "15px 8px 20px" }}
                                            placeholderValue={"Select Relationship Type"}
                                            label={"Relationship (With Nominee)"}
                                            value={this.state.data.relationship}
                                            page="personal"
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.relationship = e;
                                                    errors.relationship = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={relation_to_applicant}
                                            error={this.state.errors.relationship}
                                            icon={
                                                <LocationIcon
                                                    style={{ marginRight: "5px", marginTop: "2px" }}
                                                />
                                            }
                                        ></SelectSearch>

                                    </div>

                                    <div className="col-sm-6">
                                        <DateComponent
                                            value={this.state.data.dob?.length <= 10 ? this.state.data.dob : this.state.data.dob?.slice(8, 10) + "-" + this.state.data.dob?.slice(5, 7) + "-" + this.state.data?.dob?.slice(0, 4)}
                                            onDateChange={this.onDateChange}
                                            error={this.state.errors.dob}
                                            label="Date of Birth"
                                            readOnly={true}
                                        />
                                    </div>


                                    <div className="col-sm-12 d-flex justify-content-between mt-3 mb-3">
                                        <b className="h5">Vehicle Details</b>
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.engineNo}
                                            error={this.state.errors.engineNo}
                                            icon={<LocationIcon />}
                                            label="Engine No."
                                            readOnly={true}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.chassisNumber}
                                            error={this.state.errors.chassisNumber}
                                            icon={<LocationIcon />}
                                            label="Chassis Number"
                                            readOnly={true}
                                        />
                                    </div>


                                    <div className="col-sm-12 text-left">
                                        <label htmlFor="EmployeeType">
                                            Is Vehicle Under Loan?
                                            <span style={{ color: "#FF4C30" }}>*</span>
                                        </label>
                                    </div>



                                    <div className="col-sm-12 text-left">
                                        <Radio
                                            value={'Y'}
                                            label={'Yes'}
                                            groupValue={this.state.data.isVehicleUnderLoan}
                                            onClick={() => this.onChange('Y')}
                                        />

                                        <Radio
                                            value={'N'}
                                            label={'No'}
                                            groupValue={this.state.data.isVehicleUnderLoan}
                                            onClick={() => this.onChange('N')}
                                        />
                                    </div>

                                    {this.state.data.isVehicleUnderLoan === "Y" ? <div className="col-sm-6 mt-3">
                                        <PersonalInput
                                            value={this.state.data.financierName}
                                            error={this.state.errors.financierName}
                                            icon={<LocationIcon />}
                                            label="Financier Name"
                                            readOnly={true}
                                        />
                                    </div> : ""}

                                    <div className="col-sm-12 d-flex justify-content-between mt-3 mb-3">
                                        <b className="h5">Payment Details</b>
                                    </div>

                                    <div className="col-sm-6 text-left">
                                        <PersonalAmountInput
                                            value={this.state.data.amountCollected}
                                            error={this.state.errors.amountCollected}
                                            icon={<LocationIcon />}
                                            label="Amount Collected"
                                            readOnly={true}
                                            required={true}
                                        />
                                    </div>

                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Submit
                                        </button>

                                    </div>


                                </div>
                            </form>
                        </div>
                    </div>
                    <CreditFooter />
                </Container>
            </section >
        </>
    }
}

const mapStateToProps = (state) => ({
    loadingProposal: getICICI(state).loadingProposal,
    loading: getpinCode(state).loading
});
const mapDispatchToProps = (dispatch) => ({
    iciciProposal: (params, callback) => dispatch(iciciProposal(params, callback)),
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ICICIMain)
);


