import React, { Component } from "react";
import { Container, Row } from "react-bootstrap";
import CreditFooter from "../../../cibilFlow/footer";
import Form from "../../../common/form";
import Joi from "joi-browser";
import PersonalInput from "../../../common/personalInput";
import { ReactComponent as LocationIcon } from "../../../../include/assets/homepageIcons/icon-pincode.svg";
import { RTO_values } from "../../../common/dropdownValues";
import SelectSearch from "../../../common/select";
import DateComponent from "../../../../components/common/date"
import Pincode from "../../../common/pincode";
import Moment from "moment";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import BackDropComponent from "../../../../common/BackDropComponent";
import { getpanName, loadPanName } from "../../../../store/panName";
import Swal from "sweetalert2";
import { getpinCode, loadPinCode } from "../../../../store/pincode";
import { getICICI, fetchChesisData, getQuote, saveQuote, getInfoFromRCNo } from "../../../../store/iciciinsurancetw";
import LogoutIcon from "../../../../include/assets/logoutIcon.svg";
import ASMNavBar from "../../ASMNavBar";
import PATH from "../../../../paths/Paths";


class ICICIMain extends Form {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                zeroDepreciation: false,
                roadSideAssistance: false,
            },
            errors: {},
            show: false,
            details: {},
            login: false,
            loading: false
        };
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        this.setState({
            details: {
                pin: localStorage.getItem("pin"),
                city: localStorage.getItem("city"),
                address: localStorage.getItem("ASM_Address")
            }
        })
    }

    handleAddCustomer = () => {
        this.setState({ login: false })
    }


    schema = {
        registrationNo: Joi.string()
            .required("")
            .error(() => {
                return { message: "Registration Number is required" };
            }),
        chassisNumber: Joi.string()
            .required("")
            .error(() => {
                return { message: "Chassis Number is required" };
            }),
        purchaseDate: Joi.string()
            .required("")
            .error(() => {
                return { message: "Purchase date is required" };
            }),
        rtoCode: Joi.string()
            .required()
            .error(() => {
                return { message: "RTO Code is required" };
            }),
        pan: Joi.string()
            .required()
            .regex(
                new RegExp("[A-Z]{5}[0-9]{4}[A-Z]{1}")
            )
            .error(errors => {
                errors.forEach(err => {
                    console.log(err)
                    switch (err.type) {
                        case "any.empty":
                        case "any.required":
                            err.message = "Pancard is required.";
                            break;
                        case "string.regex.base":
                            err.message = "Invalid pan format."
                            break;
                    }
                });
                return errors;
            }),
        dob: Joi.string()
            .required()
            .label("Date of Birth")
            .error((err) => {
                return { message: "Date of Birth field is required." };
            }),
        mobileNumber: Joi.string()
            .required("")
            .error(() => {
                return { message: "Mobile Number is required" };
            }),
        pincode: Joi.string().required().error(() => {
            return { message: "Pin code field is required." };
        }),
        zeroDepreciation: Joi.boolean().default(false),
        roadSideAssistance: Joi.boolean().default(false)
    };




    doSubmit = () => {
        console.log("-------FORM IS BEING SUBMITTED-----");
        console.log(this.state.data);

        // 10026

        let formData = {
            chassis_no: this.state.data.chassisNumber,
            purchase_date: this.state.data.purchaseDate.split("-")[2] + "-" + this.state.data.purchaseDate.split("-")[1] + "-" + this.state.data.purchaseDate.split("-")[0],
            rto: "10026",
            pan: this.state.data.pan,
            dob: this.state.data.dob.split("-")[2] + "-" + this.state.data.dob.split("-")[1] + "-" + this.state.data.dob.split("-")[0],
            mobile: parseInt(this.state.data.mobileNumber),
            pincode: parseInt(this.state.data.pincode),
            asm_id: parseInt(localStorage.getItem("ASM_Id")),
            zeroDeprication: this.state.data.zeroDepreciation,
            roadAssistance: this.state.data.roadSideAssistance,
            isNonAsm: false,
            vehicle_make_model: this.props.vehicleData.vehicle_make_model,
            productCode: 10
        }
        this.props.getQuote(formData, this.callbackGetQuote);
    }

    callbackGetQuote = (res) => {
        if (res.data.success) {
            this.setState({ show: true })
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: res.data.errorDetails,
                timer: 3000,
                showConfirmButton: false
            });

        }
    }

    __handlePinCode = (e) => {
        e.preventDefault();
        let mobile = localStorage.getItem("ASM_mobilenumber");
        if (e.target.value.length === 6) {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            this.setState({ data });
            let formData =
                { mobile: mobile, pincode: e.target.value };

            if (localStorage.getItem("ASM_Id")) {
                formData['asm_id'] = localStorage.getItem("ASM_Id")
            }
            this.props.loadPinCode(formData, this.callbackPin);
        }
    };

    callbackPin = (res) => {
        if (res) {
            let errors = { ...this.state.errors };
            if (res.data.success === false) {
                errors.pincode = res.data.message;
                this.setState({ errors });
                ///////////////show swal/////////
            } else if (res.data.success === true) {
                errors.pincode = "";
                this.setState({ errors });
            }
        }
    };


    getDataFromChessis = () => {
        let formData = {
            registrationNum: this.state.data.registrationNo
        }

        this.props.getInfoFromRCNo(formData, this.callbackGetInfoFromRCNo);
    }

    callbackGetInfoFromRCNo = (res) => {
        if (res.data.success) {
            let vehicleInfo = res.data.data.result;
            ////////////////////ADD THIS CHECK TO THE PRODUCTION ONLY////////////

            // if (Object.keys(vehicleInfo.insurance).length && new Date(vehicleInfo.insurance.expiry_date) >= new Date()) {
            //     let data = { ...this.state.data };
            //     Swal.fire({
            //         position: "center",
            //         icon: "error",
            //         title: `You are already insured through ${vehicleInfo.insurance.company}`,
            //         timer: 3000,
            //         showConfirmButton: true
            //     });
            // } else {

            let data = { ...this.state.data };
            localStorage.setItem("customerDetails",
                JSON.stringify({
                    engineNo: vehicleInfo.rc_engine_number,
                    financer: vehicleInfo.financer === "NA" ? "" : vehicleInfo.financer
                }))
            let pincode = vehicleInfo.user_permanent_address.substr(vehicleInfo.user_permanent_address.length - 6);
            data['chassisNumber'] = vehicleInfo.rc_chassis_number;
            data['pincode'] = isNaN(pincode) ? "" : pincode;
            data['rtoCode'] = vehicleInfo.rc_rto_code;
            data['purchaseDate'] = vehicleInfo.rc_registration_date ? Moment(vehicleInfo.rc_registration_date).format("DD-MM-YYYY") : "";
            this.setState({ data: data })
            // }

        } else {

            let data = { ...this.state.data };
            let errors = {}
            data['chassisNumber'] = "";
            data['pincode'] = "";
            data['rtoCode'] = "";
            data['purchaseDate'] = "";
            ///////////show toast here////////////
            this.setState({ data, errors });
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Invalid Resgistration Number",
                showConfirmButton: true,
            })
        }
    }


    callbackChassisData = (res) => {

        if (res.data.success) {
            let ChassisData = res.data.data[0];
            let data = { ...this.state.data };
            data.purchaseDate = ChassisData?.registration_date ? ChassisData.registration_date.split("T")[0].split("-").reverse().join("-") : "";
            data.pan = ChassisData?.pan ? ChassisData.pan : "";
            data.dob = ChassisData?.proposer_dob ? ChassisData.proposer_dob.split("T")[0].split("-").reverse().join("-") : "";
            data.pincode = ChassisData?.pincode ? ChassisData.pincode : "";
            data.mobileNumber = ChassisData?.mobile ? ChassisData.mobile : "";
            data.rtoCode = ChassisData?.rto_code ? RTO_values.filter((data) => data.value === ChassisData?.rto_code)[0] : "";
            data.roadSideAssistance = ChassisData?.road_assistance ? ChassisData.road_assistance : false;
            data.zeroDepreciation = ChassisData?.zero_deprication ? ChassisData.zero_deprication : false;
            this.setState({ data, errors: {} })
        } else {
            this.setState({
                data: {
                    chassisNumber: this.state.data.chassisNumber,
                    zeroDepreciation: false,
                    roadSideAssistance: false,
                }
            })
        }
    }



    __handlePANChange = (e) => {
        let data = { ...this.state.data };
        data.pan = e.target.value.toUpperCase();
        this.setState({ data: data })
    }

    callback = async (res) => {
        try {
            let r = await res;
            if (r.data) {
                if (!r.data.success) {
                    this.setState(({ errors }) => ({
                        errors: {
                            ...errors,
                            pan: r.data.message,
                        },
                    }));
                }
            } else {
                throw r.data.message.toString();
            }
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };

    onDateChange = async (e) => {
        let d = await e.target.value;
        this.setState(({ data }) => ({
            data: {
                ...data,
                dob: d,
            },
        }));
        if (!this.state.data.dob.includes("_")) {
            if (Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "" },
                }));
            } else {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "Date Of Birth field is invalid." },
                }));
            }
        }
    };


    onChangePurchaseDate = async (e) => {
        let d = await e.target.value;
        this.setState(({ data }) => ({
            data: {
                ...data,
                purchaseDate: d,
            },
        }));
        if (!this.state.data.purchaseDate.includes("_")) {
            if (Moment(this.state.data.purchaseDate, "DD-MM-YYYY", true).isValid()) {
                this.setState(({ errors }) => ({
                    errors: { ...errors, purchaseDate: "" },
                }));
            } else {
                this.setState(({ errors }) => ({
                    errors: { ...errors, purchaseDate: "Purchase Date field is invalid." },
                }));
            }
        }
    };

    handleProceed = () => {
        let formData = {
            mobile: this.state.data.mobileNumber,
            id: this.props.updatedData.id,
            isNonAsm: false,
        }
        this.props.saveQuote(formData, this.callbackSaveQuote);
    }

    callbackSaveQuote = (res) => {
        if (res.data) {
            let newData = res.data.ckycData;
            let customerData = JSON.parse(localStorage.getItem("customerDetails"));

            localStorage.setItem("customerDetails", JSON.stringify
                ({
                    ...customerData,
                    name: newData.Name ? newData.Name : "",
                    mobile: this.state.data.mobileNumber,
                    chassisNumber: this.state.data.chassisNumber,
                    address: newData.PermanentAddress ? newData.PermanentAddress : "",
                    pincode: newData.PermanentAddress ? newData.PermanentAddress.split(",")[res.data.data.PermanentAddress.split(",").length - 1] : "",
                    amount: this.props.getQuoteData.FinalPremium,
                    id: this.props.updatedData.id
                }))
            if (this.props.updatedData.stagename.toLowerCase() === "kyc rejected") {
                this.props.history.push(PATH.PRIVATE.ASM_INSURANCE_KYC_SCREEN)
            } else {
                this.props.history.push(PATH.PRIVATE.ASM_INSURANCE_ADDITIONAL_DETAILS_ICICI)
            }
        }
    }



    render() {
        let quoteData = this.props?.getQuoteData;

        return <>
            {
                (this.props.loading || this.props.loadingPinCode || this.props.loadingChassisData || this.props.loadingGetQuote || this.props.loadingSaveQuote || this.props.loadingGetInfoFromRCNo) ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}
            <section className="bs-main-section asm" >

                <ASMNavBar
                    pin={this.state.details?.pin}
                    address={this.state.details?.address}
                    city={this.state.details?.city}
                    pinError={this.state.details?.pinError}
                    geoError={this.state.details?.geoError}
                    handleAddCustomer={this.handleAddCustomer}
                    isInsurance={true} />


                <Container className="asm-insurance">

                    <h1 className="main-title">Two Wheeler Insurance</h1>
                    <p className="sub-title">Revolt RV400</p>


                    <div className="row insideFormBlock">
                        <div className="col-sm-12">
                            {this.state.show ? "" : <form className="panVeryfyForm">
                                <div className="row">


                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.registrationNo}
                                            error={this.state.errors.registrationNo}
                                            icon={<LocationIcon />}
                                            label="Registration Number"
                                            readOnly={false}
                                            __handleChange={(e) => {
                                                this.setState({ data: { ...this.state.data, registrationNo: e.target.value.trim() } })
                                            }}
                                        />
                                    </div>


                                    <div className="col-sm-6" style={{ marginTop: "15px", marginLeft: "-40px" }}>
                                        <button
                                            type="button"
                                            onClick={this.getDataFromChessis}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Get Info
                                        </button>
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.chassisNumber}
                                            error={this.state.errors.chassisNumber}
                                            icon={<LocationIcon />}
                                            label="Chassis Number"
                                            readOnly={true}
                                        />
                                    </div>



                                    <div className="col-sm-6">
                                        <DateComponent
                                            value={this.state.data.purchaseDate}
                                            onDateChange={this.onChangePurchaseDate}
                                            error={this.state.errors.purchaseDate}
                                            label="Purchase Date"
                                            readOnly={true}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.rtoCode}
                                            error={this.state.errors.rtoCode}
                                            icon={<LocationIcon />}
                                            label="RTO Code"
                                            readOnly={true}
                                        />
                                    </div>

                                    <div className="col-sm-12 mt-3">
                                        <h1 className="sub-title">Enter Details to Update KYC</h1>
                                    </div>


                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.pan}
                                            __handleChange={this.__handlePANChange}
                                            error={this.state.errors.pan}
                                            icon={<LocationIcon />}
                                            label="PAN Number"
                                        /> </div>
                                    <div className="col-sm-6">
                                        <DateComponent
                                            value={this.state.data.dob?.length <= 10 ? this.state.data.dob : this.state.data.dob?.slice(8, 10) + "-" + this.state.data.dob?.slice(5, 7) + "-" + this.state.data?.dob?.slice(0, 4)}
                                            onDateChange={this.onDateChange}
                                            error={this.state.errors.dob}
                                            label="Date of Birth"
                                            readOnly={true}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.pincode}
                                            error={this.state.errors.pincode}
                                            icon={<LocationIcon />}
                                            label="Pincode"
                                            readOnly={true}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.mobileNumber}
                                            __handleChange={(e) => {
                                                let data = { ...this.state.data };
                                                let errors = { ...this.state.errors };

                                                let pattern = /^\d+\.?\d*$/;
                                                if (pattern.test(e.target.value) && e.target.value.trim().length <= 10) {
                                                    errors.mobileNumber = "";
                                                    data.mobileNumber = e.target.value.toUpperCase();
                                                    this.setState({ errors, data })
                                                }
                                                else if (pattern.test(e.target.value) === false && e.target.value.trim().length < 10) {
                                                    data.mobileNumber = e.target.value.toUpperCase();
                                                    errors.mobileNumber = "Mobile Number must be 10 digits long.";
                                                    this.setState({ errors, data })
                                                }
                                            }}
                                            error={this.state.errors.mobileNumber}
                                            icon={<LocationIcon />}
                                            label="Mobile Number"
                                        /> </div>

                                    <div className="col-sm-12 additional-cover-box">
                                        <h1>Additional Covers</h1>

                                        <div className="form-check mt-3">
                                            <input
                                                className="form-check-input"
                                                type="checkbox"
                                                name="checkedG"
                                                id="checkedG"
                                                onChange={(e) => {
                                                    let data = { ...this.state.data }
                                                    data.zeroDepreciation = !this.state.data.zeroDepreciation
                                                    this.setState({ data })
                                                }}
                                                checked={this.state.data.zeroDepreciation}
                                                style={{
                                                    cursor: "pointer"


                                                }}
                                            />
                                            <b>Zero Depreciation cover</b>
                                            <p>Every bike's parts depreciate over time and lose their market value. As a result, the coverage for the parts may be lower at the time of claim due to the deduction of the depreciated amount. By choosing this add-on, you can increase the payout for your claim and nullify the loss due to the market value drop.</p>
                                        </div>

                                        <div className="form-check">
                                            <input
                                                className="form-check-input"
                                                type="checkbox"
                                                name="checkedG"
                                                id="checkedG"
                                                onChange={(e) => {
                                                    let data = { ...this.state.data }
                                                    data.roadSideAssistance = !this.state.data.roadSideAssistance
                                                    this.setState({ data })
                                                }}
                                                checked={this.state.data.roadSideAssistance}
                                                style={{
                                                    cursor: "pointer"


                                                }}
                                            />
                                            <b>24x7 Roadside Assistance cover</b>
                                            <p>When your bike or scooter breaks down or meets with an accident, the roadside assistance add-on can cover you for battery jump-start, towing facility, flat tyre or minor repairs assistance, hotel stay or even a cab ride. For the complete list of services, visit our website.</p>
                                        </div>
                                    </div>

                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Get Quote
                                        </button>

                                    </div>
                                </div>
                            </form>}

                            {this.state.show ? <div>
                                <div className="col-sm-12 d-flex justify-content-between align-items-center mt-3" >
                                    <img
                                        className="backBtnICICI"
                                        src={LogoutIcon}
                                        onClick={(e) => {
                                            this.setState({ show: false })
                                        }}
                                    />
                                </div>
                                <div className="col-sm-12 insured-value-section">
                                    <span>Insured Declared Value</span>
                                    <span>{'₹' + Number(quoteData.IDV).toLocaleString('en-IN')}</span>
                                </div>
                                <div className="col-sm-12 get-quote-detail-box" >
                                    <div className="col-8">
                                        <h1>{Moment(quoteData.PolicyEndtDate).diff(Moment(quoteData.PolicyStartDate), 'years') + 1 > 1 ? (Moment(quoteData.PolicyEndtDate).diff(Moment(quoteData.PolicyStartDate), 'years') + 1) + ' Years' : ' Year'}</h1>
                                        <span>Protection for a single year</span>
                                    </div>

                                    <div className="col-4">
                                        <span className="font-weight-bold">Total Premium</span>
                                        <h1 className="mt-2">{'₹' + Number(quoteData.FinalPremium).toLocaleString('en-IN')}</h1>
                                        <span >with GST <b>{'₹' + Number(quoteData.GST).toLocaleString('en-IN')}</b></span>
                                    </div>
                                </div>


                                <div className="col-sm-12 breakup-section">

                                    <ul class="list-group">
                                        <li class="list-group-item d-flex justify-content-center align-items-center font-weight-bold active">
                                            Premium Breakup
                                        </li>
                                    </ul>

                                    <ul class="list-group mt-3">
                                        <li class="list-group-item d-flex justify-content-between align-items-center active">
                                            Liabilities
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Owner Driver PA Liability
                                            <span>{'₹' + Number(quoteData.MotorPremium.Liability.OwnerDriverPALiability).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Basic Liability
                                            <span>{'₹' + Number(quoteData.MotorPremium.Liability.BasicLiability).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Paid Driver Legal Liability
                                            <span>{'₹' + Number(quoteData.MotorPremium.Liability.PaidDriverLegalLiability).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <p className="font-weight-bold">Total Liability Premium</p>
                                            <span className="font-weight-bold">{'₹' + Number(quoteData.MotorPremium.Liability.TotalLiabilityPremium).toLocaleString('en-IN')}</span>
                                        </li>
                                    </ul>
                                    <ul class="list-group mt-3">
                                        <li class="list-group-item d-flex justify-content-between align-items-center active">
                                            Motor Own Damage
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Basic OD
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.BasicOD).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Ncb Protection Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.NcbProtectionPremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Garage Cash Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.GarageCashPremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Consumable Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.ConsumablePremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Engine Protect Plus Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.EngineProtectPlusPremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Key Protect Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.KeyProtectPremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Tyre Protect Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.TyreProtectPremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Loss Of Personal Belongings Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.LossOfPersonalBelongingsPremium).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Anti Theft Discount
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.AntiTheftDiscount).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Auto AssnMem Discount
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.AutoAssnMemDiscount).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            No Claim Bonus Discount
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.NoClaimBonusDiscount).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Voluntary Discount
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.VoluntaryDiscount).toLocaleString('en-IN')}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Rsa Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.RsaPremium).toLocaleString('en-IN')}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Zero Depreciation Premium
                                            <span>{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.ZeroDepreciationPremium).toLocaleString('en-IN')}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <p className="font-weight-bold">Total OwnDamage Premium</p>
                                            <span className="font-weight-bold">{'₹' + Number(quoteData.MotorPremium.MotorOwnDamage.TotalOwnDamagePremium).toLocaleString('en-IN')}</span>
                                        </li>
                                    </ul>

                                    <ul class="list-group mt-3">
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <p className="font-weight-bold">Break In Loading</p>
                                            <span className="font-weight-bold">{'₹' + Number(quoteData.MotorPremium.BreakInLoading).toLocaleString('en-IN')}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <p className="font-weight-bold">Ncb Discount</p>
                                            <span className="font-weight-bold">{'₹' + Number(quoteData.MotorPremium.NcbDiscount).toLocaleString('en-IN')}</span>
                                        </li>
                                    </ul>

                                </div>


                                <div className="col-sm-12 text-center">
                                    <button
                                        type="button"
                                        onClick={this.handleProceed}
                                        variant="contained"
                                        className="nextButton"
                                    >
                                        Proceed
                                    </button>

                                </div>
                            </div> : ""}
                        </div>
                    </div>

                    <CreditFooter />
                </Container>
            </section >
        </>
    }
}

const mapStateToProps = (state) => ({

    loading: getpanName(state).loading,
    loadingPinCode: getpinCode(state).loading,
    loadingChassisData: getICICI(state).loadingChassisData,
    loadingGetQuote: getICICI(state).loadingGetQuote,
    getQuoteData: getICICI(state).getQuoteData,
    updatedData: getICICI(state).updatedData,
    loadingSaveQuote: getICICI(state).loadingSaveQuote,
    loadingGetInfoFromRCNo: getICICI(state).loadingGetInfoFromRCNo,
    vehicleData: getICICI(state).vehicleData
});

const mapDispatchToProps = (dispatch) => ({
    loadPanName: (params, callback) => dispatch(loadPanName(params, callback)),
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
    fetchChesisData: (params, callback) => dispatch(fetchChesisData(params, callback)),
    getQuote: (params, callback) => dispatch(getQuote(params, callback)),
    saveQuote: (params, callback) => dispatch(saveQuote(params, callback)),
    getInfoFromRCNo: (params, callback) => dispatch(getInfoFromRCNo(params, callback))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ICICIMain)
);


