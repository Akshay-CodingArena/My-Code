import React, { Component } from "react";
import { Modal, Row, Col } from "react-bootstrap";
// import { ReactComponent as Close } from "../../include/assets/close.svg";

import SecureLS from "secure-ls";
import { withRouter } from "react-router-dom";
import { encryptStore } from "../../../Utils/store";
import { getOS } from "../../../Utils/device_function";
import DownloadAppModal from "../../../common/DownloadApp";
import CONSTANTS from "../../../constants/Constants";
import PATH from "../../../paths/Paths";

import SetEmailForm from "../../Authentication/plLogin/SetEmailForm";
import LoginForm from "../../Authentication/plLogin/LoginForm";
import OTPForm from "../../Authentication/plLogin/otpForm";
import LoginFormCC from "../../Authentication/creditCLogin/LoginForm";
import OTPFormCC from "../../Authentication/creditCLogin/otpForm";

let localStore = new SecureLS({
    encodingType: "aes",
    isCompression: true,
});

class CustomerLogin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            initialStep: 1,
            step: 1,
            showOTP: false,
            otp: "",
            OTPError: "",
            stgOneHitId: "",
            stgTwoHitId: "",
            resend: false,
            data: {},
            cardApplied: {}
        };
    }

    componentDidMount = () => {
        let cardsCompare = JSON.parse(localStorage.getItem("cardsCompare"));
        let utmUrl = localStorage.getItem("creditUTMLink");
        // localStorage.clear();
        // localStore.removeAll();
        // localStorage.removeItem("GCToken");
        if (cardsCompare) {
            localStorage.setItem("cardsCompare", JSON.stringify(cardsCompare));
            if (utmUrl) {
                localStorage.setItem("creditUTMLink", utmUrl);
            }
        }
        this.setState({ ...this.state, cardApplied: this.props.appliedCard, handleCloseLogin: this.props.handleCloseLogin });



        ///////////////step added in case of CC///////////
        if (this.props.step) {
            this.setState({ step: this.props.step, initialStep: this.props.step })
        }
    }

    updateStep = (e, page) => {
        if (e) e.preventDefault();
        this.setState({ ...this.state, step: page });
    };

    setData = (data) => {
        this.setState({ ...this.state, data: data(this.state.data) })
    }

    leftSideStep = () => {
        switch (this.state.step) {
            case 1:
                return (
                    <LoginForm
                        loginCustomer={this.props.loginCustomer}
                        updateStep={this.updateStep}
                        data={this.state.data}
                        setData={this.setData}
                        isAddCustomer={true} />
                );
            case 2:
                return (
                    <OTPForm
                        updateStep={this.updateStep}
                        data={this.state.data}
                        setData={this.setData}
                        isAddCustomer={true}
                        handleCloseLogin={this.props.handleCloseLogin} />
                );
            case 3: {
                return <SetEmailForm isAddCustomer={true} />;
            }

            case 4: return <LoginFormCC
                loginCustomer={this.props.loginCustomer}
                updateStep={this.updateStep}
                data={this.state.data}
                setData={this.setData}
                isCustomerASM={true}
            />

            case 5: return <OTPFormCC
                loginCustomer={this.props.loginCustomer}
                updateStep={this.updateStep}
                data={this.state.data}
                setData={this.setData}
                isCustomerASM={true}
            />
            case 6:
                const mobile = localStorage.getItem("mobilenumber");
                const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
                let storeData = { loanType: loanType }
                encryptStore(mobile, storeData)
                this.props.history.push({
                    pathname: PATH.PRIVATE.PAN_VERIFY,
                    state: {
                        isASMFlow: true
                    }
                })
                break;

            default:
                break;
        }
    };


    onHide = () => {
        return null
    }
    checkUTMLinks = () => {
        if (window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_TWO_WHEELER) {
            return false;
        } else if (
            window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_PERSONAL_LOAN
        ) {
            return false;
        } else if (
            window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_CREDIT_CARD
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_TWO_WHEELER
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_PERSONAL_LOAN
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_BUSINESS_LOAN
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_CARD
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_SCORE
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_HOME_LOAN
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_PHONEPE_HIDE_POPUP.UTM_CREDIT_CARD
        ) {
            return false;
        }
        else {
            return true;
        }
    };
    render() {
        //    console.log("Modal Openend", this.state.step, this.state)
        return (
            <Modal className="bsOtpbox ccLoginBox" show={this.props.show} onHide={this.onHide}>
                <Modal.Body style={{ textAlign: "center" }}>
                    {" "}
                    <div className="row d-flex justify-content-center align-items-center h-100">
                        <button type="button" class="close" onClick={() => {
                            this.props.handleCloseLogin();

                            this.setState({
                                step: this.state.initialStep,
                                showOTP: false,
                                otp: "",
                                OTPError: "",
                                stgOneHitId: "",
                                stgTwoHitId: "",
                                resend: false,
                                data: {},
                                cardApplied: {}
                            })

                        }}><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                        <div className="d-flex">
                            {this.leftSideStep()}

                        </div>


                        {/* <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2">
                                        {this.leftSideStep()}
                                    </div> */}
                    </div>

                </Modal.Body>
            </Modal>
        )
    }
}

export default withRouter((CustomerLogin))
