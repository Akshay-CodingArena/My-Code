import { useEffect, useRef, useState } from "react";
import { Col, Container, Modal, ModalFooter, Row, Table } from "react-bootstrap";
import { useHistory, useLocation } from "react-router-dom";
import PATH from "../../paths/Paths";
import CustomerLogin from "./AddCustomer/CustomerLogin";
import ASMNavBar from "./ASMNavBar";
import UsersIcon from "../../include/assets/moneyPlus/users.svg"
import LocationIcon from "../../include/assets/moneyPlus/location.svg"
import { useDispatch, useSelector } from "react-redux";
import { loadPinCode } from "../../store/pincode";
import CreditFooter from "../cibilFlow/footer";
import DateRangePicker from '@wojtekmaj/react-daterange-picker'
import { getFullDay, getMonthName } from "./DateConverter";
import { numberFormat, numberFormatASM } from "../../Utils/numberFormat";
import CreatableSelect from "react-select/creatable";
import SelectSearch from "../common/select";
import ShowEntries from "../../common/ShowEntries";
import SearchBar from "../../common/SearchBar";
import Paging from "../../common/Pagination";
import CalenderIcon from "../../include/assets/moneyPlus/calendar.svg"
import ArrowDown from "../../include/assets/moneyPlus/down-arrow.svg"
import ApprovedIcon from "../../include/assets/moneyPlus/approvedApplication.svg"
import DisbursedIcon from "../../include/assets/moneyPlus/disbursedApplication.svg"
import ProgressIcon from "../../include/assets/moneyPlus/inProgressApplication.svg"
import RejectedIcon from "../../include/assets/moneyPlus/rejectedApplication.svg"
import TotalIcon from "../../include/assets/moneyPlus/totalApplication.svg"
import fileIcon from "../../include/assets/moneyPlus/doc.svg"
import editIcon from "../../include/assets/moneyPlus/edit.svg"
import IconsGenerator from "./IconsGenerator";
import BankDetails from "../PersonalLoanJourney/BankDetailsVerification/BankDetails";
import { decryptStore, encryptStore } from "../../Utils/store";
import CONSTANTS from "../../constants/Constants";
import { asmDashboard, asmGenerateToken, getASM } from "../../store/asm";
import BackDropComponent from "../../common/BackDropComponent";
import { months } from "../CibilCheck/accountType";
import { getAccountInfo } from "../../store/account";
import { JourneyContinueMoneyplus } from "../TwoWheelerJourney/Revolt/loanStages";
import InsuranceLogo from "../../include/assets/icons/insurance.png";
import { getOffer } from "../../store/bankOffer";

let debounce = () => {
    let id
    let debounceTime = 1000
    return (asmApplications, asmDashboard, formData, callbackAsmDashboard) => {
        clearTimeout(id)
        id = setTimeout(() => {
            asmApplications(asmDashboard(formData, callbackAsmDashboard))
        }, debounceTime)
    }
}

let wrapper = debounce()

const CreditCard = ({ showInsurance, setShowInsurance }) => {
    // const history = useHistory()
    const [login, setLogin] = useState()
    const asmApplications = useDispatch()
    const [state, setState] = useState({})
    const [dateFilter, setDateFilter] = useState([])
    const [calender, setCalender] = useState(false)
    const [currPage, setCurrPage] = useState(1)
    const [offset, setOffset] = useState(10)
    const [totalPage, setTotalPage] = useState(1)
    const [searchQuery, setSearch] = useState(null)
    const [loginCustomer, setLoginCustomer] = useState("")
    const history = useHistory()
    const loanNameRef = useRef("")
    const [showDetails, setShowDetails] = useState({})

    let { customerDetail } = useSelector(state => (state.entities.account));

    const handleAddCustomer = () => {
        // history.push({ pathname: PATH.PUBLIC.GET_CREDIT_CARD })
        setLogin(true);
    }

    let [currentStatus, setCurrentStatus] = useState("total")

    const dummy = [["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Approved"],
    ["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Pending"], ["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Approved"],
    ["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Approved"], ["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Approved"],
    ["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Approved"], ["12/02/2023", "LA-409090", "9731723123", "Naresh Singh", "120000", "90000", "Approved"],]


    let loanPayload = {
        "total": {
            "applicationProgress": false,
            "applicationapproved": false,
            "applicationdisbursed": false,
            "applicationrejected": false,
        },
        "applicationProgress": {
            "applicationProgress": true,
            "applicationapproved": false,
            "applicationdisbursed": false,
            "applicationrejected": false,
        },
        "applicationapproved": {
            "applicationProgress": false,
            "applicationapproved": true,
            "applicationdisbursed": false,
            "applicationrejected": false,
        },
        "applicationdisbursed": {
            "applicationProgress": false,
            "applicationapproved": false,
            "applicationdisbursed": true,
            "applicationrejected": false,
        },
        "applicationrejected": {
            "applicationProgress": false,
            "applicationapproved": false,
            "applicationdisbursed": false,
            "applicationrejected": true,
        }
    }
    const callbackAsmDashboard = (res) => {
        if (res) {

            let { applicationApproved, applicationDisbursed, applicationProgress, applicationRejected, totalApplication, listResult } = res.data?.details
            let { searchCount } = res.data?.details
            setState({
                ...state,
                searchCount,
                applicationApproved, applicationDisbursed, applicationProgress, applicationRejected, totalApplication, listResult
            })
            setTotalPage(Math.ceil(searchCount / offset))
        }
    }
    useEffect(() => {

        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        if (!localStorage.getItem("isASM")) {
            if (window) {
                window.location.href = (window.location.origin + "/backoffice-login")
            }
        }
        let fromDate = new Date()
        fromDate.setDate(fromDate.getDate() - 7)
        setDateFilter([dateFormatter(fromDate), dateFormatter(new Date())])

        setState({
            ...state,
            pin: localStorage.getItem("pin"),
            city: localStorage.getItem("city"),
            address: localStorage.getItem("ASM_Address")
        })

    }, [])

    useEffect(() => {
        const formData = {
            ...loanPayload[currentStatus],
            "asm_id": parseInt(localStorage.getItem('ASM_Id')),
            "start_date": sendDateFormatter(dateFilter[0]),
            "end_date": sendDateFormatter(dateFilter[1]),
            "offset": offset,
            "loanType": "Credit_Card",
            "page_number": currPage - 1,
            "search_param": searchQuery?.toUpperCase() ? searchQuery?.toUpperCase() : ""
        }
        //  setDateFilter([dateFormatter(new Date()), dateFormatter(new Date())])
        if (dateFilter[0]) {
            asmApplications(asmDashboard(formData, callbackAsmDashboard))
        }
    }, [dateFilter, offset, currPage, currentStatus])

    const sendDateFormatter = (date) => {
        //30 Mar 2023
        if (date) {
            let year = date.slice(7)
            let monthKeys = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
            let month = monthKeys.filter((month) => months[month] === date.slice(3, 6))
            let day = date.slice(0, 2)
            return `${year}-${month}-${day}`
        }

    }

    useEffect(() => {
        if (searchQuery != null) {
            const formData = {
                ...loanPayload[currentStatus],
                "asm_id": parseInt(localStorage.getItem('ASM_Id')),
                "start_date": sendDateFormatter(dateFilter[0]),
                "end_date": sendDateFormatter(dateFilter[1]),
                "offset": offset,
                "page_number": currPage - 1,
                "search_param": searchQuery?.toUpperCase(),
                "loanType": "Credit_Card"
            }
            //  setDateFilter([dateFormatter(new Date()), dateFormatter(new Date())])
            if (dateFilter[0]) {
                wrapper(asmApplications, asmDashboard, formData, callbackAsmDashboard)
            }

            //  debounce()();
        }

    }, [searchQuery])

    const handleLoginCustomer = (mobile) => {
        setLoginCustomer(mobile)
        setLogin(true)
    }

    const dateFormatter = (date) => {

        const fromDay = getFullDay(date.getDate())
        const fromMonth = getMonthName(date.getMonth() + 1)
        const fromYear = date.getFullYear()
        return `${fromDay} ${fromMonth} ${fromYear}`
    }
    const changeDate = (range) => {
        if (range) {
            const fromDay = getFullDay(range[0].getDate())
            const toDay = getFullDay(range[1].getDate())
            const fromMonth = getMonthName(range[0].getMonth() + 1)
            const toMonth = getMonthName(range[1].getMonth() + 1)
            const fromYear = range[0].getFullYear()
            const toYear = range[1].getFullYear()

            setDateFilter([`${fromDay} ${fromMonth} ${fromYear}`, `${toDay} ${toMonth} ${toYear}`])
        }
    }

    const callBackToken = (res) => {
        if (res.data?.success) {
            let mobile = res.data.data.data[0].pl_mobile_no__c
            console.log("access ytoken", res.data.data.accessToken)
            localStorage.setItem("accessToken", res.data.data.accessToken)
            localStorage.setItem("mobilenumber", mobile)
            asmApplications(getAccountInfo({ mobile: mobile }, callBackDetails))
        }
    }


    const callBackGet = (res) => {
        if (res) {
            if (res.data.success) {
                if (res.data.breData[0]?.loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
                    history.push({
                        pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
                        state: res.data,
                    });
                } else if (res.data.breData[0]?.loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
                    history.push({
                        pathname: PATH.PRIVATE.HOME_LOAN_OFFERS,
                        state: res.data,
                    });
                }
            }
        }
    };

    const callBackDetails = (res) => {
        if (res) {
            localStorage.setItem("accsfid", res.data.customer.accsfid);
            localStorage.setItem("fullName", res.data.customer.name);
            localStorage.setItem("email", res.data.customer.personemail);
            localStorage.setItem("firstName", res.data.customer.firstname);
            localStorage.setItem("lastName", res.data.customer.lastname);
            localStorage.setItem("pan", res.data.customer.panNumber);

            let loanData = res.data?.details?.loanData.length ? res.data.details.loanData[0].pl_loans.filter(loanData => loanData.loanName === loanNameRef.current) : []
            if (loanData.length) {

                let e = loanData[0];

                let mobile = localStorage.getItem("mobilenumber");

                let storeData = {
                    loansfid: e.loanId,
                    loanName: e.loanName,
                    loanType: e.loanType,
                };

                encryptStore(mobile, storeData);


                if (e.loanStage === "Disbursement") {
                    history.push({
                        pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`,
                        state: e,
                    });
                }


                else if (e.lenderName === "HDFC") {
                    let storeData = {
                        loanAmount: e.appliedLoanAmount,
                        proposedEmi: e.emi,
                        tenure: parseInt(e.pl_applied_tenure__c),
                        monthlySalary: res.data.customer.monthlysalary,
                        employerNameCode: res.data.customer.pl_employer__pc,
                        stageName: e.loanStage,
                        isDropoff: true,
                        lenderName: e.lenderName,
                        applicationId: e.application_id ? e.application_id : "",
                        loanName: e.loanName ? e.loanName : "",
                        lenderId: e.lender_id__c ? e.lender_id__c : "",
                        sfid: e.loanSfid ? e.loanSfid : "",
                        platform: "Website"
                    }
                    encryptStore(mobile, storeData);
                    let appliedLoanInfo =
                    {
                        IRR: e.IRR,
                        PF: e.PF,
                        appliedLoanAmount: e.appliedLoanAmount,
                        bankImage: e.bankImage,
                        emi: e.emi,
                        pl_applied_tenure__c: e.pl_applied_tenure__c
                    }
                    if (e.loanStage === "Application in Review" ||
                        e.loanStage === "Under Process" ||
                        e.loanStage === "Case Initiated" ||
                        e.loanStage === "Duplicate case" ||
                        e.loanStage === "Pre-Sanction Document Check" ||
                        e.loanStage === "Decision Awaited" ||
                        e.loanStage === "Disbursement Under Process" ||
                        e.loanStage === "Disbursed" ||
                        e.loanStage === "Approved" ||
                        e.loanStage === "Additional Documents / Check pending" ||
                        e.loanStage === "Reject" ||
                        e.loanStage === "Cancelled" ||
                        e.loanStage === "Verification Pending"
                    ) {

                        let dataToEncrypt = {
                            Filler1: e.filler1 ? e.filler1_as_resp : "",
                            Filler4: e.filler4 ? e.filler1_as_resp : "",
                            deviceId: e.device_id ? e.device_id : "",
                        }

                        encryptStore(mobile, dataToEncrypt);

                        history.push({
                            pathname: PATH.PRIVATE.HDFC_PL_FLOW,
                            state: {
                                step: CONSTANTS.CONGRATULATIONS_HDFC,
                                stepperData: {},
                                appliedLoanInfo: appliedLoanInfo,
                                dropoffData: e,
                                stepperStep: 6
                            }
                        })

                    } else if (e.loanStage === "Declined") {
                        history.push({
                            pathname: PATH.PRIVATE.HDFC_PL_FLOW,
                            state: {
                                step: CONSTANTS.FAILED_SCREEN_HDFC,
                                stepperData: {},
                                appliedLoanInfo: appliedLoanInfo,
                                dropoffData: e,
                                stepperStep: 1
                            }
                        })
                    }
                    else {
                        history.push({
                            pathname: PATH.PRIVATE.HDFC_PL_FLOW,
                            state: {
                                step: CONSTANTS.ADDITIONAL_INFO_HDFC_PL,
                                stepperData: {},
                                appliedLoanInfo: appliedLoanInfo,
                                dropoffData: e
                            }
                        })
                    }
                }
                else if (
                    e.loanStage !== "Assigned" ||
                    e.loanStage !== "Soft Approved" ||
                    e.loanStage !== "Declined"
                ) {
                    if (e.loanStage === "Offers") {
                        let formData =
                            "mobile=" +
                            mobile +
                            "&loanId=" +
                            e.loanId +
                            "&loanType=" +
                            e.loanType;

                        asmApplications(getOffer(formData, callBackGet));
                    } else if (
                        e.loanStage === "Mobile Registered" ||
                        e.loanStage === "customer details" ||
                        e.loanStage === "Basic Loan Details" ||
                        e.loanStage === "Captured"
                    ) {
                        if (customerDetail.pan_verified__c === true) {
                            history.push(PATH.PRIVATE.PERSONAL_DETAIL);
                        } else {
                            history.push(PATH.PRIVATE.PAN_VERIFY);
                        }
                    } else {
                        history.push({
                            pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`,
                            state: e,
                        });
                    }
                } else {
                    history.push({
                        pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`,
                        state: e,
                    });
                }
            }
        }
    }

    const handleContinue = (mobile, loanName) => {
        loanNameRef.current = loanName
        let formData = {
            "mobile": mobile,
            "asm_id": localStorage.getItem("ASM_Id")
        }
        asmApplications(asmGenerateToken(formData, callBackToken))
    }

    const handleShowDetails = (index) => {

        setShowDetails(state?.listResult[index])
    }

    const handleInsurance = () => {
        history.push({ pathname: PATH.PRIVATE.ASM_INSURANCE_ICICI })
    }

    return <>
        {useSelector(state => (state.entities.asm.asmLoading || state.entities.account.loading)) ? < BackDropComponent /> : null}
        {Object.keys(showDetails)?.length ? <Modal
            // className="DownLoadAppModal campaignModal"
            show={showDetails}
            onHide={() => setShowDetails(false)}
            dialogClassName="modal-90w"
            aria-labelledby="example-custom-modal-styling-title"
        >
            <Modal.Header closeButton><strong>Loan Details</strong></Modal.Header>
            <Modal.Body className="text-center">
                <div className="DownLoadAppBlock">
                    <p>Application No:<span style={{ fontWeight: 'bold' }}> {showDetails['appliednumber']}</span></p>
                    <p>Customer Name:<span style={{ fontWeight: 'bold' }}> {showDetails['username']}</span></p>
                    <p>Bank Name:<span style={{ fontWeight: 'bold' }}> {showDetails['lendername']}</span></p>
                    <p>Approved Amount:<span style={{ fontWeight: 'bold' }}> {showDetails['amountapproved'] ? numberFormat(showDetails['amountapproved']) : "-"}</span></p>
                    <p>Tenure:<span style={{ fontWeight: 'bold' }}> {showDetails?.['pl_revised_tenure__c'] ? showDetails?.['pl_revised_tenure__c'] + " Months" : "-"}</span></p>
                    <p>EMI:<span style={{ fontWeight: 'bold' }}> {showDetails['pl_revised_emi__c'] ? numberFormat(showDetails['pl_revised_emi__c']) : "-"}</span></p>
                    <p>Rate of Interest:<span style={{ fontWeight: 'bold' }}> {showDetails?.['pl_roi__c']}%</span></p>
                </div>
            </Modal.Body>
        </Modal> : null}
        <section className="bs-main-section asmDashBoard asm" >
            <ASMNavBar
                pin={state.pin}
                address={state?.address}
                city={state.city}
                pinError={state.pinError}
                geoError={state.geoError}
                handleAddCustomer={handleAddCustomer}
                isCreditCard={true}
            />

            <CustomerLogin show={login} loginCustomer={loginCustomer} handleCloseLogin={() => setLogin(false)} step={4} />

            <Container>
                <Row>
                    <div className="col-sm-8"><p className="font-weight-bolder">Welcome !<span className="ml-1" style={{ fontWeight: 'bold' }}> {` ${localStorage.getItem("ASM_firstName")}`}</span></p> </div>
                    <div className="col-sm-4" style={{ height: '30px' }}>
                        {calender ? <div className="d-flex justify-content-end">
                            <DateRangePicker calendarIcon={<img src={CalenderIcon} />} clearIcon={<img src={ArrowDown} />} onCalendarClose={() => setCalender(false)} isOpen={calender} id="dateSelector" returnValue="range" value={dateFilter} onChange={changeDate} maxDate={new Date()} />
                        </div> :
                            <div className="d-flex justify-content-end" onClick={() => setCalender(true)}><img className="calenderIcon" src={CalenderIcon} /><p className="calenderDate">{`${dateFilter[0]} - ${dateFilter[1]}`}</p><img src={ArrowDown} className="calenderClearIcon" /></div>}
                    </div>
                    {/* <div className="col-sm-12 d-flex  justify-content-space-between flex-row-reverse mt-4 pb-4 asmDashoardShadow mobileBlock" >
                        <div className="d-flex align-items-center justify-content-end mt-4 mobileCenter" style={{ width: '100%' }}>
                            <img style={{ height: '100%' }} className="mr-4" src={UsersIcon} alt="" />
                        </div>
                        <div className="col-sm-6 pt-4 mobileCenter">
                            <h2 style={{ fontWeight: 'bold' }}>What is Personal Loan</h2>
                            <h4>hafhweoifweknanflk isahioewqhfa fds fkjbsgjbsd sajffw ef ds ds f fjdsf s jdsdsfsddsfdsf f dsfds fs</h4>
                            <button
                                type="submit"
                                onClick={handleAddCustomer}
                                variant="contained"
                                className="nextButton addCustomerBtn"
                            >
                                Add Customer
                            </button>
                        </div>

                    </div> */}

                    <div >
                        <p className="font-weight-bolder mt-4">
                            <ul class="nav nav-tabs">
                                <li class="nav-item">
                                    <a class={`nav-link`} aria-current="page" onClick={() => {
                                        localStorage.setItem("ASM_Flow_For", "loans")
                                        setShowInsurance("loans")
                                    }} >Loans</a>
                                </li>
                                <li class="nav-item">
                                    <a class={`nav-link`} aria-current="page" onClick={() => {
                                        localStorage.setItem("ASM_Flow_For", "insurance")
                                        setShowInsurance("insurance")
                                    }}>Insurance</a>
                                </li>
                                <li class="nav-item">
                                    <a class={`nav-link active`} aria-current="page" onClick={() => {
                                        localStorage.setItem("ASM_Flow_For", "credit card")
                                        setShowInsurance("credit card")
                                    }}>Credit Card</a>
                                </li>
                            </ul>
                        </p>
                    </div>

                    {/* <button
                        type="submit"
                        onClick={handleInsurance}
                        variant="contained"
                        className="nextButton addCustomerBtn"
                    >
                        Insurance
                    </button> */}


                    <div className="col-sm-12">
                        <p className="font-weight-bolder mt-4">Loan Status<span className="font-weight-bold ml-1">List</span></p></div>

                    <div class="container mt-1">
                        <div class="row">
                            <div class='col - 6 col-md-4 col-lg col-sm-6 col-xs-6' style={{ cursor: "pointer" }} onClick={() => {
                                setCurrPage(1)
                                setCurrentStatus("total")
                            }
                            }>
                                <div className={`pt-4 pb-4 asmCard ${currentStatus === "total" ? 'asmCardActive' : ''}`}>
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={TotalIcon} />
                                        {/* <img className="mr-1 " src={UsersIcon} alt="" /> */}
                                        <p className="asmAppCount">{state?.totalApplication ? numberFormatASM(state?.totalApplication) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Total Application</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6" style={{ cursor: "pointer" }} onClick={() => {
                                setCurrPage(1)
                                setCurrentStatus("applicationProgress")
                            }}>
                                <div className={`pt-4 pb-4 asmCard ${currentStatus === "applicationProgress" ? 'asmCardActive' : ''}`}>
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={ProgressIcon} />
                                        <p className="asmAppCount">{state.applicationProgress ? numberFormatASM(state.applicationProgress) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Application In Progress</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6 " style={{ cursor: "pointer" }} onClick={() => {
                                setCurrPage(1)
                                setCurrentStatus("applicationapproved")
                            }}>
                                <div className={`pt-4 pb-4 asmCard ${currentStatus === "applicationapproved" ? 'asmCardActive' : ''}`}>
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={ApprovedIcon} />
                                        <p className="asmAppCount">{state.applicationApproved ? numberFormatASM(state?.applicationApproved) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Application Approved</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6" style={{ cursor: "pointer" }} onClick={() => {
                                setCurrPage(1)
                                setCurrentStatus("applicationdisbursed")
                            }}>
                                <div className={`pt-4 pb-4 asmCard ${currentStatus === "applicationdisbursed" ? 'asmCardActive' : ''}`}>
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={DisbursedIcon} />
                                        <p className="asmAppCount">{state?.applicationDisbursed ? numberFormatASM(state?.applicationDisbursed) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Application Disbursed</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6" style={{ cursor: "pointer" }} onClick={() => {
                                setCurrPage(1)
                                setCurrentStatus("applicationrejected")
                            }}>
                                <div className={`pt-4 pb-4 asmCard ${currentStatus === "applicationrejected" ? 'asmCardActive' : ''}`}>
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={RejectedIcon} />
                                        <p className="asmAppCount">{state?.applicationRejected ? numberFormatASM(state?.applicationRejected) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Application Rejected</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container mt-1">
                        <div className="mt-4"><p className="font-weight-bolder">User Loan <span className="font-weight-bold">View</span></p></div>
                        <div className="col-12 mt-3 pt-2 pb-4 asmDashoardShadow">
                            <div className="row">
                                <div className="col-md-6 order-xs-1 order-md-2 col-sm-7 pt-4 asmmobileSearchBar">
                                    <SearchBar search={searchQuery} setSearch={setSearch} />
                                </div>
                                <div className="col-md-6 order-xs-2 order-md-1 col-sm-6 d-flex pt-4">
                                    <p className="font-weight-bolder asm">Show</p><div style={{ marginTop: "-6px", marginLeft: "15px" }}>
                                        <ShowEntries totalApplication={state.searchCount} offset={state?.searchCount < 10 ? state.searchCount : offset} setOffset={setOffset} setCurrPage={setCurrPage} />
                                    </div>
                                    <p className="font-weight-bolder ml-2">Entries</p>
                                </div>
                            </div>
                            <div style={{ overflow: "auto" }}>
                                <Table className="asmLoansTable striped">
                                    <thead>
                                        <tr>
                                            <th>Appl. Date</th>
                                            <th>Appl. No</th>
                                            <th>Mobile No.</th>
                                            <th>Name</th>
                                            <th>Card Name</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {state?.listResult?.map((data, index) => (
                                            <tr >
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['applieddate'] ? dateFormatter(new Date(data['applieddate'])) : '-'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['appliednumber'] ?? '-'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['mobilenumber'] ?? '-'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['username'] ?? '-'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['card_name__c'] ? data['card_name__c'] : '-'}</p>
                                                </td>

                                                <td className={`${data['status'].includes("Failed") || data['status'].includes("Rejected") ? "text-danger" : "text-success"}`} align="left">
                                                    <p className="font-weight-bolder">{data['status']}</p>
                                                </td>

                                            </tr>
                                        ))}

                                    </tbody>

                                </Table>
                            </div>
                            <div className="row mt-2">
                                {state.searchCount ? <p className="asmFontSmall col-md-6 col-xs-12">{`Showing ${(offset * (currPage - 1)) + 1} to ${state.searchCount < (offset * currPage) ? state.searchCount : offset * currPage} of ${state.searchCount} entries`}</p> : <p className="asmFontSmall col-md-6 col-xs-12">No entries found</p>}
                                <div className="col-md-6 col-xs-12 d-flex" style={{ flexDirection: 'row-reverse' }}>
                                    {totalPage > 1 ? <Paging pages={totalPage} currPage={currPage} setCurrPage={setCurrPage} /> : null}
                                </div>
                            </div>
                        </div>
                    </div>
                </Row>
                <CreditFooter />
            </Container>
        </section >
    </>
}

export default CreditCard;