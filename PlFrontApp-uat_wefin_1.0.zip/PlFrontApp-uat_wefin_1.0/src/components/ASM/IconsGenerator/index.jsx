function IconsGenerator(props) {
    return (
        <div className="d-flex justify-content-center align-items-center asmIconContainer" >
            <img className="asmIconSize" src={props.icon} />
        </div>
    )
}

export default IconsGenerator