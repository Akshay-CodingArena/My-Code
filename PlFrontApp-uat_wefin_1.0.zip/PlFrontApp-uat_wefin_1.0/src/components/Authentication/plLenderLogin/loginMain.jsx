import React, { useEffect } from "react";
import LeftMenuDecider from "../../../common/leftMenuContent";
import LoginForm from "./LoginForm";
import SecureLS from "secure-ls";
import SetEmailForm from "./SetEmailForm";
import OTPForm from "./otpForm";
import BottomSection from "../../../common/bottom";
import CreditFooter from "../../cibilFlow/footer";

import DownloadAppModal from "../../../common/DownloadApp";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const LoginPLMain = () => {
  const [step, setStep] = React.useState(1);
  const [data, setData] = React.useState({});
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  useEffect(() => {
    localStorage.clear();
    localStore.removeAll();
    localStorage.removeItem("GCToken");
  }, []);

  const leftSideStep = () => {
    switch (step) {
      case 1:
        return (
          <LoginForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 2:
        return (
          <OTPForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 3: {
        return <SetEmailForm />;
      }
      default:
        break;
    }
  };
  const checkUTMLinks = () => {
    if (window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_TWO_WHEELER) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    } else {
      return true;
    }
  };

  return (
    <>
      {getOS() !== "desktop" && checkUTMLinks() && <DownloadAppModal />}
      <section className="bs-login-section">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1">
              <div>
                <LeftMenuDecider leftComponent={2} />
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2">
              {leftSideStep()}
            </div>
          </div>
        </div>
      </section>
      <section className="cs-login-content">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Personal loans </h2>
              <p>
                Personal loans are a type of an unsecured form which is meant
                for immediate requirements. It can be used for various purposes
                including wedding, home renovation, travel purposes and more.
                Moreover, you can borrow up to 40 lakhs and can be used for any
                purpose. It also helps you to build your credit faster when
                compared with other forms of credit.
              </p>
              <h5>Eligibility Criteria</h5>
              <p>
                Following details are evaluated by lending partners while
                reviewing your loan applications.
              </p>
              <table>
                <tr>
                  <th>Criteria</th>
                  <th>Salaried</th>
                  <th>Self-Employed</th>
                </tr>
                <tr>
                  <td>Age </td>
                  <td>21 years to 60 years</td>
                  <td>22 years to 60 years</td>
                </tr>
                <tr>
                  <td>Monthly Salary</td>
                  <td>Rs. 15,000</td>
                  <td>Rs. 25,000</td>
                </tr>
                <tr>
                  <td>Minimum Loan Amount</td>
                  <td>Rs. 50,000</td>
                  <td>Rs. 50,000</td>
                </tr>
                <tr>
                  <td>Maximum Loan Amount</td>
                  <td>Rs. 40 lakh</td>
                  <td>Rs. 1 Cr</td>
                </tr>

                <tr>
                  <td>Minimum Tenure of Loan</td>
                  <td>12 Months</td>
                  <td>12 Months</td>
                </tr>

                <tr>
                  <td>Maximum Tenure of Loan</td>
                  <td>60 Months</td>
                  <td>48 Months</td>
                </tr>
                <tr>
                  <td>Rate of Interest </td>
                  <td>10.25% * Onwards</td>
                  <td>16% * Onwards</td>
                </tr>
              </table>
              <p className="subject-tnc">
                *Subject to t&c of lender banks or NBFCs
              </p>
            </div>
          </div>
        </div>
      </section>
      <BottomSection />
      <CreditFooter />
    </>
  );
};

export default LoginPLMain;
