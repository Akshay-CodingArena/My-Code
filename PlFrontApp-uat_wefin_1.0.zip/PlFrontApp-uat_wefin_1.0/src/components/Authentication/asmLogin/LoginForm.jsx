import React, { Component } from "react";
import { ReactComponent as CallIcon } from "../../../include/assets/phoneIcon.svg";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
    setCustomerLogin,
    getCustomer,
    getCustomerOTP,
} from "../../../store/login";
import BackDropComponent from "../../../common/BackDropComponent";
import { getOS } from "../../../Utils/device_function";
import SecureLS from "secure-ls";
import Joi from "joi-browser";
import { getASM, loadLeadStatus, setASMLogin } from "../../../store/asm";
import PATH from "../../../paths/Paths";
import Swal from "sweetalert2";
import LeftMenuDecider from "../../../common/leftMenuContent";
import CreditFooter from "../../cibilFlow/footer";
import BottomSection from "../../../common/bottom";
import Form from "../../common/form";
class LoginForm extends Form {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                email: "",
                password: ""
            },
            errors: {
                email: "",
                password: ""
            },
            disable: false,
            loading: false,
        };
    }


    componentDidMount = () => {
        localStorage.clear();
    }


    schema = {
        email: Joi.string()
            .email()
            .max(50)
            .required()
            .label("Email")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "any.required":
                        case "any.empty":
                            err.message = "Email field is required.";
                            break;
                        case "string.email":
                            err.message = "Email field is invalid.";
                            break;
                        case "string.max":
                            err.message = "Email field is invalid.";
                            break;
                        default:
                            break;
                    }
                });
                return errors;
            }), password: Joi.string()
                .required()
                .regex(
                    new RegExp("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$ %^&*-]).{8,}$")
                )
                .error(errors => {
                    errors.forEach(err => {
                        console.log(err)
                        switch (err.type) {
                            case "any.empty":
                            case "any.required":
                                err.message = "Password is required.";
                                break;
                            case "string.regex.base":
                                err.message = "Invalid password format."
                                break;
                        }
                    });
                    return errors;
                }),
        isChecked: Joi.allow('')
    };



    __handleEmail = (event) => {
        const email = event.target.value;
        this.setState(({ errors, data }) => {
            return { ...this.state, data: { ...data, email: email } }
        })
    };

    __handlePassword = (event) => {
        const password = event.target.value;
        this.setState(({ errors, data }) => {
            return { ...this.state, data: { ...data, password: password } }
        })
    }

    handleSubmit = (e) => {
        e.preventDefault();
        const formData = {
            email: this.state.data.email,
            password: this.state.data.password,
            version: "1.0",
            platform:
                getOS() === "ios"
                    ? "web_ios"
                    : getOS() === "android"
                        ? "web_android"
                        : "web",
        };
        const options = { abortEarly: false };
        let errors = {}
        const { error } = Joi.validate(this.state.data, this.schema, options)
        error?.details.forEach(detail => {
            if (!errors.hasOwnProperty(detail.context.key))
                errors[detail.context.key] = detail.message
        })
        if (error) {
            this.setState({ ...this.state, errors: { ...errors } })
        }
        else {
            this.props.setASMLogin(formData, this.callBackLogin)
        }
    };

    callbackLeadStatus = (res) => {
        if (res.data.success) {
            debugger
            localStorage.setItem("leadStatusDropdown", JSON.stringify(res.data.data));
            this.props.history?.push(PATH.PRIVATE.FOS_DASHBOARD)
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: false,
                timer: 1000
            })
        }
    }

    callBackLogin = (res) => {
        if (res) {
            sessionStorage.setItem("logout", window.location.origin + "/backoffice-login")
            if (res?.data.isExisting === true) {
                let role = res.data?.data?.data[0]?.role__c.toUpperCase()
                if (role === "ASM") {
                    localStorage.setItem("ASM_Id", res.data.data?.data[0]?.id)
                    localStorage.setItem("ASM_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isASM", true);
                    localStorage.setItem("ASM_fullName", res.data.data?.data[0]?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c);
                    localStorage.setItem("state", res.data?.data?.data[0]?.state_name)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])
                    localStorage.setItem("ASM_Address", res.data?.data?.data[0]?.address__c)
                    this.props.history?.push(PATH.PRIVATE.ASM_DASHBOARD)
                }
                if (role === "FOS" || role === "FOS_CALL" || role === "FOS_ADMIN") {
                    localStorage.setItem("ASM_Id", res.data.data?.data[0]?.id)
                    localStorage.setItem("ASM_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isASM", true);
                    localStorage.setItem("ASM_fullName", res.data.data?.data[0]?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c);
                    localStorage.setItem("state", res.data?.data?.data[0]?.state_name)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])
                    localStorage.setItem("ASM_Address", res.data?.data?.data[0]?.address__c);
                    localStorage.setItem("role", role);

                    this.props.loadLeadStatus({}, this.callbackLeadStatus);

                }
                else if (role === "TELE_VERIFIER") {
                    localStorage.setItem("TeleVerify_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isTeleVerify", true)
                    localStorage.setItem("ASM_fullName", res.data?.data?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])
                    this.props.history?.push(PATH.PRIVATE?.TELE_VERIFICATION_DASHBOARD)
                    // console.log("Teleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
                }

                else if (role === "EXTERNAL_VERIFIER") {
                    localStorage.setItem("TeleVerify_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isExternalTeleVerify", true)
                    localStorage.setItem("ASM_fullName", res.data?.data?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])
                    this.props.history?.push(PATH.PRIVATE?.EXTERNAL_TELE_VERIFICATION_DASHBOARD)
                }
                else if (role === "DEALER") {
                    localStorage.setItem("ASM_Id", res.data.data?.data[0]?.id)
                    localStorage.setItem("ASM_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isASM", true);
                    localStorage.setItem("ASM_fullName", res.data.data?.data[0]?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c);
                    localStorage.setItem("state", res.data?.data?.data[0]?.state_name)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])

                    this.props.history?.push(PATH.PRIVATE.ASM_DASHBOARD)
                }
                else if (role === "MONEYPLUS_ADMIN") {

                    localStorage.setItem("ASM_Id", res.data.data?.data[0]?.id)
                    localStorage.setItem("TeleVerify_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isMoneyPlusAdmin", true);
                    localStorage.setItem("ASM_fullName", res.data.data?.data[0]?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c);
                    localStorage.setItem("state", res.data?.data?.data[0]?.state_name)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])
                    this.props.history?.push(PATH.PRIVATE.EXTERNAL_TELE_VERIFICATION_DASHBOARD)
                }
            } else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: "Invalid Email or Password",
                    showConfirmButton: false,
                    timer: 1000
                })
            }
        }
    }

    handleShow = (e) => {
        this.setState({
            ...this.state, showPassword: e.target.checked
        })
    }

    render() {
        return (
            <>
                <section className="bs-login-section" >
                    <div className="container">
                        <div className="row d-flex justify-content-center align-items-center h-100">
                            <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1" >
                                <div>
                                    <LeftMenuDecider leftComponent={2} />
                                </div>
                            </div>
                            <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2" style={{ height: '520px !important' }}>
                                <div className="bs-login-block" style={{ maxHeight: '520px', height: '520px' }} >
                                    {
                                        this.props.loadingLogin || this.props.loadingLogout || this.state.loading ? (
                                            <BackDropComponent />
                                        ) : (
                                            ""
                                        )
                                    }

                                    < form autoComplete="off" >
                                        <div className="bs-login-logo">
                                            <img alt="" src={NEO} />
                                        </div>

                                        <div className="LoginFormFields" style={{ margin: '20px 0px 0px 0px' }}>
                                            <div className="form-group">
                                                <label htmlFor="MobileNumber">Email/Username<span className="text-danger">*</span></label>
                                                <input
                                                    className="form-control"
                                                    placeholder="Enter Email"
                                                    value={this.state.data?.email}
                                                    onChange={this.__handleEmail}
                                                    autoFocus
                                                    id="Email"
                                                    name="Email"
                                                />

                                                <span className="input-icon">
                                                    {" "}
                                                    <CallIcon />
                                                </span>
                                                {this.state.errors?.email && (
                                                    <p className="error-form">{this.state.errors?.email}</p>
                                                )}

                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="MobileNumber">Password<span className="text-danger">*</span></label>
                                                <input
                                                    type={this.state.showPassword ? "text" : "password"}
                                                    className="form-control"
                                                    placeholder="Enter Password"
                                                    value={this.state.data?.password}
                                                    onChange={this.__handlePassword}
                                                    maxLength="20"
                                                    id="Password"
                                                    name="Password"
                                                />

                                                <span className="input-icon">
                                                    {" "}
                                                    <CallIcon />
                                                </span>
                                                {this.state.errors?.password && (
                                                    <p className="error-form" >{this.state.errors.password}</p>
                                                )}

                                            </div>
                                            <div className="showPassword">
                                                <input id="ShowPassword" checked={this.state.showPassword} onChange={(e) => this.handleShow(e)} name="ShowPassword" type="checkbox" />
                                                <label htmlFor="ShowPassword">Show Password</label>
                                            </div>


                                            <div className="col-sm-12 text-center">
                                                <button
                                                    disabled={this.state.disable}
                                                    type="submit"
                                                    onClick={this.handleSubmit}
                                                    style={{ margin: '20px 0px 25px' }}
                                                    className="btn btn-primary get-otp-btn"
                                                >
                                                    Login
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div >
                            </div>
                        </div>
                    </div >
                </section >
                <BottomSection />
                <CreditFooter />
            </>
        );
    }
}
const mapStateToProps = (state) => ({
    loadingLogin: getASM(state).asmLoading
});
const mapDispatchToProps = (dispatch) => ({
    loadLeadStatus: (params, callback) => dispatch(loadLeadStatus(params, callback)),
    setASMLogin: (params, callback) =>
        dispatch(setASMLogin(params, callback)),
    setCustomerLogin: (params, callback) =>
        dispatch(setCustomerLogin(params, callback)),
    getCustomerOTP: (params, callback) =>
        dispatch(getCustomerOTP(params, callback))
});
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(LoginForm)
);
