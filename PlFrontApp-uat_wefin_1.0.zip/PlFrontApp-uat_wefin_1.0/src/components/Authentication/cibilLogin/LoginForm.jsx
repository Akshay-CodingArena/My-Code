import React, { Component } from "react";
import { ReactComponent as CallIcon } from "../../../include/assets/phoneIcon.svg";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import {
  setCustomerLogin,
  getCustomer,
  getCustomerOTP,
} from "../../../store/login";
import BackDropComponent from "../../../common/BackDropComponent";
import { getOS } from "../../../Utils/device_function";
import { splitMulti } from "../../../common/helperCells";
// import * as DOMPurify from 'dompurify';

class LoginForm extends Component {
  state = {
    MobileNumberError: "",
    MobileNumber: "",
    disable: true,
    // referCode: "",
  };

  __handleMobileNumber = (event) => {
    event.preventDefault();
    const mobile_number = event.target.value;
    if (Number(mobile_number) && mobile_number.length === 10) {
      this.setState({ disable: false });
    }
    if (mobile_number.length === 10 && !/^[6789]\d{9}$/.test(mobile_number)) {
      this.setState({
        disable: true,
        MobileNumberError: "Please enter a valid mobile number.",
      });
    } else {
      this.setState({
        MobileNumberError: "",
      });
    }
    if (
      (Number(mobile_number) && mobile_number.length < 10) ||
      event.target.value.length < 1
    ) {
      this.setState({ disable: true });
    }
    if (
      mobile_number.length <= 10 &&
      (/^[0-9]+$/.test(mobile_number) || mobile_number === "")
    ) {
      this.setState({ MobileNumber: mobile_number });
    }
  };
  // __handleReferCode = (event) => {
  //   event.preventDefault();
  //   const refer_code = event.target.value;
  //   if (refer_code === "" || refer_code.length <= 10) {
  //     this.setState({ referCode: refer_code });
  //   }
  // };
  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "Enter Mobile Number":
          const mobile_number = event.target.value;
          this.setState({ disable: true });
          if (mobile_number.length === 10 && this.state.disable === false) {
            this.__handleRequestForOTP(event);
          } else {
            // let msg = "Ten digits not Entered !";
          }
          break;
        // case "Enter Refer Code":
        //   const refer_code = event.target.value;
        //   if (
        //     this.state.MobileNumber.length === 10 &&
        //     this.state.disable === false &&
        //     refer_code.length >= 3 &&
        //     refer_code.length <= 10
        //   ) {
        //     this.__handleRequestForOTP(event);
        //   } else {
        //     // let msg = "Ten digits not Entered !";
        //   }
        //   break;
        default:
          break;
      }
    }
  };
  __handleRequestForOTP = (e) => {
    e.preventDefault();
    const query = splitMulti(this.props.location.search, ["?", "&", "="]);
    var formData;
    if (query.length > 0) {
      formData = {
        mobile: this.state.MobileNumber,
        // refercode: this.state.referCode,
        version: "1.0",
        // platform: isMobile ? "web_mobile" : "web_desktop",
        platform:
          getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
        utm_source: query[2],
        utm_medium: query[4],
        utm_id: query[8],
        utm_campaign: query[6],
      };
    } else {
      formData = {
        mobile: this.state.MobileNumber,
        version: "1.0",
        // platform: isMobile ? "web_mobile" : "web_desktop",
        platform:
          getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
      };
    }

    this.props.setCustomerLogin(formData, this.callBackLogin);
  };
  callBackLogin = (res) => {
    if (res) {
      if (res.data) {
        localStorage.setItem("customer_id", res.data.smsscrappinglimit.sfid);
        if (res.data.success) {
          this.props.setData((prevState) => ({
            ...prevState,
            existing: res.data.isExisting,
            mobile: this.state.MobileNumber,
          }));
          gaLogEvent(CONSTANTS.GA_EVENTS.MOBILE_CAPTURED);
          gaLogEvent(CONSTANTS.GA_EVENTS.LOGIN_CS);
          this.props.getCustomerOTP(
            this.state.MobileNumber,
            this.callBackGETOtp
          );
        }
      }
    }
  };
  callBackGETOtp = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.updateStep(null, 2);
      }
    }
  };
  render() {
    return (
      <div className="bs-login-block">
        {this.props.loadingLogin ? <BackDropComponent /> : ""}
        <form autocomplete="off" onSubmit={this.__handleRequestForOTP}>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            <h1>
              Check Your <span>Credit Score</span> for FREE
            </h1>
          </div>
          <div className="LoginFormFields">
            <div className="form-group">
              <label htmlFor="MobileNumber">Mobile Number</label>
              <input
                className="form-control"
                placeholder="Enter Mobile Number"
                value={this.state.MobileNumber}
                onChange={this.__handleMobileNumber}
                maxLength="10"
                onKeyPress={(e) =>
                  this.__handleKeyPress(e, "Enter Mobile Number")
                }
                autofocus
                id="MobileNumber"
                name="MobileNumber"
              />

              <span className="input-icon">
                {" "}
                <CallIcon />
              </span>
              {this.state.MobileNumberError && (
                <p className="error-form">{this.state.MobileNumberError}</p>
              )}

              {/* <input
                className="form-control refer-input"
                placeholder="Refer Code (Optional)"
                value={DOMPurify.sanitize(this.state.referCode)}
                onChange={this.__handleReferCode}
                maxLength="10"
                onKeyPress={(e) => this.__handleKeyPress(e, "Enter Refer Code")}
                id="referCode"
                name="referCode"
              /> */}
            </div>

            <div className="col-sm-12 text-center">
              <button
                disabled={this.state.disable}
                type="submit"
                onClick={(e) => window.fbq("track", "PageView")}
                className="btn btn-primary get-otp-btn"
              >
                Get OTP
              </button>
            </div>
            <div className="bs-terms-of-use">
              By logging in, you agree to the following{" "}
              <a href="https://wefin.in/terms-of-use.html" >
                Terms of Use
              </a>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingLogin: getCustomer(state).loadingLogin,
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerLogin: (params, callback) =>
    dispatch(setCustomerLogin(params, callback)),
  getCustomerOTP: (params, callback) =>
    dispatch(getCustomerOTP(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(LoginForm)
);
