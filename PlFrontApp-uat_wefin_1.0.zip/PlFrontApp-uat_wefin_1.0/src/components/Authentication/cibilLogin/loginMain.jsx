import React, { useEffect } from "react";
import LeftMenuDecider from "../../../common/leftMenuContent";
import LoginForm from "./LoginForm";
import SecureLS from "secure-ls";
import SetEmailForm from "./SetEmailForm";
import OTPForm from "./otpForm";
import CreditFooter from "../../cibilFlow/footer";
import BottomSection from "../../../common/bottom";
import DownloadAppModal from "../../../common/DownloadApp";
import { getOS } from "../../../Utils/device_function";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const LoginCibilMain = () => {
  const [step, setStep] = React.useState(1);
  const [data, setData] = React.useState({});
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  useEffect(() => {
    localStorage.clear();
    localStore.removeAll();
    localStorage.removeItem("GCToken");
    gaLogEvent(CONSTANTS.GA_EVENTS.CS_LANDING_PAGE);
  }, []);

  const leftSideStep = () => {
    switch (step) {
      case 1:
        return (
          <LoginForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 2:
        return (
          <OTPForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 3: {
        return <SetEmailForm />;
      }
      default:
        break;
    }
  };

  const checkUTMLinks = () => {
    if (window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_TWO_WHEELER) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_TWO_WHEELER
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_BUSINESS_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_SCORE
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_HOME_LOAN
    ) {
      return false;
    }
    else {
      return true;
    }
  };
  return (
    <>
      {" "}
      {getOS() !== "desktop" && checkUTMLinks() && <DownloadAppModal />}
      <section className="bs-login-section">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1">
              <div>
                <LeftMenuDecider leftComponent={2} />
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2">
              {leftSideStep()}
            </div>
          </div>
        </div>
      </section>
      <section className="cs-login-content">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Credit score</h2>
              <p>
                Credit score is a three-digit number ranging from 300–900 which
                most of the banks and lending institutes use to decide how
                likely they will grant you a credit card or loan. It considers
                your past behavior regarding your credit report.
              </p>
              <h5>Experian Score Range</h5>
              <p>
                The Experian score ranges between 300 and 900. Credit Score
                above 800 and above is considered excellent. A good credit score
                is anything above 700. Higher credit score is better preffered
                by most of the Banks and NBFCs as you will be able to repay the
                loan more easily. Most credit scores range between 600 and 750.
              </p>
            </div>
          </div>
        </div>
      </section>
      <BottomSection />
      <CreditFooter />
    </>
  );
};

export default LoginCibilMain;
