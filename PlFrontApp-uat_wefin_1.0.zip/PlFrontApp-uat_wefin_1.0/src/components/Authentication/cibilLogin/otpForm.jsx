import React, { Component } from "react";
import Swal from "sweetalert2";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  setCustomerOtp,
  getCustomer,
  getCustomerOTP,
} from "../../../store/login";
import ArrowForwardIcon from "../../../include/assets/otpArrow.png";
import BackDropComponent from "../../../common/BackDropComponent";
import { getExperian, loadExperianCheck } from "../../../store/experian";
import {
  gAKeys,
  gtag_report_conversion,
} from "../../../Utils/googleTagTracking";
import PATH from "../../../paths/Paths";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
class OTPForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      OTPError: "",
      otp: "",
      OTPIconDisable: false,
      otpData: {},
      seconds: 40,
      showOTP: false,
      loading: false,
    };
  }

  componentDidMount = () => {
    let interval = this.___handleTimer();
    return () => {
      clearInterval(interval);
    };
  };
  ___handleTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.seconds > 0) {
        this.setState({ seconds: this.state.seconds - 1 });
      } else {
        this.setState({ showOTP: true });
        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };
  __handleOTP = (event) => {
    event.preventDefault();
    const otp = event.target.value;
    if (otp.length <= 4 && (/^[0-9]+$/.test(otp) || otp === "")) {
      this.setState({ otp: otp });
    }
  };

  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "* * * *":
          const otp = event.target.value;
          if (otp.length === 4 && this.state.OTPIconDisable === false) {
            this.setState({ OTPIconDisable: true });
            this.__verifyOTP();
          }
          break;
        default:
          break;
      }
    }
  };
  __verifyOTP = () => {
    this.setState({ loading: true });
    localStorage.setItem("mobilenumber", this.props.data.mobile);
    let FCMToken = localStorage.getItem("GCToken");
    const formData = {
      otp: this.state.otp,
      mobile: this.props.data.mobile,
      loginType: "otp",
      webFCMToken: FCMToken,
    };
    setTimeout(() => {
      this.props.setCustomerOtp(formData, this.callBackOTP);
    }, 3000);
  };
  handleShow = () => {
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackExperian);
  };
  callBackExperian = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error" || res.data.success === false) {
          this.props.history.push(PATH.PRIVATE.CIBIL_SCORE_ANALYSIS);
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          gtag_report_conversion(gAKeys.loginCreditScore);
          this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
        }
      }
    }
  };
  callBackOTP = (res) => {
    if (res) {
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.OTP_VERFIED);
        this.setState({ loading: false });
        localStorage.setItem("firstName", res.data.data.firstname);
        localStorage.setItem("fullName", res.data.data.name);
        localStorage.setItem("lastName", res.data.data.lastname);
        localStorage.setItem("accessToken", res.data.data.accessToken);
        localStorage.setItem("email", res.data.data.Email);
        localStorage.setItem("referCode", res.data.data.refer_code);
        const formData = {
          consentName: "CONSENT_POLICY",
          consentType: "BTN",
          consentStatus: "true",
          platform: getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
        }
        this.props.loadConsents(formData, this.consentCallback)
        if (this.props.data.existing) {
          localStorage.setItem("userExists", 1);
          gaLogEvent(CONSTANTS.GA_EVENTS.EXISTING_CUSTOMER);
          this.handleShow();
        } else {
          gaLogEvent(CONSTANTS.GA_EVENTS.NEW_CUSTOMER);
          this.props.updateStep(null, 3);
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: true,
          timer: 1800,
        });
        this.setState({ OTPIconDisable: false, loading: false });
      }
    }
  };
  consentCallback = (res) => {
    if (res) {
      console.log(res)
    }
  }
  __handleResendForOTP = () => {
    this.props.getCustomerOTP(this.props.data.mobile, this.callBackGETOtp);
    this.setState({
      seconds: 40,
      OTPIconDisable: false,
      showOTP: false,
      otp: "",
    });
  };
  callBackGETOtp = (res) => {
    if (res) {
      if (res.data.success === true) {
        this.___handleTimer();
      }
    }
  };
  render() {
    // const { classes } = this.props;
    return (
      <div className="bs-login-block">
        {this.props.loadingGet ||
          this.props.loadingOtp ||
          this.state.loading ||
          this.props.loadingCheck ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <form>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            <h1>
              Looking for a <span>Credit Report?</span>
            </h1>
          </div>
          <div className="LoginFormFields">
            <>
              <div className="form-group">
                <input
                  placeholder="****"
                  value={this.state.otp}
                  onChange={this.__handleOTP}
                  onKeyPress={(e) => this.__handleKeyPress(e, "* * * *")}
                  autofocus
                  id="otpField"
                  className="otpField"
                  name="otpField"
                  autoComplete="off"
                />
                <span className="opt-arrow">
                  <img
                    src={ArrowForwardIcon}
                    alt="arrow forward icon"
                    onClick={this.__verifyOTP}
                  />
                </span>
              </div>
            </>
            <div
              className="otpBottomContainer"
              style={{
                display: "flex",
                flexDirection: "column",
                marginTop: "20px",
              }}
            >
              <div style={{ color: "#2e0080", textAlign: "center" }}>
                {this.state.seconds === 0 ? null : (
                  <h4>
                    Re-send in 00 :{" "}
                    {this.state.seconds < 10
                      ? `0${this.state.seconds}`
                      : this.state.seconds}
                  </h4>
                )}
              </div>
              <p>
                We have sent you a 4 digit verification code on your mobile
                number{" "}
                <span style={{ fontWeight: "800" }}>
                  +91-{this.props.data.mobile}
                </span>
                <a
                  href={PATH.PUBLIC.CREDIT_SCORE}
                  style={{ color: "#2e0080", fontWeight: "700" }}
                >
                  {" "}
                  (Change)
                </a>
              </p>
              <div className="OptNotRcvd">
                {" "}
                {this.state.showOTP ? (
                  <span>
                    Didn't receive the OTP? &nbsp;
                    <button
                      type="submit"
                      onClick={this.__handleResendForOTP}
                      className="btn btn-primary get-otp-btn"
                    >
                      Resend OTP
                    </button>
                  </span>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingOtp: getCustomer(state).loadingOtp,
  loadingGet: getCustomer(state).loadingGet,
  experian: getExperian(state),
  loadingCheck: getExperian(state).loadingCheck,
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerOtp: (params, callback) =>
    dispatch(setCustomerOtp(params, callback)),
  getCustomerOTP: (params, callback) =>
    dispatch(getCustomerOTP(params, callback)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OTPForm)
);
