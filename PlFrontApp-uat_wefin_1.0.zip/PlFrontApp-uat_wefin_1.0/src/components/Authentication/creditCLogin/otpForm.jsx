import React, { Component } from "react";
import Swal from "sweetalert2";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  setCustomerOtp,
  getCustomer,
  getCustomerOTP,
} from "../../../store/login";
import ArrowForwardIcon from "../../../include/assets/otpArrow.png";
import BackDropComponent from "../../../common/BackDropComponent";
import { encryptStore } from "../../../Utils/store";
import { getAccountInfo, getAccount } from "../../../store/account";
import { loadccApplyLoan, getApplyLoan } from "../../../store/applyLoan";
import { getBankOffer, getOffer } from "../../../store/bankOffer";
import {
  gAKeys,
  gtag_report_conversion,
} from "../../../Utils/googleTagTracking";
import PATH from "../../../paths/Paths";
import CONSTANTS from "../../../constants/Constants";
import { gaLogEvent } from "../../../init-fcm";
import { splitMulti } from "../../../common/helperCells";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
import cardRedirection from "../../creditCard/cardRedirection";
class OTPForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      OTPError: "",
      otp: "",
      OTPIconDisable: false,
      otpData: {},
      seconds: 40,
      showOTP: false,
      loading: false,
      panVerified: true
    };
  }

  componentDidMount = () => {
    let interval = this.___handleTimer();
    return () => {
      clearInterval(interval);
    };
  };
  ___handleTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.seconds > 0) {
        this.setState({ seconds: this.state.seconds - 1 });
      } else {
        this.setState({ showOTP: true });
        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };
  __handleOTP = (event) => {
    event.preventDefault();
    const otp = event.target.value;
    if (otp.length <= 4 && (/^[0-9]+$/.test(otp) || otp === "")) {
      this.setState({ otp: otp });
    }
  };

  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "* * * *":
          const otp = event.target.value;
          if (otp.length === 4 && this.state.OTPIconDisable === false) {
            this.setState({ OTPIconDisable: true });
            this.__verifyOTP();
          }
          break;
        default:
          break;
      }
    }
  };
  __verifyOTP = () => {
    this.setState({ loading: true });
    localStorage.setItem("mobilenumber", this.props.data.mobile);
    let FCMToken = localStorage.getItem("GCToken");

    const formData = !this.props.isCustomerASM ? {
      otp: this.state.otp,
      mobile: this.props.data.mobile,
      loginType: "otp",
      webFCMToken: FCMToken,
      lenderId: this.props.state.card?.lender_sfid__c,
      loanType: "Credit_Card",
      newLoan: true,
      cardSfid: this.props.state.card?.sfid
    } : {
      otp: this.state.otp,
      mobile: this.props.data.mobile,
      loginType: "otp",
      webFCMToken: FCMToken,
    };

    if (localStorage.getItem("isUTM")) {
      let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
      formData.utm_source = UTM_Data?.utm_source;
      formData.utm_medium = UTM_Data?.utm_medium;
      formData.utm_id = UTM_Data?.utm_id;
      formData.utm_campaign = UTM_Data?.utm_campaign;
    }
    setTimeout(() => {
      this.props.setCustomerOtp(formData, this.callBackOTP);
    }, 3000);
  };


  journeyContinue = (res) => {
    console.log("Loan api is calling", res)
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid, loanType }
        } = res.data;
        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN,
        };
        console.log("Loan is", loanType, "response message", res.data.message, "props are", this.props)
        encryptStore(mobile, storeData);
        gtag_report_conversion(gAKeys.loginGetCreditCard);
        console.log(res.data.data)
        localStorage.setItem("ccLoans", JSON.stringify(this.props.getAccountDetail[0]?.cc_loans))
        if (res.data.data.loan_exists != true) {
          console.log("props are as", this.props)
          if (this.props.state.card) {
            this.props.handleCloseLogin()
            cardRedirection(this.props, this.props.state.card, this.props.getAccountInfo, true)
          }
          this.props.handleCloseLogin()
          //    this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
        }
        else {
          console.log("Already exist running", this.props.history)
          this.props.history.push({
            pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
            state: this.props.getAccountDetail[0]?.cc_loans,
            showPopUp: true
          })
          console.log("Already exist complete", this.props.history)
        }

      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.GET_CREDIT_CARD);
        });
      }
    } else {
      console.log("dead")
    }
  }

  callbackGetAccountDetails = (res) => {
    if (res.data.success) {
      let customerDetails = res.data.customer;

      let ccLoans =
        res.data?.details?.loanData?.[0]?.cc_loans ?
          res.data.details.loanData[0].cc_loans : [];

      if (!customerDetails.pan_verified__c) {
        ////////////////send to pan verification////////
        const mobile = localStorage.getItem("mobilenumber");
        const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN;
        let storeData = { loanType: loanType };
        encryptStore(mobile, storeData)
        this.props.history.push({
          pathname: PATH.PRIVATE.PAN_VERIFY,
          state: {
            isASMFlow: true
          }
        })
      }
      else {
        if (this.props.isCustomerASM) {
          this.props.history.push({
            pathname: PATH.PUBLIC.GET_CREDIT_CARD,
            state: {
              isASM: true
            }
          })
        } else {
          if (ccLoans.length) {
            this.props.history.push({
              pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
              state: ccLoans
            })
          }
          else {
            this.props.history.push({
              pathname: PATH.PUBLIC.GET_CREDIT_CARD
            })
          }
        }
      }
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res.data.message,
        showConfirmButton: true,
        timer: 1800,
      });
    }
  }

  callBackOTP = async (res) => {
    if (res) {
      if (res.data.success) {

        localStorage.setItem("ASM_Flow_For", "credit card")

        gaLogEvent(CONSTANTS.GA_EVENTS.OTP_VERFIED);
        this.setState({ loading: false });
        localStorage.setItem("firstName", res.data.data.firstname);
        localStorage.setItem("fullName", res.data.data.name);
        localStorage.setItem("lastName", res.data.data.lastname);
        localStorage.setItem("accessToken", res.data.data.accessToken);
        localStorage.setItem("email", res.data.data.Email);
        localStorage.setItem("referCode", res.data.data.refer_code);
        const formData = {
          consentName: "CONSENT_POLICY",
          consentType: "BTN",
          consentStatus: "true",
          platform: getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
        }
        this.props.loadConsents(formData, this.consentCallback);

        if (this.props.data.existing) {
          if (this.props.isCustomerASM) {
            localStorage.setItem("userExists", 1);
            gaLogEvent(CONSTANTS.GA_EVENTS.EXISTING_CUSTOMER);
            const mobile = localStorage.getItem("mobilenumber");
            this.props.getAccountInfo({ mobile: mobile }, this.callbackGetAccountDetails);
          }
          else {
            localStorage.setItem("userExists", 1);
            gaLogEvent(CONSTANTS.GA_EVENTS.EXISTING_CUSTOMER);
            const mobile = localStorage.getItem("mobilenumber");
            await this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
            console.log("props are", this.props)
            if (this.state.panVerified) {
              console.log("Pan is ", this.state.panVerified)
              this.journeyContinue(res)
            }
          }
        } else {
          gaLogEvent(CONSTANTS.GA_EVENTS.NEW_CUSTOMER);
          // this.props.handleCloseLogin()
          if (this.props.isCustomerASM) {
            this.props.updateStep(null, 6);
          } else {
            this.props.updateStep(null, 3);
          }
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: true,
          timer: 1800,
        });
        this.setState({ OTPIconDisable: false, loading: false });
      }
    }
  };
  consentCallback = (res) => {
    if (res) {
      console.log(res)
    }
  }
  callbackDetail = (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.GET_CREDIT_CARD);
        });
      } else {
        const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN;
        const mobile = localStorage.getItem("mobilenumber");
        const query = splitMulti(this.props.location.search, ["?", "&", "="]);
        if (query.length > 0) {
          var formData;
          formData = {
            mobile: mobile,
            utm_source: query[2],
            utm_medium: query[4],
            utm_id: query[8],
            utm_campaign: query[6],
            loanType: loanType,
            cardSfid: this.props.state.card.sfid,
            lenderId: this.props.state.card.lender_sfid__c
          };
        } else {
          formData = {
            mobile: mobile,
            loanType: loanType,
          };
        }        //  To INsert

        if (!(res.data?.customer?.pan_verified__c ?? false)) {
          let storeData = { loanType: loanType }
          encryptStore(mobile, storeData)

          formData = {
            mobile: mobile,
            loanType: loanType,
            cardSfid: this.props.state.card.sfid,
            lenderId: this.props.state.card.lender_sfid__c
          };
          this.setState({ ...this.state, panVerified: false })
          localStorage.setItem("appliedCard", JSON.stringify(this.props.state.card))
          this.props.history.push({ pathname: PATH.PRIVATE.PAN_VERIFY, appliedCard: this.props.state.card })
        }
        else {
          this.callbackLoan()
        }
        console.log("pan is", res.data?.customer?.pan_verified__c)

        localStorage.setItem("email", res.data?.customer?.personemail);
        console.log("data we get", res.data)
      }
    }
  };


  __handleResendForOTP = () => {
    this.props.getCustomerOTP(this.props.data.mobile, this.callBackGETOtp);
    this.setState({
      seconds: 40,
      OTPIconDisable: false,
      showOTP: false,
      otp: "",
    });
  };
  callBackGETOtp = (res) => {
    if (res) {
      if (res.data.success === true) {
        this.___handleTimer();
      }
    }
  };
  render() {
    console.log("data we have", this.props.state, "state", this.state)
    // const { classes } = this.props;
    return (
      <div className="bs-login-block">
        {this.props.loadingGet ||
          this.props.loadingOtp ||
          this.props.loading ||
          this.props.loadingLoan ||
          this.props.loadingGetOffer ||
          this.state.loading ||
          this.props.loadingCheck ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <form>
          {/* <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div> */}
          <div className="bs-login-title">
            <h1>
              Enter <span>OTP</span>
            </h1>
          </div>
          <div className="LoginFormFields">
            <>
              <div className="form-group">
                <input
                  placeholder="****"
                  value={this.state.otp}
                  onChange={this.__handleOTP}
                  onKeyPress={(e) => this.__handleKeyPress(e, "* * * *")}
                  autoFocus
                  id="otpField"
                  className="otpField"
                  name="otpField"
                  autoComplete="off"
                />
                <span className="opt-arrow">
                  <img src={ArrowForwardIcon} alt="ArrowForwardIcon" onClick={this.__verifyOTP} />
                </span>
              </div>
            </>
            <div
              className="otpBottomContainer"
              style={{
                display: "flex",
                flexDirection: "column",
                marginTop: "20px",
              }}
            >
              <div style={{ color: "#2e0080", textAlign: "center" }}>
                {this.state.seconds === 0 ? null : (
                  <h4>
                    Re-send in 00 :{" "}
                    {this.state.seconds < 10
                      ? `0${this.state.seconds}`
                      : this.state.seconds}
                  </h4>
                )}
              </div>
              <p>
                We have sent you a 4 digit verification code on your mobile
                number{" "}
                <span style={{ fontWeight: "800" }}>
                  +91-{this.props.data.mobile}
                </span>
                <a
                  href={PATH.PUBLIC.GET_CREDIT_CARD}
                  style={{ color: "#2e0080", fontWeight: "700" }}
                >
                  {" "}
                  (Change)
                </a>
              </p>
              <div className="OptNotRcvd">
                {" "}
                {this.state.showOTP ? (
                  <span>
                    Didn't receive the OTP? &nbsp;
                    <button
                      type="submit"
                      onClick={this.__handleResendForOTP}
                      className="btn btn-primary get-otp-btn"
                    >
                      Resend OTP
                    </button>
                  </span>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingOtp: getCustomer(state).loadingOtp,
  loadingGet: getCustomer(state).loadingGet,
  getApplyLoan: getApplyLoan(state),
  getOffer: getBankOffer(state).getBreOffer,
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
  loadingLoan: getApplyLoan(state).loadingLoan,
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerOtp: (params, callback) =>
    dispatch(setCustomerOtp(params, callback)),
  getCustomerOTP: (params, callback) =>
    dispatch(getCustomerOTP(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadccApplyLoan: (params, callback) =>
    dispatch(loadccApplyLoan(params, callback)),
  getOffer: (params, callback) => dispatch(getOffer(params, callback)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OTPForm)
);
