import React, { Component } from "react";
import CONSTANTS from "../../../constants/Constants";
import Swal from "sweetalert2";
import Validations from "../../../common/Validations";
import Messag from "../../../include/assets/twoWheelerLogo/mssgs.png";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { setCustomerEmail, getCustomer } from "../../../store/login";
import { encryptStore } from "../../../Utils/store";
import { getAccountInfo, getAccount } from "../../../store/account";
import { loadApplyLoan, getApplyLoan } from "../../../store/applyLoan";
import { getBankOffer, getOffer } from "../../../store/bankOffer";
import BackDropComponent from "../../../common/BackDropComponent";
import ReactTooltip from "react-tooltip";
import whatsApp from "./.././../../include/assets/whatsapp.svg";
import {
  gAKeys,
  gtag_report_conversion,
} from "../../../Utils/googleTagTracking";
import PATH from "../../../paths/Paths";
import { gaLogEvent } from "../../../init-fcm";
import * as DOMPurify from 'dompurify';
// import { splitMulti } from "../../../common/helperCells";
class SetEmailForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailError: "",
      email: "",
      disable: true,
      subscribe: true,
      referCode: ""
    };
  }

  _handleChangeEmail = (event) => {
    event.preventDefault();
    const email = event.target.value;
    this.setState({ email: email });
    localStorage.setItem("personalEmail", email);
    localStorage.setItem("email", email);

    let storeData = {
      personalEmail: email,
    };
    let mobileNumber = localStorage.getItem("mobilenumber");
    encryptStore(mobileNumber, storeData);

    if (email) {
      const EmailRes = Validations(email, CONSTANTS.VALIDATION_CONSTANTS.EMAIL);
      this.setState({ emailError: EmailRes });
      if (!EmailRes) {
        this.setState({ disable: false });
      } else {
        this.setState({ disable: true });
      }
    }
  };

  __IsUserExist = (e) => {
    e.preventDefault();
    const formData = {
      Email: this.state.email,
      mobile: localStorage.getItem("mobilenumber"),
      refercode: this.state.referCode,
      whatsAppOpt: this.state.subscribe ? "true" : "false",
    };
    this.props.setCustomerEmail(formData, this.callBackEmail);
  };
  callBackEmail = (res) => {
    if (res) {
      if (res.data.success) {
        const mobile = localStorage.getItem("mobilenumber");
        this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
        gaLogEvent(CONSTANTS.GA_EVENTS.EMAIL_ENTERED);
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        });
        this.props.history.push(PATH.PUBLIC.BUSINESS_LOAN);
      }
    }
  };

  callbackDetail = (res) => {
    if (res.data.success === false) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res.data.message,
        showConfirmButton: false,
        timer: 1800,
      }).then(() => {
        this.props.history.push(PATH.PUBLIC.BUSINESS_LOAN);
      });
    } else {
      const loanType = CONSTANTS.LOAN_TYPE.BUSINESS_LOAN;

      const mobile = localStorage.getItem("mobilenumber");

      const urlSearchParams = new URLSearchParams(window.location.search);
      const params = Object.fromEntries(urlSearchParams.entries());
      /////////////UTM CODE////////////
      let isUTM = params.hasOwnProperty('utm_source');
      /////////////////////////////////////////////////////////////
      if (isUTM) {
        var formData;
        formData = {
          mobile: mobile,
          utm_source: params?.utm_source,
          utm_medium: params?.utm_medium,
          utm_id: params?.utm_id,
          utm_campaign: params?.utm_campaign,
          loanType: loanType,
        };
      } else {
        formData = {
          mobile: mobile,
          loanType: loanType,
        };
      }
      this.props.loadApplyLoan(formData, this.callbackLoan);
      localStorage.setItem("email", res.data.customer.personemail);
    }
  };
  callbackLoan = (res) => {
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid },
          loanType,
        } = res.data;
        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: loanType,
        };
        encryptStore(mobile, storeData);
        if (loanType === CONSTANTS.LOAN_TYPE.BUSINESS_LOAN) {
          if (!this.props.customerDetail.pan_verified__c) {
            this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
          }
          else {
            if (
              this.props.getAccountDetail[0].bl_loans &&
              this.props.getAccountDetail[0].bl_loans.length &&
              this.props.getAccountDetail[0].bl_loans[0].loanStage === "Captured"
            ) {
              this.props.history.push(PATH.PRIVATE.BUSINESS_LOAN_OFFERS);
            }
            else {
              this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
            }
          }
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.BUSINESS_LOAN);
        });
      }
    }
  };
  callBackGet = (res) => {
    if (res) {
      if (res.data.success) {
        gtag_report_conversion(gAKeys.loginPersonalLoan);
        this.props.history.push({
          pathname: PATH.PRIVATE.BUSINESS_LOAN_OFFERS,
          state: res.data,
        });
      }
    }
  };
  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      if (this.state.disable === false) {
        this.setState({ disable: true });
        if (!this.state.emailError) {
          this.__IsUserExist(event);
        }
      }
    }
  };

  __handleReferCode = (event) => {
    event.preventDefault();
    const refer_code = event.target.value;
    if (refer_code === "" || refer_code.length <= 10) {
      this.setState({ referCode: refer_code });
    }
  };

  componentDidMount = () => {
    //scroll to top//
    window.scrollTo(0, 0)

    document.getElementById("subscribe").checked = true;
  };

  handleSubscribe = async (e) => {
    let r = await e;
    this.setState({ subscribe: r.target.checked });
  };

  render() {
    return (
      <div className="bs-login-block">
        {this.props.loadingEmail ||
          this.props.loadingLoan ||
          this.props.loading ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <form>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            <h1>
              Looking for a <span>Business Loan?</span>
            </h1>
          </div>
          <div className="LoginFormFields">
            <div className="form-group">
              <label htmlFor="EmailAddress">Email Address</label>
              <input
                autoFocus
                className="form-control"
                placeholder="Enter Your Email Address"
                error={this.state.emailError}
                value={this.state.email}
                onChange={this._handleChangeEmail}
                onKeyPress={this.__handleKeyPress}
                maxLength="100"
                id="EmailAddress"
                name="EmailAddress"
              />

              <span className="input-icon">
                {" "}
                <img src={Messag} alt="" width="" height="" />
              </span>

              <input
                className="form-control refer-input"
                placeholder="Refer Code (Optional)"
                value={DOMPurify.sanitize(this.state.referCode)}
                onChange={this.__handleReferCode}
                maxLength="10"
                onKeyPress={(e) => this.__handleKeyPress(e, "Enter Refer Code")}

                id="referCode"
                name="referCode"
              />
            </div>
            <div className="bsWhatsAppSubscribe row col-md-12 col-sm-12 justify-content-start ">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  name="subscribe"
                  id="subscribe"
                  onChange={this.handleSubscribe}
                />
                <label className={`form-check-label`} htmlFor="subscribe">
                  Receive
                </label>
              </div>
              <img src={whatsApp} alt="whatsapp logo" />{" "}
              <span>&nbsp;WhatsApp notifications</span>
              <span
                data-tip={`To receive updates about payments, bank charges, rewards & other alerts.`}
                data-background-color="#2e0080"
                data-text-color="#FFF"
                data-place="top"
                style={{
                  display: "inline-block",
                  cursor: "pointer",
                }}
                className="btn-link"
              >
                &nbsp; know more
              </span>
              <ReactTooltip />
            </div>
            <div className="col-sm-12 text-center">
              <button
                onClick={(e) => this.__IsUserExist(e)}
                className="btn btn-primary get-otp-btn"
                disabled={this.state.disable || !this.state.subscribe}
              >
                Next
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  loadingEmail: getCustomer(state).loadingEmail,
  getApplyLoan: getApplyLoan(state),
  getOffer: getBankOffer(state).getBreOffer,
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
  loadingLoan: getApplyLoan(state).loadingLoan,
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerEmail: (params, callback) =>
    dispatch(setCustomerEmail(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadApplyLoan: (params, callback) =>
    dispatch(loadApplyLoan(params, callback)),
  getOffer: (params, callback) => dispatch(getOffer(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SetEmailForm)
);
