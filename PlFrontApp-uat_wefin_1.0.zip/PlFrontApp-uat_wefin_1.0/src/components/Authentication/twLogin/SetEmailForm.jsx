import React, { Component } from "react";
import CONSTANTS from "../../../constants/Constants";
import Swal from "sweetalert2";
import Validations from "../../../common/Validations";
import Messag from "../../../include/assets/twoWheelerLogo/mssgs.png";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { setCustomerEmail, getCustomer } from "../../../store/login";
import { encryptStore, decryptStore } from "../../../Utils/store";
import { getAccountInfo, getAccount } from "../../../store/account";
import {
  loadApplyLoan,
  getApplyLoan,
  loadLoanDetail,
  loadApprovalDetail,
} from "../../../store/applyLoan";
import BackDropComponent from "../../../common/BackDropComponent";
import ReactTooltip from "react-tooltip";
import whatsApp from "./.././../../include/assets/whatsapp.svg";
import {
  gAKeys,
  gtag_report_conversion,
} from "../../../Utils/googleTagTracking";
import PATH from "../../../paths/Paths";
import { gaLogEvent } from "../../../init-fcm";
import { splitMulti } from "../../../common/helperCells";
import * as DOMPurify from 'dompurify';
import { asmEmail } from "../../../store/asm";
class SetEmailForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailError: "",
      email: "",
      disable: true,
      subscribe: true,
      referCode: ""
    };
  }

  _handleChangeEmail = (event) => {
    event.preventDefault();
    const email = event.target.value;
    this.setState({ email: email });
    localStorage.setItem("personalEmail", email);
    localStorage.setItem("email", email);

    let storeData = {
      personalEmail: email,
    };


    if (email) {
      const EmailRes = Validations(email, CONSTANTS.VALIDATION_CONSTANTS.EMAIL);
      this.setState({ emailError: EmailRes });
      if (!EmailRes) {
        let mobileNumber = localStorage.getItem("mobilenumber");
        let storeData = {
          personalEmail: email,
        };
        encryptStore(mobileNumber, storeData);
        this.setState({ disable: false });
      } else {
        this.setState({ disable: true });
      }
    }
  };

  __IsUserExist = (e) => {
    e.preventDefault();
    const formData = {
      Email: this.state.email,
      mobile: localStorage.getItem("mobilenumber"),
      whatsAppOpt: this.state.subscribe ? "true" : "false",
    };
    if (this.props?.isAddCustomer) {
      this.props.asmEmail(formData, this.callBackEmail)
    }
    else {
      this.props.setCustomerEmail(formData, this.callBackEmail);
    }
  };
  callBackEmail = (res) => {
    if (res) {
      if (res.data.success) {
        const mobile = localStorage.getItem("mobilenumber");
        this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
        gaLogEvent(CONSTANTS.GA_EVENTS.EMAIL_ENTERED);
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        });
        this.props.history.push(PATH.PUBLIC.TWO_WHEELER_LOAN);
      }
    }
  };

  callbackDetail = (res) => {
    if (res.data.success === false) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res.data.message,
        showConfirmButton: false,
        timer: 1800,
      }).then(() => {
        this.props.history.push(PATH.PUBLIC.TWO_WHEELER_LOAN);
      });
    } else {
      const loanType = CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN;
      const mobile = localStorage.getItem("mobilenumber");
      const urlSearchParams = new URLSearchParams(window.location.search);
      const params = Object.fromEntries(urlSearchParams.entries());
      /////////////UTM CODE////////////
      let isUTM = params.hasOwnProperty('utm_source');
      /////////////////////////////////////////////////////////////
      if (isUTM) {
        var formData;
        formData = {
          mobile: mobile,
          utm_source: params?.utm_source,
          utm_medium: params?.utm_medium,
          utm_id: params?.utm_id,
          utm_campaign: params?.utm_campaign,
          loanType: loanType,
        };
      } else {
        formData = {
          mobile: mobile,
          loanType: loanType,
        };
      }
      localStorage.setItem("email", res.data.customer.personemail);
      if (this.props.isAddCustomer) {
        let loanData = res.data?.details?.loanData[0].tw_loans
        localStorage.setItem("accsfid", res?.data?.customer?.accsfid)
        encryptStore(localStorage.getItem("mobilenumber"), {
          loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN,
          manufacturer: "REVOLT",
          loanId: loanData[0].loanId,
          loanSfid: loanData[0].loanSfid,
          loanName: loanData[0].loanName,
        })
        this.props.history.push({ pathname: PATH.PRIVATE.TWO_WHEELER_VARIANT + "/REVOLT/RV400", isAddCustomer: true });
      } else {
        this.props.loadApplyLoan(formData, this.callbackLoan);
      }
    }
  };
  callbackLoan = (res) => {
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid },
          loanType,
        } = res.data;
        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: loanType,
        };
        encryptStore(mobile, storeData);
        if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          if (
            this.props.getAccountDetail.length > 0 &&
            this.props.getAccountDetail[0].tw_loans &&
            this.props.getAccountDetail[0].tw_loans.length === 1 &&
            this.props.getAccountDetail[0].tw_loans[0].loanStage ===
            "PAN Verified"
          ) {
            gtag_report_conversion(gAKeys.loginTwoWheelerLoan);
            this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
          } else {
            this.setState({ setLoading: true });
            this.__handleTwoWheelerLoan(loansfid);
          }
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.TWO_WHEELER_LOAN);
        });
      }
    }
  };

  __handleTwoWheelerLoan = (loansfid) => {
    let data = {
      mobile: localStorage.getItem("mobilenumber"),
      loanid: loansfid,
    };
    this.props.loadApprovalDetail(data, this.callApproval);
  };
  callApproval = (res) => {
    if (res) {
      if (res.data.success) {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loansfid } = decryptedData;
        const { loanStage, loanType } = res.data.details;
        if (
          loanStage === "Captured" ||
          loanStage === "Soft Approved" ||
          loanStage === "Declined"
        ) {
          let getBankData = {
            loanId: loansfid,
            loanType: loanType,
          };
          this.props.loadLoanDetail(getBankData, this.callBackBank);
        } else {
          gtag_report_conversion(gAKeys.loginTwoWheelerLoan);
          this.setState({ setLoading: false });
          this.props.history.push(PATH.PRIVATE.TWO_WHEELER);
        }
      }
    }
  };
  callBackBank = (res) => {
    if (res) {
      if (res.data.success) {
        localStorage.setItem(
          "loanDetail",
          JSON.stringify(res.data.getLoanDetails)
        );
        if (res.data.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          gtag_report_conversion(gAKeys.loginTwoWheelerLoan);
          if (
            res.data?.getLoanDetails?.length > 0 &&
            res.data.getLoanDetails[0].status__c === "Active"
          ) {
            this.bankOffer(JSON.parse(localStorage.getItem("loanDetail")));
          } else {
            setTimeout(() => {
              this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS);
              this.setState({ setLoading: false });
            }, 2000);
          }
        }
      }
    }
  };

  __handleKeyPress = (event) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      if (this.state.disable === false) {
        this.setState({ disable: true });
        if (!this.state.emailError) {
          this.__IsUserExist(event);
        }
      }
    }
  };

  __handleReferCode = (event) => {
    event.preventDefault();
    const refer_code = event.target.value;
    if (refer_code === "" || refer_code.length <= 10) {
      this.setState({ referCode: refer_code });
    }
  };

  componentDidMount = () => {
    document.getElementById("subscribe").checked = true;
  };

  handleSubscribe = async (e) => {
    let r = await e;
    this.setState({ subscribe: r.target.checked });
  };

  render() {
    return (
      <div className="bs-login-block">
        {this.props.loadingEmail ||
          this.props.loading ||
          this.props.loadingLoan ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <form>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            {!this.props.isAddCustomer && <h1>
              Looking for a <span>Two Wheeler Loan?</span>
            </h1>}
          </div>
          <div className="LoginFormFields">
            <div className="form-group">
              <label htmlFor="EmailAddress">Email Address</label>
              <input
                autoFocus
                className="form-control"
                placeholder="Enter Your Email Address"
                error={this.state.emailError}
                value={this.state.email}
                onChange={this._handleChangeEmail}
                onKeyPress={this.__handleKeyPress}
                maxLength="100"
                autofocus
                id="EmailAddress"
                name="EmailAddress"
              />


              <input
                className="form-control refer-input"
                placeholder="Refer Code (Optional)"
                value={DOMPurify.sanitize(this.state.referCode)}
                onChange={this.__handleReferCode}
                maxLength="10"
                onKeyPress={(e) => this.__handleKeyPress(e, "Enter Refer Code")}
                id="referCode"
                name="referCode"
              />

              <span className="input-icon">
                {" "}
                <img src={Messag} alt="" width="" height="" />
              </span>
            </div>
            <div className="bsWhatsAppSubscribe row col-md-12 col-sm-12 justify-content-start ">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  name="subscribe"
                  id="subscribe"
                  onChange={this.handleSubscribe}
                />
                <label className={`form-check-label`} htmlFor="subscribe">
                  Receive
                </label>
              </div>
              <img src={whatsApp} alt="whatsapp logo" />{" "}
              <span>&nbsp;WhatsApp notifications</span>
              <span
                data-tip={`To receive updates about payments, bank charges, rewards & other alerts.`}
                data-background-color="#2e0080"
                data-text-color="#FFF"
                data-place="top"
                style={{
                  display: "inline-block",
                  cursor: "pointer",
                }}
                className="btn-link"
              >
                &nbsp; know more
              </span>
              <ReactTooltip />
            </div>
            <div className="col-sm-12 text-center">
              <button
                onClick={(e) => this.__IsUserExist(e)}
                className="btn btn-primary get-otp-btn"
                disabled={this.state.disable || !this.state.subscribe}
              >
                Next
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  loadingEmail: getCustomer(state).loadingEmail,
  getApplyLoan: getApplyLoan(state),
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
  loadingLoan: getApplyLoan(state).loadingLoan,
});
const mapDispatchToProps = (dispatch) => ({
  asmEmail: (params, callback) =>
    dispatch(asmEmail(params, callback)),
  setCustomerEmail: (params, callback) =>
    dispatch(setCustomerEmail(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadApplyLoan: (params, callback) =>
    dispatch(loadApplyLoan(params, callback)),
  loadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  loadApprovalDetail: (params, callBack) =>
    dispatch(loadApprovalDetail(params, callBack)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SetEmailForm)
);
