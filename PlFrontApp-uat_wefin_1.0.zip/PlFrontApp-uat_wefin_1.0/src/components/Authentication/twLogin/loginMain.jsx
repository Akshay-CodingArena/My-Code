import React, { useEffect } from "react";
import LeftMenuDecider from "../../../common/leftMenuContent";
import LoginForm from "./LoginForm";
import SecureLS from "secure-ls";
import SetEmailForm from "./SetEmailForm";
import OTPForm from "./otpForm";
import CreditFooter from "../../cibilFlow/footer";
import BottomSection from "../../../common/bottom";
import DownloadAppModal from "../../../common/DownloadApp";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
import PATH from "../../../paths/Paths";

let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const LoginTWMain = () => {
  const [step, setStep] = React.useState(1);
  const [data, setData] = React.useState({});
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  useEffect(() => {
    if (window) {
      console.log(window.location.href)
      if (!isAddCustomer()) {

        localStore.removeAll();
        localStorage.removeItem("GCToken");
        localStorage.clear();
      }
    }
  }, []);

  const isAddCustomer = () => {
    if (window) {
      if (window.location.href.indexOf(PATH.PRIVATE.ASM_ADD_CUSTOMER) >= 0) {
        return true
      }
      return false
    }
  }

  const leftSideStep = () => {
    switch (step) {
      case 1:
        return (
          <LoginForm updateStep={updateStep} data={data} setData={setData} isAddCustomer={isAddCustomer()} />
        );
      case 2:
        return (
          <OTPForm updateStep={updateStep} data={data} setData={setData} isAddCustomer={isAddCustomer()} />
        );
      case 3: {
        return <SetEmailForm isAddCustomer={isAddCustomer()} />;
      }
      default:
        break;
    }
  };

  const checkUTMLinks = () => {
    if (window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_TWO_WHEELER) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_TWO_WHEELER
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_BUSINESS_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_SCORE
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_HOME_LOAN
    ) {
      return false;
    }
    else {
      return true;
    }
  };

  return (
    <>
      {" "}
      {getOS() !== "desktop" && checkUTMLinks() && <DownloadAppModal />}
      <section className="bs-login-section">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1">
              <div>
                <LeftMenuDecider leftComponent={2} />
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2">
              {leftSideStep()}
            </div>
          </div>
        </div>
      </section>
      <section className="cs-login-content">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Two-Wheeler Loan</h2>
              <p>
                Get your choice of two-wheelers, scooters, motorcycle, EV bikes
                from India’s top automobile brands.
              </p>
              <h5>IDFC Offer Details:</h5>
              <ul>
                <li>11% ROI</li>
                <li>Loan Amount up to 85% of vehicle cost</li>
                <li>No Income document required</li>
                <li> 2 mins approval process</li>
                <li>2% Processing Fees</li>
                <li>2700 + models</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <BottomSection />
      <CreditFooter />
    </>
  );
};

export default LoginTWMain;
