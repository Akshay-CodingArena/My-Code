import React, { Component } from "react";
import Swal from "sweetalert2";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  setCustomerOtp,
  getCustomer,
  getCustomerOTP,
} from "../../../store/login";
import ArrowForwardIcon from "../../../include/assets/otpArrow.png";
import BackDropComponent from "../../../common/BackDropComponent";
import { encryptStore, decryptStore } from "../../../Utils/store";
import { getAccountInfo, getAccount } from "../../../store/account";
import {
  loadApplyLoan,
  getApplyLoan,
  loadLoanDetail,
  loadApprovalDetail,
} from "../../../store/applyLoan";
import {
  gAKeys,
  gtag_report_conversion,
} from "../../../Utils/googleTagTracking";
import PATH from "../../../paths/Paths";
import CONSTANTS from "../../../constants/Constants";
import { gaLogEvent } from "../../../init-fcm";
import { splitMulti } from "../../../common/helperCells";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";
import { asmVerifyOtp, getASM } from "../../../store/asm";
import { JourneyContinueMoneyplus } from "../../TwoWheelerJourney/Revolt/loanStages";

class OTPForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      OTPError: "",
      otp: "",
      OTPIconDisable: false,
      otpData: {},
      seconds: 40,
      showOTP: false,
      loading: false,
    };
  }

  componentDidMount = () => {
    let interval = this.___handleTimer();
    return () => {
      clearInterval(interval);
    };
  };
  ___handleTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.seconds > 0) {
        this.setState({ seconds: this.state.seconds - 1 });
      } else {
        this.setState({ showOTP: true });
        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };
  __handleOTP = (event) => {
    event.preventDefault();
    const otp = event.target.value;
    if (otp.length <= 4 && (/^[0-9]+$/.test(otp) || otp === "")) {
      this.setState({ otp: otp });
    }
  };

  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "* * * *":
          const otp = event.target.value;
          if (otp.length === 4 && this.state.OTPIconDisable === false) {
            this.setState({ OTPIconDisable: true });
            this.__verifyOTP();
          }
          break;
        default:
          break;
      }
    }
  };
  __verifyOTP = () => {
    // this.setState({ loading: true });
    let mobile = this.props.data.mobile
    localStorage.setItem("mobilenumber", mobile);
    let storeData = {
      loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN,
      manufacturer: "REVOLT"
    }
    encryptStore(mobile, storeData)
    let FCMToken = localStorage.getItem("GCToken");
    const formData = {
      otp: this.state.otp,
      mobile: this.props.data.mobile,
      loginType: "otp",
      asm_id: localStorage.getItem("ASM_Id"),
      loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN,
      webFCMToken: FCMToken,
    };
    setTimeout(() => {
      if (this.props.isAddCustomer) {
        this.props.asmVerifyOtp(formData, this.callBackOTP)
      } else {
        this.props.setCustomerOtp(formData, this.callBackOTP);
      }
    }, 3000);
  };

  callbackLoanASM = (res) => {
    if (res.data.success) {
      this.props.updateStep(null, 3);
    }

  }
  callBackOTP = (res) => {
    if (res) {
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.OTP_VERFIED);
        //   this.setState({ loading: false });
        localStorage.setItem("firstName", res.data.data.firstname);
        localStorage.setItem("fullName", res.data.data.name);
        localStorage.setItem("lastName", res.data.data.lastname);
        localStorage.setItem("accessToken", res.data.data.accessToken);
        localStorage.setItem("email", res.data.data.Email);
        localStorage.setItem("referCode", res.data.data.refer_code);
        const formData = {
          consentName: "CONSENT_POLICY",
          consentType: "BTN",
          consentStatus: "true",
          platform: getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
        }
        this.props.loadConsents(formData, this.consentCallback)
        if (this.props.data.existing) {
          localStorage.setItem("userExists", 1);
          gaLogEvent(CONSTANTS.GA_EVENTS.EXISTING_CUSTOMER);
          const mobile = localStorage.getItem("mobilenumber");
          this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
        } else {
          gaLogEvent(CONSTANTS.GA_EVENTS.NEW_CUSTOMER);

          if (localStorage.getItem('isASM')) {
            let formData = {
              mobile: localStorage.getItem("mobilenumber"),
              loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN,
              asm_id: localStorage.getItem("ASM_Id")
            }
            localStorage.setItem("email", res.data?.customer?.personemail);
            this.props.loadApplyLoan(formData, this.callbackLoanASM);
          } else {
            this.props.updateStep(null, 3);
          }
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: true,
          timer: 1800,
        });
        this.setState({ OTPIconDisable: false, loading: false });
      }
    }
  };

  consentCallbackASM = (res) => {
    if (res) {
      console.log("ASM Consent send")
    }
  }
  consentCallback = (res) => {
    if (res) {
      const formData = {
        consentName: "Authorized ASM",
        consentType: "ASM",
        consentStatus: "true",
        platform: getOS() === "ios"
          ? "web_ios"
          : getOS() === "android"
            ? "web_android"
            : "web",
      }
      if (localStorage.getItem("isASM")) {
        this.props.loadConsents(formData, this.consentCallbackASM)
      }
    }
  }
  callbackDetail = (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.TWO_WHEELER_LOAN);
        });
      } else {
        localStorage.setItem("accsfid", res.data.customer.accsfid);
        const loanType = CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN;
        const mobile = localStorage.getItem("mobilenumber");
        const urlSearchParams = new URLSearchParams(window.location.search);
        const params = Object.fromEntries(urlSearchParams.entries());
        /////////////UTM CODE////////////
        let isUTM = params.hasOwnProperty('utm_source');
        /////////////////////////////////////////////////////////////
        if (isUTM) {
          var formData;
          formData = {
            mobile: mobile,
            utm_source: params?.utm_source,
            utm_medium: params?.utm_medium,
            utm_id: params?.utm_id,
            utm_campaign: params?.utm_campaign,
            loanType: loanType,

          };
        } else {
          formData = {
            mobile: mobile,
            loanType: loanType,
          };
        }
        if (localStorage.getItem('isASM')) {
          let loanData = res.data?.details?.loanData.length ? res.data.details.loanData[0].tw_loans.filter(loanData => loanData.lenderName === "Money Plus") : []
          if (loanData.length) {
            encryptStore(localStorage.getItem("mobilenumber"), {
              loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN,
              manufacturer: "REVOLT",
              loanId: loanData[0].loanId,
              loanSfid: loanData[0].loanSfid,
              loanName: loanData[0].loanName,
              lenderName: loanData[0].lenderName,
              lenderId: loanData[0].lender_id__c
            })
            this.props.history.push(JourneyContinueMoneyplus(loanData[0]))
          } else {
            formData = { ...formData, asm_id: localStorage.getItem("ASM_Id") }
            localStorage.setItem("email", res.data.customer.personemail);
            this.props.loadApplyLoan(formData, this.callbackLoan);
          }
        } else {
          this.props.loadApplyLoan(formData, this.callbackLoan);
          localStorage.setItem("email", res.data.customer.personemail);
        }
      }
    }
  };
  callbackLoan = (res) => {
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid },
          loanType,
        } = res.data;
        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: loanType,
        };
        encryptStore(mobile, storeData);
        if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          if (
            this.props.getAccountDetail.length > 0 &&
            this.props.getAccountDetail[0].tw_loans &&
            this.props.getAccountDetail[0].tw_loans.length === 1 &&
            this.props.getAccountDetail[0].tw_loans[0].loanStage ===
            "PAN Verified"
          ) {
            gtag_report_conversion(gAKeys.loginTwoWheelerLoan);
            if (this.props.isAddCustomer) {
              this.props.handleCloseLogin()
              Swal.fire({
                icon: "warning",
                title: "Loan Already Applied",
                showCancelButton: true,
                confirmButtonText: "Continue",
                confirmButtonColor: "#d63031",
                cancelButtonColor: "#2e0080",
              }).then((res) => {
                if (res.isConfirmed) {
                  this.__handleTwoWheelerLoan(loansfid)
                }
              });
            } else {
              this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
            }
          } else {
            this.setState({ setLoading: true });
            this.__handleTwoWheelerLoan(loansfid);
          }
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.TWO_WHEELER_LOAN);
        });
      }
    }
  };

  __handleTwoWheelerLoan = (loansfid) => {
    let data = {
      mobile: localStorage.getItem("mobilenumber"),
      loanid: loansfid,
    };
    this.props.loadApprovalDetail(data, this.callApproval);
  };
  callApproval = (res) => {
    if (res) {
      if (res.data.success) {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loansfid } = decryptedData;
        const { loanStage, loanType } = res.data.details;
        if (
          loanStage === "Captured" ||
          loanStage === "Soft Approved" ||
          loanStage === "Declined"
        ) {
          let getBankData = {
            loanId: loansfid,
            loanType: loanType,
          };
          this.props.loadLoanDetail(getBankData, this.callBackBank);
        } else {
          gtag_report_conversion(gAKeys.loginTwoWheelerLoan);
          this.setState({ setLoading: false });
          if (this.props.isAddCustomer) {
            this.props.history.push({ pathname: PATH.PRIVATE.TWO_WHEELER_VARIANT + "/REVOLT/RV400", isAddCustomer: true });
          } else {
            this.props.history.push(PATH.PRIVATE.TWO_WHEELER);
          }
        }
      }
    }
  };
  callBackBank = (res) => {
    if (res) {
      if (res.data.success) {
        localStorage.setItem(
          "loanDetail",
          JSON.stringify(res.data.getLoanDetails)
        );
        gtag_report_conversion(gAKeys.loginTwoWheelerLoan);
        if (res.data.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          if (
            res.data?.getLoanDetails?.length > 0 &&
            res.data.getLoanDetails[0].status__c === "Active"
          ) {
            this.bankOffer(JSON.parse(localStorage.getItem("loanDetail")));
          } else {
            setTimeout(() => {
              this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD);
              this.setState({ setLoading: false });
            }, 2000);
          }
        }
      }
    }
  };

  __handleResendForOTP = () => {
    this.props.getCustomerOTP(this.props.data.mobile, this.callBackGETOtp);
    this.setState({
      seconds: 40,
      OTPIconDisable: false,
      showOTP: false,
      otp: "",
    });
  };
  callBackGETOtp = (res) => {
    if (res) {
      if (res.data.success === true) {
        this.___handleTimer();
      }
    }
  };
  render() {
    // const { classes } = this.props;
    return (
      <div className="bs-login-block">
        {this.props.loadingOtp ||
          this.props.loadingGet ||
          this.props.loadingOtp ||
          this.props.loading ||
          this.props.loadingLoan ||
          this.state.loading ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <form>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            {!this.props.isAddCustomer && <h1>
              Looking for a <span>Two Wheeler Loan?</span>
            </h1>}
          </div>
          <div className="LoginFormFields">
            <>
              <div className="form-group">
                <input
                  placeholder="****"
                  value={this.state.otp}
                  onChange={this.__handleOTP}
                  onKeyPress={(e) => this.__handleKeyPress(e, "* * * *")}
                  autofocus
                  id="otpField"
                  className="otpField"
                  name="otpField"
                />
                <span className="opt-arrow">
                  <img
                    src={ArrowForwardIcon}
                    alt="arrow forward icon"
                    onClick={this.__verifyOTP}
                  />
                </span>
              </div>
            </>
            <div
              className="otpBottomContainer"
              style={{
                display: "flex",
                flexDirection: "column",
                marginTop: "20px",
              }}
            >
              <div style={{ color: "#2e0080", textAlign: "center" }}>
                {this.state.seconds === 0 ? null : (
                  <h4>
                    Re-send in 00 :{" "}
                    {this.state.seconds < 10
                      ? `0${this.state.seconds}`
                      : this.state.seconds}
                  </h4>
                )}
              </div>
              <p>
                We have sent you a 4 digit verification code on your mobile
                number{" "}
                <span style={{ fontWeight: "800" }}>
                  +91-{this.props.data.mobile}
                </span>
                {this.props.isAddCustomer ? <span style={{ textDecoration: "underline", cursor: 'pointer', marginLeft: "5px", color: 'darkblue', color: '#5200bb' }} onClick={(e) => this.props.updateStep(e, 1)}>Change</span> : <a
                  href={PATH.PUBLIC.TWO_WHEELER_LOAN}
                  style={{ color: "#2e0080", fontWeight: "700" }}
                >
                  {" "}
                  (Change)
                </a>}

              </p>
              <div className="OptNotRcvd">
                {" "}
                {this.state.showOTP ? (
                  <span>
                    Didn't receive the OTP? &nbsp;
                    <button
                      type="submit"
                      onClick={this.__handleResendForOTP}
                      className="btn btn-primary get-otp-btn"
                    >
                      Resend OTP
                    </button>
                  </span>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingOtp: getCustomer(state).loadingOtp,
  loadingGet: getCustomer(state).loadingGet,
  getApplyLoan: getApplyLoan(state),
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
  loadingLoan: getApplyLoan(state).loadingLoan,
  loadingOtp: getASM(state).asmLoading
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerOtp: (params, callback) =>
    dispatch(setCustomerOtp(params, callback)),
  getCustomerOTP: (params, callback) =>
    dispatch(getCustomerOTP(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadApplyLoan: (params, callback) =>
    dispatch(loadApplyLoan(params, callback)),
  loadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  loadApprovalDetail: (params, callBack) =>
    dispatch(loadApprovalDetail(params, callBack)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),
  asmVerifyOtp: (params, callback) => dispatch(asmVerifyOtp(params, callback))
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OTPForm)
);
