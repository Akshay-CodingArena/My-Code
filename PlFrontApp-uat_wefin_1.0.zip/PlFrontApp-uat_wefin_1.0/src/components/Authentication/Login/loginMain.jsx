import React, { useEffect } from "react";
// import { useSearchParams } from "react-router-dom";
import LeftMenuDecider from "../../../common/leftMenuContent";
import LoginForm from "./LoginForm";
import SecureLS from "secure-ls";
import SetEmailForm from "./SetEmailForm";
import OTPForm from "./otpForm";
import CreditFooter from "../../cibilFlow/footer";
import BottomSection from "../../../common/bottom";
// import { Link } from "react-router-dom";
// import AppStore from "../../../include/assets/icons/appstore.svg";
// import PlayStore from "../../../include/assets/icons/playstore.svg";
import DownloadAppModal from "../../../common/DownloadApp";
import CampaignModal from "../../../common/campaignModal";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
import { updateCampaignIVR } from "../../../store/login";
import { useDispatch } from "react-redux";
let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const LoginMain = () => {
  const [step, setStep] = React.useState(1);
  const [data, setData] = React.useState({});
  const [cc, setcc] = React.useState(false);
  const [campaignData, setChampaignData] = React.useState();
  const ivr = useDispatch()
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  let callBackIVR = (res) => {
    if (res?.data) {
      if (res?.data?.campaignLink) {
        window.location.replace(res?.data?.campaignLink);
      } else if (res?.data?.redirectAfterApiCall) {
        window.location.replace(res?.data?.redirectAfterApiCall);
      } else {
        setChampaignData(res?.data);
      }
    }
  }
  useEffect(() => {
    localStorage.clear();
    localStore.removeAll();
    localStorage.removeItem("GCToken");
    if (window) {
      const url = new URL(window.location.href)
      const params = new URLSearchParams(url.search)
      params.get('cc') ? setcc(params.get('cc')) : setcc(false)
      console.log('cc adata', cc)
    }
  }, []);

  useEffect(() => {
    if (cc) {
      ivr(updateCampaignIVR({ customer_code__c: cc }, callBackIVR))
    }
  }, [cc])

  const leftSideStep = () => {
    switch (step) {
      case 1:
        return (
          <LoginForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 2:
        return (
          <OTPForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 3: {
        return <SetEmailForm />;
      }
      default:
        break;
    }
  };


  const checkUTMLinks = () => {

    if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_TWO_WHEELER
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_BUSINESS_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_SCORE
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_HOME_LOAN
    ) {
      return false;
    }
    else {
      return true;
    }
  };
  return (
    <>
      <section className="bs-login-section">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1">
              <div>
                <LeftMenuDecider leftComponent={2} />
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2">
              {leftSideStep()}
            </div>
          </div>
        </div>
      </section>
      <BottomSection />

      {campaignData ? <CampaignModal campaignData={campaignData} /> : null}
      <CreditFooter />
      {getOS() !== "desktop" && checkUTMLinks() && <DownloadAppModal />}
    </>
  );
};

export default LoginMain;
