import React, { Component } from "react";
import CONSTANTS from "../../../constants/Constants";
import Swal from "sweetalert2";
import Validations from "../../../common/Validations";
import Messag from "../../../include/assets/twoWheelerLogo/mssgs.png";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { setCustomerEmail, getCustomer } from "../../../store/login";
import { encryptStore } from "../../../Utils/store";
import BackDropComponent from "../../../common/BackDropComponent";
import ReactTooltip from "react-tooltip";
import whatsApp from "./.././../../include/assets/whatsapp.svg";
import { gAKeys, gtag_report_conversion } from "../../../Utils/googleTagTracking";
import { gaLogEvent } from "../../../init-fcm";
import PATH from "../../../paths/Paths";
import * as DOMPurify from 'dompurify';
class SetEmailForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailError: "",
      email: "",
      disable: true,
      subscribe: true,
      referCode: ""
    };
  }

  _handleChangeEmail = (event) => {
    event.preventDefault();
    const email = event.target.value;
    this.setState({ email: email });
    localStorage.setItem("personalEmail", email);
    localStorage.setItem("email", email);

    let storeData = {
      personalEmail: email,
    };
    let mobileNumber = localStorage.getItem("mobilenumber");
    encryptStore(mobileNumber, storeData);

    if (email) {
      const EmailRes = Validations(email, CONSTANTS.VALIDATION_CONSTANTS.EMAIL);
      this.setState({ emailError: EmailRes });
      if (!EmailRes) {
        this.setState({ disable: false });
      } else {
        this.setState({ disable: true });
      }
    }
  };

  __IsUserExist = (e) => {
    e.preventDefault();
    const formData = {
      Email: this.state.email,
      mobile: localStorage.getItem("mobilenumber"),
      refercode: this.state.referCode,
      whatsAppOpt: this.state.subscribe ? 'true' : 'false'
    };
    this.props.setCustomerEmail(formData, this.callBackEmail);
  };
  callBackEmail = (res) => {
    if (res) {
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.EMAIL_ENTERED);
        gtag_report_conversion(gAKeys.mainLogin);
        this.props.history.push(PATH.PRIVATE.PRODUCTS);
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        });
        this.props.history.push(PATH.PUBLIC.INDEX);
      }
    }
  };

  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();

      if (this.state.disable === false) {
        this.setState({ disable: true });
        if (!this.state.emailError) {
          this.__IsUserExist(event);
        }
      }
    }
  };

  componentDidMount = () => {
    document.getElementById("subscribe").checked = true;
  };

  handleSubscribe = async (e) => {
    let r = await e;
    this.setState({ subscribe: r.target.checked });
  };


  __handleReferCode = (event) => {
    event.preventDefault();
    const refer_code = event.target.value;
    if (refer_code === "" || refer_code.length <= 10) {
      this.setState({ referCode: refer_code });
    }
  };

  render() {
    return (
      <div className="bs-login-block">
        {this.props.loadingEmail ? <BackDropComponent /> : ""}
        <form>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            <h1>
              Looking for a <span> Loan?</span>
            </h1>
          </div>
          <div className="LoginFormFields">
            <div className="form-group">
              <label htmlFor="EmailAddress">Email Address</label>
              <input
                autoFocus
                className="form-control"
                placeholder="Enter Your Email Address"
                error={this.state.emailError}
                value={this.state.email}
                onChange={this._handleChangeEmail}
                onKeyPress={this.__handleKeyPress}
                maxLength="100"
                autofocus
                id="EmailAddress"
                name="EmailAddress"
              />


              <input
                className="form-control refer-input"
                placeholder="Refer Code (Optional)"
                value={DOMPurify.sanitize(this.state.referCode)}
                onChange={this.__handleReferCode}
                maxLength="10"
                onKeyPress={(e) => this.__handleKeyPress(e, "Enter Refer Code")}
                id="referCode"
                name="referCode"
              />

              <span className="input-icon">
                {" "}
                <img src={Messag} alt="" width="" height="" />
              </span>
            </div>
            <div className="bsWhatsAppSubscribe row col-md-12 col-sm-12 justify-content-start ">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  name="subscribe"
                  id="subscribe"
                  onChange={this.handleSubscribe}
                />
                <label
                  className={`form-check-label`}
                  htmlFor="subscribe"
                >
                  Receive
                </label>
              </div>
              <img src={whatsApp} alt="whatsapp logo" />{" "}
              <span>&nbsp;WhatsApp notifications</span>
              <span
                data-tip={
                  `To receive updates about payments, bank charges, rewards & other alerts.`
                }
                data-background-color="#2e0080"
                data-text-color="#FFF"
                data-place="top"
                style={{
                  display: "inline-block",
                  cursor: "pointer",
                }}
                className="btn-link"
              >
                &nbsp; know more
              </span>
              <ReactTooltip />
            </div>
            <div className="col-sm-12 text-center">
              <button
                onClick={(e) => this.__IsUserExist(e)}
                className="btn btn-primary get-otp-btn"
                disabled={this.state.disable || !this.state.subscribe}
              >
                Next
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  loadingEmail: getCustomer(state).loadingEmail,
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerEmail: (params, callback) =>
    dispatch(setCustomerEmail(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SetEmailForm)
);
