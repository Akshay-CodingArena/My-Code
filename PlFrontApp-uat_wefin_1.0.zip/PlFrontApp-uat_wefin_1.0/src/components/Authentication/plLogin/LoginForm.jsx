import React, { Component } from "react";
import { ReactComponent as CallIcon } from "../../../include/assets/phoneIcon.svg";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  setCustomerLogin,
  getCustomer,
  getCustomerOTP,
} from "../../../store/login";
import BackDropComponent from "../../../common/BackDropComponent";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import { getOS } from "../../../Utils/device_function";
import PATH from "../../../paths/Paths";
import Swal from "sweetalert2";
import SecureLS from "secure-ls";
import { Loan_Type_ASM } from "../../common/dropdownValues";
import { ReactComponent as Money } from "../../../include/assets/money.svg";
import SelectSearch from "../../common/select";
// import * as DOMPurify from 'dompurify';
// import { splitMulti } from "../../../common/helperCells";

let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
  isOpen: false,
  mobileNumber: "",
  MobileNumberError: "",
  referMobileNumber: "",
  name: "",
  // referCode: "",
  disable: true,
});


class LoginForm extends Component {
  state = {
    MobileNumberError: "",
    MobileNumber: "",
    disable: true,
    // referCode: "",
    data: {

    },
    errors: {

    }
  };

  componentDidMount = () => {
    //scroll to top//
    window.scrollTo(0, 0)
    if (localStorage.getItem("accessToken")) {
      // localStorage.clear();
    }
  }

  __handleMobileNumber = (event) => {
    event.preventDefault();
    const mobile_number = event.target.value;
    if (Number(mobile_number) && mobile_number.length === 10) {
      this.setState({ disable: false });
    }
    if (mobile_number.length === 10 && !/^[6789]\d{9}$/.test(mobile_number)) {
      this.setState({
        disable: true,
        MobileNumberError: "Please enter a valid mobile number.",
      });
    } else {
      this.setState({
        MobileNumberError: "",
      });
    }
    if (
      (Number(mobile_number) && mobile_number.length < 10) ||
      event.target.value.length < 1
    ) {
      this.setState({ disable: true });
    }
    if (
      mobile_number.length <= 10 &&
      (/^[0-9]+$/.test(mobile_number) || mobile_number === "")
    ) {
      this.setState({ MobileNumber: mobile_number });
    }

    if (this.props.isAddCustomer && !this.state.data.loanType) {
      this.setState({ disable: true });
    }
  };
  // __handleReferCode = (event) => {
  //   event.preventDefault();
  //   const refer_code = event.target.value;
  //   if (refer_code === "" || refer_code.length <= 10) {
  //     this.setState({ referCode: refer_code });
  //   }
  // };
  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "Enter Mobile Number":
          const mobile_number = event.target.value;
          this.setState({ disable: true });
          if (mobile_number.length === 10 && this.state.disable === false) {
            this.__handleRequestForOTP(event);
          } else {
            // let msg = "Ten digits not Entered !";
          }
          break;
        // case "Enter Refer Code":
        //   const refer_code = event.target.value;
        //   if (
        //     this.state.MobileNumber.length === 10 &&
        //     this.state.disable === false &&
        //     refer_code.length >= 3 &&
        //     refer_code.length <= 10
        //   ) {
        //     this.__handleRequestForOTP(event);
        //   } else {
        //     // let msg = "Ten digits not Entered !";
        //   }
        //   break;

        default:
          break;
      }
    }
  };
  __handleRequestForOTP = (e) => {

    e.preventDefault();

    if (this.props.isAddCustomer && !this.state.data.loanType) {
      let errors = { ...this.state.errors };
      errors.loanType = "Please Select Loan Type."
      this.setState({ errors: errors });
      return;
    }


    const urlSearchParams = new URLSearchParams(window.location.search);
    const params = Object.fromEntries(urlSearchParams.entries());
    /////////////UTM CODE////////////
    let isUTM = params.hasOwnProperty("utm_source");
    /////////////////////////////////////////////////////////////
    var formData;
    if (isUTM) {
      localStorage.setItem("isUTM", isUTM);
      localStorage.setItem("UTM", JSON.stringify(params));
      formData = {
        mobile: this.state.MobileNumber,
        version: "1.0",
        // platform: isMobile ? "web_mobile" : "web_desktop",
        platform:
          getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
        utm_source: params?.utm_source,
        utm_medium: params?.utm_medium,
        utm_id: params?.utm_id,
        utm_campaign: params?.utm_campaign,
      };
    } else {
      formData = {
        mobile: this.state.MobileNumber,
        // refercode: this.state.referCode,
        version: "1.0",
        // platform: isMobile ? "web_mobile" : "web_desktop",
        platform:
          getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
      };
    }

    this.props.setCustomerLogin(formData, this.callBackLogin);
  };
  callBackLogin = (res) => {
    if (res) {
      if (res.data) {
        localStorage.setItem("customer_id", res.data.smsscrappinglimit.sfid);
        if (res.data.success) {
          this.props.setData((prevState) => ({
            ...prevState,
            existing: res.data.isExisting,
            mobile: this.state.MobileNumber,
            ASM_LOAN_TYPE: this.state.data.loanType
          }));
          gaLogEvent(CONSTANTS.GA_EVENTS.MOBILE_CAPTURED);
          gaLogEvent(CONSTANTS.GA_EVENTS.LOGIN_PL);
          this.props.getCustomerOTP(
            this.state.MobileNumber,
            this.callBackGETOtp
          );
        }
      }
    }
  };
  callBackGETOtp = (res) => {
    if (res) {
      if (res.data.success) {
        if (this.props.isAsmLogin) {
          this.props.updateStepASM(null, 2);
        } else {
          this.props.updateStep(null, 2);
        }
      }
    }
  };
  render() {
    return (
      <div className="bs-login-block">
        {this.props.loadingLogin || this.props.loadingLogout ? <BackDropComponent /> : ""}
        <form autocomplete="off">
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            {!this.props.isAddCustomer ? <h1>
              Looking for a <span>Personal Loan?</span>
            </h1> : ""}
          </div>
          <div className="LoginFormFields">
            <div className="form-group">
              <label htmlFor="MobileNumber">{this.props.isAddCustomer ? 'Customer mobile number' : 'Mobile Number'}<span className="text-danger">*</span></label>
              <input
                className="form-control"
                placeholder={this.props.isAddCustomer ? 'Enter Customer mobile number' : 'Enter Mobile Number'}
                value={this.state.MobileNumber}
                onChange={this.__handleMobileNumber}
                maxLength="10"
                onKeyPress={(e) =>
                  this.__handleKeyPress(e, "Enter Mobile Number")
                }
                autofocus
                id="MobileNumber"
                name="MobileNumber"
              />

              <span className="input-icon">
                {" "}
                <CallIcon />
              </span>
              {this.state.MobileNumberError && (
                <p className="error-form">{this.state.MobileNumberError}</p>
              )}

              {/* <input
                className="form-control refer-input"
                placeholder="Refer Code (Optional)"
                value={DOMPurify.sanitize(this.state.referCode)}
                onChange={this.__handleReferCode}
                maxLength="10"
                onKeyPress={(e) => this.__handleKeyPress(e, "Enter Refer Code")}
                id="referCode"
                name="referCode"
              /> */}
            </div>

            {this.props.isAddCustomer ? <div>
              <SelectSearch
                style={{ margin: "10px 8px 20px" }}
                placeholderValue={"Loan Type"}
                label={"Loan Type"}
                value={this.state.data.loanType}
                page="personal"
                setSelectedOption={(e) => {
                  const data = { ...this.state.data };
                  const errors = { ...this.state.errors };


                  if (this.state.MobileNumber.length === 10 && /^[6789]\d{9}$/.test(this.state.MobileNumber)) {
                    this.setState({ disable: false });
                  }

                  if (e) {
                    data.loanType = e;
                    errors.loanType = "";
                    this.setState({ data, errors });
                  }
                }}
                dropDownOptions={Loan_Type_ASM}
                icon={
                  <Money
                    style={{ marginRight: "5px", marginTop: "2px" }}
                  />
                }
              ></SelectSearch>

              <p style={{ color: "#e74d10", marginTop: "-15px", textAlign: "left", fontSize: "14px" }}>{this.state.errors?.loanType}</p>
            </div> : ""}

            <div className="col-sm-12 text-center">
              <button
                disabled={this.state.disable}
                type="submit"
                onClick={(e) => this.__handleRequestForOTP(e)}
                className="btn btn-primary get-otp-btn"
              >
                Get OTP
              </button>
            </div>
            <div className="bs-terms-of-use">
              By logging in, you agree to the following{" "}
              <a href="https://wefin.in/terms-of-use.html">
                Terms of Use
              </a>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingLogin: getCustomer(state).loadingLogin
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerLogin: (params, callback) =>
    dispatch(setCustomerLogin(params, callback)),
  getCustomerOTP: (params, callback) =>
    dispatch(getCustomerOTP(params, callback))
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(LoginForm)
);
