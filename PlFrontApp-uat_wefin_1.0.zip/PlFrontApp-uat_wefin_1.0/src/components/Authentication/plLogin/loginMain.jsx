import React, { useEffect } from "react";
import LeftMenuDecider from "../../../common/leftMenuContent";
import LoginForm from "./LoginForm";
import SecureLS from "secure-ls";
import SetEmailForm from "./SetEmailForm";
import OTPForm from "./otpForm";
import BottomSection from "../../../common/bottom";
import CreditFooter from "../../cibilFlow/footer";

import DownloadAppModal from "../../../common/DownloadApp";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const LoginPLMain = () => {
  const [step, setStep] = React.useState(1);
  const [data, setData] = React.useState({});
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  useEffect(() => {
    localStorage.clear();
    localStore.removeAll();
    localStorage.removeItem("GCToken");
  }, []);

  const leftSideStep = () => {
    switch (step) {
      case 1:
        return (
          <LoginForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 2:
        return (
          <OTPForm updateStep={updateStep} data={data} setData={setData} />
        );
      case 3: {
        return <SetEmailForm />;
      }
      default:
        break;
    }
  };

  const checkUTMLinks = () => {
    if (window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_TWO_WHEELER) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    } else if (
      window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_CREDIT_CARD
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.UTM_WELFUND_HIDE_POPUP.UTM_PERSONAL_LOAN
    ) {
      return false;
    }
    else if (
      window.location.href === CONSTANTS.CREDIT_SAISION_POPUP_HIDE.CREDIT_SAISION_LINK
    ) {
      return false;
    } else {
      return true;
    }
  };

  return (
    <>
      {getOS() !== "desktop" && checkUTMLinks() && <DownloadAppModal />}
      <section className="bs-login-section">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1">
              <div>
                <LeftMenuDecider leftComponent={2} />
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2">
              {leftSideStep()}
            </div>
          </div>
        </div>
      </section>
      <section className="cs-login-content">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Personal loans </h2>
              <p>
                Personal loans are a type of an unsecured loan, which is meant
                for immediate requirements. It can be used for various purposes
                including wedding, home renovation, travel and more.
                Moreover, you can borrow up to 40 lakhs to fullfil your financial requirements. It also helps you to build your credit faster when
                compared with other forms of credit.
              </p>
              <h5>Eligibility Criteria</h5>
              <p>
                Following details are evaluated by lending partners while
                reviewing your loan applications.
              </p>
              <table>
                <tr>
                  <th>Criteria</th>
                  <th>Salaried</th>
                  <th>Self-Employed</th>
                </tr>
                <tr>
                  <td>Age </td>
                  <td>21 years to 60 years</td>
                  <td>22 years to 60 years</td>
                </tr>
                <tr>
                  <td>Monthly Salary</td>
                  <td>Rs. 15,000</td>
                  <td>Rs. 25,000</td>
                </tr>
                <tr>
                  <td>Minimum Loan Amount</td>
                  <td>Rs. 50,000</td>
                  <td>Rs. 50,000</td>
                </tr>
                <tr>
                  <td>Maximum Loan Amount</td>
                  <td>Rs. 40 lakh</td>
                  <td>Rs. 1 Cr</td>
                </tr>

                <tr>
                  <td>Minimum Tenure of Loan</td>
                  <td>12 Months</td>
                  <td>12 Months</td>
                </tr>

                <tr>
                  <td>Maximum Tenure of Loan</td>
                  <td>60 Months</td>
                  <td>48 Months</td>
                </tr>
                <tr>
                  <td>Rate of Interest </td>
                  <td>10.25% * Onwards</td>
                  <td>16% * Onwards</td>
                </tr>
              </table>
              <p className="subject-tnc">
                *Subject to T&C of banks or NBFCs
              </p>
            </div>

            <div className="col-sm-12 hdfc_pl_links">
              <h2>HDFC Bank Personal Loan</h2>
              <p>HDFC Bank Personal Loan Interest Rates start from 10.75% - 25%  p.a. Get instant Personal Loan up to Rs. 40 lakhs and also customer can avail upto Rs. 75 Lakh as per bank eligibility norms for multiple purposes. With minimum documents and easy to meet Personal Loan Eligibility Criteria, it is completely hassle free to apply for HDFC Personal Loan. You can instantly calculate EMI for the loan using EMI Calculator and get instant approval for an attractive interest rate on personal loan.</p>

              <h3>HDFC Personal Loan Details</h3>

              <table>
                <tr>
                  <th>Loan Feature </th>
                  <th>Details</th>
                </tr>
                <tr>
                  <th>Interest Rate </th>
                  <td>10.75% - 25%</td>
                </tr>

                <tr>
                  <th>Loan Quantum</th>
                  <td>Rs. 50,000 - Rs. 40 Lakhs and also Rs. 75 Lakhs as per eligibility norms</td>
                </tr>

                <tr>
                  <th>Eligibility age </th>
                  <td>
                    <ol>
                      <li>Minimum age: 21 years</li>
                      <li>Maximum age: 60 years at the end of loan tenure</li>
                    </ol>
                  </td>
                </tr>

                <tr>
                  <th>Minimum income required </th>
                  <td>Rs.25000 per month</td>
                </tr>

                <tr>
                  <th>Repayment tenure</th>
                  <td>Up to 7 Years</td>
                </tr>

                <tr>
                  <th>Processing Fees</th>
                  <td>Upto Rs. 4999/-</td>
                </tr>

                <tr>
                  <th>Prepayment Charges</th>
                  <td>4% of principal outstanding for 13 - 24 months, 3% of principal outstanding for 25 - 36 months, and 2% of principal outstanding for above 36 months</td>
                </tr>

              </table>

              <div className="mt-3">
                <p>For more info, refer to link <a href="https://www.hdfcbank.com/personal/borrow/popular-loans/personal-loan" target="_blank">https://www.hdfcbank.com/personal/borrow/popular-loans/personal-loan</a></p>
                <p className="mt-3">Note: HDFC Bank is powered by <a href="https://www.hdfcbank.com/" target="_blank">https://www.hdfcbank.com/</a> and the information mentioned here is provided by HDFC Bank.</p>

                <p className="mt-3">
                  APR Calculator : <a href="https://www.hdfcbank.com/personal/tools-and-calculators#/Footer" target="_blank">https://www.hdfcbank.com/personal/tools-and-calculators#/Footer </a>
                </p>

                <p>
                  HDFC Bank Important Links : <a href="https://www.hdfcbank.com/personal/useful-links/important-messages/product-features-and-policy" target="_blank">https://www.hdfcbank.com/personal/useful-links/important-messages/product-features-and-policy</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section >
      <BottomSection />
      <CreditFooter />
    </>
  );
};

export default LoginPLMain;
