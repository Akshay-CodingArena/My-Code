import React, { Component } from "react";
import Swal from "sweetalert2";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  setCustomerOtp,
  getCustomer,
  getCustomerOTP,
} from "../../../store/login";
import ArrowForwardIcon from "../../../include/assets/otpArrow.png";
import BackDropComponent from "../../../common/BackDropComponent";
import { encryptStore } from "../../../Utils/store";
import { getAccountInfo, getAccount } from "../../../store/account";
import { loadApplyLoan, getApplyLoan } from "../../../store/applyLoan";
import { getBankOffer, getOffer } from "../../../store/bankOffer";
import { gAKeys, gtag_report_conversion } from "../../../Utils/googleTagTracking";
import PATH from "../../../paths/Paths";
import CONSTANTS from "../../../constants/Constants";
import { gaLogEvent } from "../../../init-fcm";
import { loadConsents } from "../../../store/consent";
import { getOS } from "../../../Utils/device_function";

class OTPForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      OTPError: "",
      otp: "",
      OTPIconDisable: false,
      otpData: {},
      seconds: 40,
      showOTP: false,
      loading: false,
    };
  }

  componentDidMount = () => {
    let interval = this.___handleTimer();
    return () => {
      clearInterval(interval);
    };
  };
  ___handleTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.seconds > 0) {
        this.setState({ seconds: this.state.seconds - 1 });
      } else {
        this.setState({ showOTP: true });
        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };
  __handleOTP = (event) => {
    event.preventDefault();
    const otp = event.target.value;
    if (otp.length <= 4 && (/^[0-9]+$/.test(otp) || otp === "")) {
      this.setState({ otp: otp });
    }
  };

  __handleKeyPress = (event, key) => {
    if (event.key === "Enter" && event.shiftKey === false) {
      event.preventDefault();
      switch (key) {
        case "* * * *":
          const otp = event.target.value;
          if (otp.length === 4 && this.state.OTPIconDisable === false) {
            this.setState({ OTPIconDisable: true });
            this.__verifyOTP();
          }
          break;
        default:
          break;
      }
    }
  };
  __verifyOTP = () => {
    this.setState({ loading: true });
    localStorage.setItem("mobilenumber", this.props.data.mobile);
    let FCMToken = localStorage.getItem("GCToken");
    const formData = {
      otp: this.state.otp,
      mobile: this.props.data.mobile,
      loginType: "otp",
      webFCMToken: FCMToken,
    };
    setTimeout(() => {
      this.props.setCustomerOtp(formData, this.callBackOTP);
    }, 3000);
  };
  callBackOTP = (res) => {
    if (res) {
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.OTP_VERFIED);
        this.setState({ loading: false });

        localStorage.setItem("ASM_Flow_For", "loans")


        localStorage.setItem("firstName", res.data.data.firstname);
        localStorage.setItem("fullName", res.data.data.name);
        localStorage.setItem("lastName", res.data.data.lastname);
        localStorage.setItem("accessToken", res.data.data.accessToken);
        localStorage.setItem("email", res.data.data.Email);
        localStorage.setItem("referCode", res.data.data.refer_code);
        sessionStorage.setItem("logout", window.location.origin)
        const formData = {
          consentName: "CONSENT_POLICY",
          consentType: "BTN",
          consentStatus: "true",
          platform: getOS() === "ios"
            ? "web_ios"
            : getOS() === "android"
              ? "web_android"
              : "web",
        }
        this.props.loadConsents(formData, this.consentCallback)
        if (this.props.data.existing) {
          localStorage.setItem("userExists", 1);
          gaLogEvent(CONSTANTS.GA_EVENTS.EXISTING_CUSTOMER);
          const mobile = localStorage.getItem("mobilenumber");
          this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
        } else {
          gaLogEvent(CONSTANTS.GA_EVENTS.NEW_CUSTOMER);
          this.props.updateStep(null, 3);
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: true,
          timer: 1800,
        });
        this.setState({ OTPIconDisable: false, loading: false });
      }
    }
  };
  consentCallback = (res) => {
    if (res) {
      console.log(res)
    }
  }
  callbackDetail = (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.PERSONAL_LOAN);
        });
      } else {
        let loanType = CONSTANTS.LOAN_TYPE.PERSONAL_LOAN;

        if (this.props.isAddCustomer) {
          loanType = this.props.data.ASM_LOAN_TYPE.value
        }

        const mobile = localStorage.getItem("mobilenumber");

        const urlSearchParams = new URLSearchParams(window.location.search);
        const params = Object.fromEntries(urlSearchParams.entries());
        /////////////UTM CODE////////////
        let isUTM = params.hasOwnProperty('utm_source');
        /////////////////////////////////////////////////////////////
        if (isUTM) {
          var formData;
          formData = {
            mobile: mobile,
            utm_source: params?.utm_source,
            utm_medium: params?.utm_medium,
            utm_id: params?.utm_id,
            utm_campaign: params?.utm_campaign,
            loanType: loanType,
          };
        } else {
          formData = {
            mobile: mobile,
            loanType: loanType,
          };
        }

        this.props.loadApplyLoan(formData, this.callbackLoan);
        localStorage.setItem("email", res.data.customer.personemail);
      }
    }
  };
  callbackLoan = (res) => {
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid },
          loanType,
        } = res.data;
        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: loanType,
        };
        encryptStore(mobile, storeData);
        if (loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
          if (!this.props.customerDetail.pan_verified__c) {
            this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
          }
          /////////////////condition added for ASM/////////////
          else if (this.props.customerDetail.pan_verified__c && this.props.isAddCustomer) {
            this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
          }
          else if (
            this.props.getAccountDetail[0].pl_loans &&
            this.props.getAccountDetail[0].pl_loans.length === 1 &&
            this.props.getAccountDetail[0].pl_loans[0].loanStage === "Offers"
          ) {
            let formData =
              "mobile=" +
              mobile +
              "&loanId=" +
              this.props.getAccountDetail[0].pl_loans[0].loanId +
              "&loanType=" +
              this.props.getAccountDetail[0].pl_loans[0].loanType;

            this.props.getOffer(formData, this.callBackGet);
          }
          else if (this.props.customerDetail.pan_verified__c === true) {
            gtag_report_conversion(gAKeys.loginPersonalLoan);
            this.props.history.push(
              `${PATH.PRIVATE.LOAN_APPLICATIONS}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN_OFFERS}`
            );
          } else {
            gtag_report_conversion(gAKeys.loginPersonalLoan);
            this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
          }
        } else if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {

          if (!this.props.customerDetail.pan_verified__c) {
            this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
          }

          else if (this.props.getAccountDetail?.[0]?.hl_loans &&
            this.props.getAccountDetail?.[0]?.hl_loans?.length === 1 &&
            this.props.getAccountDetail?.[0]?.hl_loans?.[0]?.loanStage === "Captured") {

            Swal.fire({
              position: "center",
              icon: "error",
              title: "Your loan for Home Loan has already received.We'll keep you posted on progress.",
              showConfirmButton: false,
              timer: 5000,
            })
          } else {
            this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
          }
        } else if (loanType === CONSTANTS.LOAN_TYPE.BUSINESS_LOAN) {

          if (!this.props.customerDetail.pan_verified__c) {
            this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
          }

          else if (this.props.getAccountDetail?.[0]?.bl_loans &&
            this.props.getAccountDetail?.[0]?.bl_loans?.length === 1 &&
            this.props.getAccountDetail?.[0]?.bl_loans?.[0]?.loanStage === "Captured") {

            Swal.fire({
              position: "center",
              icon: "error",
              title: "Your loan for Business Loan has already received.We'll keep you posted on progress.",
              showConfirmButton: false,
              timer: 5000,
            })

          } else {
            this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
          }
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.PERSONAL_LOAN);
        });
      }
    }
  };
  callBackGet = (res) => {
    if (res) {
      if (res.data.success) {
        gtag_report_conversion(gAKeys.loginPersonalLoan);
        this.props.history.push({
          pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
          state: res.data,
        });
      }
    }
  };
  __handleResendForOTP = () => {
    this.props.getCustomerOTP(this.props.data.mobile, this.callBackGETOtp);
    this.setState({
      seconds: 40,
      OTPIconDisable: false,
      showOTP: false,
      otp: "",
    });
  };
  callBackGETOtp = (res) => {
    if (res) {
      if (res.data.success === true) {
        this.___handleTimer();
      }
    }
  };
  render() {
    // const { classes } = this.props;
    return (
      <div className="bs-login-block">
        {this.props.loadingGet ||
          this.props.loadingOtp ||
          this.props.loading ||
          this.props.loadingLoan ||
          this.props.loadingGetOffer ||
          this.state.loading ? (
          <BackDropComponent />
        ) : (
          ""
        )}
        <form>
          <div className="bs-login-logo">
            <img alt="" src={NEO} />
          </div>
          <div className="bs-login-title">
            {!this.props.isAddCustomer ? <h1>
              Looking for a <span>Personal Loan?</span>
            </h1> : ""}
          </div>
          <div className="LoginFormFields">
            <>
              <div className="form-group">
                <input
                  placeholder="****"
                  value={this.state.otp}
                  onChange={this.__handleOTP}
                  onKeyPress={(e) => this.__handleKeyPress(e, "* * * *")}
                  autofocus
                  id="otpField"
                  className="otpField"
                  name="otpField"
                />
                <span className="opt-arrow">
                  <img
                    src={ArrowForwardIcon}
                    alt="arrow forward icon"
                    onClick={this.__verifyOTP}
                  />
                </span>
              </div>
            </>
            <div
              className="otpBottomContainer"
              style={{
                display: "flex",
                flexDirection: "column",
                marginTop: "20px",
              }}
            >
              <div style={{ color: "#2e0080", textAlign: "center" }}>
                {this.state.seconds === 0 ? null : (
                  <h4>
                    Re-send in 00 :{" "}
                    {this.state.seconds < 10
                      ? `0${this.state.seconds}`
                      : this.state.seconds}
                  </h4>
                )}
              </div>
              <p>
                We have sent you a 4 digit verification code on your mobile
                number{" "}
                <span style={{ fontWeight: "800" }}>
                  +91-{this.props.data.mobile}
                </span>
                <a
                  href={PATH.PUBLIC.PERSONAL_LOAN}
                  style={{ color: "#2e0080", fontWeight: "700" }}
                >
                  {" "}
                  (Change)
                </a>
              </p>
              <div className="OptNotRcvd">
                {" "}
                {this.state.showOTP ? (
                  <span>
                    Didn't receive the OTP? &nbsp;
                    <button
                      type="submit"
                      onClick={this.__handleResendForOTP}
                      className="btn btn-primary get-otp-btn"
                    >
                      Resend OTP
                    </button>
                  </span>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  loadingOtp: getCustomer(state).loadingOtp,
  loadingGet: getCustomer(state).loadingGet,
  getApplyLoan: getApplyLoan(state),
  getOffer: getBankOffer(state).getBreOffer,
  getAccountDetail: getAccount(state).getAccountDetail,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
  loadingLoan: getApplyLoan(state).loadingLoan,
  loadingGetOffer: getBankOffer(state).loadingGet,
});
const mapDispatchToProps = (dispatch) => ({
  setCustomerOtp: (params, callback) =>
    dispatch(setCustomerOtp(params, callback)),
  getCustomerOTP: (params, callback) =>
    dispatch(getCustomerOTP(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadApplyLoan: (params, callback) =>
    dispatch(loadApplyLoan(params, callback)),
  getOffer: (params, callback) => dispatch(getOffer(params, callback)),
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OTPForm)
);
