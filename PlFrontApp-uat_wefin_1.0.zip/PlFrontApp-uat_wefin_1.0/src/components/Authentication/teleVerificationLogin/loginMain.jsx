import React, { useEffect } from "react";
import LeftMenuDecider from "../../../common/leftMenuContent";
import LoginForm from "./LoginForm";
import SecureLS from "secure-ls";
import CreditFooter from "../../cibilFlow/footer";
import BottomSection from "../../../common/bottom";
import DownloadAppModal from "../../../common/DownloadApp";
import { getOS } from "../../../Utils/device_function";
import CONSTANTS from "../../../constants/Constants";
import { useLocation, withRouter } from "react-router-dom";
import { useHistory } from "react-router-dom";
import PATH from "../../../paths/Paths";
import { setASMLogin } from "../../../store/asm";
import { useDispatch } from "react-redux";

let localStore = new SecureLS({
    encodingType: "aes",
    isCompression: true,
});

const LoginTeleVerificationMain = () => {
    const [step, setStep] = React.useState(1);
    const [data, setData] = React.useState({});
    const asm = useDispatch()
    const location = useLocation()
    const history = useHistory()
    const updateStep = (e, page) => {
        if (e) e.preventDefault();
        setStep(page);
    };

    useEffect(() => {
        if (localStorage.getItem("isTeleVerifier")) {
            history.push(PATH.PRIVATE.TELE_VERIFICATION_DASHBOARD)
        }
        //  localStorage.clear();
        //  localStore.removeAll();
        //   localStorage.removeItem("GCToken");
    }, []);

    const leftSideStep = () => {
        console.log(history)
        switch (step) {
            case 1: return <LoginForm updateStep={updateStep} data={data} setData={setData} />
            // case 2: history?.push(PATH.PRIVATE.ASM_DASHBOARD
            // )
            //     break
            // case 2: history?.push({
            //     pathname: PATH.PUBLIC.TWO_WHEELER_VARIANT + "/REVOLT/RV400"
            // })
            default: return null
        }

    };

    const checkUTMLinks = () => {
        if (window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_TWO_WHEELER) {
            return false;
        } else if (
            window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_PERSONAL_LOAN
        ) {
            return false;
        } else if (
            window.location.href === CONSTANTS.UTM_OPP_HIDE_POPUP.UTM_CREDIT_CARD
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_TWO_WHEELER
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_PERSONAL_LOAN
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_BUSINESS_LOAN
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_CARD
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_CREDIT_SCORE
        ) {
            return false;
        }
        else if (
            window.location.href === CONSTANTS.UTM_FASTEMI_HIDE_POPUP.UTM_HOME_LOAN
        ) {
            return false;
        }
        else {
            return true;
        }
    };

    return (
        <>
            {" "}
            {getOS() !== "desktop" && checkUTMLinks() && <DownloadAppModal />}
            <section className="bs-login-section" >
                <div className="container">
                    <div className="row d-flex justify-content-center align-items-center h-100">
                        <div className="col-12 col-sm-6 col-md-6 col-lg-7 order-2 order-md-1" >
                            <div>
                                <LeftMenuDecider leftComponent={2} />
                                {/* <h1 style={{ fontSize: '50px', fontWeight: 'bold', color: '#2E0080' }}>ASM LOGIN</h1> */}
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-5  order-md-2" style={{ height: '520px !important' }}>
                            {leftSideStep()}
                        </div>
                    </div>
                </div>
            </section>

            {/* <BottomSection /> */}
            <CreditFooter />
        </>
    );
};


export default withRouter(LoginTeleVerificationMain);
