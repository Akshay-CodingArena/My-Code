import React, { Component } from "react";
import { ReactComponent as CallIcon } from "../../../include/assets/phoneIcon.svg";
import NEO from "../../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
    setCustomerLogin,
    getCustomer,
    getCustomerOTP,
} from "../../../store/login";
import BackDropComponent from "../../../common/BackDropComponent";
import { getOS } from "../../../Utils/device_function";
import { gaLogEvent } from "../../../init-fcm";
import CONSTANTS from "../../../constants/Constants";
import SecureLS from "secure-ls";
import Joi from "joi-browser";
import Form from "../../common/form";
import { getASM, setASMLogin } from "../../../store/asm";
import PATH from "../../../paths/Paths";
import Swal from "sweetalert2";

let localStore = new SecureLS({
    encodingType: "aes",
    isCompression: true,
    isOpen: false,
    mobileNumber: "",
    MobileNumberError: "",
    referMobileNumber: "",
    name: "",
    disable: false,
});


class LoginForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                email: null,
                password: null
            },
            errors: {
                email: "",
                password: ""
            },
            disable: false,
            loading: false,
        };
    }


    componentDidMount = () => {
        if (localStorage.getItem("ASM_accessToken")) {
            //     localStorage.clear();
        }
    }

    schema = {
        email: Joi.string()
            .email()
            .required()
            .label("Email")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "string.email":
                            err.message = "Please enter a valid email";
                            break;
                        default:
                            err.message = "Email field is required";
                    }
                });
                return errors;
            }),
        password: Joi.string()
            .min(8)
            .max(16)
            .required()
            .label("Password")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "any.empty":
                            err.message = "Password field is required";
                            break;
                        case "string.min":
                            err.message = "Min 8 digits required";
                            break;
                        case "string.max":
                            err.message = "Max 16 digits required";
                            break;
                        default:
                            err.message = "Password field is required";
                    }
                });
                return errors;
            })
    }


    __handleEmail = (event) => {
        const email = event.target.value;
        this.setState(({ errors, data }) => {
            return { ...this.state, data: { ...data, email: email } }
        })
    };

    __handlePassword = (event) => {
        const password = event.target.value;
        this.setState(({ errors, data }) => {
            return { ...this.state, data: { ...data, password: password } }
        })
    }


    // __handleKeyPress = (event, key) => {
    //     if (event.key === "Enter" && event.shiftKey === false) {
    //         //      event.preventDefault();
    //         switch (key) {
    //             case "Enter Mobile Number":
    //                 const mobile_number = event.target.value;
    //                 this.setState({ disable: true });
    //                 if (mobile_number.length === 10 && this.state.disable === false) {
    //                     this.__handleRequestForOTP(event);
    //                 } else {
    //                     // let msg = "Ten digits not Entered !";
    //                 }
    //                 break;
    //             case "Enter Email":
    //                 const email = event.target.value;
    //                 this.setState({ disable: true });
    //                 if (email.length === 8) {

    //                 }
    //             default:
    //                 break;
    //         }
    //     }
    // };
    __handleRequestForOTP = (e) => {
        e.preventDefault();
        const formData = {
            email: this.state.data.email,
            password: this.state.data.password,
            version: "1.0",
            platform:
                getOS() === "ios"
                    ? "web_ios"
                    : getOS() === "android"
                        ? "web_android"
                        : "web",
        };
        const options = { abortEarly: false };
        let errors = {}
        const { error } = Joi.validate(this.state.data, this.schema, options)
        error?.details?.forEach(detail => {
            errors[detail?.context?.key] = detail?.message
        })
        if (error) {
            this.setState({ ...this.state, errors: { ...errors } })
        }
        else {
            this.props.setASMLogin(formData, this.callBackLogin)
        }
        console.log(errors, error)
        // this.props.updateStep(null, 2);

        // this.props.setCustomerLogin(formData, this.callBackLogin);
    };

    callBackLogin = (res) => {
        console.log(res)
        if (res) {
            if (res?.data.isExisting === true) {
                let role = res.data?.data?.data[0]?.role__c.toUpperCase()
                if (role === "tele_verifier".toUpperCase()) {
                    localStorage.setItem("TeleVerify_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isTeleVerify", true)
                    localStorage.setItem("ASM_fullName", res.data?.data?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])
                    this.props.history?.push(PATH.PRIVATE?.TELE_VERIFICATION_DASHBOARD)
                    // console.log("Teleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
                }
                else {
                    localStorage.setItem("ASM_accessToken", res.data?.data?.accessToken);
                    localStorage.setItem("isASM", true)
                    localStorage.setItem("ASM_fullName", res.data?.data?.name);
                    localStorage.setItem("ASM_mobilenumber", res.data?.data?.data[0]?.mobile_number__c)
                    localStorage.setItem("pin", res.data?.data?.data[0]?.pincode__c)
                    localStorage.setItem("city", res.data?.data?.data[0]?.city__c)
                    localStorage.setItem("ASM_firstName", res.data?.data?.data[0]?.name?.split(" ")[0])
                    localStorage.setItem("ASM_lastName", res.data?.data?.data[0]?.name?.split(" ")[1])

                    this.props.history?.push(PATH.PRIVATE.ASM_DASHBOARD)
                }
                // this.props.history?.push({
                //     pathname: PATH.PUBLIC.TWO_WHEELER_VARIANT + "/REVOLT/RV400"
                // })
            } else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: "Invalid Email or Password",
                    showConfirmButton: false,
                    timer: 1000
                })
            }
        }
    }

    handleShow = (e) => {
        this.setState({
            ...this.state, showPassword: e.target.checked
        })
    }

    render() {
        return (
            <div className="bs-login-block" style={{ maxHeight: '520px', height: '520px' }} >
                {
                    this.props.loadingLogin || this.props.loadingLogout || this.state.loading ? (
                        <BackDropComponent />
                    ) : (
                        ""
                    )
                }

                < form autoComplete="off" >
                    <div className="bs-login-logo">
                        <img alt="" src={NEO} />
                    </div>
                    <div className="bs-login-title">
                        <h1>
                            Signup |<span> Login</span>
                        </h1>
                    </div>
                    <div className="LoginFormFields" style={{ margin: '20px 0px 0px 0px' }}>
                        <div className="form-group">
                            <label htmlFor="MobileNumber">Email/Username</label>
                            <input
                                className="form-control"
                                placeholder="Enter Email"
                                value={this.state.data?.email}
                                onChange={this.__handleEmail}
                                autoFocus
                                id="Email"
                                name="Email"
                            />

                            <span className="input-icon">
                                {" "}
                                <CallIcon />
                            </span>
                            {this.state.errors?.email && (
                                <p className="error-form">{this.state.errors?.email}</p>
                            )}

                        </div>
                        <div className="form-group">
                            <label htmlFor="MobileNumber">Password</label>
                            <input
                                type={this.state.showPassword ? "text" : "password"}
                                className="form-control"
                                placeholder="Enter Password"
                                value={this.state.data?.password}
                                onChange={this.__handlePassword}
                                maxLength="20"
                                autoFocus
                                id="Password"
                                name="Password"
                            />

                            <span className="input-icon">
                                {" "}
                                <CallIcon />
                            </span>
                            {this.state.errors?.password && (
                                <p className="error-form" >{this.state.errors.password}</p>
                            )}

                        </div>
                        <div className="showPassword">
                            <input id="ShowPassword" checked={this.state.showPassword} onChange={(e) => this.handleShow(e)} name="ShowPassword" type="checkbox" />
                            <label htmlFor="ShowPassword">Show Password</label>
                        </div>


                        <div className="col-sm-12 text-center">
                            <button
                                disabled={this.state.disable}
                                type="submit"
                                onClick={(e) => this.__handleRequestForOTP(e)}
                                style={{ margin: '20px 0px 25px' }}
                                className="btn btn-primary get-otp-btn"
                            >
                                Login
                            </button>
                        </div>
                        {/* <div className="bs-terms-of-use">
                            By logging in, you agree to the following{" "}
                            <a href="https://bankse.in/terms-of-use.html" target="_blank">
                                Terms of Use
                            </a>
                        </div> */}
                    </div>
                </form>
            </div >
        );
    }
}
const mapStateToProps = (state) => ({
    loadingLogin: getASM(state).asmLoading
});
const mapDispatchToProps = (dispatch) => ({
    setASMLogin: (params, callback) =>
        dispatch(setASMLogin(params, callback)),
    setCustomerLogin: (params, callback) =>
        dispatch(setCustomerLogin(params, callback)),
    getCustomerOTP: (params, callback) =>
        dispatch(getCustomerOTP(params, callback))
});
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(LoginForm)
);
