import React, { Component } from "react";
import { numberFormat } from "../../Utils/numberFormat";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import Slider from "react-rangeslider";
import { decryptStore, encryptStore } from "../../Utils/store";
import Back from "../common/back";
import TopNavBar from "../../common/TopNavBar";
import LeftMenuDecider from "../../common/leftMenuContent";
import selectIcon from "../../include/assets/select-icon.svg";
import ReactTooltip from "react-tooltip";
import { ReactComponent as ArrowForwardIosIcon } from "../../include/assets/buttonArrow.svg";
import { Table } from "react-bootstrap";
import {
    updateBankOffer,
    getBankOffer,
    setBankOfferList,
    creditSaisonDedupe,
} from "../../store/bankOffer";
import BackDropComponent from "../../common/BackDropComponent";
import { getAccount, getAccountInfo } from "../../store/account";
import "react-rangeslider/lib/index.css";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../../components/cibilFlow/footer";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import Swal from "sweetalert2";
import { getTwoWheeler, offersTWRevolt, setOfferTWRevolt } from "../../store/twoWheeler";
import ASMNavBar from "../ASM/ASMNavBar";
class LoanOffer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            bank: {},
            firstName: "",
            lastName: "",
            middleName: "",
            principal: "",
            tenure: "",
            minDownpaymentAmount: 0,
            maxDownpaymentAmount: 0,
            minTenure: 0,
            maxTenure: 0,
            offers: [],
            stepperStep: 2
        };
    }

    handleApply = (bank) => {

        this.setState({ bank: bank });
        let mobile = localStorage.getItem("mobilenumber");
        let decryptData = decryptStore(mobile);
        encryptStore(localStorage.getItem("mobilenumber"), {
            ...decryptData,
            lender: bank.lenderName,
            lenderId: bank.lenderId,
            manufacturer: this.props.location.state.bike.manufacturer__c,

        })
        let formData = {
            lenderId: bank.lenderId,
            mobile: localStorage.getItem("mobilenumber"),
            loanAmount: bank.loanAmount,
            emi: bank.emi,
            roi: bank.roi,
            tenure: bank.tenure,
            pf: bank.processingFees,
            loanName: decryptData?.loanName ? decryptData.loanName : "",
            tw_master_id__c: decryptData.twMasterSfid,
            asm_id: localStorage.getItem("ASM_Id")
        };

        this.props.setOfferTWRevolt(formData, this.callBackSet);
    };

    callBackSet = (res) => {
        if (res) {
            if (res.data.success) {
                let loanSfid = res.data.data[0].sfid;
                let pl_sync_heroku_id__c = res.data.data[0].pl_sync_heroku_id__c;
                let decryptData = decryptStore(localStorage.getItem("mobilenumber"))
                encryptStore(localStorage.getItem("mobilenumber"), {
                    ...decryptData, appliedLoanAmount: res.data.data[0].pl_applied_loan_amount__c, loanSfid, loanId: pl_sync_heroku_id__c,
                })
                this.props.history.push({
                    pathname: PATH.PRIVATE.AADHAAR_SELFIE,
                    state: {
                        bike: this.props.location.state.bike
                    }
                })
                // this.props.history.push({
                //     pathname: PATH.PRIVATE.PERSONAL_DETAIL,
                //     state: { bike: this.props.location.state.bike },
                // });
            }
            else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res?.data?.message ? res.data.message : "Some error occured",
                    showConfirmButton: false,
                    timer: 1800,
                });
            }
        }

    }

    __handleEMI = (principal, tenure) => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

        let formData = {
            downPayment: principal,
            tenure: tenure,
            mobileNumber: localStorage.getItem("mobilenumber") || "",
            state: localStorage.getItem("state") || "",
            account_sfid: localStorage.getItem("accsfid") || "",
            opportunity_sfid: decryptedData.loansfid
        }
        this.props.offersTWRevolt(formData, this.callbackTWOffersRevolt);
    };

    componentDidMount = () => {

        window.scrollTo(0, 0);
        gaLogEvent(CONSTANTS.GA_EVENTS.PL_OFFERS);
        let mobile = localStorage.getItem("mobilenumber");
        let fullName = localStorage.getItem("fullName");

        let bikeData = this.props.location.state.bike;

        let minDownpaymentAmount = 5000;
        let maxDownpaymentAmount = bikeData.onRoadPrice;
        let minTenure = 24;
        let maxTenure = 42;

        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"))


        if (decryptedData.manufacturer === "REVOLT") {
            maxTenure = 42;
            minDownpaymentAmount = parseInt(this.props.location.state.bike.moneyplus_dp);
            maxDownpaymentAmount = (this.props.location.state.appliedData.maxDpPercent * parseInt(bikeData.onRoadPrice)) / 100
            this.setState({ stepperStep: 1 })
        }

        const name = fullName.split(" ");
        if (name.length > 2) {
            this.setState({
                firstName: name[0],
                lastName: name[2],
                middleName: name[1],
                principal: minDownpaymentAmount,
                tenure: maxTenure,
                minDownpaymentAmount: minDownpaymentAmount,
                maxDownpaymentAmount: maxDownpaymentAmount,
                minTenure: minTenure,
                maxTenure: maxTenure
            });
        } else {
            this.setState({
                firstName: name[0], lastName: name[1],
                principal: minDownpaymentAmount,
                tenure: maxTenure,
                minDownpaymentAmount: minDownpaymentAmount,
                maxDownpaymentAmount: maxDownpaymentAmount,
                minTenure: 24,
                maxTenure: 42
            });
        }

        let formData = {
            downPayment: minDownpaymentAmount,
            tenure: maxTenure,
            mobileNumber: localStorage.getItem("mobilenumber") || "",
            state: localStorage.getItem("state") || "",
            account_sfid: localStorage.getItem("accsfid") || "",
            opportunity_sfid: decryptedData.loansfid
        }

        this.props.offersTWRevolt(formData, this.callbackTWOffersRevolt);

        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
    };


    callbackTWOffersRevolt = (res) => {
        if (res?.data?.success) {
            this.setState({ offers: res.data.data });
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res?.data?.message ? res.data.message : "Some error occured",
                showConfirmButton: false,
                timer: 1800,
            });
            this.setState({ offers: [] });
        }
    }

    //Revolt Specific Tenure Slider
    changeTenureSlider = () => {
        let id = null
        return (v) => {
            clearTimeout(id)
            id = setTimeout(() => {
                this.setState({ tenure: this.state.tenure - v === 0 ? v : (this.state.tenure - v > 0 ? (this.state.tenure === 42 ? 36 : 24) : (this.state.tenure === 24 ? 36 : 42)) })
            }, 1000)
        }
    }
    render() {
        let tenureSlider = this.changeTenureSlider()   // Revolt Specific
        return (
            <>
                {localStorage.getItem("isASM") ? <ASMNavBar /> : <TopNavBar />}
                <section className="bs-main-section">
                    <Container>
                        <Row>
                            <Col sm={12} md={3}>
                                <LeftMenuDecider activeStep={this.state.stepperStep} state={this.props.location.state} />
                            </Col>
                            <Col sm={12} md={9}>

                                {this.props.loadinGetAccDetails || this.props.loadingOffersTWRevolt || this.props.loadingSet || this.props.loadingSetOfferTWRevolt ? (
                                    <BackDropComponent />
                                ) : (
                                    ""
                                )}
                                <div className="row">
                                    <div className="col-sm-12">
                                        <div className="bsEmiCalcBox">
                                            <div className="bsEmiCalcHeader">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="bsSliderTxt">
                                                            Max Downpayment Amount:{" "}
                                                            <strong>
                                                                {" "}
                                                                {numberFormat(
                                                                    this.state.maxDownpaymentAmount
                                                                )}
                                                            </strong>
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <div className="bsSliderTxt">
                                                            Max Tenure:
                                                            <strong>
                                                                {" "}
                                                                {this.state.maxTenure}{" "}
                                                                Months
                                                            </strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="bsEmiCalcSlider">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="bsSliderInpitBox text-right">
                                                            <span>Downpayment ₹</span>
                                                            <input
                                                                className="text-center"
                                                                type="text"
                                                                pattern="[0-9]*"
                                                                id="principal"
                                                                maxLength="7"
                                                                name="principal"
                                                                value={this.state.principal}
                                                                onChange={(e) => {
                                                                    let v = e.target.validity.valid
                                                                        ? e.target.value
                                                                        : "";
                                                                    this.setState({ principal: v });
                                                                }}
                                                                onBlur={(e) => {
                                                                    this.__handleEMI(this.state.principal, this.state.tenure)
                                                                }}
                                                            />
                                                        </div>
                                                        <Slider
                                                            className="bsEmiSlider"
                                                            min={this.state.minDownpaymentAmount}
                                                            tooltip={false}
                                                            max={this.state.maxDownpaymentAmount}
                                                            labels={{
                                                                minLoanAmount:
                                                                    "Min: " + numberFormat(this.state.minDownpaymentAmount),
                                                                2000000: "Max: " + numberFormat(this.state.maxDownpaymentAmount),
                                                            }}
                                                            value={this.state.principal}
                                                            aria-label="Default"
                                                            valueLabelDisplay="on"
                                                            onChange={(v) => {
                                                                this.setState({ principal: v })
                                                            }}
                                                            onChangeComplete={(v) =>
                                                                this.__handleEMI(this.state.principal, this.state.tenure)
                                                            }
                                                        />
                                                    </div>
                                                    <div className="col-sm-6 ">
                                                        <div className="bsSliderInpitBox text-right">
                                                            <span>Months</span>
                                                            <input
                                                                className="text-center bsMonth"
                                                                type="text"
                                                                id="tenure"
                                                                name="tenure"
                                                                pattern="[0-9]*"
                                                                maxLength="2"
                                                                value={this.state.tenure}
                                                                onChange={(e) => {
                                                                    let v = e.target.validity.valid
                                                                        ? e.target.value
                                                                        : "";
                                                                    this.setState({ tenure: v });
                                                                }}
                                                                onBlur={(e) => {
                                                                    this.__handleEMI(this.state.principal, this.state.tenure)
                                                                }}
                                                            />
                                                        </div>
                                                        <Slider
                                                            className="bsEmiSlider"
                                                            tooltip={false}
                                                            min={24}
                                                            max={42}
                                                            step={2}
                                                            labels={{
                                                                maxTenure:
                                                                    "Max: " + this.state.maxTenure + " Months",
                                                                minTenure:
                                                                    "Min: " + this.state.minTenure + " Months",
                                                            }}
                                                            value={this.state.tenure}
                                                            aria-label="Default"
                                                            valueLabelDisplay="on"
                                                            ticks={[24, 36, 42]}
                                                            ticks_snap_bounds={10}
                                                            ticks_tooltip={true}
                                                            onChange={(v) => {
                                                                tenureSlider(v)
                                                            }}
                                                            onChangeComplete={(v) =>
                                                                this.__handleEMI(this.state.principal, this.state.tenure)
                                                            }
                                                        />
                                                        <span style={{ fontSize: '11px', position: 'absolute', left: '230px', top: '72px' }}>36 Months</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-sm-12">
                                        <div>
                                            <div className="bsResponsiveTable">
                                                <Table className="bsLoanOfferTable striped bordered hover">
                                                    <thead>
                                                        <tr>
                                                            <th>Bank</th>
                                                            <th>Processing Fees</th>
                                                            <th>ROI</th>
                                                            <th>
                                                                EMI{" "}
                                                                <p
                                                                    data-tip={
                                                                        "*T&C. The charges shown are indicative and the EMI figure is indicative for" +
                                                                        " " +
                                                                        this.state.maxTenure +
                                                                        " " +
                                                                        "months tenure ."
                                                                    }
                                                                    data-background-color="#2e0080"
                                                                    data-text-color="#FFF"
                                                                    data-place="top"
                                                                    style={{
                                                                        display: "inline-block",
                                                                        cursor: "pointer",
                                                                    }}
                                                                >
                                                                    (T&C)
                                                                </p>
                                                                <ReactTooltip />
                                                            </th>
                                                            <th>Proceed</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.state.offers.length ? (
                                                            this.state.offers
                                                                .slice()
                                                                .sort((a, b) => b.isInstant - a.isInstant)
                                                                .map((e, i) => (
                                                                    <tr key={i}>
                                                                        <td align="left">
                                                                            {e.isInstant === true ? (
                                                                                <div className="InstantApproveBox">
                                                                                    <img
                                                                                        src={selectIcon}
                                                                                        alt="select Icon"
                                                                                    />{" "}
                                                                                    2 Min Disbursal
                                                                                </div>
                                                                            ) : (
                                                                                ""
                                                                            )}
                                                                            {e.lenderLogo ? (
                                                                                <img
                                                                                    src={e.lenderLogo}
                                                                                    alt=""
                                                                                    width="100"
                                                                                />
                                                                            ) : (
                                                                                <img
                                                                                    src="/bankLogos/default.svg"
                                                                                    alt=""
                                                                                    style={{ width: "60px" }}
                                                                                />
                                                                            )}
                                                                        </td>

                                                                        <td
                                                                            align="left"
                                                                            style={{
                                                                                color: "#2e0080",
                                                                                fontWeight: 600,
                                                                            }}
                                                                        >
                                                                            {numberFormat(e.processingFees)}<span>*</span>{" "}
                                                                        </td>
                                                                        <td
                                                                            align="left"
                                                                            style={{
                                                                                color: "#2e0080",
                                                                                fontWeight: 600,
                                                                            }}
                                                                        >
                                                                            {e.roi}<span>%</span>{" "}
                                                                        </td>

                                                                        <td
                                                                            align="left"
                                                                            style={{
                                                                                color: "#2e0080",
                                                                                fontWeight: 600,
                                                                            }}
                                                                        >
                                                                            {numberFormat(e.emi)}<span>*</span>{" "}
                                                                        </td>


                                                                        <td align="left">
                                                                            <button
                                                                                onClick={() => this.handleApply(e)}
                                                                            >
                                                                                Apply <ArrowForwardIosIcon />
                                                                            </button>
                                                                        </td>
                                                                    </tr>
                                                                ))
                                                        ) : (
                                                            <tr>
                                                                <td align="left">No Record Found.</td>
                                                            </tr>
                                                        )}
                                                    </tbody>
                                                </Table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section >
                <CreditFooter />
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    customerDetail: getAccount(state).customerDetail,
    loadinGetAccDetails: getAccount(state).loading,
    loadingOffersTWRevolt: getTwoWheeler(state).loadingOffersTWRevolt,
    offersTwDataRevolt: getTwoWheeler(state).offersTwDataRevolt,
    loadingSet: getBankOffer(state).loadingSet,
    loadingSetOfferTWRevolt: getTwoWheeler(state).loadingSetOfferTWRevolt
});

const mapDispatchToProps = (dispatch) => ({
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    offersTWRevolt: (params, callbackDetail) =>
        dispatch(offersTWRevolt(params, callbackDetail)),
    setOfferTWRevolt: (params, callBack) =>
        dispatch(setOfferTWRevolt(params, callBack)),
});
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(LoanOffer)
);
