import React from "react";
import employer from "../../store/employer";
const employeeType = (props) => {
  return (
    <div className="form-group">
      <label htmlFor="Gender">
        Gender
        <span style={{ color: "#FF4C30" }}>*</span>
      </label>
      <div onChange={(e) => props.onChangeGender(e)}>
        <div className="form-check form-check-inline radioBtn">
          <input
            className="form-check-input"
            id="male"
            type="radio"
            value="1"
            name="gender"
            defaultChecked
          />
          <label className="form-check-label" htmlFor="male">
            Male{" "}
          </label>
        </div>
        <div className="form-check form-check-inline radioBtn">
          <input
            className="form-check-input"
            type="radio"
            id="female"
            value="2"
            name="gender"
          />{" "}
          <label className="form-check-label" htmlFor="female">
            {" "}
            Female
          </label>
        </div>
      </div>

      <span className="input-icon">{props.icon}</span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default employeeType;
