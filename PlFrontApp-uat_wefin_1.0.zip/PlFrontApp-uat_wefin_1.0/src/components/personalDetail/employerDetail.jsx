import React from "react";
import Joi from "joi-browser";
import Form from "../../components/common/form";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/homepageIcons/monthly-icon.svg";
import { ReactComponent as BusinessIcon } from "../../include/assets/homepageIcons/bank-icon.svg";
import { ReactComponent as Industry } from "../../include/assets/personalLoan/industry.svg"
import CONSTANTS from "../../constants/Constants";
// import Back from "../common/back";
// import USER_ICON from "../../include/assets/1/smartphone@2x.png";
import SelectSearch from "../../components/common/select";
import PersonalAmountInput from "../common/personalAmountInput";
import { loadEmployerDetail, getEmployer } from "../../store/employer";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import CreatableSelect from "react-select/creatable";
import { decryptStore } from "../../Utils/store";
import { getBankName, getApplicant } from "../../store/applicantDetail";
import { gaLogEvent } from "../../init-fcm";
import BackDropComponent from "../../common/BackDropComponent";
import * as DOMPurify from 'dompurify';
import { getAccount, getAccountInfo } from "../../store/account";
import customerDetail from "./customerDetail";
import EmployeeType from "../common/employeeType";
import PATH from "../../paths/Paths";
import { perfiosCheck, perfiosData } from "../../store/perfios";
import { employmentTypeFilter } from "../common/dropdownValues";
import { organization_type_perfios } from "../common/fullerTonDropdown";
import Radio from "../common/Radio";
class EmployerDetail extends Form {
  state = {
    data: {
      employeetype: '1'
    }, errors: {},
  };
  schema = decryptStore(localStorage.getItem("mobilenumber")).loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ? {
    employer: Joi.object()
      .required()
      .label("Name of Company ")
      .error(() => {
        return { message: "Name of Company field is required." };
      }),
    employeetype: Joi.string()
      .required()
      .label("Type of Employement")
      .error(() => {
        return { message: "Type of Employement field is required." };
      }),
    organization: Joi.object().required()
      .label("Organization Type").error(() => {
        return { message: "Organization Type field is required." };
      }),
    salary: Joi.string()
      .required("")
      .error(() => {
        return { message: "Monthly In-hand Salary field is required." };
      }),
    bank: Joi.object()
      .required("")
      .error(() => {
        return { message: "Salary Recieved in field is required." };
      }),
  } : {
    employeetype: Joi.string()
      .required()
      .label("Type of Employement")
      .error(() => {
        return { message: "Type of Employement field is required." };
      }),
    employer: Joi.object()
      .required()
      .label("Name of Company ")
      .error(() => {
        return { message: "Name of Company field is required." };
      }),
    salary: Joi.string()
      .required("")
      .error(() => {
        return { message: !localStorage.getItem("ASM_Id") ? "Monthly In-hand Salary field is required." : "Net Salary field is required." };
      }),
    bank: Joi.object()
      .required("")
      .error(() => {
        return { message: "Salary Recieved in field is required." };
      })
  }

  customStyles = {
    control: (provided) => ({
      ...provided,
      height: "40px",
      paddingLeft: "2px",
      borderColor: "#E0E0E0",
      borderWidth: "1px",
      boxShadow: "0 0 0 0px #2e0080",
      width: "100%",
      "&:hover": {
        borderColor: "#2e0080",
        borderWidth: "1px",
      },
      "&:focus": {
        borderColor: "#2e0080",
        borderWidth: "1px",
      },
    }),
    option: (provided, state) => ({
      ...provided,
      borderBottom: "0.5px solid rgba(46, 0, 128, 0.5)",
      textAlign: "left",
      fontSize: "15px",
      padding: "7px 10px",
      width: "100% !important",
      maxWidth: "100% !important",
      backgroundColor: state.isSelected
        ? "#2e0080"
        : state.isFocused
          ? "rgba(46, 0, 128, 0.12)"
          : "#eae4f9",
    }),
    menu: (provided) => ({
      ...provided,
      borderRadius: "5px",
      color: "#5E5E5E",
      background: "#eae4f9",
      zIndex: 12,
      width: "100%",
    }),
    dropdownIndicator: (base) => ({
      ...base,
      marginTop: "6px",
    }),
  };

  populateData = () => {
    return {
      salary: this.props.getCustomerDetail?.monthlysalary?.toString()
    }
  }

  callBackDetails = (res) => {
    if (res.data.customer?.monthlySalary) {
      this.setState({ ...this.state, data: { ...this.state.data, salary: res.data.customer?.monthlysalary } })
    }
  }

  onChangeEmploymentType = (type) => {
    const data = { ...this.state.data };
    data.employeeType = type;
    this.setState({ data })
  };

  componentDidMount = () => {
    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"))
    if (decryptedData.lender === "Money Plus" && decryptedData.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
      this.props.setStepperStep(3);
    }

    let mobile = localStorage.getItem("mobilenumber");
    this.props.loadEmployerDetail({ mobile: mobile, companyStr: "" });
    let formData = "mobile=" + mobile + "&bankStr=";
    this.props.getBankName(formData);
    console.log("details", this.props.getCustomerDetail)
    if (this.props.getCustomerDetail) {
      this.setState((p) => ({
        ...p,
        data: {
          ...p.data,
          ...this.populateData(),
        },
      }));
    } else {
      this.setState({ ...this.state, loader: true })
      this.props.getAccountInfo({ mobile: localStorage.getItem("mobilenumber") }, this.callBackDetails)
    }
    //  console.log("This is employeeer........")
  };
  _handleChangeSalary = (event) => {
    event.preventDefault();
    const salaryMonthly = event.target.value;
    if (salaryMonthly.length <= 16 || salaryMonthly === "") {
      const data = { ...this.state.data };
      const errors = { ...this.state.errors };
      errors.salary = "";
      data.salary = salaryMonthly.replace(/\D+/g, "");
      this.setState({ data, errors });
    }
  };

  onChangeEmployeeType = (e) => {
    console.log(e.target.value);

    if (e) {
      const data = { ...this.state.data };
      data.employeetype = e.target.value;
      this.setState({ data });
    }
  };

  handleInputChange = (character) => {

    let mobile = localStorage.getItem("mobilenumber");
    this.setState((prevState) => {
      return {
        characterEntered: prevState.characterEntered,
      };
    });
    if (character && this.state.characterEntered !== character) {
      //  this.state.employersDetail({ mobile: mobile, companyStr: character })
      this.props.loadEmployerDetail({ mobile: mobile, companyStr: character });
    }
  };

  callBackPerfios = (res) => {
    let { loanType } = decryptStore(localStorage.getItem("mobilenumber"))
    this.props.history.push({
      pathname: PATH.PRIVATE.UPLOAD_BANK_STATEMENT,
      state: { ...this.props.state, loanType: CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN },
    })
  }
  doSubmit = () => {
    const errors = { ...this.state.errors };
    if (!(/^[A-Za-z0-9 .]*$/.test(this.state.data.employer.label))) {
      errors.employer = "Invalid Name of Company format.";
      this.setState({ errors });
      return;
    }
    this.props.setpLData((prevState) => ({
      ...prevState,
      employerName: this.state.data.employer.label,
      monthlySalary: this.state.data.salary,
      bank: this.state.data.bank.value,
    }));
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
      gaLogEvent(CONSTANTS.GA_EVENTS.CC_BASIC_DETAILS_2);
    } else if (loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
      gaLogEvent(CONSTANTS.GA_EVENTS.PL_LOAN_DETAILS_2);
    }
    else {
      gaLogEvent(CONSTANTS.GA_EVENTS.TW_DETAILS_2);
    }
    if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
      let { loanSfid, loanName } = decryptStore(localStorage.getItem("mobilenumber"))
      let formData = {
        mobile: localStorage.getItem("mobilenumber"),
        email: localStorage.getItem("email"),
        employmentType: employmentTypeFilter[this.state.data.employeetype],
        salary: this.state.data.salary,
        companyName: this.state?.employerName.name,
        salaryBankName: this.state.data.bank?.value,
        companyType: this.state.data.organization.value,
        loanSfid,
        loanName
      }
      this.props.perfiosCheck(formData, this.callBackPerfios)
      // this.props.updateStep(null, CONSTANTS.RENDER_UPLOAD_DOCUMENTS)

      //Upload Salary
    } else {

      this.props.updateStep(null, CONSTANTS.RENDER_PERSONAL_LOAN_CUSTOMER_DETAIL);
    }
  }

  formatCreate = (inputValue) => {
    return <p> Add: {inputValue}</p>;
  };


  render() {
    const { employerDetail, bankName } = this.props;
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;

    return (
      <div className="row insideFormBlock">
        {this.state.loading || this.props.perfiosloader ? <BackDropComponent /> : ""}
        <div className="col-sm12">
        </div>
        <div className="col-sm-12 text-center">
          <div className="bsFormHeader">
            {/* <div className="bsFormHeaderIcon">
              <img alt="" src={USER_ICON} />
            </div> */}
            {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
              <h1>We will check Credit Cards offers against your Details </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
              <h1>Check Two Wheeler Loan offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
              <h1>Check Personal Loan offers </h1>
            )}{" "}
          </div>
        </div>
        <div className="col-sm-12">
          <form className="panVeryfyForm">
            <div className="panFormFields">

              {
                loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
                  <>
                    <div>
                      <label htmlFor="EmployeeType">
                        Employment Type
                        <span style={{ color: "#FF4C30" }}>*</span>
                      </label>
                    </div>
                    <div className="mb-3">
                      <Radio
                        value={'1'}
                        label={'Salaried'}
                        groupValue={this.state.data.employeetype}
                        onClick={() => this.onChangeEmploymentType('1')}
                      />

                      <Radio
                        value={'2'}
                        label={'Self Employed Business'}
                        disabled={true}
                        groupValue={this.state.data.employeetype}
                        onClick={() => this.onChangeEmploymentType('2')}
                      />

                      <Radio
                        value={'3'}
                        label={'Self Employed Professional'}
                        disabled={true}
                        groupValue={this.state.data.employeetype}
                        onClick={() => this.onChangeEmploymentType('3')}
                      />
                    </div>
                  </>
                  : null
              }
              <div className="form-group">
                <label htmlFor="employer">
                  Name of Company
                  <span style={{ color: "#FF4C30" }}>*</span>
                </label>
                <CreatableSelect
                  style={{ color: "#f00" }}
                  isClearable
                  styles={this.customStyles}
                  name="employer"
                  onChange={(e) => {
                    if (e) {
                      if (e.__isNew__) {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        errors.employer = "";
                        data.employer = e;
                        this.setState({ errors, data, value: e.value });
                      } else {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        errors.employer = "";
                        data.employer = e;
                        this.setState({
                          data,
                          errors,
                          employerName: e.value,
                        });
                      }
                    }
                    if (e === null) {
                      const data = { ...this.state.data };
                      data.employer = "";
                      this.setState({
                        data,
                        employerName: {},
                        value: "",
                      });
                    }
                  }}
                  onInputChange={this.handleInputChange}
                  options={employerDetail.map((item) => ({
                    label: item.name,
                    value: item,
                  }))}
                  placeholder="Select Company Name"
                  formatCreateLabel={this.formatCreate}
                  value={
                    this.state.data.employer &&
                    this.state.data.employer.label &&
                    this.state.data.employer
                  }
                />
                <span className="dropIcon">
                  <BusinessIcon
                    style={{ marginBottom: "-6px", marginRight: "5px" }}
                  />
                </span>
                {this.state.errors.employer && (
                  <p className="bsInputErr">{this.state.errors.employer}</p>
                )}
              </div>
              {
                loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ?
                  <div className="form-group">
                    <SelectSearch
                      placeholderValue={"Organization Type"}
                      label={"Organization Type"}
                      value={this.state.data.organization}
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.organization = e;
                          errors.organization = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={organization_type_perfios}
                      error={this.state.errors.organization}
                      icon={
                        <Industry
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>
                  : null
              }
              {/* </div> */}

              <div className="form-group">
                <PersonalAmountInput
                  value={this.state.data.salary}
                  __handleChange={this._handleChangeSalary}
                  error={this.state.errors.salary}
                  icon={<CardMembershipIcon />}
                  label={localStorage.getItem("ASM_Id") ? "Net Salary" : "Monthly In-hand Salary"}
                  required={true}
                />
              </div>
              <div className="form-group">
                <SelectSearch
                  icon={
                    <BusinessIcon
                      style={{ marginRight: "3px", marginTop: "2px" }}
                    />
                  }
                  placeholderValue={"Select Bank"}
                  label={"Salary Recieved In"}
                  value={this.state.data.bank}
                  page="personal"
                  setSelectedOption={(e) => {
                    const data = { ...this.state.data };
                    const errors = { ...this.state.errors };
                    if (e) {
                      data.bank = e;
                      errors.bank = "";
                      this.setState({ data, errors });
                    }
                  }}
                  dropDownOptions={bankName.map((item) => ({
                    label: item.bankName,
                    value: item.bankName,
                  }))}
                  error={this.state.errors.bank}
                ></SelectSearch>
              </div>

              <div className="col-sm-12 text-center">
                <button
                  type="submit"
                  onClick={this.handleSubmit}
                  variant="contained"
                  className="nextButton"
                >
                  Next
                </button>
              </div>
            </div >
          </form >
        </div >
      </div >
    );
  }
}
const mapStateToProps = (state) => ({
  employerDetail: getEmployer(state).employerDetail,
  loadingDetail: getEmployer(state).loadingDetail,
  bankName: getApplicant(state).bankName,
  getCustomerDetail: getAccount(state).customerDetail,
  perfiosloader: perfiosData(state)?.loadingPerfios
});
const mapDispatchToProps = (dispatch) => ({
  perfiosCheck: (params, callback) => dispatch(perfiosCheck(params, callback)),
  loadEmployerDetail: (params) => dispatch(loadEmployerDetail(params)),
  getBankName: (params) => dispatch(getBankName(params)),
  getAccountInfo: (params) => dispatch(getAccountInfo(params))
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(EmployerDetail)
);
