import React, { Component } from "react";
import { numberFormat } from "../../Utils/numberFormat";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import Slider from "react-rangeslider";
import { decryptStore, encryptStore } from "../../Utils/store";
// import Back from "../common/back";
import TopNavBar from "../../common/TopNavBar";
import LeftMenuDecider from "../../common/leftMenuContent";
import selectIcon from "../../include/assets/select-icon.svg";
import ReactTooltip from "react-tooltip";
import { ReactComponent as ArrowForwardIosIcon } from "../../include/assets/buttonArrow.svg";
import { Modal, Table } from "react-bootstrap";
import {
  updateBankOffer,
  getBankOffer,
  setOfferList,
  setBankOfferList,
  creditSaisonDedupe,
} from "../../store/bankOffer";
import BackDropComponent from "../../common/BackDropComponent";
import { getAccount, getAccountInfo } from "../../store/account";
import "react-rangeslider/lib/index.css";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../../components/cibilFlow/footer";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import Swal from "sweetalert2";
import { axisPL, moneyViewRedirection, earlySalaryRedirection } from "../../store/personalLoan/axis";
import { getExperian, loadExperianCheck } from "../../store/experian";
import { paysensePL, paysenseGetPlans } from "../../store/personalLoan/paysense";

class LoanOffer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      principal: "",
      tenure: "",
      bank: {},
      firstName: "",
      lastName: "",
      middleName: "",
      redirectionModalIsOpen: false,
      redirectionLink: ""
    };
  }


  handleApply = (bank) => {
    console.log("applied", bank)

    if (bank.lenderName === "Fibe") {
      bank = { ...bank }
      delete bank.utmUrl
    }

    this.setState({ bank: bank });

    let formData = {
      lenderId: bank.lender_id__c,
      loanType: bank.loanType,
      mobile: localStorage.getItem("mobilenumber"),
      loanAmount: bank.appliedLoanAmount,
      offerId: bank.id,
      emi: bank.emi,
      roi: bank.IRR,
      tenure: bank.appliedTenure,
      pf: bank.PF,
      loanId: bank.loanId ? bank.loanId : "",
    };
    if (localStorage.getItem("isUTM")) {
      let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
      formData.utm_source = UTM_Data?.utm_source;
      formData.utm_medium = UTM_Data?.utm_medium;
      formData.utm_id = UTM_Data?.utm_id;
      formData.utm_campaign = UTM_Data?.utm_campaign;
    }
    this.props.setOfferList(formData, this.callBackSet);
  };

  callBackSet = (res) => {
    if (res) {
      console.log("bank", this.state.bank.lenderName)
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.PL_OFFER_SELECTED, {
          Lender_Name: this.state.bank.lenderName,
        });
        const mobile = localStorage.getItem("mobilenumber");
        let storeData = {
          lenderId: res.data.data.lenderId,
          loansfid: res.data.data.loansfid,
          sfid: res.data.data.sfid,
          lenderName: this.state.bank.lenderName,
          loanName: res.data.data.loanName
        };
        localStorage.setItem("loansfid", res.data.data.loansfid)
        encryptStore(mobile, storeData);
        if (this.state.bank.utmUrl) {
          window.open(this.state.bank.utmUrl, "_blank");
          this.props.history.push("/loan-applications/pl_loans/pl_offers");
        } else if (
          this.state.bank.lenderName === "Axis" ||
          this.state.bank.lenderName === "Axis Bank"
        ) {
          const formData = {
            firstName: this.state.firstName
              ? this.state.firstName
              : this.props.customerDetail.firstname,
            middleName: this.state.middleName
              ? this.state.middleName
              : this.props.customerDetail.middlename,
            lastName: this.state.lastName
              ? this.state.lastName
              : this.props.customerDetail.lastname,
            loanId: res.data.data.loansfid,
            loanType: res.data.loanType,
            lenderId: this.state.bank.lender_id__c,
            mobile: mobile,
            offerId: this.state.bank.id && this.state.bank.id.toString(),

          };
          this.props.setBankOfferList(formData, this.callBackSetOffer);
        } else if (this.state.bank.lenderName === "Pay Sense") {
          let formData = {
            lenderId: this.state.bank.lender_id__c,
            loanName: res.data.data.loanName
          }
          this.props.paysenseGetPlans(formData, this.callbackGetPlans)
        }
        else if (this.state.bank.lenderName === "HDFC") {
          console.log(this.props.customerDetail)

          let storeData = {
            loanAmount: this.state.bank.appliedLoanAmount,
            proposedEmi: this.state.bank.emi,
            tenure: this.state.bank.appliedTenure,
            monthlySalary: this.props.customerDetail.monthlysalary,
            employerNameCode: this.props.customerDetail.pl_employer__pc
          };

          encryptStore(mobile, storeData);

          this.props.history.push({ pathname: PATH.PRIVATE.HDFC_PL_FLOW, state: { step: CONSTANTS.ADDITIONAL_INFO_HDFC_PL, stepperData: {}, appliedLoanInfo: { ...this.state.bank } } })
        }
        else if (this.state.bank.lenderName === "Fibe") {
          let formData = {
            mobilenumber: localStorage.getItem("mobilenumber"),
            firstname: this.props.customerDetail?.firstname ? this.props.customerDetail.firstname : "",
            lastname: this.props.customerDetail?.lastname ? this.props.customerDetail.lastname : "",
            gender: this.props.customerDetail?.gender ? this.props.customerDetail.gender : "",
            profession: this.props.customerDetail?.emptype__c ? this.props.customerDetail.emptype__c : "",
            pincode: this.props?.userData?.length ? this.props?.userData[0].pincode.toString() : "",
            pan: this.props?.userData?.length ? this.props?.userData[0].pan : "",
            dob: this.props.customerDetail?.dob ? this.props.customerDetail.dob.split("T")[0] : "",
            emailid: localStorage.getItem("email"),
            officepincode: this.props?.userData?.length ? this.props?.userData[0].pincode.toString() : "",
            salary: this.props.customerDetail?.monthlysalary ? this.props.customerDetail.monthlysalary.toString() : "",
            loanname: res.data.data.loanName
          }
          this.props.earlySalaryRedirection(formData, this.callbackRedirection)
        }
        else if (this.state.bank.lenderName === "Money View") {
          let formData =
          {
            phone: localStorage.getItem("mobilenumber"),
            loanName: res.data.data.loanName,
            lenderId: this.state.bank.lender_id__c,
            sfid: res.data.data.sfid,
            gender: this.props.customerDetail?.gender ? this.props.customerDetail.gender.toLowerCase() : "",
            email: this.props.customerDetail?.personemail ? this.props.customerDetail.personemail : "",
            declaredIncome: this.props.customerDetail?.monthlysalary
              ? this.props.customerDetail.monthlysalary
                .toString() : "",
            dateOfBirth: this.props.customerDetail?.dob ? this.props.customerDetail.dob.split("T")[0] : "",
            pincode: this.props?.userData?.length ? this.props?.userData[0].pincode : "",
            name: this.props.customerDetail?.name ? this.props.customerDetail.name : "",
            pan: this.props?.userData?.length ? this.props?.userData[0].pan : "",
            employmentType: this.props.customerDetail?.emptype__c ? this.props.customerDetail.emptype__c : "Salaried"
          }
          this.props.moneyViewRedirection(formData, this.callbackRedirection)
        }
        else if (this.state.bank.lenderName === "Credit Saison") {
          const formData = {
            loanId: res.data.data.loansfid,
            loanType: res.data.loanType,
            lenderId: this.state.bank.lender_id__c,
            mobile: mobile,
            offerId: this.state.bank.id && this.state.bank.id.toString(),
            loanName: res.data.data.loanName,
          };
          this.props.creditSaisonDedupe(formData, this.callBackDedupe);
        } else {
          this.props.history.push({
            pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
              }/${this.state.bank.loanType
                .split(/\s/)
                .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank,
          });
        }
      }
    }
  };

  callbackGetPlans = (res) => {
    if (res.data.success) {
      this.props.history.push({
        pathname: PATH.PRIVATE.PAYSENSE_PL_FLOW,
        state: {
          step: CONSTANTS.GET_PLANS_SCREEN_PAYSENSE,
          stepperData: { ...this.state.bank },
          data: res.data.response
        }
      })
    } else {
      Swal.fire({
        position: "center",
        icon: "error",
        title: res.data.message,
        position: "center",
        showConfirmButton: true,
      })
    }
  }

  callbackRedirection = (res) => {
    if (res.data.success) {
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      if (decryptedData.lenderName === "Money View") {
        window.open(res.data.redirectionUrl, "_blank")
        this.props.history.push(PATH.PRIVATE.PRODUCTS)
      }
      else if (decryptedData.lenderName === "Fibe") {
        window.open(res.data.data.earlySalaryIngestion.responseData.redirectionUrl, "_blank")
        this.props.history.push(PATH.PRIVATE.PRODUCTS)
      }
    } else {
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      if (decryptedData.lenderName === "Fibe") {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data?.data?.earlySalaryIngestion?.responseData?.reason ? res.data.data.earlySalaryIngestion.responseData.reason : "",
          position: "center",
          showConfirmButton: true,
        })
      }
      else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: `<div>${res.data.message ? res.data.message : ""}</div><div>${res.data?.leadResponse?.responseData?.message ? res.data.leadResponse.responseData.message : ""}</div>`,
          position: "center",
          showConfirmButton: true,
        })

      }

    }
  }
  callBackDedupe = (res) => {
    try {
      if (res.data.success) {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
            }/${this.state.bank.loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
          state: this.state.bank,
        });
      } else if (res.data.description.toString().toLowerCase() === "entity exists") {
        throw new Error(
          "We are unable to proceed with this application as one of your's previous application is already in queue with Credit Saison"
        );
      } else {
        throw new Error(res.data.description);
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };
  callBackSetOffer = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push("/loan-applications/pl_loans/pl_offers");
        const url =
          res.data.axisData &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted.Response &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted.Response
            .productUrl;
        window.open(url, "_blank");
      }
    }
  };
  __handleEMI = (amount, time) => {
    this.setState({ principal: amount, tenure: time });
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid } = decryptedData;
    let formData = {
      mobile: mobile,
      loanType: CONSTANTS.LOAN_TYPE.PERSONAL_LOAN,
      loanId: loansfid,
      loanAmount: amount.toString(),
      tenure: time.toString(),
    };
    this.props.updateBankOffer(formData, this.callBackUpdate);
  };
  callBackUpdate = (res) => {
    if (res?.success === false) {
    }
  };
  componentDidMount = () => {
    window.scrollTo(0, 0);
    gaLogEvent(CONSTANTS.GA_EVENTS.PL_OFFERS);
    let mobile = localStorage.getItem("mobilenumber");
    let fullName = localStorage.getItem("fullName");
    const name = fullName.split(" ");
    if (name.length > 2) {
      this.setState({
        firstName: name[0],
        lastName: name[2],
        middleName: name[1],
      });
    } else {
      this.setState({ firstName: name[0], lastName: name[1] });
    }

    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);


    const { breData } = this.props.updateOffer.appliedLoanAmount
      ? this.props.updateOffer
      : (this.props.twData ? this.props.twData : this.props.location && this.props.location?.state)
    this.setState({
      principal:
        breData && breData.length > 0 ? breData[0].appliedLoanAmount : 0,
      tenure: 60
      //initillay set tenure to 60 to get the maximum offers/////
      // breData && breData.length > 0 ? breData[0].appliedTenure : 72
      ,
    });
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
  };

  callbackDetail = (res) => {
    if (res.data.success) {
      let formData = {
        mobile: localStorage.getItem("mobilenumber"),
        isExperian: true,
      };
      this.props.loadExperianCheck(formData, this.callBackVerify);
    }
  }

  callBackVerify = (res) => {

    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

    if (decryptedData.lenderName === "Money View" && decryptedData.loanStage === "Assigned") {
      let formData =
      {
        phone: localStorage.getItem("mobilenumber"),
        loanName: decryptedData.loanName,
        lenderId: decryptedData.lenderId,
        sfid: decryptedData.sfid,
        gender: this.props.customerDetail?.gender ? this.props.customerDetail.gender.toLowerCase() : "",
        email: this.props.customerDetail?.personemail ? this.props.customerDetail.personemail : "",
        declaredIncome: this.props.customerDetail?.monthlysalary
          ? this.props.customerDetail.monthlysalary
            .toString() : "",
        dateOfBirth: this.props.customerDetail?.dob ? this.props.customerDetail.dob.split("T")[0] : "",
        pincode: this.props?.userData?.length ? this.props?.userData[0].pincode : "",
        name: this.props.customerDetail?.name ? this.props.customerDetail.name : "",
        pan: this.props?.userData?.length ? this.props?.userData[0].pan : ""
      }

      let pl_loans = this.props.getAccountDetail[0].pl_loans;

      let loanData = pl_loans.filter((value) => value.loanName === decryptedData.loanName)[0]

      switch (loanData.applicantType) {
        case 1:
          formData.employmentType = 'Salaried';
          break;
        case 2:
          formData.employmentType = 'Self Employed Business';
          break;
        case 3:
          formData.employmentType = 'Self Employed Professional';
          break;
        default:
          formData.employmentType = ''
      }
      this.props.moneyViewRedirection(formData, this.callbackRedirection)
    }
    else if (decryptedData.lenderName === "Fibe" && decryptedData.loanStage === "Assigned") {
      let formData = {
        mobilenumber: localStorage.getItem("mobilenumber"),
        firstname: this.props.customerDetail?.firstname ? this.props.customerDetail.firstname : "",
        lastname: this.props.customerDetail?.lastname ? this.props.customerDetail.lastname : "",
        gender: this.props.customerDetail?.gender ? this.props.customerDetail.gender : "",
        profession: this.props.customerDetail?.emptype__c ? this.props.customerDetail.emptype__c : "",
        pincode: this.props?.userData?.length ? this.props?.userData[0].pincode.toString() : "",
        pan: this.props?.userData?.length ? this.props?.userData[0].pan : "",
        dob: this.props.customerDetail?.dob ? this.props.customerDetail.dob.split("T")[0] : "",
        emailid: localStorage.getItem("email"),
        officepincode: this.props?.userData?.length ? this.props?.userData[0].pincode : "",
        salary: this.props.customerDetail?.monthlysalary ? this.props.customerDetail.monthlysalary.toString() : "",
        loanname: decryptedData.loanName
      }
      this.props.earlySalaryRedirection(formData, this.callbackRedirection)
    }
    else if (decryptedData.lenderName === "Fibe" && decryptedData.loanStage === "Declined") {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: "Sorry you do not qualify for the offer this time.Please continue with other banking partners.",
        showConfirmButton: true,
      })
    }
    else if (decryptedData.lenderName === "Fibe" && decryptedData.loanStage === "Hold") {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: "Apologies your loan application could not be processed due to technical error.Please try again after some time.",
        showConfirmButton: true,
      })
    }
  }
  render() {
    const { loading, updateOffer, loadingSet, loadingBank, loadingDedupe } =
      this.props;
    const { breData, minLoanAmount } = updateOffer?.appliedLoanAmount
      ? updateOffer
      : (this.props.twData ? this.props.twData : this.props.location && this.props.location?.state)
    // let maxTenure =
    //   breData && breData.length > 0 ? breData[0].appliedTenure : 72;
    const defaultAmount =
      breData && breData.length > 0 ? breData[0].appliedLoanAmount : 0;
    // let minTenure = breData && breData.length > 0 ? breData[0].min_tenure : 3;

    let maxTenure = 72;
    let minTenure = 3;
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <LeftMenuDecider activeStep={2} />
              </Col>
              <Col sm={12} md={9}>
                {/* <Back
                  onClick={() => {
                    this.props.history.push("/products");
                  }}
                /> */}
                {
                  loading || loadingSet || loadingBank || loadingDedupe || this.props.loadingMoneyView || this.props.loadinGet || this.props.loadingEarlySalary || this.props.loadingGetAccountDetails
                    || this.props.loadingCheck ||
                    this.props.loadingPaysense
                    ? (
                      <BackDropComponent />
                    ) : (
                      ""
                    )
                }
                <div className="row">
                  <div className="col-sm-12">
                    <div className="bsEmiCalcBox">
                      <div className="bsEmiCalcHeader">
                        <div className="row">
                          <div className="col-sm-6">
                            <div className="bsSliderTxt">
                              Requested Loan Amount:{" "}
                              <strong>
                                {" "}
                                {numberFormat(
                                  breData && breData.length > 0
                                    ? breData[0].appliedLoanAmount
                                    : ""
                                )}
                              </strong>
                            </div>
                          </div>
                          <div className="col-sm-6">
                            <div className="bsSliderTxt">
                              Tenure:
                              <strong>
                                {" "}
                                {this.state.tenure
                                  ? this.state.tenure
                                  : maxTenure}{" "}
                                Months
                              </strong>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bsEmiCalcSlider">
                        <div className="row">
                          <div className="col-sm-6">
                            <div className="bsSliderInpitBox text-right">
                              <span>₹</span>
                              <input
                                className="text-center"
                                type="text"
                                pattern="[0-9]*"
                                id="principal"
                                maxLength="7"
                                name="principal"
                                value={this.state.principal}
                                onChange={(e) => {
                                  let v = e.target.validity.valid
                                    ? e.target.value
                                    : "";
                                  this.setState({ principal: v });


                                }}
                                onBlur={() =>
                                  this.__handleEMI(
                                    this.state.principal,
                                    this.state.tenure
                                  )
                                }
                              />
                            </div>
                            <Slider
                              className="bsEmiSlider"
                              key={`slider-${defaultAmount}`}
                              min={minLoanAmount}
                              tooltip={false}
                              max={2000000}
                              step={50000}
                              labels={{
                                minLoanAmount:
                                  "Min: " + numberFormat(minLoanAmount ? minLoanAmount : 0),
                                2000000: "Max: " + numberFormat(2000000),
                              }}
                              value={
                                this.state.principal
                                  ? this.state.principal
                                  : defaultAmount
                              }
                              aria-label="Default"
                              valueLabelDisplay="on"
                              onChange={(v) => this.setState({ principal: v })}
                              onChangeComplete={(v) =>
                                this.__handleEMI(
                                  this.state.principal,
                                  this.state.tenure
                                )
                              }
                            />
                          </div>
                          <div className="col-sm-6 ">
                            <div className="bsSliderInpitBox text-right">
                              <span>Months</span>
                              <input
                                className="text-center bsMonth"
                                type="text"
                                id="tenure"
                                name="tenure"
                                pattern="[0-9]*"
                                maxLength="2"
                                value={this.state.tenure}
                                // onChange={(e) => {
                                //   this.setState({ tenure: e.target.value });
                                // }}
                                onChange={(e) => {
                                  let v = e.target.validity.valid
                                    ? e.target.value
                                    : "";
                                  this.setState({ tenure: v });


                                }}
                                onBlur={() =>
                                  this.__handleEMI(
                                    this.state.principal,
                                    this.state.tenure
                                  )
                                }
                              />
                            </div>
                            <Slider
                              className="bsEmiSlider"
                              key={`slider-${maxTenure}`}
                              tooltip={false}
                              min={3}
                              max={72}
                              step={3}
                              labels={{
                                maxTenure:
                                  "Max: " + maxTenure + " Months",
                                minTenure:
                                  "Min: " + minTenure + " Months",
                              }}
                              value={
                                this.state.tenure
                                  ? this.state.tenure
                                  : maxTenure
                              }
                              aria-label="Default"
                              valueLabelDisplay="on"
                              onChange={(v) => this.setState({ tenure: v })}
                              onChangeComplete={(v) =>
                                this.__handleEMI(
                                  this.state.principal,
                                  this.state.tenure
                                )
                              }
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12">
                    <div>
                      <div className="bsResponsiveTable">
                        <Table className="bsLoanOfferTable striped bordered hover">
                          <thead>
                            <tr>
                              <th>Bank</th>
                              <th>Interest Rate</th>
                              <th>PF</th>
                              <th>
                                EMI{" "}
                                <p
                                  data-tip={
                                    "*T&C. The charges shown are indicative and the EMI figure is indicative for" +
                                    " " +
                                    maxTenure +
                                    " " +
                                    "months tenure ."
                                  }
                                  data-background-color="#2e0080"
                                  data-text-color="#FFF"
                                  data-place="top"
                                  style={{
                                    display: "inline-block",
                                    cursor: "pointer",
                                  }}
                                >
                                  (T&C)
                                </p>
                                <ReactTooltip />
                              </th>
                              <th>Prepayment Charges</th>
                              <th>Proceed</th>
                            </tr>
                          </thead>
                          <tbody>
                            {breData && breData.length > 0 ? (
                              breData
                                .slice()
                                .sort((a, b) => b.isInstant - a.isInstant)
                                .map((e, i) => (
                                  <tr key={i}>
                                    <td align="left">
                                      {e.isInstant === true ? (
                                        <div className="InstantApproveBox">
                                          <img
                                            src={selectIcon}
                                            alt="select Icon"
                                          />{" "}
                                          2 Min Disbursal
                                        </div>
                                      ) : (
                                        ""
                                      )}
                                      {e.bankImage ? (
                                        <img
                                          src={e.bankImage}
                                          alt=""
                                          width="100"
                                        />
                                      ) : (
                                        <img
                                          src="/bankLogos/default.svg"
                                          alt=""
                                          style={{ width: "60px" }}
                                        />
                                      )}
                                    </td>
                                    <td align="left">{e.IRR}%<span>*</span></td>
                                    <td align="left">{e.PF}%<span>*</span></td>

                                    <td
                                      align="left"
                                      style={{
                                        color: "#2e0080",
                                        fontWeight: 600,
                                      }}
                                    >
                                      {numberFormat(e.emi)}<span>*</span>{" "}
                                    </td>

                                    <td align="left">
                                      <ul>
                                        {e.prePaymentCharges &&
                                          e.prePaymentCharges
                                            // .split("|")
                                            .map((e1) => <li>{e1}</li>)}
                                      </ul>
                                    </td>
                                    <td align="left">
                                      <button
                                        onClick={() => this.handleApply(e)}
                                      >
                                        Apply <ArrowForwardIosIcon />
                                      </button>
                                    </td>
                                  </tr>
                                ))
                            ) : (
                              <tr>
                                <td align="left">No Record Found.</td>
                              </tr>
                            )}
                          </tbody>
                        </Table>
                      </div>
                    </div>
                  </div>
                </div>
              </Col >
            </Row >
          </Container >
        </section >
        <CreditFooter />

        <Modal
          className="ReferFriendModal AaModal"
          show={this.state.redirectionModalIsOpen}
          onHide={this.closeRedirectionPopupModal}
          closeButton={true}
        >
          <Modal.Body className="text-center">
            <div className="container-iframe">
              <iframe class="responsive-iframe" src={this.state.redirectionUrl}></iframe>
            </div>
          </Modal.Body>
        </Modal>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  updateOffer: getBankOffer(state).updateOffer,
  loading: getBankOffer(state).loadingUpdate,
  loadingSet: getBankOffer(state).loadingSet,
  customerDetail: getAccount(state).customerDetail,
  getAccountDetail: getAccount(state).getAccountDetail,
  setBankOffer: getBankOffer(state).setBankOffer,
  loadingBank: getBankOffer(state).loadingBank,
  loadingDedupe: getBankOffer(state).loadingDedupe,
  loadingMoneyView: axisPL(state).loadingMoneyView,
  loadinGet: getAccount(state).loading,
  loadingEarlySalary: axisPL(state).loadingEarlySalary,
  loadingGetAccountDetails: getAccount(state).loading,
  setOffer: getBankOffer(state).setOffer,
  loadingCheck: getExperian(state).loadingCheck,
  userData: getExperian(state).userData,
  loadingPaysense: paysensePL(state).loadingPaysense,
});

const mapDispatchToProps = (dispatch) => ({
  updateBankOffer: (params, callBack) =>
    dispatch(updateBankOffer(params, callBack)),
  setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  creditSaisonDedupe: (params, callBack) =>
    dispatch(creditSaisonDedupe(params, callBack)),
  moneyViewRedirection: (params, callbackDetail) =>
    dispatch(moneyViewRedirection(params, callbackDetail)),
  earlySalaryRedirection: (params, callbackDetail) =>
    dispatch(earlySalaryRedirection(params, callbackDetail)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  paysenseGetPlans: (params, callback) =>
    dispatch(paysenseGetPlans(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(LoanOffer)
);
