import React, { useEffect } from "react";
import TopNavbar from "../../common/TopNavBar";
import LeftMenuDecider from "../../common/leftMenuContent";
import HomeLoanAmount from "./homeLoanAmount";
import LoanAmount from "./loanAmount";
import EmployerDetail from "./employerDetail";
import CustomerDetail from "./customerDetail";
import CONSTANTS from "../../constants/Constants";
import PersonalLoan from "./personalLoan";
import PersonalAddress from "./personalAddress";
import CurrentAddress from "../PersonalLoanJourney/bankVerification/personalAddress"
import TwoWheelerEmployer from "./twoWheelerEmployer";
import OfficeAddress from "./officeAddress";
import { decryptStore } from "../../Utils/store";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAccountInfo } from "../../store/account";
import { total_wrk_exp } from "../common/dropdownValues";
import { useLocation } from "react-router-dom";
import Aadhar from "../TwoWheelerJourney/TwDetail/aadhar";
import PermanentAddress from "../PersonalLoanJourney/bankVerification/permanentAddress";
import UploadSalary from "../PersonalLoanJourney/bankVerification/UploadSalary";
import ASMNavBar from "../ASM/ASMNavBar";
import ResidenceDetailsPermanent from "../TwoWheelerJourney/Revolt/residencePermanentAddress";
import ResidenceDetailsCurrent from "../TwoWheelerJourney/Revolt/residenceCurrentAddress";
import WaitingMessageScreen from "../TwoWheelerJourney/Revolt/waitingmessage";
import EsignAgreementRevolt from "../TwoWheelerJourney/Revolt/esignagreement";
import { getStepperStep } from "./getStepperStep";


const PersonalDetailMain = ({ pLData, setpLData }) => {
  let [twData, setTWData] = useState({});
  let mobile = localStorage.getItem("mobilenumber") ?? 123456;
  let decryptedData = decryptStore(mobile);
  let { loanType } = decryptedData;
  const location = useLocation()
  //console.log(location.state.bike)
  const [details, setDetails] = useState(useSelector(state => state.entities.account.customerDetail))
  const [loading, setLoading] = useState(true);
  const fetchDetails = useDispatch()
  const [step, setStep] = React.useState(
    loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN
      ? CONSTANTS.RENDER_PERSONAL_LOAN
      : loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN
        ? (localStorage.getItem("isASM")
          ? CONSTANTS.RENDER_TWO_WHEELER_AADHAR
          : CONSTANTS.RENDER_TWO_WHEELER_PERSONAL_ADDRESS)
        : loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? CONSTANTS.RENDER_HOME_LOAN_AMOUNT : CONSTANTS.RENDER_LOAN_AMOUNT
  );
  const [lat, setLat] = React.useState("");
  const [lng, setLng] = React.useState("");
  const [stepperStep, setStepperStep] = useState(1);

  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  useEffect(() => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    navigator.geolocation.getCurrentPosition((position) => {
      setLat(position.coords.latitude);
      setLng(position.coords.longitude);
    });

    if (location?.state?.step) {
      setStep(location.state.step);
    }
    if (Object.keys(details).length) {
      setLoading(false)
      console.log("details are", details);

    } else {
      fetchDetails(getAccountInfo({ mobile: localStorage.getItem("mobilenumber") }, callBackDetails))
    }

    if (location?.state?.step) {
      let step = getStepperStep(location.state.step);
      setStepperStep(step ? step : stepperStep);
    }

  }, []);

  const callBackDetails = (res) => {
    if (res) {
      setDetails(res.data.customer)
      setLoading(false)
    }
  }

  const leftSideStep = () => {
    console.log(step)
    switch (step) {
      case CONSTANTS.RENDER_LOAN_AMOUNT:
        return <LoanAmount setpLData={setpLData} updateStep={updateStep} />;
      case CONSTANTS.RENDER_HOME_LOAN_AMOUNT:
        return <HomeLoanAmount setpLData={setpLData} updateStep={updateStep} />;
      case CONSTANTS.RENDER_PERSONAL_LOAN:
        return <PersonalLoan setpLData={setpLData} updateStep={updateStep} />;
      case CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL:
        return <EmployerDetail
          setpLData={setpLData}
          updateStep={updateStep}
          stepperStep={stepperStep}
          setStepperStep={setStepperStep}
          state={location.state} />;

      case CONSTANTS.RENDER_PERSONAL_LOAN_CUSTOMER_DETAIL:
        return (
          <CustomerDetail
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            populateData={{
              companyExp: total_wrk_exp[Math.floor(parseInt(details?.currorgexp__c))],
              exp: total_wrk_exp[Math.floor(parseInt(details?.work_total_exp__c))]
            }}
          />
        );
      case CONSTANTS.RENDER_TWO_WHEELER_PERSONAL_ADDRESS:
        return (
          <PersonalAddress setpLData={setpLData} updateStep={updateStep} />
        );
      case CONSTANTS.RENDER_WAITING_SCREEN_REVOLT:
        let message = "We are currently conducting tele-verification and request you to return once it is completed."
        if (location?.state?.loanType === CONSTANTS.TWO_WHEELER_LOAN && location?.state?.lender === "Money Plus") {
          if (location?.state?.loanStage === "Financial Check") {
            ////////////////message changes///////////
          }
          else if (location?.state?.loanStage === "Application Review") {
            ////////////////message changes///////////
          }
        }
        return (
          <WaitingMessageScreen
            message={message}
          />
        );
      case CONSTANTS.RENDER_ESIGN_AGREEMENT_REVOLT:
        return (
          <EsignAgreementRevolt
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            stepperStep={stepperStep}
            setStepperStep={setStepperStep}
          />
        );

      case CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_PERMANENT:
        return (
          <ResidenceDetailsPermanent
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
          />
        );
      case CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_CURRENT:
        return (
          <ResidenceDetailsCurrent
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
          />
        );
      case CONSTANTS.RENDER_PERSONAL_ADDRESS:
        return (
          <CurrentAddress
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            populateData={{
              currentAddress: details.currAddrDetails,
            }}
          />
        );
      case CONSTANTS.RENDER_PERMANENT_ADDRESS:
        return (
          <PermanentAddress
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location}
            step={step}
            nextStep={CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL}
            populateData={{
              permanentAddress: details?.resAddrDetails
            }}
          />
        );



      case CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_PERMANENT:
        return (
          <ResidenceDetailsPermanent
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location} />
        );
      case CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_CURRENT:
        return (
          <ResidenceDetailsCurrent
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
            location={location} />
        );
      case CONSTANTS.RENDER_TWO_WHEELER_AADHAR:
        return (
          <Aadhar
            isChild={true}
            state={location?.state}
            pLData={pLData}
            setpLData={setpLData}
            setStep={setStep}
            stepperStep={stepperStep}
            setStepperStep={setStepperStep}
          />
        )

      case CONSTANTS.RENDER_TWO_WHEELER_EMPLOYER:
        return (
          <TwoWheelerEmployer
            pLData={pLData}
            setpLData={setpLData}
            updateStep={updateStep}
          />
        );
      case CONSTANTS.RENDER_TWO_WHEELER_EMPLOYER_ADDRESS:
        return (
          <OfficeAddress
            updateStep={updateStep}
            pLData={pLData}
            lat={lat}
            lng={lng}
          />
        );
      default:
        break;
    }
  };
  return (
    <>
      {<TopNavbar step={step} updateStep={updateStep} />}
      <section className="bs-main-section">
        <Container>
          <Row>
            <Col sm={12} md={3}>
              <LeftMenuDecider activeStep={stepperStep} state={location.state} />
            </Col>
            <Col sm={12} md={9}>
              {leftSideStep()}
            </Col>
          </Row>
        </Container>
      </section>
      <CreditFooter />
    </>
  );
};

export default PersonalDetailMain;
