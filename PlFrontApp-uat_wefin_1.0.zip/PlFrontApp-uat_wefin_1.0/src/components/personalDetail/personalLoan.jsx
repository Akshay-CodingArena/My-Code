import Joi from "joi-browser";
import Form from "../../components/common/form";
import EmployeeType from "../../components/common/employeeType";
import CONSTANTS from "../../constants/Constants";
// import USER_ICON from "../../include/assets/1/smartphone@2x.png";
import { ReactComponent as Money } from "../../include/assets/money.svg";
// import Back from "../common/back";
import PersonalAmountInput from "../common/personalAmountInput";
import { withRouter } from "react-router";
import { decryptStore } from "../../Utils/store";
import { gaLogEvent } from "../../init-fcm";

class PersonalLoan extends Form {
  state = { data: {}, errors: {} };

  schema = {
    employeetype: Joi.string()
      .required()
      .label("Employment Type")
      .error(() => {
        return { message: "Employment Type field is required." };
      }),
    emiPay: Joi.string().allow(""),
  };
  _handleChangeEmi = (event) => {
    event.preventDefault();
    const emi = event.target.value;
    if (emi.length <= 16 || emi === "") {
      const data = { ...this.state.data };
      data.emiPay = emi.replace(/\D+/g, "");
      this.setState({ data });
    }
  };
  onChangeEmployeeType = (e) => {
    if (e) {
      const data = { ...this.state.data };
      data.employeetype = e.target.value;
      this.setState({ data });
    }
  };
  componentDidMount = () => {
    window.scrollTo(0, 0);
    const data = { ...this.state.data };
    data.employeetype = "1";
    this.setState({ data });
  };
  doSubmit = () => {
    let storeData = {
      applicantType: this.state.data.employeetype,
      emiPay: this.state.data.emiPay,
    };
    this.props.setpLData(storeData);
    this.props.updateStep(null, CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL);
    gaLogEvent(CONSTANTS.GA_EVENTS.CC_BASIC_DETAILS_1);
  };
  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    return (
      <div className="row insideFormBlock">
        <div className="col-sm12">
          {/* <Back
            onClick={() => {
              this.props.history.push("/pan-verify");
            }}
          /> */}
        </div>
        <div className="col-sm-12 text-center">
          <div className="bsFormHeader">
            {/* <div className="bsFormHeaderIcon">
              <img alt="" src={USER_ICON} />
            </div> */}
            {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
              <h1>We will check Credit Cards offers against your Details </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
              <h1>Check Two Wheeler Loan offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
              <h1>Check Personal Loan offers </h1>
            )}{" "}
          </div>
        </div>

        <div className="col-sm-12">
          <form className="panVeryfyForm">
            <div className="panFormFields">
              <div className="row">
                <div className="col-sm-12">
                  <EmployeeType
                    onChangeEmployeeType={this.onChangeEmployeeType}
                    employeetype={this.state.data.employeetype}
                  />
                </div>
                <div className="col-sm-12">
                  <PersonalAmountInput
                    value={this.state.data.emiPay}
                    __handleChange={this._handleChangeEmi}
                    error={this.state.errors.emiPay}
                    icon={<Money />}
                    label="Total EMI you pay currently (Monthly)"
                  />
                </div>
                <div className="col-sm-12 text-center">
                  <div>
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}
export default withRouter(PersonalLoan);
