import React, { useEffect } from "react";
import TopNavbar from "../../common/TopNavBar";
import LeftMenuDecider from "../../common/leftMenuContent";
import LoanAmount from "./loanAmount";
import EmployerDetail from "./employerDetail";
import CustomerDetail from "./customerDetail";
import CONSTANTS from "../../constants/Constants";
import PersonalLoan from "./personalLoan";
import { decryptStore } from "../../Utils/store";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
const PersonalDetailPLMain = ({ pLData, setpLData }) => {

    const [step, setStep] = React.useState(
        CONSTANTS.RENDER_LOAN_AMOUNT
    );
    const [lat, setLat] = React.useState("");
    const [lng, setLng] = React.useState("");

    const updateStep = (e, page) => {
        if (e) e.preventDefault();
        setStep(page);
    };
    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        navigator.geolocation.getCurrentPosition((position) => {
            setLat(position.coords.latitude);
            setLng(position.coords.longitude);
        });
    }, []);
    const leftSideStep = () => {
        switch (step) {
            case CONSTANTS.RENDER_LOAN_AMOUNT:
                return <LoanAmount setpLData={setpLData} updateStep={updateStep} />;

            case CONSTANTS.RENDER_PERSONAL_LOAN:
                return <PersonalLoan setpLData={setpLData} updateStep={updateStep} />;
            case CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL:
                return <EmployerDetail setpLData={setpLData} updateStep={updateStep} />;

            case CONSTANTS.RENDER_PERSONAL_LOAN_CUSTOMER_DETAIL:
                return (
                    <CustomerDetail
                        pLData={pLData}
                        setpLData={setpLData}
                        updateStep={updateStep}
                    />
                );



            default:
                break;
        }
    };
    return (
        <>
            <TopNavbar step={step} updateStep={updateStep} />
            <section className="bs-main-section">
                <Container>
                    <Row>
                        <Col sm={12} md={3}>
                            <LeftMenuDecider activeStep={1} />
                        </Col>
                        <Col sm={12} md={9}>
                            {leftSideStep()}
                        </Col>
                    </Row>
                </Container>
            </section>
            <CreditFooter />
        </>
    );
};

export default PersonalDetailPLMain;
