import React from "react";
// import USER_ICON from "../../include/assets/1/smartphone@2x.png";

import Joi from "joi-browser";
import Form from "../../components/common/form";
import Pincode from "../common/pincode";
import { ReactComponent as EmailIcon } from "../../include/assets/emailIcon.svg";
import { ReactComponent as LocationIcon } from "../../include/assets/fullertonLogos/Places.svg";
import { ReactComponent as EmployerNameIcon } from "../../include/assets/fullertonLogos/Group 20218.svg";
import { decryptStore } from "../../Utils/store";
// import Back from "../common/back";
import {
  setProfileDetail,
  getAccount,
  getAccountInfo,
} from "../../store/account";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import Swal from "sweetalert2";
import BackDropComponent from "../../common/BackDropComponent";
import { loadLoanDetail, getApplyLoan } from "../../store/applyLoan";
import { getBankOffer, setBankOfferList } from "../../store/bankOffer";
import { getpinCode, loadPinCode } from "../../store/pincode";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";

class OfficeAddress extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      pinSfid: "",
      stateSfid: "",
      citySfid: "",
      lat: "",
      lng: "",
      loaderMessage: {
        lineOne: "",
      },
      count: 0,
      setLoading: false,
    };
  }

  schema = {
    add1: Joi.string()
      .required()
      .label("Address Line 1")
      .error(() => {
        return { message: "Office Address Line 1 field is required." };
      }),
    add2: Joi.string()
      .required()
      .label("Address Line 2")
      .error(() => {
        return { message: "Office Address Line 2 field is required." };
      }),
    street: Joi.string()
      .required()
      .label("Street/Landmark")
      .error(() => {
        return { message: "Street/Landmark field is required." };
      }),
    pincode: Joi.number()
      .required()
      .label("Pin Code")
      .error(() => {
        return { message: "Pincode field is required." };
      }),
    offEmail: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Office Email field is required.";
              break;

            case "string.email":
              err.message = "Office Email field is invalid";
              break;
            case "string.max":
              err.message = "Office Email field is invalid";
              break;
            default:
              err.message = "Office Email field is invalid";
              break;
          }
        });
        return errors;
      }),
    city: Joi.string().label("City"),
    state: Joi.string().label("State"),
  };
  componentDidMount = () => {
    let mobile = localStorage.getItem("mobilenumber");
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.setState({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      },
      (error) => {
        if (error) {
          Swal.fire({
            position: "center",
            icon: "warning",
            title: "Please allow your location !!",
            showConfirmButton: true,
          });
        }
      }
    );
  };
  callbackDetail = (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };
  doSubmit = () => {
    const data = { ...this.state.data };
    const twData = this.props.pLData;
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanName, loanType } = decryptedData;
    const employer = twData.employerName;
    const { panNumber, dob, personemail, gender } =
      this.props.customerDetail;
    var formData;
    if (this.state.lat && this.state.lng) {
      const userName = isNaN(localStorage.getItem("lastName"))
        ? localStorage.getItem("fullName")
        : localStorage.getItem("firstName");
      if (twData.occupation.value === "1") {
        formData = {
          employerPincode: data.pincode,
          employerAddress: data.add1 + " " + data.add2,
          employerStateSfid: this.state.stateSfid,
          employerPincodeSfid: this.state.pinSfid,
          mobile: localStorage.getItem("mobilenumber"),
          officeEmail: data.offEmail,
          employerCity: data.city,
          employerCitySfid: this.state.citySfid,
          longitude: this.state.lng.toString(),
          latitude: this.state.lat.toString(),
          loanType: loanType,
          loanAppsfid: loansfid,
          statesfid: twData.currstateSfid,
          city: twData.cityCA,
          employerState: this.state.data.state,
          citysfid: twData.currcitySfid,
          salary: twData.monthlySalary,
          pincodesfid: twData.currpinSfid,
          state: twData.stateCA,
          pincode: twData.postalCodeCA,
          addressline1: twData.address1CA,
          addressline2: twData.address2CA,
          employerName: employer.name,
          orgType: twData.organization,
          employmentType: twData.occupation,
          product: "2",
          loanAppName: loanName,
          propertyStatus: twData.residentTypeCA,
          stateCode: twData.statecode.toString(),
          isNegative: twData.isNegative,
          employerCategory: employer.pl_company_category__c
            ? employer.pl_company_category__c
            : "E",
          employersfid: employer.sfid,
          employerRisk: employer.risk_category__c
            ? employer.risk_category__c
            : "High Risk",
          name: userName,
          dob: dob,
          panNumber: panNumber,
          gender: gender,
          personalEmail: personemail,
        };
      } else {
        formData = {
          employerPincode: data.pincode,
          employerAddress: data.add1 + " " + data.add2,
          employerStateSfid: this.state.stateSfid,
          employerPincodeSfid: this.state.pinSfid,
          mobile: localStorage.getItem("mobilenumber"),
          officeEmail: data.offEmail,
          employerCity: data.city,
          employerCitySfid: this.state.citySfid,
          longitude: this.state.lng.toString(),
          latitude: this.state.lat.toString(),
          loanType: loanType,
          loanAppsfid: loansfid,
          statesfid: twData.currstateSfid,
          city: twData.cityCA,
          employerState: this.state.data.state,
          citysfid: twData.currcitySfid,
          salary: twData.monthlySalary,
          pincodesfid: twData.currpinSfid,
          state: twData.stateCA,
          pincode: twData.postalCodeCA,
          addressline1: twData.address1CA,
          addressline2: twData.address2CA,
          businessName: twData.business,
          orgType: twData.organization,
          employmentType: twData.occupation,
          product: "2",
          loanAppName: loanName,
          propertyStatus: twData.residentTypeCA,
          stateCode: twData.statecode.toString(),
          isNegative: twData.isNegative,
          name: userName,
          dob: dob,
          panNumber: panNumber,
          gender: gender,
          personalEmail: personemail,
        };
      }

      this.props.setProfileDetail(formData, this.callBackProfile);
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: "Please allow your location !!",
        showConfirmButton: true,
      }).then(() => {
        this.props.history.push(PATH.PRIVATE.PRODUCTS);
      });
    }
  };
  callBackProfile = (res) => {
    if (res) {
      if (res.data.success) {
        if (res.data.failureData.length > 0) {
          this.props.history.push(PATH.PRIVATE.LOAN_APP_FAILED);
        } else {
          gaLogEvent(CONSTANTS.GA_EVENTS.TW_CAPTUIRED);
          const { message } = res.data;
          let splitMsg = message && message.split(".");
          this.setState({
            loaderMessage: { lineOne: `${splitMsg[0]}.` },
            setLoading: true,
          });
          let mobile = localStorage.getItem("mobilenumber");
          let decryptedData = decryptStore(mobile);
          let { loanType, loansfid } = decryptedData;
          let getBankData = {
            loanId: loansfid,
            loanType: loanType,
            getOffer: true,
          };
          this.props.loadLoanDetail(getBankData, this.callBackLoan);
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "info",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        });
        if (res.data.message === "Authentication Failed") {
          this.props.history.push(PATH.PUBLIC.INDEX);
        }
      }
    }
  };
  callBackLoan = (res) => {
    if (res) {
      if (res.data.success && res.data.message !== "no loan offers!") {
        localStorage.setItem(
          "loanDetail",
          JSON.stringify(res.data.getLoanDetails)
        );
        if (
          res.data.getLoanDetails.length > 0 &&
          res.data.getLoanDetails[0].status__c === "Active"
        ) {
          this.bankOffer(JSON.parse(localStorage.getItem("loanDetail")));
        }

        if (res.data.loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          setTimeout(() => {
            this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS);
            this.setState({ setLoading: false });
          }, 2000);
        }
      } else if (this.state.count === 15) {
        Swal.fire({
          position: "center",
          icon: "info",
          title: "Our Services are down please check after some time!",
          showConfirmButton: true,
        });
        this.props.history.push(PATH.PRIVATE.PRODUCTS);
      }
      this.setState({ count: this.state.count + 1 });
    }
  };

  bankOffer = (data) => {
    if (data) {
      let setDetailsData = {
        loanId: data[0].loan_application_id__c,
        loanType: data[0].loan_record_type__c,
        lenderId: data[0].lender_id__c,
        roi: data[0].roi,
        tenure: data[0].tenure,
        mobile: localStorage.getItem("mobilenumber"),
        emi: data[0].emi,
        offerSfid: data[0].offerSfid,
        downPayment: data[0].down_payment__c,
      };
      this.props.setBankOfferList(setDetailsData, this.callBack);
    }
  };
  callBack = (res) => {
    if (res) {
      if (!res.data.success) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };
  componentDidUpdate = (prevProps, prevState) => {
    if (prevState.count !== this.state.count && this.state.count <= 15) {
      setTimeout(() => {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType, loansfid } = decryptedData;
        let getBankData = {
          loanId: loansfid,
          loanType: loanType,
          getOffer: true,
        };
        this.props.loadLoanDetail(getBankData, this.callBackLoan);
      }, 8000);
    }
  };

  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");

    if (/^[0-9]+$/.test(e.target.value)) {
      if (e.target.value.length === 6) {
        const data = { ...this.state.data };
        data.pincode = e.target.value;
        this.setState({ data });
        let formData = { mobile: mobile, pincode: e.target.value };
        this.props.loadPinCode(formData, this.callbackPin);
      }
    }
  };
  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data?.success === false) {
        errors.pincode = res.data.message;
        this.setState({ errors });
      } else if (res.data?.success === true) {
        const errors = { ...this.state.errors };
        const data = { ...this.state.data };
        data.city = res.data.data.cityname;
        data.state = res.data.data.statename;
        errors.pincode = "";
        this.setState({
          data,
          errors,
          pinSfid: res.data.data.sfid,
          stateSfid: res.data.data.state__c,
          citySfid: res.data.data.city__c,
        });
      }
    }
  };

  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    return (
      <>
        <div className="col-sm12">
          {/* <Back
            onClick={() => {
              this.props.history.push("/products");
            }}
          /> */}
        </div>
        <div className="col-sm-12 text-center">
          <div className="bsFormHeader">
            {/* <div className="bsFormHeaderIcon">
              <img alt="" src={USER_ICON} />
            </div> */}

            {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
              <h1>We will check Credit Cards offers against your Details </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
              <h1>Check Two Wheeler Loan offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
              <h1>Check Personal Loan offers </h1>
            )}
          </div>
        </div>
        {this.props.profileLoading || this.state.setLoading ? (
          <BackDropComponent loaderMessage={this.state.loaderMessage} />
        ) : (
          ""
        )}
        <div className="col-sm-12">
          <form className="panVeryfyForm">
            <div className="panFormFields">
              <div className="row insideFormBlock">
                <div className="col-sm-6">
                  {this.renderInput(
                    "add1",
                    "Office Address Line 1",
                    <EmployerNameIcon />
                  )}
                </div>
                <div className="col-sm-6">
                  {this.renderInput(
                    "add2",
                    "Office Address Line 2",
                    <EmployerNameIcon />
                  )}
                </div>
                <div className="col-sm-6">
                  {this.renderInput(
                    "street",
                    "Street/Landmark",
                    <LocationIcon />
                  )}
                </div>
                <div className="col-sm-6">
                  <Pincode
                    value={this.state.data.pincode}
                    __handlePinCode={this.__handlePinCode}
                    error={this.state.errors.pincode}
                  />
                </div>
                <div className="col-sm-3">
                  {this.renderInput("city", "City", <LocationIcon />, true)}
                </div>
                <div className="col-sm-3">
                  {this.renderInput("state", "State", <LocationIcon />, true)}
                </div>
                <div className="col-sm-6">
                  {this.renderEmail(
                    "offEmail",
                    "Office Email ID ",
                    <EmailIcon />,
                    false
                  )}
                </div>

                <div className="col-sm-12 text-center">
                  <button
                    type="submit"
                    onClick={this.handleSubmit}
                    variant="contained"
                    className="nextButton"
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  profileDetail: getAccount(state).profileDetail,
  profileLoading: getAccount(state).profileLoading,
  customerDetail: getAccount(state).customerDetail,
  loanDetail: getApplyLoan(state).loanDetail,
  setBankOffer: getBankOffer(state).setBankOffer,
  getpinCode: getpinCode(state),
});
const mapDispatchToProps = (dispatch) => ({
  setProfileDetail: (params, callBack) =>
    dispatch(setProfileDetail(params, callBack)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OfficeAddress)
);
