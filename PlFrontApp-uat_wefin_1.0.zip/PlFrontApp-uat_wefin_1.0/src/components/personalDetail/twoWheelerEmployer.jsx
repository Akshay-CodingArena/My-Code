import React from "react";
import Joi from "joi-browser";
import Form from "../../components/common/form";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/homepageIcons/monthly-icon.svg";
import { ReactComponent as BusinessIcon } from "../../include/assets/homepageIcons/bank-icon.svg";
import {
  organization_type,
  employment_type,
} from "../../components/common/dropdownValues";
import SelectSearch from "../../components/common/select";
import PersonalAmountInput from "../common/personalAmountInput";
import {
  loadEmployerDetail,
  getEmployer,
  addEmployer,
} from "../../store/employer";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import CreatableSelect from "react-select/creatable";
import { ReactComponent as PersonIcon } from "../../include/assets/Profile.svg";
import { decryptStore } from "../../Utils/store";
import Swal from "sweetalert2";
import { loadLoanDetail, getApplyLoan } from "../../store/applyLoan";
import { getBankOffer, setBankOfferList } from "../../store/bankOffer";
import {
  setProfileDetail,
  getAccount,
  getAccountInfo,
} from "../../store/account";
import { gaLogEvent } from "../../init-fcm";
import CONSTANTS from "../../constants/Constants";
import BackDropComponent from "../../common/BackDropComponent";
import PATH from "../../paths/Paths";
class TwoWheelerEmployer extends Form {
  state = {
    data: {},
    errors: {},
    id: "",
    employerName: {},
    value: "",
    lat: "",
    lng: "",
    loading: false
  };
  schema = {
    employer: Joi.object()
      .required()
      .label("Name of Company")
      .error(() => {
        return { message: "Name of Company field is required." };
      }),
    business: Joi.string()
      .required("")
      .error(() => {
        return { message: "Business Name field is required." };
      }),
    occupation: Joi.object()
      .required()
      .label("Employment Type")
      .error(() => {
        return { message: "Employment Type field is required." };
      }),

    salary: Joi.string()
      .required("")
      .error(() => {
        return { message: "Monthly In-hand Salary field is required." };
      }),
    organization: Joi.object()
      .required("")
      .error(() => {
        return { message: "Organization Type in field is required." };
      }),
    businessType: Joi.string()
      .required("")
      .error(() => {
        return { message: "Organization Type in field is required." };
      }),
  };
  customStyles = {
    control: (provided) => ({
      ...provided,
      height: "40px",
      paddingLeft: "25px",
      borderColor: "#E0E0E0",
      borderWidth: "1px",
      boxShadow: "0 0 0 0px #2e0080",
      width: "100%",
      "&:hover": {
        borderColor: "#2e0080",
        borderWidth: "1px",
      },
      "&:focus": {
        borderColor: "#2e0080",
        borderWidth: "1px",
      },
    }),
    option: (provided, state) => ({
      ...provided,
      borderBottom: "0.5px solid rgba(46, 0, 128, 0.5)",
      textAlign: "left",
      fontSize: "15px",
      padding: "7px 10px",
      width: "100% !important",
      maxWidth: "100% !important",
      backgroundColor: state.isSelected
        ? "#2e0080"
        : state.isFocused
          ? "rgba(46, 0, 128, 0.12)"
          : "#eae4f9",
    }),
    menu: (provided) => ({
      ...provided,
      borderRadius: "5px",
      color: "#5E5E5E",
      background: "#eae4f9",
      zIndex: 12,
      width: "100%",
    }),
    dropdownIndicator: (base) => ({
      ...base,
      marginTop: "6px",
    }),
  };

  componentDidMount = () => {
    let mobile = localStorage.getItem("mobilenumber");
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
    this.props.loadEmployerDetail({ mobile: mobile, companyStr: "" });
    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.setState({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      },
      (error) => {
        if (error) {
          Swal.fire({
            position: "center",
            icon: "warning",
            title: "Please allow your location !!",
            showConfirmButton: true,
          });
        }
      }
    );
  };
  callbackDetail = (res) => {
    if (res) {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push("/");
        });
      }
    }
  };
  _handleChangeSalary = (event) => {
    event.preventDefault();
    const salaryMonthly = event.target.value;
    if (salaryMonthly.length <= 16 || salaryMonthly === "") {
      const data = { ...this.state.data };
      const errors = { ...this.state.errors };
      errors.salary = "";
      data.salary = salaryMonthly.replace(/\D+/g, "");
      this.setState({ data, errors });
    }
  };
  handleInputChange = (character) => {
    let mobile = localStorage.getItem("mobilenumber");
    this.setState((prevState) => {
      return {
        characterEntered: prevState.characterEntered,
      };
    });
    if (character && this.state.characterEntered !== character) {
      this.props.loadEmployerDetail({ mobile: mobile, companyStr: character });
    }
  };

  callBackAdd = (res) => {
    let mobile = localStorage.getItem("mobilenumber");
    this.props.loadEmployerDetail({ mobile: mobile, companyStr: "" });
    if (res) {
      if (res.data.status) {
        this.setState({ employerName: res.data.data });
      }
    }
  };
  componentDidUpdate = (prevProps, prevState) => {
    if (this.state.value && prevState.value !== this.state.value) {
      const formdata = {
        data: { company_name: this.state.value },
      };
      this.props.addEmployer(formdata, this.callBackAdd);
    }
    if (this.state.data.business !== "" && !this.state.data.employer) {
      const data = { ...this.state.data };
      data.employer = {
        label: this.state.data.business,
        value: this.state.data.business,
      };
      this.setState({ data });
    }
    if (
      (this.state.data?.occupation?.value === "2" ||
        this.state.data?.occupation?.value === "3") &&
      !this.state.data.businessType
    ) {
      const data = { ...this.state.data };
      data.organization = {
        label: "Partnership Firm",
        value: "Partnership Firm",
      };
      data.businessType = "Partnership Firm";
      this.setState({ data });
    }
    if (prevState.count !== this.state.count && this.state.count <= 15) {
      setTimeout(() => {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType, loansfid } = decryptedData;
        let getBankData = {
          loanId: loansfid,
          loanType: loanType,
          getOffer: true,
        };
        this.props.loadLoanDetail(getBankData, this.callBackLoan);
      }, 8000);
    }
  };
  doSubmit = () => {
    let errors = { ...this.state.errors };
    if (!(/^[A-Za-z0-9 .]*$/.test(this.state.data.employer.label))) {
      errors.employer = "Invalid Name of Company format.";
      this.setState({ errors });
      return;
    }

    errors = { ...this.state.errors };
    errors.employer = "";
    this.setState({ errors });
    // const data = { ...this.state.data };
    const twData = this.props.pLData;
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanName, loanType } = decryptedData;
    const employer = this.state.employerName;
    const { panNumber, dob, personemail, gender } =
      this.props.customerDetail;
    var formData;
    if (this.state.lat && this.state.lng) {
      const userName = isNaN(localStorage.getItem("lastName"))
        ? localStorage.getItem("fullName")
        : localStorage.getItem("firstName");
      if (this.state.data.occupation.value === "1") {
        formData = {
          employerPincode: twData.postalCodeCA,
          employerAddress: twData.address1CA + " " + twData.address2CA,
          employerStateSfid: twData.currstateSfid,
          employerPincodeSfid: twData.currpinSfid,
          mobile: localStorage.getItem("mobilenumber"),
          officeEmail: personemail,
          employerCity: twData.cityCA,
          employerCitySfid: twData.currcitySfid,
          longitude: this.state.lng.toString(),
          latitude: this.state.lat.toString(),
          loanType: loanType,
          loanAppsfid: loansfid,
          statesfid: twData.currstateSfid,
          city: twData.cityCA,
          employerState: twData.stateCA,
          citysfid: twData.currcitySfid,
          salary: this.state.data.salary,
          pincodesfid: twData.currpinSfid,
          state: twData.stateCA,
          pincode: twData.postalCodeCA,
          addressline1: twData.address1CA,
          addressline2: twData.address2CA,
          employerName: employer.name,
          orgType: this.state.data.organization.value,
          employmentType: this.state.data.occupation.value,
          product: "2",
          loanAppName: loanName,
          propertyStatus: twData.residentTypeCA,
          stateCode: twData.statecode.toString(),
          isNegative: twData.isNegative,
          employerCategory: employer.pl_company_category__c
            ? employer.pl_company_category__c
            : "E",
          employersfid: employer.sfid,
          employerRisk: employer.risk_category__c
            ? employer.risk_category__c
            : "High Risk",
          name: userName,
          dob: dob,
          panNumber: panNumber,
          gender: gender,
          personalEmail: personemail,
        };
      } else {
        formData = {
          employerPincode: twData.postalCodeCA,
          employerAddress: twData.address1CA + " " + twData.address2CA,
          employerStateSfid: twData.currstateSfid,
          employerPincodeSfid: twData.currpinSfid,
          mobile: localStorage.getItem("mobilenumber"),
          officeEmail: personemail,
          employerCity: twData.cityCA,
          employerCitySfid: twData.currcitySfid,
          longitude: this.state.lng.toString(),
          latitude: this.state.lat.toString(),
          loanType: loanType,
          loanAppsfid: loansfid,
          statesfid: twData.currstateSfid,
          city: twData.cityCA,
          employerState: twData.stateCA,
          citysfid: twData.currcitySfid,
          salary: this.state.data.salary,
          pincodesfid: twData.currpinSfid,
          state: twData.stateCA,
          pincode: twData.postalCodeCA,
          addressline1: twData.address1CA,
          addressline2: twData.address2CA,
          businessName: this.state.data.business,
          orgType: this.state.data.organization.value,
          employmentType: this.state.data.occupation.value,
          product: "2",
          loanAppName: loanName,
          propertyStatus: twData.residentTypeCA,
          stateCode: twData.statecode.toString(),
          isNegative: twData.isNegative,
          name: userName,
          dob: dob,
          panNumber: panNumber,
          gender: gender,
          personalEmail: personemail,
        };
      }
      gaLogEvent(CONSTANTS.GA_EVENTS.TW_DETAILS_3);
      this.setState({ loading: true, });
      this.props.setProfileDetail(formData, this.callBackProfile);
    } else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: "Please allow your location !!",
        showConfirmButton: true,
      }).then(() => {
        this.props.history.push("/products");
      });
    }
  };

  formatCreate = (inputValue) => {
    return <p> Add: {inputValue}</p>;
  };
  callBackProfile = (res) => {
    if (res) {
      if (res.data.success) {
        if (res.data.failureData.length > 0) {
          this.setState({ loading: false });
          this.props.history.push("/loan-application-failed");
        } else {
          const { message } = res.data;
          let splitMsg = message && message.split(".");
          this.setState({
            loaderMessage: { lineOne: `${splitMsg[0]}.` },
            loading: true,
          });
          let mobile = localStorage.getItem("mobilenumber");
          let decryptedData = decryptStore(mobile);
          let { loanType, loansfid } = decryptedData;
          let getBankData = {
            loanId: loansfid,
            loanType: loanType,
            getOffer: true,
          };
          this.props.loadLoanDetail(getBankData, this.callBackLoan);
        }
      } else {
        this.setState({ loading: false });
        Swal.fire({
          position: "center",
          icon: "info",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        });
        if (res.data.message === "Authentication Failed") {
          this.props.history.push("/");
        }
      }
    }
  };

  callBackLoan = (res) => {
    if (res) {
      if (res.data.success && res.data.message !== "no loan offers!") {
        localStorage.setItem(
          "loanDetail",
          JSON.stringify(res.data.getLoanDetails)
        );
        if (
          res.data.getLoanDetails.length > 0 &&
          res.data.getLoanDetails[0].status__c === "Active"
        ) {
          this.bankOffer(JSON.parse(localStorage.getItem("loanDetail")));
        }

        if (res.data.loanType === "TW_Loan") {
          setTimeout(() => {
            // this.props.history.push({
            //   pathname: `${PATH.PRIVATE.LOAN_APPLICATIONS}/tw_loans/tw_loans`,
            // })
            this.props.history.push(PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS_DASHBOARD);
            this.setState({ loading: false });
          }, 2000);
        }
      } else if (this.state.count === 15) {
        Swal.fire({
          position: "center",
          icon: "info",
          title: "Our Services are down please check after some time!",
          showConfirmButton: true,
        });
        this.props.history.push("/products");
      }
      this.setState({ count: this.state.count + 1 });
    }
  };

  bankOffer = (data) => {
    if (data) {
      let setDetailsData = {
        loanId: data[0].loan_application_id__c,
        loanType: data[0].loan_record_type__c,
        lenderId: data[0].lender_id__c,
        roi: data[0].roi,
        tenure: data[0].tenure,
        mobile: localStorage.getItem("mobilenumber"),
        emi: data[0].emi,
        offerSfid: data[0].offerSfid,
        downPayment: data[0].down_payment__c,
      };
      this.props.setBankOfferList(setDetailsData, this.callBack);
    }
  };
  callBack = (res) => {
    if (res) {
      if (!res.data.success) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push("/");
        });
      }
    }
  };
  render() {
    const { employerDetail } = this.props;
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    return (
      <>

        <div className="col-sm12">
          {/* <Back
            onClick={(e) => {
              this.props.updateStep(
                e,
                CONSTANTS.RENDER_TWO_WHEELER_PERSONAL_ADDRESS
              );
            }}
          /> */}
        </div>
        <div className="col-sm-12 text-center">
          {this?.state?.loading ? <BackDropComponent /> : ''}
          <div className="bsFormHeader">
            {/* <div className="bsFormHeaderIcon">
              <img alt="" src={USER_ICON} />
            </div> */}
            {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
              <h1>We will check Credit Cards offers against your Details </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
              <h1>Check Two Wheeler Loan offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
              <h1>Check Personal Loan offers </h1>
            )}{" "}
          </div>
        </div>
        <div className="col-sm-12">
          <form className="panVeryfyForm">
            <div className="panFormFields">
              <div className="row insideFormBlock">
                <div className="col-sm-6">
                  <SelectSearch
                    style={{ margin: "15px 8px 25px" }}
                    placeholderValue={"Employment Type"}
                    label={"Employment Type"}
                    value={this.state.data.occupation}
                    page="personal"
                    setSelectedOption={(e) => {
                      const data = { ...this.state.data };
                      const errors = { ...this.state.errors };
                      if (e) {
                        data.occupation = e;
                        errors.occupation = "";
                        this.setState({ data, errors });
                      }
                    }}
                    dropDownOptions={employment_type}
                    error={this.state.errors.occupation}
                    icon={
                      <PersonIcon
                        style={{ marginRight: "6px", marginTop: "3px" }}
                      />
                    }
                  ></SelectSearch>
                </div>
                <div className="col-sm-6">
                  {this.state.data?.occupation?.value === "2" ||
                    this.state.data?.occupation?.value === "3" ? (
                    this.renderInput(
                      "business",
                      "Business Name",
                      <BusinessIcon />
                    )
                  ) : (
                    <div className="form-group">
                      <label htmlFor="employer">
                        Name of Company
                        <span style={{ color: "#FF4C30" }}>*</span>
                      </label>
                      <CreatableSelect
                        style={{ color: "#f00" }}
                        isClearable
                        styles={this.customStyles}
                        onChange={(e) => {
                          if (e) {
                            if (e.__isNew__) {
                              const data = { ...this.state.data };
                              const errors = { ...this.state.errors };
                              errors.employer = "";
                              data.employer = e;
                              data.business = e.label;
                              this.setState({
                                errors,
                                data,
                                value: e.value,
                              });
                            } else {
                              const data = { ...this.state.data };
                              const errors = { ...this.state.errors };
                              errors.employer = "";
                              data.employer = e;
                              data.business = e.label;
                              this.setState({
                                data,
                                errors,
                                employerName: e.value,
                              });
                            }
                          }
                          if (e === null) {
                            const data = { ...this.state.data };
                            data.employer = "";
                            this.setState({
                              data,
                              employerName: {},
                              value: "",
                            });
                          }
                        }}
                        onInputChange={this.handleInputChange}
                        options={employerDetail.map((item) => ({
                          label: item.name,
                          value: item,
                        }))}
                        placeholder="Select Company Name"
                        formatCreateLabel={this.formatCreate}
                        value={
                          this.state.data.employer &&
                          this.state.data.employer.label &&
                          this.state.data.employer
                        }
                      />
                      <span className="dropIcon">
                        <BusinessIcon
                          style={{ marginBottom: "-6px", marginRight: "5px" }}
                        />
                      </span>
                      {this.state.errors.employer && (
                        <p className="bsInputErr">
                          {this.state.errors.employer}
                        </p>
                      )}
                    </div>
                  )}
                </div>
                <div className="col-sm-6">
                  <PersonalAmountInput
                    style={{
                      width: "100%",
                      margin: "15px 8px 25px",
                      padding: "0px",
                    }}
                    value={this.state.data.salary}
                    __handleChange={this._handleChangeSalary}
                    error={
                      this.state.errors.salary
                        ? this.state.data.occupation?.value === "2" ||
                          this.state.data.occupation?.value === "3"
                          ? "Annual Revenue field is required."
                          : "Monthly In-hand Salary field is required."
                        : this.state.errors.salary
                    }
                    icon={<CardMembershipIcon />}
                    label={
                      this.state.data?.occupation?.value === "2" ||
                        this.state.data?.occupation?.value === "3"
                        ? "Annual Revenue"
                        : "Monthly In-hand Salary"
                    }
                    required={true}
                  />
                </div>
                <div className="col-sm-6">
                  {this.state.data?.occupation?.value === "2" ||
                    this.state.data?.occupation?.value === "3" ? (
                    <div className="form-group">
                      <label htmlFor="Organization Type">
                        Organization Type
                        <span style={{ color: "#FF4C30" }}>*</span>
                      </label>
                      <input
                        className="form-control"
                        style={{ textTransform: "capitalize" }}
                        placeholder="Organization Type"
                        name="Organization Type"
                        id="Organization Type"
                        defaultValue={this.state.data.businessType}
                        readOnly="true"
                      />

                      <span className="input-icon">
                        <BusinessIcon
                          style={{ marginRight: "3px", marginTop: "2px" }}
                        />
                      </span>
                      {this.state.errors.organizationType && (
                        <p className="error-form">
                          {this.state.errors.organizationType}
                        </p>
                      )}
                    </div>
                  ) : (
                    <SelectSearch
                      style={{
                        width: "100%",
                        margin: "15px 8px 25px",
                        padding: "0px",
                      }}
                      icon={
                        <BusinessIcon
                          style={{ marginRight: "3px", marginTop: "2px" }}
                        />
                      }
                      placeholderValue={"Organization Type"}
                      label={"Organization Type"}
                      value={this.state.data.organization}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.organization = e;
                          data.businessType = e.label;
                          errors.organization = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={organization_type}
                      error={this.state.errors.organization}
                    ></SelectSearch>
                  )}
                </div>

                <div className="col-sm-12 text-center">
                  <button
                    type="submit"
                    onClick={this.handleSubmit}
                    variant="contained"
                    className="nextButton"
                  >
                    Apply
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  employerDetail: getEmployer(state).employerDetail,
  loadingDetail: getEmployer(state).loadingDetail,
  newEmployer: getEmployer(state).addEmployer,
  profileDetail: getAccount(state).profileDetail,
  profileLoading: getAccount(state).profileLoading,
  customerDetail: getAccount(state).customerDetail,
  loanDetail: getApplyLoan(state).loanDetail,
  setBankOffer: getBankOffer(state).setBankOffer,
});
const mapDispatchToProps = (dispatch) => ({
  loadEmployerDetail: (params) => dispatch(loadEmployerDetail(params)),
  addEmployer: (params, callBack) => dispatch(addEmployer(params, callBack)),
  setProfileDetail: (params, callBack) =>
    dispatch(setProfileDetail(params, callBack)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadLoanDetail: (params, callBack) =>
    dispatch(loadLoanDetail(params, callBack)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TwoWheelerEmployer)
);
