import CONSTANTS from "../../constants/Constants";


export const getStepperStep = (currentStep) => {
    switch (currentStep) {
        case CONSTANTS.RENDER_TWO_WHEELER_AADHAR:
        case CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_PERMANENT:
        case CONSTANTS.RENDER_TWO_WHEELER_REVOLT_RESIDENCE_DETAIL_CURRENT:
            return 2;
        case CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL:
        case CONSTANTS.RENDER_WAITING_SCREEN_REVOLT:
            return 3;
        case CONSTANTS.RENDER_ESIGN_AGREEMENT_REVOLT:
            return 4;
        default: return undefined;
    }
}
