import React from "react";
import { ReactComponent as PersonIcon } from "../../include/assets/Profile.svg";
import { ReactComponent as LocalPhoneIcon } from "../../include/assets/phoneIcon.svg";
import { ReactComponent as EmailIcon } from "../../include/assets/emailIcon.svg";
// import USER_ICON from "../../include/assets/1/smartphone@2x.png";
import BackDropComponent from "../../common/BackDropComponent";
import TopNavBar from "../../common/TopNavBar";
import LeftMenuDecider from "../../common/leftMenuContent";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/panIcon.svg";
// import Back from "../../components/common/back";
import Joi from "joi-browser";
import Gender from "../common/gender";
import Form from "../../components/common/form";
import DateComponent from "../../components/common/date";
import Pincode from "../../components/common/pincode";
import PersonalInput from "../common/personalInput";
import { withRouter } from "react-router";
import { Container, Row, Col } from "react-bootstrap";
import {
  getpanName,
  loadPanName,
  panVerification,
  loadCheckDedupe,
} from "../../store/panName";
import {
  credit_marital_status,
} from "../common/fullerTonDropdown";
import { connect } from "react-redux";
import { getpinCode, loadPinCode } from "../../store/pincode";
import Swal from "sweetalert2";
import { decryptStore } from "../../Utils/store";
import Moment from "moment";
import {
  getAccount,
  setAccountInfo,
  getAccountInfo,
} from "../../store/account";
import { getExperian, loadExperianCheck } from "../../store/experian";
import OTPModal from "../HomeProducts/OTPModal";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import SelectSearch from "../common/select";
import { ReactComponent as Marriage } from "../../include/assets/personalLoan/marriage.svg";
import {
  myprofile_marital_status,
} from "../common/fullerTonDropdown";
import mapGender from "../common/mapGender";
import ASMNavBar from "../ASM/ASMNavBar";
import { dropdown_gender_values } from "../common/dropdownValues";
import cardRedirection from "../creditCard/cardRedirection";

class PanVerify extends Form {
  constructor(props) {
    super(props);
    ////by default male is selected///////
    this.state = {
      data: {
        gender: '1'
      },
      errors: {},
      terms: true,
      stgOneHitId: "",
      stgTwoHitId: "",
      openOtp: false,
      btnIsActive: true,
      loader: false,
    };
  }
  schema = {
    gender: Joi
      .string()
      .required()
      .label("Gender")
      .error(() => {
        return { message: "Gender field is required." };
      }),
    fullName: Joi.string()
      .required()
      .label("Full Name")
      .error(() => {
        return { message: "Full Name field is required." };
      }),
    pan: Joi.string()
      .min(10)
      .max(10)
      .required()
      .label("PAN Number")
      .error(() => {
        return { message: "PAN Number field is required." };
      }),
    email: Joi.string()
      .email()
      .max(50)
      .required()
      .label("Email")
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            case "any.empty":
              err.message = "Email field is required";
              break;

            case "string.email":
              err.message = "Email field is invalid";
              break;
            case "string.max":
              err.message = "Email field is invalid";
              break;
            default:
              err.message = "Email field is invalid";
          }
        });
        return errors;
      }),
    maritalStatus: Joi.object()
      .required()
      .label("Marital Status")
      .error(() => {
        return { message: "Marital Status field is required." };
      }),
    pincode: Joi.string().required().error(() => {
      return { message: "Pin code field is required." };
    }),
    mobile: Joi.number()
      .required()
      .label("Landline No.")
      .error(() => {
        return { message: "Mobile Number field is required" };
      }),
    dob: Joi.string()
      .required()
      .label("Date of Birth")
      .error((err) => {
        return { message: "Date of Birth field is required." };
      }),
  };

  dobValidate = () => {
    var date = new Date(Date.now());
    var year = parseInt(date.getFullYear())
    if (parseInt(this.state.data.dob.slice(6)) >= year - 12 && year - parseInt(this.state.data.dob.slice(6)) > 100) {
      return false
    } else {
      return true
    }
  }

  componentDidUpdate = () => {
    if (this.state.data.email === "null" || this.state.data.email === "undefined") {
      this.setState({ ...this.state, data: { ...this.state.data, email: "" } })
    }
  }

  doSubmit = () => {
    // console.log("status of marriage", this.state.data.maritalStatus, "gender", this.state.gender)
    this.dobValidate()
    try {
      if (this.dobValidate()) {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType, loansfid } = decryptedData;
        if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && this.props.getCustomerDetail.pan_verified__c) {
          if (
            !localStorage.getItem("pin") ||
            localStorage.getItem("pin") === ""
          ) {
            let a = 'Please select pin code on two wheeler loan home page or before apply for new two wheeler loan';
            throw a;
          } else {
            //  console.log("mobile number is", mobile)
            let formData = {
              mobile: mobile,
              gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.state.data.gender.toLowerCase())[0].label,
              name: this.state.data.fullName,
              pan: this.state.data.pan,
              dob: reverseDateString(this.state.data.dob),
              email: this.state.data.email,
              loanType: loanType,
              loanId: loansfid,
              cityName: localStorage.getItem("city"),
              twMasterSfid:
                this.props.location.state && this.props.location.state.bike.sfid,
              pincode: localStorage.getItem("pin"),
            };
            this.setState({ loader: true });
            this.props.panVerification(formData, this.callBackPANVerify);
          }
        } else {
          if (
            !this.state.data.pincode ||
            this.state.data.pincode === "" ||
            this.state.data.pincode === undefined ||
            this.state.data.pincode === null
          ) {
            this.setState(({ errors }) => ({
              errors: {
                ...errors,
                pincode: "Pincode field is required.",
              },
            }));
          } else {
            let formData =
            {
              mobile: this.state.data.mobile,
              pincode: this.state.data.pincode,
              name: this.state.data.fullName,
              pan: this.state.data.pan,
              dob: reverseDateString(this.state.data.dob),
              email: this.state.data.email,
              cibilcheck: "Yes",
              creditCode: "B",
              gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.state.data.gender.toLowerCase())[0].label
            };
            this.setState({ loader: true });
            this.props.setAccountInfo(formData, this.callBackAcc);
          }
        }
      } else {
        throw "Invalid Date of Birth"
      }
    } catch (e) {
      this.setState({ loader: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      });
    }
  };
  callBackExperian = async (res) => {
    try {
      let r = res;

      if (r?.data?.status === 203) {
        this.setState({ loader: false });
        let formData = {
          mobile: this.state.data.mobile,
          pincode: this.state.data.pincode,
          name: this.state.data.fullName,
          pan: this.state.data.pan,
          dob: reverseDateString(this.state.data.dob),
          email: this.state.data.email,
          cibilcheck: "Yes",
          creditCode: "B",
          gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.state.data.gender.toLowerCase())[0].label
        };
        this.props.setAccountInfo(formData, this.callBackAcc);
      } else if (r?.data?.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.CREDIT_SCORE_INITIATE);
        this.setState({ loader: false });
        if (r.data.data) {
          this.setState({
            stgOneHitId: r.data.data.stgOneHitId,
            stgTwoHitId: r.data.data.stgTwoHitId,
            openOtp: true,
          });
        }
        // if (r.data.experianData) {
        //   console.log("response inside")
        //   this.setState({
        //     stgOneHitId: r.data.experianData.responseData.stgOneHitId,
        //     stgTwoHitId: r.data.experianData.responseData.stgTwoHitId,
        //     openOtp: true,
        //   });
        // }
        else {
          let { loanType } = decryptStore(localStorage.getItem("mobilenumber"));

          if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
            this.props.history.push({
              pathname: PATH.PRIVATE.PERSONAL_DETAIL,
              state: { bike: this.props.location.state.bike },
            });
          }
          else {
            this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
          }
        }

      } else {
        this.setState({ loader: false });
      }
    } catch (e) {
      this.setState({ loader: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
        timer: 1800,
      });
    }
  };
  callBackAcc = async (res) => {
    try {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType } = this.props?.loanType ?? decryptedData;

      let r = await res;
      if (r.data.success) {
        this.setState({ loader: false });
        
        localStorage.setItem("fullName", this.state.data.fullName);

        if (loanType === CONSTANTS.LOAN_TYPE.BUSINESS_LOAN) {
          this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
        }
        else if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
          this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
        }

        else if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
          if (this.props?.location?.state?.isASMFlow) {
            this.props.history.push({
              pathname: PATH.PUBLIC.GET_CREDIT_CARD,
              state: {
                isASM: true
              }
            })
          } else {
            //       console.log("Home Product Credit Card", this.props)
            let card = this.props?.location?.appliedCard ?? JSON.parse(localStorage.getItem("appliedCard"))
            //       console.log("applied card is", card, "props", this.props)
            console.log("card is", card, loanType)
            if (card) {
              if (this.props?.location?.ccformData) {
                await this.props.loadccApplyLoan(this.props.location.ccformData, this.callbackLoan)
              }
              else {
                cardRedirection(this.props, this.props.location.appliedCard, this.props.getAccountInfo, true)
              }
            }
            else {
              this.props.history.goBack();
            }
          }
        }
        else if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && this.props.location.state.bike.manufacturer__c === "REVOLT") {
          if (localStorage.getItem("isASM")) {
            this.props.history.push(
              {
                pathname: `${PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS}`,
                state: this.props.location.state
              });
          } else {
            this.props.history.push(
              {
                pathname: PATH.PRIVATE.PERSONAL_DETAIL,
                state: this.props.location.state
              });
          }
        } else if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          this.props.history.push
            ({
              pathname: PATH.PRIVATE.PERSONAL_DETAIL,
              state: { bike: this.props.location.state.bike },
            });
        }
        else {
          this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
        }
      } else {
        throw r.data.message.toString();
      }
    } catch (e) {
      this.setState({ loader: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
        timer: 1800,
      });
    }
  };

  callbackLoan = (res) => {
    if (res) {
      let appliedCard = this.props?.location?.appliedCard ?? JSON.parse(localStorage.getItem("appliedCard"));
      cardRedirection(this.props, appliedCard, this.props.getAccountInfo, true)
    }
  }

  callBackPANVerify = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.PAN_VERIFIED);
        gaLogEvent(CONSTANTS.GA_EVENTS.TW_DETAILS_1);
        this.setState({ loader: false });

        localStorage.setItem("fullName", this.props.data.fullName);

        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType } = decryptedData;

        ///////////for business and home loan

        if (loanType === CONSTANTS.LOAN_TYPE.BUSINESS_LOAN) {
          this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
        }

        else if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
          this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
        }

        else if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
          if (this.props?.location?.locationData.state?.isASMFlow) {
            this.props.history.push({
              pathname: PATH.PUBLIC.GET_CREDIT_CARD
            })
          } else {
            //       console.log("Home Product Credit Card", this.props)
            let card = this.props?.location?.appliedCard ?? JSON.parse(localStorage.getItem("appliedCard"))
            //       console.log("applied card is", card, "props", this.props)
            console.log("card is", card, loanType)
            if (card) {
              if (this.props?.location?.ccformData) {
                await this.props.loadccApplyLoan(this.props.location.ccformData, this.callbackLoan)
              }
              else {
                cardRedirection(this.props, this.props.location.appliedCard, this.props.getAccountInfo, true)
                //      await this.props.loadccApplyLoan(formData, this.callbackLoan);
                //          this.props.history.push(PATH.PRIVATE.PRODUCTS)
              }
            }
            else {
              this.props.history.goBack();
            }
          }
        }

        else if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && this.props.location.state.bike.manufacturer__c === "REVOLT") {
          if (localStorage.getItem("isASM")) {
            this.props.history.push(
              {
                pathname: `${PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS}`,
                state: this.props.location.state
              });
          } else {
            this.props.history.push(
              {
                pathname: PATH.PRIVATE.PERSONAL_DETAIL,
                state: this.props.location.state
              });
          }
        } else if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN) {
          this.props.history.push
            ({
              pathname: PATH.PRIVATE.PERSONAL_DETAIL,
              state: { bike: this.props.location.state.bike },
            });
        }
        else {
          this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
        }
      } else {
        throw r.data.message.toString();
      }
    } catch (e) {
      this.setState({ loader: false });
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
        timer: 1800,
      });
    }
  };
  callbackDetail = async (res) => {
    try {
      if (res.data.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      } else {
        this.setState((p) => ({
          ...p,

          loader: false,
          data: {
            ...p.data,
            ...this.populateData(),
            gender: this.props.getCustomerDetail?.gender ? dropdown_gender_values?.filter((value, index) => value.label.toLowerCase() === this.props.getCustomerDetail?.gender.toLowerCase())[0].value : this.state.data.gender,
            mobile: localStorage.getItem("mobilenumber"),
            email: localStorage.getItem("email"),
          },
        }));
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
        timer: 1800,
      });
    }
  };
  __handlePANChange = (e) => {
    let panNumber = e.target.value.toUpperCase();
    if (e.target.value.length <= 10) {
      this.setState((p) => ({
        ...p,
        data: {
          ...p.data,
          pan: panNumber,
          fullName: "",
          dob: "",
          pincode: "",
          gender: "1"
        },
        /////GENDER BY DEAFULT SET TO MALE////
        errors: { ...p.errors, pan: "", fullName: "", dob: "", gender: "", pincode: "", gender: "" },
      }));
      if (e.target.value.length === 10) {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loansfid } = decryptedData;
        let formData = {
          mobile: mobile,
          pan: panNumber,
          loanAppsfid: loansfid,
        };
        this.props.loadCheckDedupe(formData, this.callBackDedeupe);
      }
    }
  };
  callBackDedeupe = async (res) => {
    try {
      let r = await res;
      if (!r.data.isDuplicate && !r.data.isFinnOneDuplicate) {
        let mobile = localStorage.getItem("mobilenumber");
        let formData = {
          mobile: mobile,
          pan: this.state.data.pan,
        };
        this.props.loadPanName(formData, this.callback);
      } else {
        throw r.data.message.toString();
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
        timer: 18000,
      });
    }
  };
  callback = async (res) => {
    try {
      let r = await res;
      if (r.data) {
        if (r.data.success) {
          let data = r.data
          localStorage.setItem("fullName", data.name);
          localStorage.setItem("firstName", data.firstname);
          localStorage.setItem("lastName", data.lastName);
          localStorage.setItem("pan", this.state.data.pan);

          this.setState((p) => ({
            ...p,
            data: {
              ...p.data,
              fullName: data.name,
              // dob: Moment(data.dob).format("DD-MM-YYYY"),
              // gender: dropdown_gender_values?.filter((value, index) => value.label?.toLowerCase() === data.gender?.toLowerCase())[0].value,
              // pincode: data.address.pinCode,
            },
            errors: {
              ...p.errors,
              pan: "",
              fullName: "",
            },
          }));
        } else {
          this.setState(({ errors }) => ({
            errors: {
              ...errors,
              pan: r.data.message,
            },
          }));
        }
      } else {
        throw r.data.message.toString();
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
        timer: 1800,
      });
    }
  };

  populateData = () => {
    console.log(Moment(this.props.getCustomerDetail.dob).format("DD-MM-YYYY"))

    return {
      dob: this.props.getCustomerDetail.dob?.length ? Moment(this.props.getCustomerDetail.dob).format("DD-MM-YYYY") : "",
      pincode: this.props.getCustomerDetail?.resAddrDetails?.pincode,
      fullName: this.props.getCustomerDetail?.name,
      pan: this.props.getCustomerDetail?.panNumber,
      maritalStatus: myprofile_marital_status?.filter((data, index) => this.props.getCustomerDetail?.maritalstatus === data.value)[0]
    }
  }

  componentDidMount = () => {
    console.log("ghjhjkj", this.props.location)
    window.scrollTo(0, 0);
    console.log("Customer Details", this.props.getCustomerDetail)
    if (this.props.customerDetail) {
      this.setState((p) => ({
        ...p,
        data: {
          ...p.data,
          gender: mapGender(this.props.getCustomerDetail?.gender) ?? mapGender(this.state.data.gender),
          ...this.populateData(),
          mobile: localStorage.getItem("mobilenumber"),
          email: localStorage.getItem("email"),
        },
      }));
    } else {
      this.setState({ ...this.state, loader: true })
      this.props.getAccountInfo({ mobile: localStorage.getItem("mobilenumber") }, this.callbackDetail)
    }
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  };
  onDateChange = async (e) => {
    let d = await e.target.value;
    this.setState(({ data }) => ({
      data: {
        ...data,
        dob: d,
      },
    }));
    if (!this.state.data.dob.includes("_")) {
      if (Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
        this.setState(({ errors }) => ({
          errors: { ...errors, dob: "" },
          btnIsActive: true,
        }));
      } else {
        this.setState(({ errors }) => ({
          errors: { ...errors, dob: "Date of Birth field is invalid." },
          btnIsActive: false,
        }));
      }
    } else {
      this.setState({ btnIsActive: false });
    }
  };

  handleCheckBoxChange = () => {
    this.setState({
      terms: !this.state.terms,
    });
  };

  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    if (e.target.value.length === 6) {
      const data = { ...this.state.data };
      data.pincode = e.target.value;
      this.setState({ data });
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callbackPin);
    }
  };

  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data.success === false) {
        errors.pincode = res.data.message;
        this.setState({ errors });
      } else if (res.data.success === true) {
        errors.pincode = "";
        this.setState({ errors });
      }
    }
  };

  onChangeGender = (e) => {
    if (e) {
      console.log(e.target.value)
      this.setState({ ...this.state, data: { ...this.state.data, gender: e.target.value } });
    }
  };

  closeOTPModal = () => {
    this.setState({
      openOtp: false,
      data: {
        ...this.state.data,
        email: localStorage.getItem("email"),
        mobile: localStorage.getItem("mobilenumber"),
      },
    });
  };

  render() {
    const { loading, loadingVerify, loadingCheck } = this.props.getpanName;
    const { loadingACC } = this.props.getAccount;
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    // console.log("decrypted loadn", loanType)

    // console.log("formData", this.props.location.ccformData)
    return (
      <>
        {<TopNavBar />}
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <LeftMenuDecider activeStep={1} state={this.props.location?.state} />
              </Col>
              <Col sm={12} md={9}>
                {this.props.loadingCheck ||
                  loading ||
                  loadingACC ||
                  loadingVerify ||
                  loadingCheck ||
                  this.props.loading ||
                  this.state.loader ? (
                  <BackDropComponent />
                ) : (
                  ""
                )}
                {/* <Back
                  onClick={(e) => {
                    e.preventDefault();
                    this.props.history.push("/products");
                  }}
                /> */}
                <div className="row">
                  <div className="col-sm-12 text-center">
                    <div className="bsFormHeader">
                      {/* <div className="bsFormHeaderIcon">
                        <img alt="" src={USER_ICON} />
                      </div> */}
                      {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
                        <h1>Check Credit Cards offers </h1>
                      )}
                      {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
                        <h1>Check Two Wheeler Loan offers </h1>
                      )}
                      {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
                        <h1>Check Personal Loan offers </h1>
                      )}
                      {loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN && (
                        <h1>Check Home Loan offers </h1>
                      )}
                    </div>
                  </div>
                </div>
                <div
                  className="row insideFormBlock"
                  style={{ marginBottom: "30px" }}
                >
                  <div className="col-sm-12">
                    <form className="panVeryfyForm">
                      <div className="panFormFields">
                        <div className="row">
                          <div className="col-sm-6">
                            <PersonalInput
                              value={this.state.data.pan}
                              __handleChange={this.__handlePANChange}
                              error={this.state.errors.pan}
                              icon={<CardMembershipIcon />}
                              label="PAN Number"
                              readOnly={this.props.getCustomerDetail.pancard_status__c}
                            />
                          </div>

                          <div className="col-sm-6">
                            <PersonalInput
                              value={this.state.data.fullName}
                              error={this.state.errors.fullName}
                              icon={<PersonIcon />}
                              label="Full Name as per PAN"
                              readOnly={true}
                            />
                          </div>

                          <div className="col-sm-6">

                            <DateComponent
                              value={this.state.data.dob?.length <= 10 ? this.state.data.dob : this.state.data.dob?.slice(8, 10) + "-" + this.state.data.dob?.slice(5, 7) + "-" + this.state.data?.dob?.slice(0, 4)}
                              onDateChange={this.onDateChange}
                              error={this.state.errors.dob}
                              label="Date of Birth"
                              readOnly={true}
                            />
                          </div>

                          <div className="col-sm-6">
                            {/* {loanType ===
                              CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ? (
                              <Gender
                                onChangeGender={this.onChangeGender}
                                gender={this.state.gender}
                              />
                            ) : (
                              <Pincode
                                value={this.state.data.pincode}
                                __handlePinCode={this.__handlePinCode}
                                error={this.state.errors.pincode}
                              />
                            )} */}
                            <Pincode
                              value={this.state.data.pincode}
                              __handlePinCode={this.__handlePinCode}
                              error={this.state.errors.pincode}
                              disabled={false}
                            />
                          </div>
                          <div className="col-sm-6">
                            {this.renderInput(
                              "mobile",
                              "Phone Number",
                              <LocalPhoneIcon />,
                              true,
                              10,
                              10
                            )}
                          </div>
                          <div className="col-sm-6">
                            {this.renderEmail(
                              "email",
                              "Email ID",
                              <EmailIcon />,
                              false
                            )}
                          </div>
                          <div className="col-sm-6">
                            <Gender
                              onChangeGender={this.onChangeGender}
                              value={this.state?.data?.gender}
                              error={this.state.errors.gender}
                            />
                          </div>
                          <div className="col-sm-6">
                            <SelectSearch
                              placeholderValue={"Select Marital Status"}
                              label={"Marital Status"}
                              value={this.state.data.maritalStatus}
                              setSelectedOption={(e) => {
                                const data = { ...this.state.data };
                                const errors = { ...this.state.errors };
                                if (e) {
                                  data.maritalStatus = e;
                                  errors.maritalStatus = "";
                                  this.setState({ data, errors });
                                }
                              }}
                              dropDownOptions={credit_marital_status}
                              error={this.state.errors.maritalStatus}
                              icon={
                                <Marriage
                                  style={{
                                    marginRight: "5px",
                                    marginTop: "3px",
                                  }}
                                />
                              }
                            ></SelectSearch>
                          </div>
                          <div className="col-sm-12">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                name="checkedG"
                                id="checkedG"
                                onChange={this.handleCheckBoxChange}
                                checked={this.state.terms}
                              />
                              <label
                                className="form-check-label"
                                htmlFor="checkffedG"
                              >
                                You hereby
                                to Neotec being appointed as
                                your authorised representative to receive your
                                Credit Information from Experian on an ongoing
                                basis until the purpose of monitoring credit
                                healths and providing financial offers (“End Use
                                Purpose”) is satisfied or expiry of 6 months
                                from date the consent is collected; whichever is
                                earlier. You hereby agree to&nbsp;
                                <a
                                  href="https://www.wefin.in/experian-tnc.html"
                                  target="_blank"
                                  rel="noreferrer"
                                >
                                  Terms and Conditions
                                </a>
                              </label>
                            </div>

                            <div className="agreeTxt"></div>
                          </div>
                          <div className="col-sm-12 text-center">
                            {this.state.terms === true &&
                              this.state.btnIsActive ? (
                              <button
                                type="submit"
                                onClick={this.handleSubmit}
                                variant="contained"
                                className="nextButton"
                              >
                                Next
                              </button>
                            ) : (
                              <button
                                type="submit"
                                onClick={this.handleSubmit}
                                variant="contained"
                                className="nextButton"
                                disabled
                                style={{
                                  opacity: "0.5",
                                  cursor: "not-allowed",
                                }}
                              >
                                Next
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>

          {this.state.openOtp === true && (
            <OTPModal
              show={this.state.openOtp}
              handleCloseOTP={this.closeOTPModal}
              mobile={this.state.data.mobile}
              stgOneHitId={this.state.stgOneHitId}
              stgTwoHitId={this.state.stgTwoHitId}
              data={this.state.data}
              appliedCard={this.props.location.appliedCard}
              ccformData={this.props.location.ccformData}
              locationData={this.props.location}
            />
          )}
        </section>
      </>
    );
  }
}
function reverseDateString(str) {
  var splitString = str.split("-");
  var reverseArray = splitString.reverse();
  var joinArray = reverseArray.join("-");
  joinArray = joinArray + "T00:00:00.000Z";
  return joinArray;
}
const mapStateToProps = (state) => ({
  getpanName: getpanName(state),
  getpinCode: getpinCode(state),
  getAccount: getAccount(state),
  panVerify: getpanName(state).panVerify,
  checkDedupe: getpanName(state).checkDedupe,
  experian: getExperian(state),
  loadingCheck: getExperian(state).loadingCheck,
  getCustomerDetail: getAccount(state).customerDetail,
  loading: getpinCode(state).loading
});
const mapDispatchToProps = (dispatch) => ({
  loadPanName: (params, callback) => dispatch(loadPanName(params, callback)),
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  panVerification: (params, callback) =>
    dispatch(panVerification(params, callback)),
  loadCheckDedupe: (params, callback) =>
    dispatch(loadCheckDedupe(params, callback)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(PanVerify)
);
