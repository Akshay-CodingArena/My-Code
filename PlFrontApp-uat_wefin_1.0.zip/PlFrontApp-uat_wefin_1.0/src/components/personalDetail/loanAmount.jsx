import Joi from "joi-browser";
import Form from "../../components/common/form";
import CONSTANTS from "../../constants/Constants";
// import USER_ICON from "../../include/assets/1/smartphone@2x.png";
// import Back from "../common/back";
import { ReactComponent as Money } from "../../include/assets/money.svg";
import { withRouter } from "react-router";
import { decryptStore } from "../../Utils/store";
import EmployeeType from "../../components/common/employeeType";
import PersonalAmountInput from "../common/personalAmountInput";
import { gaLogEvent } from "../../init-fcm";
import { loadConsents } from "../../store/consent";
import { connect } from "react-redux";
import { getOS } from "../../Utils/device_function";

class LoanAmount extends Form {
  state = { data: {}, errors: {}, terms: false };

  schema = {
    loanAmount: Joi.string()
      .required("")
      .error(() => {
        return { message: "Loan Amount field is required." };
      }),

    employeetype: Joi.string()
      .required()
      .label("Employment Type")
      .error(() => {
        return { message: "Employment Type field is required." };
      }),
    emiPay: Joi.string().allow(""),
  };
  _handleChangeEmi = (event) => {
    event.preventDefault();
    const emi = event.target.value;
    if (emi.length <= 16 || emi === "") {
      const data = { ...this.state.data };
      data.emiPay = emi.replace(/\D+/g, "");
      this.setState({ data });
    }
  };
  _handleChangeLoan = (event) => {
    event.preventDefault();
    const loan = event.target.value;
    if (loan.length <= 16 || loan === "") {
      const data = { ...this.state.data };
      data.loanAmount = loan.replace(/\D+/g, "");
      this.setState({ data });
    }
  };
  onChangeEmployeeType = (e) => {
    if (e) {
      const data = { ...this.state.data };
      data.employeetype = e.target.value;
      this.setState({ data });
    }
  };
  doSubmit = () => {
    let storeData = {
      loanAmount: this.state.data.loanAmount,
      applicantType: this.state.data.employeetype,
      emiPay: this.state.data.emiPay,
    };
    this.props.setpLData(storeData);
    gaLogEvent(CONSTANTS.GA_EVENTS.PL_LOAN_DETAILS_1);
    this.props.updateStep(null, CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL);
  };
  componentDidMount = () => {
    window.scrollTo(0, 0);
    const data = { ...this.state.data };
    data.employeetype = "1";
    this.setState({ data });
  };
  handleCheckBoxChange = () => {
    let mobile = localStorage.getItem("mobilenumber");
    let { loanName } = decryptStore(mobile);
    const formdata = {
      consentName: "CONSENT_INCOME",
      consentType: "BTN",
      consentStatus: "true",
      accountName: localStorage.getItem("accsfid"),
      loanApplicationName: loanName,
      platform: getOS() === "ios"
        ? "web_ios"
        : getOS() === "android"
          ? "web_android"
          : "web",
    };
    this.props.loadConsents(formdata, this.consentCallback);

  };
  consentCallback = (res) => {
    if (res) {
      this.setState({
        terms: true,
      });
    }
  };
  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    return (
      <div className="row insideFormBlock">
        <div className="col-sm12">
        </div>
        <div className="col-sm-12 text-center">
          <div className="bsFormHeader">

            {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
              <h1>Check Credit Cards offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
              <h1>Check Two Wheeler Loan offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
              <h1>Check Personal Loan offers </h1>
            )}{" "}
          </div>
        </div>

        <div className="col-sm-12">
          <form className="panVeryfyForm">
            <div className="panFormFields">
              <div className="row">
                <div className="col-sm-12">
                  <EmployeeType
                    onChangeEmployeeType={this.onChangeEmployeeType}
                    employeetype={this.state.data.employeetype}
                  />
                </div>
                <div className="col-sm-12">
                  <PersonalAmountInput
                    value={this.state.data.loanAmount}
                    __handleChange={this._handleChangeLoan}
                    error={this.state.errors.loanAmount}
                    icon={<Money />}
                    label="Loan Amount"
                    required={true}
                  />
                </div>
                <div className="col-sm-12">
                  <PersonalAmountInput
                    value={this.state.data.emiPay}
                    __handleChange={this._handleChangeEmi}
                    error={this.state.errors.emiPay}
                    icon={<Money />}
                    label="Total EMI you pay currently (Monthly)"
                  />
                </div>
                <div className="aadhar_check_box">
                  <div className="form-check">
                    <input

                      type="checkbox"
                      name="checkedG"
                      id="checkedG"
                      onChange={this.handleCheckBoxChange}
                      checked={this.state.terms}
                    />
                    <label
                      className="form-check-label check_pl"
                      htmlFor="checkedG"

                    >
                      I hereby confirm that my household income is greater than INR 3,00,000/- (Rupees Three Lacs)
                      i.e. INR 25000 <span>(Twenty five thousand) Per Month.</span>
                    </label>
                  </div>
                </div>
                <div className="col-sm-12 text-center">
                  {this.state.terms === true ? <button
                    type="submit"
                    onClick={this.handleSubmit}
                    variant="contained"
                    className="nextButton"
                  >
                    Next
                  </button>
                    : <button
                      variant="contained"
                      className="nextButton"
                      disabled
                      style={{
                        opacity: "0.5",
                        cursor: "not-allowed",
                      }}
                    >
                      Next
                    </button>}
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});

export default withRouter(
  connect(null, mapDispatchToProps)(LoanAmount)
);
