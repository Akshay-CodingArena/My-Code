import Joi from "joi-browser";
import Form from "../../components/common/form";
import CONSTANTS from "../../constants/Constants";
import { ReactComponent as Money } from "../../include/assets/money.svg";
import { ReactComponent as BusinessNature } from "../../include/assets/businessNature.svg";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/homepageIcons/monthly-icon.svg";
import { withRouter } from "react-router";
import EmployeeType from "../../components/common/employeeType";
import PersonalAmountInput from "../common/personalAmountInput";
import { gaLogEvent } from "../../init-fcm";
import CreatableSelect from "react-select/creatable";
import { ReactComponent as BusinessIcon } from "../../include/assets/homepageIcons/bank-icon.svg";
import { loadEmployerDetail, getEmployer } from "../../store/employer";
import { connect } from "react-redux";
import { setApplicantDetail, getApplicant } from "../../store/applicantDetail";
import { encryptStore, decryptStore } from "../../Utils/store";
import PATH from "../../paths/Paths";
import Swal from "sweetalert2";
import { ReactComponent as PropertyIcon } from "../../include/assets/icons/property.svg";
import { NATURE_OF_BUSINESS } from "../../components/common/dropdownValues";
import BackDropComponent from "../../common/BackDropComponent";
import SelectSearch from "../common/select";

class HomeLoanAmount extends Form {
    state = {
        data: {},
        errors: {}
    };

    schema = {
        loanAmount: Joi.allow(""),
        employeetype: Joi.string()
            .required()
            .label("Employment Type")
            .error(() => {
                return { message: "Employment Type field is required." };
            }),
        employer: Joi.allow(""),
        salary: Joi.allow(""),
        natureOfBusiness: Joi.allow(""),
    };

    customStyles = {
        control: (provided) => ({
            ...provided,
            height: "40px",
            paddingLeft: "2px",
            borderColor: "#E0E0E0",
            borderWidth: "1px",
            boxShadow: "0 0 0 0px #2e0080",
            width: "100%",
            "&:hover": {
                borderColor: "#2e0080",
                borderWidth: "1px",
            },
            "&:focus": {
                borderColor: "#2e0080",
                borderWidth: "1px",
            },
        }),
        option: (provided, state) => ({
            ...provided,
            borderBottom: "0.5px solid rgba(46, 0, 128, 0.5)",
            textAlign: "left",
            fontSize: "15px",
            padding: "7px 10px",
            width: "100% !important",
            maxWidth: "100% !important",
            backgroundColor: state.isSelected
                ? "#2e0080"
                : state.isFocused
                    ? "rgba(46, 0, 128, 0.12)"
                    : "#eae4f9",
        }),
        menu: (provided) => ({
            ...provided,
            borderRadius: "5px",
            color: "#5E5E5E",
            background: "#eae4f9",
            zIndex: 12,
            width: "100%",
        }),
        dropdownIndicator: (base) => ({
            ...base,
            marginTop: "6px",
        }),
    };

    _handleChangeLoan = (event) => {
        event.preventDefault();
        const loan = event.target.value;
        if (loan.length <= 16 || loan === "") {
            const data = { ...this.state.data };
            data.loanAmount = loan.replace(/\D+/g, "");
            this.setState({ data });
        }

    };
    _handleChangeSalary = (event) => {
        event.preventDefault();
        const salaryMonthly = event.target.value;
        if (salaryMonthly.length <= 16 || salaryMonthly === "") {
            const data = { ...this.state.data };
            data.salary = salaryMonthly.replace(/\D+/g, "");
            this.setState({ data });
        }
    };
    onChangeEmployeeType = (e) => {
        if (e) {
            const data = { ...this.state.data };
            data.employeetype = e.target.value;
            let salaryMonthly = "500000"

            if (data.employeetype === "2") {
                this.state = { ...this.state, natureOfBusiness: "" }
                data.employer = { label: "" }
            }
            if (data.employeetype === "1") {
                data.natureOfBusiness = { label: "" }
            }
            this.setState({ data });
        }
    };
    doSubmit = () => {
        let errors = { ...this.setState({ errors: {} }) }
        if (this.state.data.loanAmount === '' || this.state.data.loanAmount === undefined) {
            errors = { ...errors, loanAmount: "Loan Amount field is required." }
        }
        if (this.state.data.employeetype === '1') {
            if (this.state.data.salary === '' || this.state.data.salary === undefined) {
                errors = { ...errors, salary: "Monthly In-hand Salary field is required." }
            }
            if (this.state.data.employer?.label === '' || this.state.data.employer?.label === undefined) {
                errors = { ...errors, employer: "Name of Company field is required." }
            }
            if (this.state.data.employer?.label && !(/^[A-Za-z0-9 .]*$/.test(this.state.data.employer.label))) {
                errors = { ...errors, employer: "Invalid Name of Company format." }
            }
        } else {
            if (this.state.data.natureOfBusiness === '' || this.state.data.natureOfBusiness === undefined) {
                errors = { ...errors, natureOfBusiness: "Nature Of Business field is required." }
            }
        }
        if (Object.keys(errors).length > 0) {
            this.setState({ errors: errors })
            return;
        }
        let businessNature;
        const data = { ...this.state.data };
        if (this.state.data.employeetype === "2") {
            businessNature = this.state.data.natureOfBusiness.value
            data.salary = ""
            this.setState({ data })
        }
        //    console.log(data, 'setdata')
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType, loansfid } = decryptedData;
        let formData = {
            applicantType: data.employeetype,
            currOrgExp: "",
            employerName: data?.employer?.label,
            loanAmount: data.loanAmount,
            loanId: loansfid,
            loanType: loanType,
            mobile: mobile,
            monthlySalary: data?.salary,
            salaryBank: "",
            workTotalExp: "6",
            businessNature: businessNature
        };
        this.props.setApplicantDetail(formData, this.callBack);
    };
    callBack = (res) => {
        if (res) {
            if (res.data.success) {
                let mobile = localStorage.getItem("mobilenumber");
                let decryptedData = decryptStore(mobile);
                let { loanType } = decryptedData;
                if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
                    gaLogEvent(CONSTANTS.GA_EVENTS.CC_BASIC_DETAILS_3);
                    this.props.history.push({
                        pathname: PATH.PRIVATE.CREDIT_CARD_OFFERS,
                        state: res.data.ccData,
                    });
                } else if (loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
                    gaLogEvent(CONSTANTS.GA_EVENTS.PL_LOAN_DETIALS_3);
                    this.props.history.push({
                        pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
                        state: res.data,
                    });
                } else if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
                    gaLogEvent(CONSTANTS.GA_EVENTS.PL_LOAN_DETIALS_3);
                    this.props.history.push({
                        pathname: PATH.PRIVATE.HOME_LOAN_OFFERS,
                        state: res.data,
                    });
                }
            } else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.INDEX);
                });
            }
        }
    };
    componentDidMount = () => {
        window.scrollTo(0, 0);
        const data = { ...this.state.data };
        data.employeetype = "1";
        this.setState({ data });
        let mobile = localStorage.getItem("mobilenumber");
        this.props.loadEmployerDetail({ mobile: mobile, companyStr: "" });
    };
    handleInputChange = (character) => {
        let mobile = localStorage.getItem("mobilenumber");
        this.setState((prevState) => {
            return {
                characterEntered: prevState.characterEntered,
            };
        });
        if (character && this.state.characterEntered !== character) {
            this.props.loadEmployerDetail({ mobile: mobile, companyStr: character });
        }
    };
    formatCreate = (inputValue) => {
        return <p> Add: {inputValue}</p>;
    };
    render() {
        const { employerDetail } = this.props;
        const { loading } = this.props.getApplicant;
        return (
            <div className="row insideFormBlock">
                {loading ? <BackDropComponent /> : ""}
                <div className="col-sm12">
                </div>
                <div className="col-sm-12 text-center">
                    <div className="bsFormHeader">
                        <h1>We will check Home Loan offer against your Details </h1>
                    </div>
                </div>
                <div className="col-sm-12">
                    <form className="panVeryfyForm">
                        <div className="panFormFields">
                            <div className="row">

                                <div className="col-sm-12">
                                    <EmployeeType
                                        onChangeEmployeeType={this.onChangeEmployeeType}
                                        employeetype={this.state.data.employeetype}
                                    />
                                </div>
                                <div className="col-sm-12">
                                    <PersonalAmountInput
                                        value={this.state.data.loanAmount}
                                        __handleChange={this._handleChangeLoan}
                                        error={this.state.errors.loanAmount}
                                        icon={<Money />}
                                        label="Loan Amount"
                                        required={true}
                                    />
                                </div>
                                {this.state.data.employeetype === "1" && (<>
                                    <div className="col-sm-12">
                                        <PersonalAmountInput
                                            value={this.state.data.salary}
                                            __handleChange={this._handleChangeSalary}
                                            error={this.state.errors.salary}
                                            icon={<CardMembershipIcon />}
                                            label="Monthly In-hand Salary"
                                            required={true}
                                        />
                                    </div>
                                    <div className="col-sm-12">
                                        <div className="form-group">
                                            <label htmlFor="employer">
                                                Name of Company
                                                <span style={{ color: "#FF4C30" }}>*</span>
                                            </label>
                                            <CreatableSelect
                                                style={{ color: "#f00" }}
                                                isClearable
                                                styles={this.customStyles}
                                                name="employer"
                                                onChange={(e) => {
                                                    if (e) {
                                                        if (e.__isNew__) {
                                                            const data = { ...this.state.data };
                                                            const errors = { ...this.state.errors };
                                                            errors.employer = "";
                                                            data.employer = e;
                                                            this.setState({ errors, data, value: e.value });
                                                        } else {
                                                            const data = { ...this.state.data };
                                                            const errors = { ...this.state.errors };
                                                            errors.employer = "";
                                                            data.employer = e;
                                                            this.setState({
                                                                data,
                                                                errors,
                                                                employerName: e.value,
                                                            });
                                                        }
                                                    }
                                                    if (e === null) {
                                                        const data = { ...this.state.data };
                                                        data.employer = "";
                                                        this.setState({
                                                            data,
                                                            employerName: {},
                                                            value: "",
                                                        });
                                                    }
                                                }}
                                                onInputChange={this.handleInputChange}
                                                options={employerDetail.map((item) => ({
                                                    label: item.name,
                                                    value: item,
                                                }))}
                                                placeholder="Select Company Name"
                                                formatCreateLabel={this.formatCreate}
                                                value={
                                                    this.state.data.employer &&
                                                    this.state.data.employer.label &&
                                                    this.state.data.employer
                                                }
                                            />
                                            <span className="dropIcon">
                                                <BusinessIcon
                                                    style={{ marginBottom: "-6px", marginRight: "5px" }}
                                                />
                                            </span>
                                            {this.state.errors.employer && (
                                                <p className="bsInputErr">{this.state.errors.employer}</p>
                                            )}
                                        </div>
                                    </div>
                                </>)}
                                {((this.state.data.employeetype) === "2") && (
                                    <div className="col-sm-12">
                                        <SelectSearch
                                            style={{ margin: "15px 8px 20px" }}
                                            placeholderValue={"Nature of Business"}
                                            label={"Nature of Business"}
                                            value={this.state.data.natureOfBusiness}
                                            page="personal"
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.natureOfBusiness = e;
                                                    errors.natureOfBusiness = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={NATURE_OF_BUSINESS}
                                            error={this.state.errors.natureOfBusiness}
                                            icon={
                                                <PropertyIcon
                                                    style={{ marginRight: "5px", marginTop: "2px" }}
                                                />
                                            }
                                        ></SelectSearch>
                                    </div>
                                )}
                                <div className="col-sm-12 text-center">
                                    <div>
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Next
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    employerDetail: getEmployer(state).employerDetail,
    loadingDetail: getEmployer(state).loadingDetail,
    getApplicant: getApplicant(state),
});
const mapDispatchToProps = (dispatch) => ({
    loadEmployerDetail: (params) => dispatch(loadEmployerDetail(params)),
    setApplicantDetail: (params, callBack) => dispatch(setApplicantDetail(params, callBack)),
});
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(HomeLoanAmount));
