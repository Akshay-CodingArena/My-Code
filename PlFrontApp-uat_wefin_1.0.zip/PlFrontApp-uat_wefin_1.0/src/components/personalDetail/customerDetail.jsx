import React from "react";
import Joi from "joi-browser";
import Form from "../../components/common/form";
import SelectSearch from "../../components/common/select";
import { ReactComponent as BusinessCenterIcon } from "../../include/assets/business.svg";
import { decryptStore, encryptStore } from "../../Utils/store";
import { total_wrk_exp } from "../../components/common/dropdownValues";
//  USER_ICON from "../../include/assets/1/smartphone@2x.png";
// import Back from "../common/back";
import { withRouter } from "react-router";
import { setApplicantDetail, getApplicant } from "../../store/applicantDetail";
import { connect } from "react-redux";
import BackDropComponent from "../../common/BackDropComponent";
import Swal from "sweetalert2";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import {
  updateBankOffer,
  getBankOffer,
  setOfferList,
  setBankOfferList,
  creditSaisonDedupe,
} from "../../store/bankOffer";
class CustomerDetail extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
      bank: {},
    };
  }
  schema = {
    exp: Joi.object()
      .required()
      .label("Employment Type")
      .error(() => {
        return { message: "Experience field is required." };
      }),
    companyExp: Joi.object()
      .required()
      .label("Employment Type")
      .error(() => {
        return { message: "Current Experience field is required." };
      }),
  };

  doSubmit = async () => {
    if (this.state.data.exp.value < this.state.data.companyExp.value) {
      const errors = { ...this.state.errors };
      errors.exp = "Experience must be greater than or equals to Current Exp.";
      this.setState({ errors });
    } else {
      let mobile = localStorage.getItem("mobilenumber");
      let decryptedData = decryptStore(mobile);
      let { loanType, loansfid } = decryptedData;
      let formData = {
        mobile: mobile,
        loanAmount: this.props.pLData.loanAmount,
        applicantType: this.props.pLData.applicantType,
        employerName: this.props.pLData.employerName,
        monthlySalary: this.props.pLData.monthlySalary,
        salaryBank: this.props.pLData.bank,
        loanId: loansfid,
        currOrgExp: this.state.data.companyExp.value,
        workTotalExp: this.state.data.exp.value,
        currentEmi: this.props.pLData.emiPay,
        loanType: loanType,
      };
      this.props.setApplicantDetail(formData, this.callBack);
    }
  };


  callBack = (res) => {
    if (res) {
      if (res.data.success) {
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loanType } = decryptedData;
        if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
          gaLogEvent(CONSTANTS.GA_EVENTS.CC_BASIC_DETAILS_3);
          this.props.history.push({
            pathname: PATH.PRIVATE.CREDIT_CARD_OFFERS,
            state: res.data.ccData,
          });
        } else if (loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN) {
          gaLogEvent(CONSTANTS.GA_EVENTS.PL_LOAN_DETIALS_3);
          if (localStorage.getItem("is_Pl_Lender_Offer")) {
            const bankName = localStorage.getItem("pl_Bankname");
            const lenderList = res.data.breData

            let responseList = lenderList.filter(
              (lists) =>
                lists.lenderName.toLowerCase() === bankName.split("-")
                  .join(" ").toLowerCase()
            );
            if (responseList.length > 0) {
              this.setState({ bank: responseList[0] })
              this.handleApply();
            }
            else {
              if (localStorage.getItem("is_Pl_Lender_Offer") === "yes") {
                this.props.history.push({
                  pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
                  state: res.data,
                });
              }
              else if (localStorage.getItem("is_Pl_Lender_Offer") === "no") {
                this.props.history.push({
                  pathname: `${PATH.PRIVATE.LOAN_APP_FAILED}`,
                  state: res.data,
                });
              }
            }

          } else {
            this.props.history.push({
              pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
              state: res.data,
            });
          }

        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };

  handleApply = () => {
    let formData = {
      lenderId: this.state.bank.lender_id__c,
      loanType: this.state.bank.loanType,
      mobile: localStorage.getItem("mobilenumber"),
      loanAmount: this.state.bank.appliedLoanAmount,
      offerId: this.state.bank.id,
      emi: this.state.bank.emi,
      roi: this.state.bank.IRR,
      tenure: this.state.bank.appliedTenure,
      pf: this.state.bank.PF,
      loanId: this.state.bank.loanId ? this.state.bank.loanId : "",
    };

    this.props.setOfferList(formData, this.callBackSet);
  };

  callBackSet = (res) => {
    if (res) {
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.PL_OFFER_SELECTED, {
          Lender_Name: this.state.bank.lenderName,
        });
        const mobile = localStorage.getItem("mobilenumber");
        let storeData = {
          loansfid: res.data.data.loansfid,
          lenderName: this.state.bank.lenderName,
        };
        encryptStore(mobile, storeData);
        if (this.state.bank.utmUrl) {
          window.open(this.state.bank.utmUrl, "_blank");
          this.props.history.push("/loan-applications/pl_loans/pl_offers");
        } else if (
          this.state.bank.lenderName === "Axis" ||
          this.state.bank.lenderName === "Axis Bank"
        ) {
          const formData = {
            firstName: this.state.firstName
              ? this.state.firstName
              : this.props.customerDetail.firstname,
            middleName: this.state.middleName
              ? this.state.middleName
              : this.props.customerDetail.middlename,
            lastName: this.state.lastName
              ? this.state.lastName
              : this.props.customerDetail.lastname,
            loanId: res.data.data.loansfid,
            loanType: res.data.loanType,
            lenderId: this.state.bank.lender_id__c,
            mobile: mobile,
            offerId: this.state.bank.id && this.state.bank.id.toString(),

          };
          this.props.setBankOfferList(formData, this.callBackSetOffer);
        } else if (this.state.bank.lenderName === "Credit Saison") {
          const formData = {
            loanId: res.data.data.loansfid,
            loanType: res.data.loanType,
            lenderId: this.state.bank.lender_id__c,
            mobile: mobile,
            offerId: this.state.bank.id && this.state.bank.id.toString(),
            loanName: res.data.data.loanName,
          };
          this.props.creditSaisonDedupe(formData, this.callBackDedupe);
        } else {

          this.props.history.push({
            pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
              }/${this.state.bank.loanType
                .split(/\s/)
                .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank,
          });
        }
      }
    }
  };
  callBackDedupe = (res) => {
    try {
      if (res.data.success) {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
            }/${this.state.bank.loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
          state: this.state.bank,
        });
      } else if (res.data.description.toString().toLowerCase() === "entity exists") {
        throw new Error(
          "We are unable to proceed with this application as one of your's previous  application is already in queue with Credit Saison"
        );
      } else {
        throw new Error(res.data.description);
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };
  callBackSetOffer = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push("/loan-applications/pl_loans/pl_offers");
        const url =
          res.data.axisData &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted.Response &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted.Response
            .productUrl;
        // console.log(url);
        // console.log(res.data)
        window.open(url, "_blank");
      }
    }
  };

  componentDidMount = () => {
    this.setState({ ...this.state, loadingData: true })
  }
  componentDidUpdate = () => {
    if (this.props?.populateData && this.state.loadingData) {
      const { companyExp, exp } = this.props?.populateData
      this.setState({ ...this.state, loadingData: false, data: { ...this.state?.data, companyExp, exp } })
    }
  }
  render() {
    const { loading } = this.props.getApplicant;
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    return (
      <div className="row insideFormBlock">
        <div className="col-sm12">
          {/* <Back
            onClick={(e) => {
              this.props.updateStep(
                e,
                CONSTANTS.RENDER_PERSONAL_LOAN_EMPLOYER_DETAIL
              );
            }}
          /> */}
        </div>
        {loading ? <BackDropComponent /> : ""}
        <div className="col-sm-12 text-center">
          <div className="bsFormHeader">
            {/* <div className="bsFormHeaderIcon">
              <img alt="" src={USER_ICON} />
            </div> */}
            {loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN && (
              <h1>Check Credit Cards offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && (
              <h1>Check Two Wheeler Loan offers </h1>
            )}
            {loanType === CONSTANTS.LOAN_TYPE.PERSONAL_LOAN && (
              <h1>Check Personal Loan offers </h1>
            )}{" "}
          </div>
        </div>
        <div className="col-sm-12">
          <form className="panVeryfyForm">
            <div className="panFormFields">
              <div className="col-sm-12">
                <SelectSearch
                  style={{ margin: "15px 8px 20px" }}
                  placeholderValue={"Total Experience in Current Company"}
                  label={"Total Experience in Current Company"}
                  value={this.state.data.companyExp}
                  page="personal"
                  setSelectedOption={(e) => {
                    const data = { ...this.state.data };
                    const errors = { ...this.state.errors };
                    if (e) {
                      data.companyExp = e;
                      errors.companyExp = "";
                      this.setState({ data, errors });
                    }
                  }}
                  dropDownOptions={total_wrk_exp}
                  error={this.state.errors.companyExp}
                  icon={
                    <BusinessCenterIcon
                      style={{ marginRight: "5px", marginTop: "2px" }}
                    />
                  }
                ></SelectSearch>
              </div>
              <div className="col-sm-12">
                <SelectSearch
                  placeholderValue={"Your Total Work Experience"}
                  label={"Your Total Work Experience"}
                  value={this.state.data.exp}
                  page="personal"
                  setSelectedOption={(e) => {
                    const data = { ...this.state.data };
                    const errors = { ...this.state.errors };
                    if (e) {
                      data.exp = e;
                      errors.exp = "";
                      this.setState({ data, errors });
                    }
                  }}
                  dropDownOptions={total_wrk_exp}
                  error={this.state.errors.exp}
                  icon={
                    <BusinessCenterIcon
                      style={{ marginRight: "5px", marginTop: "2px" }}
                    />
                  }
                ></SelectSearch>
              </div>
              <div className="col-sm-12 text-center">
                <button
                  type="submit"
                  onClick={this.handleSubmit}
                  variant="contained"
                  className="nextButton"
                >
                  Get Offers
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  getApplicant: getApplicant(state),
});
const mapDispatchToProps = (dispatch) => ({
  setApplicantDetail: (params, callBack) =>
    dispatch(setApplicantDetail(params, callBack)),
  setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  creditSaisonDedupe: (params, callBack) =>
    dispatch(creditSaisonDedupe(params, callBack)),

});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CustomerDetail)
);
