import React, { Component } from "react";
import { numberFormat } from "../../../Utils/numberFormat";
import Swal from "sweetalert2";
import { encryptStore } from "../../../Utils/store";
// import newLoanArrow from "../../../include/assets/newLoanArrow.svg";
// import AddIcon from "../../../include/assets/personalLoan/icons8-add-96.png";
// import { ReactComponent as ArrowForwardIosIcon } from "../../../include/assets/buttonArrow.svg";
import { connect } from "react-redux";
import { withRouter } from "react-router";
// import selectIcon from "../../../include/assets/select-icon.svg";
import { Container, Row, Col } from "react-bootstrap";
// import BackDropComponent from "../../../common/BackDropComponent";
import TopNavBar from "../../../common/TopNavBar";
// import CONSTANTS from "../../../constants/Constants";
// import { gaLogEvent } from "../../../init-fcm";
import PATH from "../../../paths/Paths";
import { getAccountInfo, getAccount } from "../../../store/account";
import { loadApplyLoan } from "../../../store/applyLoan";
import DashBoardAside from "../../../common/dashboardAside";
import CreditFooter from "../../cibilFlow/footer";
import Logo from "../../../include/assets/wefin-logo.svg";
import moment from "moment";


class BLOffer extends Component {

    constructor(props) {
        super(props);
        this.state = {};
    }

    componentDidMount = () => {
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        let mobile = localStorage.getItem("mobilenumber");
        this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
    };

    callbackDetail = (res) => {
        if (res) {
            if (res?.data?.success === false) {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.INDEX);
                });
            }
        }
    };

    loanCall = (id) => {
        const mobile = localStorage.getItem("mobilenumber");
        let formData = { mobile: mobile, loanType: id, newLoan: true };
        this.props.loadApplyLoan(formData, this.callbackLoan);
    };

    callbackLoan = (res) => {
        if (res) {
            const mobile = localStorage.getItem("mobilenumber");
            if (res.data.success) {
                let {
                    data: { loanName, loansfid },
                    loanType,
                } = res.data;
                let storeData = {
                    loansfid: loansfid,
                    loanName: loanName,
                    loanType: loanType,
                };
                encryptStore(mobile, storeData);

                if (this.props.customerDetail.pan_verified__c === true) {
                    this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
                } else {
                    this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
                }
            } else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res && res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.INDEX);
                });
            }
        }
    };

    render() {

        const { getAccountDetail } = this.props;
        const applied_business_loans = getAccountDetail[0]?.bl_loans ? getAccountDetail[0].bl_loans : [];

        return (
            <>
                <TopNavBar />
                <section className="bs-main-section">
                    <Container>
                        <Row>
                            <Col sm={12} md={3}>
                                <DashBoardAside />
                            </Col>
                            <Col sm={12} md={9}>
                                <div className="row bsFormBlock">
                                    <div className="col-sm-12">
                                        <div className="row g-0">
                                            <div
                                                className="col-12 col-sm-12"
                                                style={{ paddingLeft: "0px" }}
                                            >
                                                <h3 className="bsLoanHeadline">Business Loans</h3>
                                            </div>
                                        </div>
                                    </div>

                                    {applied_business_loans.map((e, i) => (
                                        <div className="col-sm-12 bsMyLoanSection">
                                            <div className="row g-0 align-items-center bsMyLoanBox">
                                                <div className="col-sm-9">
                                                    <div className="row g-0">
                                                        <div className="col-6 col-sm-4">
                                                            <p> Application No.</p>

                                                            <strong>{e.loanName}</strong>
                                                        </div>
                                                        <div className="col-6 col-sm-4">
                                                            <p>Loan Amount</p>

                                                            <strong>
                                                                {" "}
                                                                {e.appliedLoanAmount
                                                                    ? numberFormat(e.appliedLoanAmount)
                                                                    : "------"}
                                                            </strong>
                                                        </div>
                                                        <div className="col-6 col-sm-4">
                                                            <p>Loan Type</p>
                                                            <strong>{e.loanType.split("_").join(" ")}</strong>
                                                        </div>
                                                    </div>

                                                    <hr className="bsBorder" />
                                                    <div className="row g-0 align-items-center">
                                                        <div className="col-6 col-sm-4">
                                                            <div>
                                                                {e.bankImage ? (
                                                                    <img
                                                                        src={e.bankImage}
                                                                        alt=""
                                                                        width="100"
                                                                        style={{ width: "90px" }}
                                                                    />
                                                                ) : (
                                                                    <img
                                                                        src={Logo}
                                                                        alt=""
                                                                        width="100"
                                                                        style={{ width: "90px" }}
                                                                    />
                                                                )}
                                                            </div>
                                                        </div>

                                                        <div className="col-6 col-sm-4">
                                                            {" "}
                                                            <p>Applied Date</p>
                                                            <strong>
                                                                {e?.createddate
                                                                    ? moment(e.createddate).format('MM/DD/YYYY')
                                                                    : "------"}
                                                            </strong>
                                                            <span></span>
                                                            {e.lenderName ? "" : <span></span>}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className=" col-12 col-sm-3 text-center">
                                                    <p className="bsContinue">
                                                        Loan Stage
                                                        <strong
                                                            style={{
                                                                fontWeight: "bolder",
                                                                color: "#1aac7a",

                                                                fontSize: "16px",
                                                            }}
                                                        >
                                                            {e.loanStage}
                                                        </strong>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>
                <CreditFooter />
            </>
        );
    }
}
const mapStateToProps = (state) => ({
    getAccountDetail: getAccount(state).getAccountDetail,
});

const mapDispatchToProps = (dispatch) => ({
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    loadApplyLoan: (params, callback) =>
        dispatch(loadApplyLoan(params, callback))
});
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(BLOffer)
);
