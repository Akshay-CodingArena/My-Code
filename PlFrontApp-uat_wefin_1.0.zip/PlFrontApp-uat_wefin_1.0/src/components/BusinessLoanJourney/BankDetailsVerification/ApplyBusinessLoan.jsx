import React from "react";
// import EmployeeType from "../../common/employeeType";
// import PersonalAmountInput from "../../common/personalAmountInput";
import { ReactComponent as Money } from "../../../include/assets/money.svg";
import SelectSearch from "../../common/select";
import { BUSINESS_LOAN_DROPDOWNS } from "../../common/dropdownValues";
import { ReactComponent as BusinessCenterIcon } from "../../../include/assets/business.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import Joi from "joi-browser";
import Form from "../../common/form";
import PATH from "../../../paths/Paths";
import TopNavBar from "../../../common/TopNavBar";
import { decryptStore } from "../../../Utils/store";
import { applyBusinessLoan, getBusinessLoanDetails } from "../../../store/businessLoan";
import Swal from "sweetalert2";
import BackDropComponent from "../../../common/BackDropComponent";
import CONSTANTS from "../../../constants/Constants";
import { ReactComponent as CompanyTypeLogo } from "../../../include/assets/icons/company_type_logo.svg";
import { ReactComponent as BusinessNatureLogo } from "../../../include/assets/icons/business_nature_logo.svg";
import { ReactComponent as AnnualTurnoverLogo } from "../../../include/assets/icons/annual_turnover_logo.svg";

class ApplyBusinessLoan extends Form {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
    };
  }

  schema = {
    loanAmount: Joi.object()
      .required("")
      .error(() => {
        return { message: "Loan Amount is required." };
      }),
    companyType: Joi.object()
      .required("")
      .error(() => {
        return { message: "Company Type is required." };
      }),
    businessNature: Joi.object()
      .required("")
      .error(() => {
        return { message: "Nature of Business is required." };
      }),
    yearsInBusiness: Joi.object()
      .required("")
      .error(() => {
        return { message: "Years in Current Business is required." };
      }),
    annualTurnover: Joi.object()
      .required("")
      .error(() => {
        return { message: "Annual Turnover is required." };
      }),
  };


  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");

    window.scrollTo(0, 0);
    const data = { ...this.state.data };
    data.loanAmount = "";
    data.companyType = "";
    data.businessNature = "";
    data.yearsInBusiness = "";
    data.annualTurnover = "";
    this.setState({ data });
  };

  doSubmit = () => {
    let data = this.state.data;

    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loansfid, loanType } = decryptedData;

    let formData =
    {
      loanAmount: data?.loanAmount?.value,
      companyType: data?.companyType?.value,
      buisnessNature: data?.businessNature?.value,
      currBsYrs: data?.yearsInBusiness?.value,
      annualTurnover: data?.annualTurnover?.value,
      loanId: loansfid,
      loanType: loanType,
      mobile: localStorage.getItem('mobilenumber'),
    }
    this.props.applyBusinessLoan(formData, this.applyBusinessLoanCallback)
  }

  applyBusinessLoanCallback = async (res) => {
    try {
      let r = await res;
      if (r.data.success) {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.CONGRATULATION_SCREEN}`,
          state: {
            loan_application_number: r?.data?.data?.loanName,
            loan_type: CONSTANTS.LOAN_TYPE.BUSINESS_LOAN
          }
        })
      } else throw r.data.message.toString();
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: false,
        timer: 1800,
      });
    }
  }

  render() {
    return <React.Fragment>
      {
        (this.props.loading) ? (
          <BackDropComponent />
        ) : (
          ""
        )}
      <TopNavBar />
      <section className="bs-main-section">
        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">
              <h1>We will check Business Loan offer against your details</h1>
            </div>
          </div>
          <div className="col-sm-12">
            <form className="panVeryfyForm">
              <div className="panFormFields">
                <div className="row">
                  <div className="col-sm-6">
                    <SelectSearch
                      style={{ margin: "15px 8px 20px" }}
                      placeholderValue={"Loan Amount"}
                      label={"Loan Amount"}
                      value={this.state.data.loanAmount}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.loanAmount = e;
                          errors.loanAmount = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={BUSINESS_LOAN_DROPDOWNS?.loanAmount ? BUSINESS_LOAN_DROPDOWNS.loanAmount : []}
                      error={this.state.errors.loanAmount}
                      icon={
                        <Money
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>
                  </div>

                  <div className="col-sm-6">
                    <SelectSearch
                      style={{ margin: "15px 8px 20px" }}
                      placeholderValue={"Annual Turnover"}
                      label={"Annual Turnover"}
                      value={this.state.data.annualTurnover}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.annualTurnover = e;
                          errors.annualTurnover = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={BUSINESS_LOAN_DROPDOWNS?.annualTurnover ? BUSINESS_LOAN_DROPDOWNS.annualTurnover : []}
                      error={this.state.errors.annualTurnover}
                      icon={
                        <AnnualTurnoverLogo
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>

                  </div>



                  <div className="col-sm-6">
                    <SelectSearch
                      style={{ margin: "15px 8px 20px" }}
                      placeholderValue={"Select Company Type"}
                      label={"Company Type"}
                      value={this.state.data.companyType}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.companyType = e;
                          errors.companyType = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={BUSINESS_LOAN_DROPDOWNS?.companyType ? BUSINESS_LOAN_DROPDOWNS.companyType : []}
                      error={this.state.errors.companyType}
                      icon={
                        <CompanyTypeLogo
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>

                  </div>

                  <div className="col-sm-6">
                    <SelectSearch
                      style={{ margin: "15px 8px 20px" }}
                      placeholderValue={"Nature of Business"}
                      label={"Nature of Business"}
                      value={this.state.data.businessNature}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.businessNature = e;
                          errors.businessNature = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={BUSINESS_LOAN_DROPDOWNS?.businessNature ? BUSINESS_LOAN_DROPDOWNS.businessNature : []}
                      error={this.state.errors.businessNature}
                      icon={
                        <BusinessNatureLogo
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>

                  </div>

                  <div className="col-sm-6">
                    <SelectSearch
                      style={{ margin: "15px 8px 20px" }}
                      placeholderValue={"Years in Current Business"}
                      label={"Years in Current Business"}
                      value={this.state.data.yearsInBusiness}
                      page="personal"
                      setSelectedOption={(e) => {
                        const data = { ...this.state.data };
                        const errors = { ...this.state.errors };
                        if (e) {
                          data.yearsInBusiness = e;
                          errors.yearsInBusiness = "";
                          this.setState({ data, errors });
                        }
                      }}
                      dropDownOptions={BUSINESS_LOAN_DROPDOWNS?.yearsInCurBussiness ? BUSINESS_LOAN_DROPDOWNS.yearsInCurBussiness : []}
                      error={this.state.errors.yearsInBusiness}
                      icon={
                        <BusinessCenterIcon
                          style={{ marginRight: "5px", marginTop: "2px" }}
                        />
                      }
                    ></SelectSearch>

                  </div>

                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Submit
                    </button>

                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>
    </React.Fragment>
  }
}

const mapStateToProps = (state) =>
({
  loading: getBusinessLoanDetails(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
  applyBusinessLoan: (params, callback) => dispatch(applyBusinessLoan(params, callback))
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ApplyBusinessLoan)
);



