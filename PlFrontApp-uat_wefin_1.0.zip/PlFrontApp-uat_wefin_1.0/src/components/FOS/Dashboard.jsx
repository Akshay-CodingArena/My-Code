
import { useState } from "react"
import CreditCard from "./CreditCard";
import PersonalLoan from "./PersonalLoan";
import FOSAdminPersonalLoan from "./admin/personalLoan";
import FOSAdminCreditCard from "./admin/creditCard";


const FOSDashboard = () => {
    const [showInsurance, setShowInsurance] = useState(localStorage.getItem("FOS_Flow_For") ? localStorage.getItem("FOS_Flow_For") : "personal loan");
    let role = localStorage.getItem("role");

    const getComponent = () => {
        if (role === "FOS_ADMIN") {
            switch (showInsurance) {
                case "personal loan":
                    return <FOSAdminPersonalLoan showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
                case "credit card":
                    return <FOSAdminCreditCard showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
            }
        } else {
            switch (showInsurance) {
                case "personal loan":
                    return <PersonalLoan showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
                case "credit card":
                    return <CreditCard showInsurance={showInsurance} setShowInsurance={setShowInsurance} />
            }
        }
    }
    return (<>
        {getComponent()}
    </>
    )
}

export default FOSDashboard