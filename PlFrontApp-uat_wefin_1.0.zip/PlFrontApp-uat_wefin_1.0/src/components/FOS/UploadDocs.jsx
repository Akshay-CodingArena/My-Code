import React from "react";
import TopNavBar from "./FOSNavBar";
import { Container, Row, Col } from "react-bootstrap";
import { connect } from "react-redux";
import BackDropComponent from "../../common/BackDropComponent";
import Joi from "joi-browser";
import Swal from "sweetalert2";
import { asmDocUpload, fosDocUpload, getUpload, uploadSalary } from "../../store/upload";
import { withRouter } from "react-router";
import PATH from "../../paths/Paths";
import { pdfjs } from "react-pdf";
import PdfViewer from "../../common/PdfViewer";
import Form from "../common/form";
import { PLAttachContainerCell, PLAttachContainerCellPdf } from "../../common/helperCells";
import { getASM, isInterestedFOS, removeFileFOS } from "../../store/asm";
import PersonalInput from "../common/personalInput";

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
class FosUploadDocs extends Form {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                pan: null,
                photo: null,
                aadhaar: null,
                salSlip1: null,
                salSlip2: null,
                salSlip3: null,
                bankingDoc: null,
                otherDoc: null,
                remarks: ""
            },
            pdf: null,
            errors: {},
            loading: false,
            bank: {},
            counter: 5,
        };
        this.interestedRef = React.createRef(null);
        this.clickedDocRef = React.createRef(null)
    }


    isInterestedFunc = (is_interested) => {
        let formData = {
            "id": this.props.location.state.id,
            "customer_intrested": is_interested
        }

        this.props.isInterestedFOS(formData, this.callbackIsInterested);
    }


    callbackIsInterested = (res) => {
        if (res.data.success) {
            if (this.interestedRef.current) { } else {
                this.props.history.push(PATH.PRIVATE.FOS_DASHBOARD)
            }
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 1800,
            });
        }
    }


    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.add("NoScrool");
        document.body.classList.remove("variantScroll");

        let data = { ...this.state.data };

        if (localStorage.getItem("isMountedOnlyOnce")) {

            localStorage.removeItem("isMountedOnlyOnce");

            let bool = this.props.location.state.lead_type === "Credit_card" && localStorage.getItem("role") === "FOS_CALL";

            if (!bool && this.props.location?.state?.data?.intrested === "false" || this.props.location?.state?.data?.intrested === null) {
                Swal.fire({
                    icon: "info",
                    title: `Is the customer interested in ${this.props.location.state.lead_type === "Personal_loan" ? "obtaining a personal loan?" : "applying for a credit card?"}`,
                    showCancelButton: true,
                    confirmButtonText: "Yes",
                    cancelButtonText: "No",
                    confirmButtonColor: "#d63031",
                    cancelButtonColor: "#2e0080",
                    allowOutsideClick: false
                }).then((res) => {
                    if (res.isConfirmed) {
                        //////////API LAGANI H/////////
                        this.interestedRef.current = true;
                        this.isInterestedFunc(true)
                    }
                    if (res.isDismissed) {
                        this.interestedRef.current = false;
                        this.isInterestedFunc(false);
                    }
                });
            }
        }

        if (this.props.location?.state?.data?.kyc_pan_filename) {
            data['pan'] = { name: this.props.location.state.data.kyc_pan_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.kyc_photo_filename) {
            data['photo'] = { name: this.props.location.state.data.kyc_photo_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.kyc_aadhar_filename) {
            data['aadhaar'] = { name: this.props.location.state.data.kyc_aadhar_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.income_ss1_filename) {
            data['salSlip1'] = { name: this.props.location.state.data.income_ss1_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.income_ss2_filename) {
            data['salSlip2'] = { name: this.props.location.state.data.income_ss2_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.income_ss3_filename) {
            data['salSlip3'] = { name: this.props.location.state.data.income_ss3_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.bank_filename) {
            data['bankingDoc'] = { name: this.props.location.state.data.bank_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.other_documents_filename) {
            data['otherDoc'] = { name: this.props.location.state.data.other_documents_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.other_documents_filename) {
            data['otherDoc'] = { name: this.props.location.state.data.other_documents_filename, onlyFileName: true }
        }
        if (this.props.location?.state?.data?.remarks) {
            data['remarks'] = this.props.location.state.data.remarks
        }
        this.setState({ data: data })

    };

    schema = {

        pan: Joi.object().allow(null),
        aadhaar: Joi.object().allow(null),
        photo: Joi.object().allow(null),
        salSlip1: Joi.object().allow(null),
        salSlip2: Joi.object().allow(null),
        salSlip3: Joi.object().allow(null),
        bankingDoc: Joi.object().allow(null),
        otherDoc: Joi.object().allow(null),
        remarks: Joi.allow(null),
    };

    docUpload = (e, docType) => {
        if (docType == "photo") {
            if (e.target.files[0].type !== "image/jpeg" && e.target.files[0].type !== "image/png") {
                Swal.fire({
                    position: "center",
                    icon: "info",
                    title: "Only png/jpg file is allowed to upload",
                    showConfirmButton: true,
                });
            }
            else {
                const data = { ...this.state.data };
                data[docType] = new File([e.target.files[0]], e.target.files[0].name);
                this.setState({ data, [docType]: e.target.files[0] });
            }
        }
        else {
            if (e.target.files[0].type !== "application/pdf") {
                Swal.fire({
                    position: "center",
                    icon: "info",
                    title: "Only PDF files are allowed to upload",
                    showConfirmButton: true,
                });
            } else if (e.target.files[0].size <= 0) {
                Swal.fire({
                    position: "center",
                    icon: "info",
                    title: "PDF file size is should be greater than zero",
                    showConfirmButton: true,
                });
            } else if (e.target.files[0].size > 5000000) {
                Swal.fire({
                    position: "center",
                    icon: "info",
                    title: "PDF file size should not be greater than 5Mb ",
                    showConfirmButton: true,
                });
            } else {
                const data = { ...this.state.data };
                data[docType] = new File([e.target.files[0]], e.target.files[0].name);
                this.setState({ data, [docType]: e.target.files[0] });
            }
        }
    };

    callBackStateUpload = (res) => {
        if (res.data.success) {
            Swal.fire({
                position: "center",
                icon: "success",
                title: "Record submitted successfully",
                showConfirmButton: true,
                confirmButtonColor: "rgb(76,175,80)",
            }).then((res) => {
                if (res.isConfirmed) {
                    this.props.history.push({
                        pathname: PATH.PRIVATE.FOS_DASHBOARD,
                    })
                }
            });
        }
        else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Error Occured While Uploading Document",
                showConfirmButton: false,
                timer: 1000,
            })
        }
    }

    doSubmit = async () => {
        let { pan, photo, aadhaar, salSlip1, salSlip2, salSlip3, bankingDoc, otherDoc, remarks } = this.state.data;
        // this.setState((p) => ({ ...p, bank: { ...this.props.location.state } }));
        let bool = false;

        if (pan?.hasOwnProperty("onlyFileName")) {
            bool = true;
            pan = null
        }
        if (photo?.hasOwnProperty("onlyFileName")) {
            bool = true;
            photo = null
        }
        if (aadhaar?.hasOwnProperty("onlyFileName")) {
            bool = true;
            aadhaar = null
        }
        if (salSlip1?.hasOwnProperty("onlyFileName")) {
            bool = true;
            salSlip1 = null
        }
        if (salSlip2?.hasOwnProperty("onlyFileName")) {
            bool = true;
            salSlip2 = null
        }
        if (salSlip3?.hasOwnProperty("onlyFileName")) {
            bool = true;
            salSlip3 = null
        }
        if (bankingDoc?.hasOwnProperty("onlyFileName")) {
            bool = true;
            bankingDoc = null
        }
        if (otherDoc?.hasOwnProperty("onlyFileName")) {
            bool = true;
            otherDoc = null
        }
        if (pan || aadhaar || photo || bankingDoc || salSlip1 || salSlip2 || salSlip3 || otherDoc || remarks) {
            const formData = new FormData();
            if (pan) formData.append("kyc_pan", pan);
            if (aadhaar) formData.append("kyc_aadhar", aadhaar);
            if (photo) formData.append("kyc_photo", photo);
            if (bankingDoc) formData.append("banking", bankingDoc);
            if (salSlip1) formData.append("income_ss1", salSlip1);
            if (salSlip2) formData.append("income_ss2", salSlip2);
            if (salSlip3) formData.append("income_ss3", salSlip3);
            if (otherDoc) formData.append("other_documents", otherDoc);
            // if (doc1) formData.append("kyc", doc1, 'application/pdf', "kyc.pdf");
            // if (doc2) formData.append("banking", doc2, 'application/pdf', "banking.pdf");
            // if (doc3) formData.append("income", doc3, 'application/pdf', "income.pdf");
            formData.append("remarks", remarks ? remarks : "")
            formData.append("id", this.props.location.state.id)
            this.props.fosDocUpload(formData, this.callBackStateUpload);
        }
        else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Please upload/change atleast one document or remarks",
                showConfirmButton: true,
            })
        }
    };

    _handleChange = (key, e) => {
        let data = {};

        switch (key) {
            case "remarks":
                const remarks = e.target.value;
                data = { ...this.state.data };
                data.remarks = remarks.replace(/[^a-zA-Z\s]+/, '');
                this.setState({ data });
                break;
        }

        e.preventDefault();
    }
    componentWillUnmount = () => {

    }

    previewPdf = (pdf) => {

        this.setState({ ...this.state, pdf: URL.createObjectURL(pdf) })

    }


    handleSkip = () => {
        this.props.history.push(PATH.PRIVATE.FOS_DASHBOARD);
    }

    handleCancel = (doc_name) => {
        //////////comment//////////
        this.clickedDocRef.current = doc_name;

        if (doc_name === "pan") {

            let file = { ...this.state.data.pan };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, pan: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "kyc_pan"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "aadhaar") {

            let file = { ...this.state.data.aadhaar };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, aadhaar: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "kyc_aadhar"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "photo") {

            let file = { ...this.state.data.photo };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, photo: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "kyc_photo"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "otherDoc") {

            let file = { ...this.state.data.otherDoc };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, otherDoc: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "other_documents"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "salSlip1") {

            let file = { ...this.state.data.salSlip1 };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, salSlip1: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "income_ss1"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "salSlip2") {

            let file = { ...this.state.data.salSlip2 };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, salSlip2: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "income_ss2"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "salSlip3") {

            let file = { ...this.state.data.salSlip3 };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, salSlip3: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "income_ss3"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        } else if (doc_name === "bankingDoc") {

            let file = { ...this.state.data.bankingDoc };

            if (!file.hasOwnProperty("onlyFileName")) {
                this.setState({ data: { ...this.state.data, bankingDoc: null } })
            } else {
                let formData = {
                    id: this.props.location.state.id,
                    fileType: "banking"
                }

                this.props.removeFileFOS(formData, this.callbackRemoveFile)
            }
        }
    }

    callbackRemoveFile = (res) => {
        if (res.data.success) {
            if (this.clickedDocRef.current === "pan") {
                this.setState({ data: { ...this.state.data, pan: null } })

            } else if (this.clickedDocRef.current === "aadhaar") {
                this.setState({ data: { ...this.state.data, aadhaar: null } })

            } else if (this.clickedDocRef.current === "photo") {
                this.setState({ data: { ...this.state.data, photo: null } })
            }
            else if (this.clickedDocRef.current === "salSlip1") {
                this.setState({ data: { ...this.state.data, salSlip1: null } })
            }
            else if (this.clickedDocRef.current === "salSlip2") {
                this.setState({ data: { ...this.state.data, salSlip2: null } })
            }
            else if (this.clickedDocRef.current === "salSlip3") {
                this.setState({ data: { ...this.state.data, salSlip3: null } })
            }
            else if (this.clickedDocRef.current === "bankingDoc") {
                this.setState({ data: { ...this.state.data, bankingDoc: null } })
            }
            else if (this.clickedDocRef.current === "otherDoc") {
                this.setState({ data: { ...this.state.data, otherDoc: null } })
            }
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 3500,
            });
        }
    }

    render() {
        return (
            <>
                {/* <PdfViewer link={this.state.pdf} closeViewer={() => this.setState({ ...this.state, pdf: false })} /> */}
                <>
                    {<TopNavBar />}
                    <section className="bs-main-section" >
                        <Container>
                            <Row>
                                <Col sm={12} md={12}>
                                    {this.props.loading || this.props.loadingIsInterestedFOS || this.props.loadingRemoveFileFOS ? <BackDropComponent /> : ""}
                                    <div className="container">
                                        <div className="row">
                                            <div className="col-sm-12 text-center">
                                                <div className="bsFormHeader upload_header">
                                                    <h1>Upload your documents</h1>
                                                </div>
                                            </div>
                                            <div className="col-sm-12">
                                                <form>
                                                    <div className="row justify-content-center">
                                                        <div className="col-sm-12 text-center">
                                                            <div className="bsFormHeader upload_header">
                                                                <h1>KYC Documents</h1>
                                                            </div>
                                                        </div>
                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"PAN"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "pan")}
                                                                doc={this.state.data.pan}
                                                                error={this.state.errors.pan}
                                                                previewPdf={() => this.previewPdf(this.state.data.pan)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("pan")}
                                                            />
                                                        </div>
                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCell
                                                                uploadText={"Photo"}
                                                                dataTip={
                                                                    "Please upload jpeg/png file only"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "photo")}
                                                                doc={this.state.data.photo}
                                                                error={this.state.errors.photo}
                                                                previewPdf={() => this.previewPdf(this.state.photo)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("photo")}
                                                            />
                                                        </div>
                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"Aadhaar"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "aadhaar")}
                                                                doc={this.state.data.aadhaar}
                                                                error={this.state.errors.aadhaar}
                                                                previewPdf={() => this.previewPdf(this.state.aadhaar)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("aadhaar")}
                                                            />
                                                        </div>
                                                        <div className="col-sm-12 text-center">
                                                            <div className="bsFormHeader upload_header">
                                                                <h1>Income Proof Documents</h1>
                                                            </div>
                                                        </div>
                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"Salary Slip 1"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "salSlip1")}
                                                                doc={this.state.data.salSlip1}
                                                                error={this.state.errors.salSlip1}
                                                                previewPdf={() => this.previewPdf(this.state.salSlip1)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("salSlip1")}
                                                            />
                                                        </div>
                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"Salary Slip 2"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "salSlip2")}
                                                                doc={this.state.data.salSlip2}
                                                                error={this.state.errors.salSlip2}
                                                                previewPdf={() => this.previewPdf(this.state.salSlip2)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("salSlip2")}
                                                            />
                                                        </div>
                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"Salary Slip 3"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "salSlip3")}
                                                                doc={this.state.data.salSlip3}
                                                                error={this.state.errors.salSlip3}
                                                                previewPdf={() => this.previewPdf(this.state.salSlip3)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("salSlip3")}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-12 text-center">
                                                        <div className="bsFormHeader upload_header">
                                                            <h1>Banking Documents</h1>
                                                        </div>
                                                    </div>
                                                    <div style={{ display: "flex", justifyContent: "center" }}>

                                                        < div className="col-sm-4" >
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"Banking Document"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "bankingDoc")}
                                                                doc={this.state.data.bankingDoc}
                                                                error={this.state.errors.bankingDoc}
                                                                previewPdf={() => this.previewPdf(this.state.bankingDoc)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("bankingDoc")}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-12 text-center">
                                                        <div className="bsFormHeader upload_header">
                                                            <h1>Other Documents</h1>
                                                        </div>
                                                    </div>
                                                    <div style={{ display: "flex", justifyContent: "center" }}>

                                                        < div className="col-sm-4">
                                                            <PLAttachContainerCellPdf
                                                                uploadText={"BT/ CC outstanding statements"}
                                                                dataTip={
                                                                    "Please upload PDF file only with file size of less than 5 MB"
                                                                }
                                                                fileUpload={(e) => this.docUpload(e, "otherDoc")}
                                                                doc={this.state.data.otherDoc}
                                                                error={this.state.errors.otherDoc}
                                                                previewPdf={() => this.previewPdf(this.state.otherDoc)}
                                                                isCancel={true}
                                                                handleCancel={() => this.handleCancel("otherDoc")}
                                                            />
                                                        </div>
                                                    </div>
                                                    {/* <div className="col-sm-12">

                                                        <PersonalInput
                                                            value={this.state.data.remarks}
                                                            __handleChange={(e) => this._handleChange('remarks', e)}
                                                            error={this.state.errors.remarks}
                                                            // icon={<EmailIcon />}
                                                            label="Remarks"
                                                            required={false}
                                                        />
                                                    </div> */}
                                                    <div className="col-12">
                                                        <label><b>Remarks</b></label>
                                                        <div class="form-group">
                                                            <textarea onChange={(e) =>
                                                                this.setState({ data: { ...this.state.data, remarks: e.target.value } })} value={this.state.data.remarks} class="form-control" placeholder="Enter remarks if any..." rows="4"></textarea>
                                                        </div>
                                                    </div>


                                                    <div className="row">
                                                        <div className="col-sm-12 text-center">
                                                            <button
                                                                type="submit"
                                                                variant="contained"
                                                                onClick={this.handleSubmit}
                                                                className="nextButton"
                                                            >
                                                                Submit
                                                            </button>

                                                            <button
                                                                type="button"
                                                                variant="contained"
                                                                onClick={this.handleSkip}
                                                                className="nextButton ml-3"
                                                            >
                                                                Skip
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </Col>
                            </Row>
                        </Container >
                    </section >
                </>
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    loading: getUpload(state).loading,
    loadingIsInterestedFOS: getASM(state).loadingIsInterestedFOS,
    loadingRemoveFileFOS: getASM(state).loadingRemoveFileFOS
});
const mapDispatchToProps = (dispatch) => ({
    fosDocUpload: (params, callBack) => dispatch(fosDocUpload(params, callBack)),
    isInterestedFOS: (params, callback) => dispatch(isInterestedFOS(params, callback)),
    removeFileFOS: (params, callback) => dispatch(removeFileFOS(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(FosUploadDocs)
);