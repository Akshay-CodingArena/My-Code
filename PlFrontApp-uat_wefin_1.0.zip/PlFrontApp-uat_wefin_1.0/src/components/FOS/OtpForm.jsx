import React, { Component } from "react";
import Swal from "sweetalert2";
import NEO from "../../include/assets/wefin-logo.svg";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
    setCustomerOtp,
    getCustomer,
    getCustomerOTP,
} from "../../store/login";
import ArrowForwardIcon from "../../include/assets/otpArrow.png";
import BackDropComponent from "../../common/BackDropComponent";
import { encryptStore } from "../../Utils/store";
import { getAccountInfo, getAccount } from "../../store/account";
import { loadccApplyLoan, getApplyLoan } from "../../store/applyLoan";
import { getBankOffer, getOffer } from "../../store/bankOffer";

import { ReactComponent as Close } from "../../include/assets/close.svg";
import {
    gAKeys,
    gtag_report_conversion,
} from "../../Utils/googleTagTracking";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import { gaLogEvent } from "../../init-fcm";
import { splitMulti } from "../../common/helperCells";
import { loadConsents } from "../../store/consent";
import cardRedirection from "../creditCard/cardRedirection";
import { getOS } from "../../Utils/device_function";
import { fosAddCustomer, getASM, isInterestedFOS, resendOTPFOS, setFosOtp } from "../../store/asm";
import { dropdown_gender_values } from "../common/dropdownValues";
import { Modal } from "react-bootstrap";
// import cardRedirection from "../../credi";

class OTPForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            OTPError: "",
            otp: "",
            OTPIconDisable: false,
            otpData: {},
            seconds: 60,
            showOTP: false,
            loading: false
        };
        this.interestedRef = React.createRef(null);
    }
    componentDidMount = () => {
        window.scrollTo(0, 0)

        let interval = this.___handleTimer();
        return () => {
            clearInterval(interval);
        };

    };
    ___handleTimer = () => {
        let myInterval = setInterval(() => {
            if (this.state.seconds > 0) {
                this.setState({ seconds: this.state.seconds - 1 });
            } else {
                this.setState({ showOTP: true });
                clearInterval(myInterval);
            }
        }, 1000);
        return myInterval;
    };
    __handleOTP = (event) => {
        event.preventDefault();
        const otp = event.target.value;
        if (otp.length <= 4 && (/^[0-9]+$/.test(otp) || otp === "")) {
            this.setState({ otp: otp });
        }
    };

    __handleKeyPress = (event, key) => {
        if (event.key === "Enter" && event.shiftKey === false) {
            event.preventDefault();
            switch (key) {
                case "* * * *":
                    const otp = event.target.value;
                    if (otp.length === 4 && this.state.OTPIconDisable === false) {
                        this.setState({ OTPIconDisable: true });
                        this.__verifyOTP();
                    }
                    break;
                default:
                    break;
            }
        }
    };
    __verifyOTP = () => {

        if (this.state.otp.length < 4) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "Otp must be 4 digits long",
                showConfirmButton: false,
                timer: 1800,
            })
            return;
        }

        localStorage.setItem("mobilenumber", this.props.data.mobile);

        const formData = {
            otp: this.state.otp,
            id: this.props.id
        }

        setTimeout(() => {
            this.props.setFosOtp(formData, this.callBackOTP);
        }, 2000);
    };


    journeyContinue = (res) => {
        if (res) {
            const mobile = localStorage.getItem("mobilenumber");
            if (res.data.success) {
                let {
                    data: { loanName, loansfid, loanType }
                } = res.data;
                let storeData = {
                    loansfid: loansfid,
                    loanName: loanName,
                    loanType: CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN,
                };
                console.log("Loan is", loanType, "response message", res.data.message, "props are", this.props)
                encryptStore(mobile, storeData);
                gtag_report_conversion(gAKeys.loginGetCreditCard);
                console.log(res.data.data)
                localStorage.setItem("ccLoans", JSON.stringify(this.props.getAccountDetail[0]?.cc_loans))
                if (res.data.data.loan_exists != true) {
                    console.log("props are as", this.props)
                    if (this.props.state.card) {
                        this.props.handleCloseLogin()
                        cardRedirection(this.props, this.props.state.card, this.props.getAccountInfo, true)
                    }
                    this.props.handleCloseLogin()
                    //    this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
                }
                else {
                    console.log("Already exist running", this.props.history)
                    this.props.history.push({
                        pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
                        state: this.props.getAccountDetail[0]?.cc_loans,
                        showPopUp: true
                    })
                    console.log("Already exist complete", this.props.history)
                }

            } else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.GET_CREDIT_CARD);
                });
            }
        } else {
            console.log("dead")
        }
    }

    callbackGetAccountDetails = (res) => {
        if (res.data.success) {
            let customerDetails = res.data.customer;

            let ccLoans =
                res.data?.details?.loanData?.[0]?.cc_loans ?
                    res.data.details.loanData[0].cc_loans : [];

            if (!customerDetails.pan_verified__c) {
                ////////////////send to pan verification////////
                const mobile = localStorage.getItem("mobilenumber");
                const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN;
                let storeData = { loanType: loanType };
                encryptStore(mobile, storeData)
                this.props.history.push({
                    pathname: PATH.PRIVATE.PAN_VERIFY,
                    state: {
                        isASMFlow: true
                    }
                })
            }
            else {
                if (this.props.isCustomerASM) {
                    this.props.history.push({
                        pathname: PATH.PUBLIC.GET_CREDIT_CARD,
                        state: {
                            isASM: true
                        }
                    })
                } else {
                    if (ccLoans.length) {
                        this.props.history.push({
                            pathname: PATH.PRIVATE.CREDIT_CARD_APPLIED_SCREEN,
                            state: ccLoans
                        })
                    }
                    else {
                        this.props.history.push({
                            pathname: PATH.PUBLIC.GET_CREDIT_CARD
                        })
                    }
                }
            }
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 1800,
            });
        }
    }


    isInterestedFunc = (is_interested) => {
        let formData = {
            "id": this.props.id,
            "customer_intrested": is_interested
        }

        this.props.isInterestedFOS(formData, this.callbackIsInterested);
    }

    callbackIsInterested = (res) => {
        if (res.data.success) {
            if (this.interestedRef.current) {
                this.props.history.push({
                    pathname: PATH.PRIVATE.FOS_UPLOAD_DOCS,
                    state: {
                        id: this.props.id,
                    },
                });
            } else {
                this.props.history.push(PATH.PRIVATE.FOS_DASHBOARD)
            }

        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 1800,
            });
        }

    }

    callBackOTP = (res) => {
        if (res) {
            if (res.data.success) {

                let role = localStorage.getItem("role");

                if (role === "FOS_CALL" && this.props.lead_type === "Credit_card") {
                    ///////////////////Redirect to Credit Card Screen////////////
                    this.props.history.push({
                        pathname: PATH.PUBLIC.GET_CREDIT_CARD, state: {
                            id: this.props.id,
                            isFOS: true,
                            mobile_no: this.props.data.mobile
                        }
                    });
                }
                else {

                    if (this.props.edit_data) {
                        localStorage.setItem("isMountedOnlyOnce", true);

                        this.props.history.push({
                            pathname: PATH.PRIVATE.FOS_UPLOAD_DOCS,
                            state: {
                                id: this.props.id,
                                data: this.props.edit_data,
                                lead_type: this.props.lead_type
                            }
                        });
                    } else {

                        Swal.fire({
                            icon: "info",
                            title: `Is the customer interested in ${this.props.lead_type === "Personal_loan" ? "obtaining a personal loan?" : "applying for a credit card?"}`,
                            showCancelButton: true,
                            confirmButtonText: "Yes",
                            cancelButtonText: "No",
                            confirmButtonColor: "#d63031",
                            cancelButtonColor: "#2e0080",
                            allowOutsideClick: false
                        }).then((res) => {
                            if (res.isConfirmed) {
                                //////////API LAGANI H/////////
                                this.interestedRef.current = true;
                                this.isInterestedFunc(true)
                            }
                            if (res.isDismissed) {
                                this.interestedRef.current = false;
                                this.isInterestedFunc(false)
                            }
                        });
                    }
                }
            }
            else {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: true,
                    timer: 1800,
                });
            }
        }
    };

    consentCallback = (res) => {
        if (res) {
            console.log(res)
        }
    }
    callbackDetail = (res) => {
        if (res) {
            if (res.data.success === false) {
                Swal.fire({
                    position: "center",
                    icon: "warning",
                    title: res.data.message,
                    showConfirmButton: false,
                    timer: 1800,
                }).then(() => {
                    this.props.history.push(PATH.PUBLIC.GET_CREDIT_CARD);
                });
            } else {
                const loanType = CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN;
                const mobile = localStorage.getItem("mobilenumber");
                const query = splitMulti(this.props.location.search, ["?", "&", "="]);
                if (query.length > 0) {
                    var formData;
                    formData = {
                        mobile: mobile,
                        utm_source: query[2],
                        utm_medium: query[4],
                        utm_id: query[8],
                        utm_campaign: query[6],
                        loanType: loanType,
                        cardSfid: this.props.state.card.sfid,
                        lenderId: this.props.state.card.lender_sfid__c
                    };
                } else {
                    formData = {
                        mobile: mobile,
                        loanType: loanType,
                    };
                }        //  To INsert

                if (!(res.data?.customer?.pan_verified__c ?? false)) {
                    let storeData = { loanType: loanType }
                    encryptStore(mobile, storeData)

                    formData = {
                        mobile: mobile,
                        loanType: loanType,
                        cardSfid: this.props.state.card.sfid,
                        lenderId: this.props.state.card.lender_sfid__c
                    };
                    this.setState({ ...this.state, panVerified: false })
                    localStorage.setItem("appliedCard", JSON.stringify(this.props.state.card))
                    this.props.history.push({ pathname: PATH.PRIVATE.PAN_VERIFY, appliedCard: this.props.state.card })
                }
                else {
                    this.callbackLoan()
                }
                console.log("pan is", res.data?.customer?.pan_verified__c)

                localStorage.setItem("email", res.data?.customer?.personemail);
                console.log("data we get", res.data)
            }
        }
    };


    __handleResendForOTP = (e) => {
        let formData = {
            id: this.props.id
        };
        this.props.resendOTPFOS(formData, this.callbackResendOtp);
    };


    callbackResendOtp = (res) => {
        if (res.data.success) {
            this.setState({
                seconds: 60,
                OTPIconDisable: false,
                showOTP: false,
                otp: "",
            });
            this.___handleTimer();
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };

    callBackGETOtp = (res) => {
        if (res) {
            if (res.data.success === true) {
                this.___handleTimer();
            }
        }
    };
    render() {
        console.log("data we have", this.props.state, "state", this.state)
        // const { classes } = this.props;
        return (
            <div style={{ position: "absolute", display: 'flex', justifyContent: "center", top: '0px', width: "100%" }} >
                <div style={{ backgroundColor: "grey", opacity: ".4", width: "100%", height: '100vh', position: "fixed" }}>

                </div>
                <div className="bs-login-block" style={{ zIndex: "999" }} >
                    {this.props.loadingGet ||
                        this.props.loadingOtp ||
                        this.props.loading ||
                        this.props.loadingLoan ||
                        this.props.loadingGetOffer ||
                        this.state.loading ||
                        this.props.asmLoading ||
                        this.props.loadingCheck ||
                        this.props.loadingResendOtpFOS ||
                        this.props.loadingIsInterestedFOS
                        ? (
                            <BackDropComponent />
                        ) : (
                            ""
                        )}
                    <form>
                        <p style={{ display: "flex", justifyContent: "end", flexDirection: "row-reverse" }}>
                            <Close onClick={() => {
                                this.props.handleCloseOTP();
                            }}
                                style={{ cursor: "pointer" }}
                            />
                        </p>

                        <div className="bs-login-logo">
                            <img alt="" src={NEO} />
                        </div>

                        <div className="bs-login-title ">
                            <h1 className="text-center">
                                Enter <span>OTP</span>
                            </h1>
                        </div>

                        <div className="LoginFormFields" style={{ marginTop: "-5px" }}>
                            <>
                                <div className="form-group">
                                    <input
                                        placeholder="****"
                                        value={this.state.otp}
                                        onChange={this.__handleOTP}
                                        onKeyPress={(e) => this.__handleKeyPress(e, "* * * *")}
                                        autoFocus
                                        id="otpField"
                                        className="otpField"
                                        name="otpField"
                                        autoComplete="off"
                                    />
                                    <span className="opt-arrow">
                                        <img src={ArrowForwardIcon} alt="ArrowForwardIcon" onClick={this.__verifyOTP} />
                                    </span>
                                </div>
                            </>
                            <div
                                className="otpBottomContainer"
                                style={{
                                    display: "flex",
                                    flexDirection: "column",
                                    marginTop: "20px",
                                }}
                            >
                                <div style={{ color: "#2e0080", textAlign: "center" }}>
                                    {this.state.seconds === 0 ? null : (
                                        <h4>
                                            Re-send in 00 :{" "}
                                            {this.state.seconds < 10
                                                ? `0${this.state.seconds}`
                                                : this.state.seconds}
                                        </h4>
                                    )}
                                </div>
                                <p>
                                    We have sent you a 4 digit verification code on your mobile
                                    number{" "}
                                    <span style={{ fontWeight: "800" }}>
                                        +91-{this.props.data.mobile}
                                    </span>
                                </p>
                                <div className="OptNotRcvd">
                                    {" "}
                                    {this.state.showOTP ? (
                                        <span>
                                            Didn't receive the OTP? &nbsp;
                                            <button
                                                type="button"
                                                onClick={this.__handleResendForOTP}
                                                className="btn btn-primary get-otp-btn"
                                            >
                                                Resend OTP
                                            </button>
                                        </span>
                                    ) : (
                                        ""
                                    )}
                                </div>
                                <div className="otp-terms-of-use">
                                    By OTP Verification, you agree to the following{" "}
                                    <a href="https://wefin.in/terms-of-use.html" target="_blank">
                                        Terms of Use
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}
const mapStateToProps = (state) => ({
    loadingOtp: getCustomer(state).loadingOtp,
    loadingGet: getCustomer(state).loadingGet,
    getApplyLoan: getApplyLoan(state),
    getOffer: getBankOffer(state).getBreOffer,
    getAccountDetail: getAccount(state).getAccountDetail,
    customerDetail: getAccount(state).customerDetail,
    loading: getAccount(state).loading,
    loadingLoan: getApplyLoan(state).loadingLoan,
    asmLoading: getASM(state).asmLoading,
    loadingResendOtpFOS: getASM(state).loadingResendOtpFOS,
    loadingIsInterestedFOS: getASM(state).loadingIsInterestedFOS
});
const mapDispatchToProps = (dispatch) => ({
    isInterestedFOS: (params, callback) => dispatch(isInterestedFOS(params, callback)),
    fosAddCustomer: (params, callback) => dispatch(fosAddCustomer(params, callback)),
    resendOTPFOS: (params, callback) => dispatch(resendOTPFOS(params, callback)),
    setCustomerOtp: (params, callback) =>
        dispatch(setCustomerOtp(params, callback)),
    setFosOtp: (params, callback) =>
        dispatch(setFosOtp(params, callback)),
    getCustomerOTP: (params, callback) =>
        dispatch(getCustomerOTP(params, callback)),
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    loadccApplyLoan: (params, callback) =>
        dispatch(loadccApplyLoan(params, callback)),
    getOffer: (params, callback) => dispatch(getOffer(params, callback)),
    loadConsents: (params, callback) => dispatch(loadConsents(params, callback)),

});
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(OTPForm)
);
