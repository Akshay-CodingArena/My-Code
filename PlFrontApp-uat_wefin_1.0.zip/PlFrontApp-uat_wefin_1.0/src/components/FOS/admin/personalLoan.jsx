import { useEffect, useRef, useState } from "react";
import { Col, Container, Modal, ModalFooter, Row, Table } from "react-bootstrap";
import { useHistory, useLocation } from "react-router-dom";
import PATH from "../../../paths/Paths";
import FOSNavBar from "../FOSNavBar";
import { useDispatch, useSelector } from "react-redux";
import CreditFooter from "../../cibilFlow/footer";
import DateRangePicker from '@wojtekmaj/react-daterange-picker'
import { getFullDay, getMonthName } from "../DateConverter";
import SelectSearch from "../../common/select";
import ShowEntries from "../../../common/ShowEntries";
import SearchBar from "../../../common/SearchBar";
import Paging from "../../../common/Pagination";
import CalenderIcon from "../../../include/assets/moneyPlus/calendar.svg"
import ArrowDown from "../../../include/assets/moneyPlus/down-arrow.svg"
import editIcon from "../../../include/assets/moneyPlus/edit.svg"
import { fosDashboard, asmGenerateToken, getASM, updateLeadStatusFOS } from "../../../store/asm";
import BackDropComponent from "../../../common/BackDropComponent";
import { months } from "../../CibilCheck/accountType";
import { ReactComponent as LoanAmountIcon } from "../../../include/assets/personalLoan/loanAm.svg";
import { ReactComponent as LocalPhoneIcon } from "../../../include/assets/phoneIcon.svg";
import Swal from "sweetalert2";
import SuccessLogo from "../../../include/assets/success.png";
import CancelLogo from "../../../include/assets/cancel.png";
import PdfLogo from "../../../include/assets/samplepdf.png";
import ImageIcon from "../../../include/assets/ImageIcon.png";
import AddIcon from "../../../asset/admin_no_doc.png";
import EyeIcon from "../../../include/assets/eye.png";
import PersonalInput from "../../common/personalInput";
import { sourceTypeFOSDropdown } from "../../common/dropdownValues";
import DownloadNew from "../../../include/assets/download_new_2.0.svg";


let debounce = () => {
    let id
    let debounceTime = 1000
    return (fosApplications, fosDashboard, formData, callbackfosDashboard) => {
        clearTimeout(id)
        id = setTimeout(() => {
            fosApplications(fosDashboard(formData, callbackfosDashboard))
        }, debounceTime)
    }
}

let wrapper = debounce();


const sendDateFormatter = (date) => {
    //30 Mar 2023
    if (date) {
        let year = date.slice(7)
        let monthKeys = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
        let month = monthKeys.filter((month) => months[month] === date.slice(3, 6))
        let day = date.slice(0, 2)
        return `${year}-${month}-${day}`
    }
}

const dateFormatter = (date) => {
    date = new Date(date)
    const fromDay = getFullDay(date.getDate())
    const fromMonth = getMonthName(date.getMonth() + 1)
    const fromYear = date.getFullYear()
    return `${fromDay} ${fromMonth} ${fromYear}`
}

const PersonalLoan = ({ showInsurance, setShowInsurance }) => {
    // const history = useHistory()
    const [login, setLogin] = useState()
    const fosApplications = useDispatch()
    const [pdf, setPdf] = useState(false)
    const [state, setState] = useState({})
    const [dateFilter, setDateFilter] = useState([dateFormatter(new Date().setDate(new Date().getDate() - 7)), dateFormatter(new Date())])
    const [calender, setCalender] = useState(false)
    const [currPage, setCurrPage] = useState(1)
    const [offset, setOffset] = useState(10)
    const [totalPage, setTotalPage] = useState(1)
    const [searchQuery, setSearch] = useState(null);
    const [sourceType, setSourceType] = useState(sourceTypeFOSDropdown[0]);

    const [loginCustomer, setLoginCustomer] = useState("")
    const history = useHistory()
    const loanNameRef = useRef("")
    const [showDetails, setShowDetails] = useState({})
    let [currentStatus, setCurrentStatus] = useState("total");

    ///////////state for opening and closing of modal////////
    const [isOpen, setIsOpen] = useState(false);
    const [isDocOpen, setIsDocOpen] = useState(false);

    const [currentLeadStatus, setCurrentLeadStatus] = useState({});
    const currentDataIdref = useRef(null)


    const LeadStatusDropdown = [{ status: "None", id: null }, ...JSON.parse(localStorage.getItem("leadStatusDropdown")).Personal_loan];


    const callbackfosDashboard = (res) => {
        debugger
        if (res) {
            let searchCount = res?.data?.count

            let listResult = res?.data?.data;

            setState({
                ...state,
                searchCount,
                listResult
            })
            setTotalPage(Math.ceil(searchCount / offset))
        }
    }

    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        if (!localStorage.getItem("isASM")) {
            if (window) {
                window.location.href = (window.location.origin + "/backoffice-login")
            }
        }



        let fromDate = new Date()
        fromDate.setDate(fromDate.getDate() - 7)
        setDateFilter([dateFormatter(fromDate), dateFormatter(new Date())])

        setState({
            ...state,
            pin: localStorage.getItem("pin"),
            city: localStorage.getItem("city"),
            address: localStorage.getItem("ASM_Address")
        })
    }, [])


    useEffect(() => {
        window.scrollTo(0, 0);
        let fos_id = localStorage.getItem("ASM_Id");
        const formData = {
            "role": "FOS_ADMIN",
            "lead_type": "Personal_loan",
            "start_date": sendDateFormatter(dateFilter[0]),
            "end_date": sendDateFormatter(dateFilter[1]),
            "count": offset,
            "page_number": (currPage - 1).toString(),
            "fos_id": fos_id,
            "sources": sourceType.value,
            "isDownloadSheet": false
        }
        if (searchQuery) {
            formData["search_params"] = searchQuery?.toUpperCase();
        }
        fosApplications(fosDashboard(formData, callbackfosDashboard));

    }, [offset, currPage])




    const changeDate = (range) => {
        if (range) {
            const fromDay = getFullDay(range[0].getDate())
            const toDay = getFullDay(range[1].getDate())
            const fromMonth = getMonthName(range[0].getMonth() + 1)
            const toMonth = getMonthName(range[1].getMonth() + 1)
            const fromYear = range[0].getFullYear()
            const toYear = range[1].getFullYear()

            setDateFilter([`${fromDay} ${fromMonth} ${fromYear}`, `${toDay} ${toMonth} ${toYear}`])
        }
    }

    const handleContinue = (data) => {
        setIsDocOpen(true);
        currentDataIdref.current = data
    }

    const handleApply = () => {
        history.push({
            pathname: PATH.PRIVATE.FOS_ADD_CUSTOMER,
            state: { type: "Personal_loan" }
        });
    }


    const handleUpdateLeadStatus = (data) => {
        let leadStatus = LeadStatusDropdown.filter((value, index) => value.id == data['lead_status_id'])
        setCurrentLeadStatus({ value: leadStatus[0].id, label: leadStatus[0].status });
        setIsOpen(true);
        currentDataIdref.current = data
    }


    const closeModalUpdateLeadStatus = () => {
        setIsOpen(false);
    }

    const updateLeadStatus = () => {
        let formData = {
            id: parseInt(currentDataIdref.current.id),
            lead_status_id: currentLeadStatus.value
        }
        fosApplications(updateLeadStatusFOS(formData, callbackUpdateStatus))
    }

    const callbackUpdateStatus = (res) => {
        if (res.data.success) {
            let list = state.listResult;
            let data = list.map((value, index) => {
                if (currentDataIdref.current.id === value.id) {
                    return {
                        ...value,
                        lead_status_id: currentLeadStatus.value,
                        status: currentLeadStatus.label
                    }
                }
                return { ...value }
            })
            setState({ ...state, listResult: data })
            setIsOpen(false);
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res.data.message,
                showConfirmButton: true,
            });
        }
    }

    const closeModalUploadDoc = () => {
        setIsDocOpen(false)
    }

    const viewPdf = (url) => {
        window.open(url, "_blank");
    }


    const uploadDocuments = () => {
        history.push({
            pathname: PATH.PRIVATE.FOS_UPLOAD_DOCS,
            state: { id: currentDataIdref.current.id }
        });
    }


    const handleFilter = (e) => {

        e.preventDefault();

        let fos_id = localStorage.getItem("ASM_Id");
        const formData = {
            "role": "FOS_ADMIN",
            "lead_type": "Personal_loan",
            "start_date": sendDateFormatter(dateFilter[0]),
            "end_date": sendDateFormatter(dateFilter[1]),
            "count": offset,
            "page_number": (currPage - 1).toString(),
            "fos_id": fos_id,
            "sources": sourceType.value,
            "isDownloadSheet": false
        }
        if (searchQuery) {
            formData["search_params"] = searchQuery?.toUpperCase();
        }
        fosApplications(fosDashboard(formData, callbackfosDashboard));

        setCurrPage(1);
    }

    const handleDownload = () => {
        if (parseInt(state.searchCount)) {

            let fos_id = localStorage.getItem("ASM_Id");

            const formData = {
                "role": "FOS_ADMIN",
                "lead_type": "Personal_loan",
                "start_date": sendDateFormatter(dateFilter[0]),
                "end_date": sendDateFormatter(dateFilter[1]),
                "count": offset,
                "page_number": (currPage - 1).toString(),
                "sources": "FOS_CALL",
                "fos_id": fos_id,

                "sources": sourceType.value,
                "isDownloadSheet": true
            }
            if (searchQuery) {
                formData["search_params"] = searchQuery?.toUpperCase();
            }

            fosApplications(fosDashboard(formData, callBackDownload))
        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "No data to download",
                showConfirmButton: true,
            });
        }
    }


    const callBackDownload = (res) => {
        if (res) {
            var iframe = document.createElement("iframe");
            iframe.id = "1";
            iframe.style.display = "none";
            document.body.appendChild(iframe);
            iframe.src = res.data.data;
        }
    }

    return <>

        {useSelector(state => (state.entities.asm.asmLoading || state.entities.account.loading || state.entities.asm.loadingUpdateLeadStatusFOS)) ? < BackDropComponent /> : null}

        <section className="bs-main-section asmDashboard asm" >
            <FOSNavBar
                pin={state.pin}
                address={state?.address}
                city={state.city}
                pinError={state.pinError}
                geoError={state.geoError}
                handleAddCustomer={handleApply}
            />

            <Container>
                <Row>
                    <div className="col-sm-8">
                        <p className="font-weight-bolder">Welcome !<span className="ml-1" style={{ fontWeight: 'bold' }}> {` ${localStorage.getItem("ASM_firstName")}`}</span></p>
                    </div>



                    <div className="col-sm-12 mt-3">  <form onSubmit={handleFilter}><div className="row align-items-center">

                        <div className="col-3">
                            {calender ? <div>
                                <DateRangePicker calendarIcon={<img src={CalenderIcon} />} clearIcon={<img src={ArrowDown} />} onCalendarClose={() => setCalender(false)} isOpen={calender} id="dateSelector" returnValue="range" value={dateFilter} onChange={changeDate} maxDate={new Date()} />
                            </div> :
                                <div onClick={() => setCalender(true)}><img className="calenderIcon" src={CalenderIcon} /><p className="calenderDate">{`${dateFilter[0]} - ${dateFilter[1]}`}</p><img src={ArrowDown} className="calenderClearIcon" /></div>}
                        </div>

                        <div className="col-3">
                            <SelectSearch
                                icon={
                                    <LoanAmountIcon
                                        style={{ marginRight: "3px", marginTop: "2px" }}
                                    />
                                }
                                placeholderValue={"Select Source"}
                                label={"Select Source"}
                                value={sourceType}
                                setSelectedOption={(e) => {
                                    setSourceType(e);
                                }}
                                dropDownOptions={sourceTypeFOSDropdown}
                            ></SelectSearch>
                        </div>

                        <div className="col-4">
                            <PersonalInput
                                value={searchQuery}
                                __handleChange={(e) => setSearch(e.target.value)}
                                icon={<LocalPhoneIcon />}
                                label="Search"
                            />

                        </div>
                        <div className="col-2">
                            <button
                                type="submit"
                                variant="contained"
                                className="nextButton"
                                style={{ maxWidth: "140px", cursor: "pointer" }}
                            >
                                Filter
                            </button>

                        </div>

                    </div>
                    </form>
                    </div>

                    <div><div className="row">
                        <p className="font-weight-bolder mt-4">
                            <ul class="nav nav-tabs">
                                <li class="nav-item">
                                    <a class={`nav-link active }`} ria-current="page"
                                        onClick={
                                            () => {
                                                localStorage.setItem("FOS_Flow_For", "personal loan")
                                                setShowInsurance("personal loan")
                                            }
                                        }
                                    >Personal Loan</a>
                                </li>
                                <li class="nav-item">
                                    <a class={`nav-link backBtnICICI`} ria-current="page"
                                        onClick={() => {
                                            localStorage.setItem("FOS_Flow_For", "credit card")
                                            setShowInsurance("credit card")
                                        }
                                        }
                                    >Credit Card</a>
                                </li>
                            </ul>
                        </p>
                    </div></div>


                    <div className="col-sm-12"><p className="font-weight-bolder mt-4">Personal Loans Status<span className="font-weight-bold ml-1">List</span></p></div>


                    <div class="container mt-1">
                        <div className="col-12 mt-3 pt-2 pb-4 asmDashoardShadow">
                            <div className="row">

                                <div className="col-md-11 order-xs-2 order-md-1 col-sm-6 d-flex pt-4">
                                    {parseInt(state.searchCount) ? <>   <p className="font-weight-bolder asm">Show</p><div style={{ marginTop: "-6px", marginLeft: "15px" }}>
                                        <ShowEntries totalApplication={state.searchCount} offset={state?.searchCount < 10 ? state.searchCount : offset} setOffset={setOffset} setCurrPage={setCurrPage} />
                                    </div>
                                    </> : ""}
                                    {parseInt(state.searchCount) ? <p className="font-weight-bolder ml-2">Entries</p> : ""}
                                </div>
                                <div className="col-md-1 order-xs-1 order-md-3 col-sm-6 d-flex pt-4"><a
                                    href={"javascript:void(0)"}
                                    onClick={handleDownload}
                                >
                                    <img src={DownloadNew}
                                    />
                                </a>
                                </div>
                            </div>
                            <div style={{ overflow: "auto" }}>
                                <Table className="asmLoansTable striped">
                                    <thead>
                                        <tr>
                                            <th>Source</th>
                                            <th>Representative</th>
                                            <th>City</th>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>PAN No.</th>
                                            <th>Gender</th>
                                            <th>Email</th>
                                            <th>Mobile No.</th>
                                            <th>Mobile Verification</th>
                                            <th>Interested</th>
                                            <th>Required Loan Amount</th>
                                            <th>Lead Status</th>
                                            <th>Documents uploaded</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {state?.listResult?.map((data, index) => (

                                            <tr >

                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['submitted_role'] ? data['submitted_role'] : "N/A"}</p>
                                                </td>

                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['fos_name'] ? data['fos_name'] : 'N/A'}</p>
                                                </td>

                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['city__c'] ? data['city__c'] : 'N/A'}</p>
                                                </td>

                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['created_date'] ? dateFormatter(new Date(data['created_date'])) : 'N/A'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['customer_name'] ?? 'N/A'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['pan_no'] ?? 'N/A'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['gender'] ?? 'N/A'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['customer_email'] ?? '-'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['mobile_no'] ?? '-'}</p>
                                                </td>
                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['mobile_verification'] === "true" ? "Verified" : "Not Verified"}</p>
                                                </td>

                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['intrested'] ? data['intrested'] === "true" ? 'Yes' : 'No' : 'N/A'}</p>
                                                </td>

                                                <td align="left">
                                                    <p className="font-weight-bolder">{data['required_loan_amount'] ? "₹" + new Intl.NumberFormat('en-IN').format(data['required_loan_amount']) : 'N/A'}</p>
                                                </td>

                                                <td align="left" className="d-flex  align-items-center">
                                                    {data['status'] ? data['status'] : "N/A"}
                                                    <div style={{ cursor: "pointer" }} onClick={() => handleUpdateLeadStatus(data)}>
                                                        <img style={{ cursor: "pointer", height: '18px', width: '18px' }} className="ml-4 " src={editIcon} />
                                                    </div>
                                                </td>

                                                <td align="left">
                                                    <div className="d-flex g-2">
                                                        {<div style={{ cursor: "pointer" }} onClick={() => handleContinue(data)}>
                                                            <img style={{ cursor: "pointer", height: '15px', width: '20px' }} className="ml-4 " src={EyeIcon} />
                                                        </div>}

                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>
                            </div>
                            <div className="row mt-2">
                                {parseInt(state.searchCount) ? <p className="asmFontSmall col-md-6 col-xs-12">{`Showing ${(offset * (currPage - 1)) + 1} to ${state.searchCount < (offset * currPage) ? state.searchCount : offset * currPage} of ${state.searchCount} entries`}</p> : <p className="asmFontSmall col-md-12 col-xs-12 text-center">No entries found</p>}
                                <div className="col-md-6 col-xs-12 d-flex" style={{ flexDirection: 'row-reverse' }}>
                                    {totalPage > 1 ? <Paging pages={totalPage} currPage={currPage} setCurrPage={setCurrPage} /> : null}
                                </div>
                            </div>
                        </div>
                    </div>
                </Row>

                <Modal
                    className="ReferFriendModal AaModal"
                    show={isOpen}
                    onHide={closeModalUpdateLeadStatus}
                    closeButton={true}
                >
                    <Modal.Body className="text-center">
                        <section className="bs-main-section">

                            <div
                                className="row insideFormBlock"
                                style={{ paddingLeft: "30px", paddingRight: "30px" }}
                            >
                                <div className="col-sm-12">
                                    <form className="panVeryfyForm">
                                        <p className="title">Update Customer's Lead Status</p>
                                        <div className="panFormFields">
                                            <div className="row">
                                                <div className="col-sm-12">
                                                    <SelectSearch
                                                        icon={
                                                            <LoanAmountIcon
                                                                style={{ marginRight: "3px", marginTop: "2px" }}
                                                            />
                                                        }
                                                        placeholderValue={"Select Lead Status"}
                                                        label={"Lead Status"}
                                                        value={currentLeadStatus}
                                                        setSelectedOption={(e) => {
                                                            setCurrentLeadStatus(e);
                                                        }}
                                                        dropDownOptions={LeadStatusDropdown.map((item) => ({ label: item.status, value: item.id }))}
                                                    ></SelectSearch>
                                                </div>

                                                <div className="col-sm-12 text-center">
                                                    <button
                                                        type="button"
                                                        onClick={updateLeadStatus}
                                                        variant="contained"
                                                        className="nextButton"
                                                    >
                                                        Update Status
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </section>
                    </Modal.Body>
                </Modal>



                <Modal
                    className="ReferFriendModal AaModal"
                    show={isDocOpen}
                    onHide={closeModalUploadDoc}
                    closeButton={true}
                >
                    <Modal.Body className="text-center">
                        <div className="row p-3">
                            <div className="col-12">
                                <h6>Review Documents</h6>
                            </div>
                            <div className="col-12 mt-3 d-flex justify-content-between">
                                <span>KYC <strong>(PAN)</strong></span>
                                <span>
                                    <img
                                        src={currentDataIdref?.current?.kyc_pan ? SuccessLogo : CancelLogo} alt=""
                                        style={{ height: "20px", width: "20px" }} />
                                </span>
                                <span>
                                    {currentDataIdref?.current?.kyc_pan ?
                                        <img src={PdfLogo} alt=""
                                            onClick={(e) => viewPdf(currentDataIdref.current.kyc_pan)}
                                            style={{ height: "30px", width: "30px", cursor: "pointer" }}
                                        />
                                        : <img src={AddIcon} alt=""
                                            style={{ height: "35px", width: "35px", cursor: "not-allowed" }}
                                        />}
                                </span>
                            </div>
                            <div className="col-12 mt-3 d-flex justify-content-between">
                                <span>KYC <strong>(Photo)</strong></span>
                                <span style={{ marginLeft: "-15px" }}>
                                    <img
                                        src={currentDataIdref?.current?.kyc_photo ? SuccessLogo : CancelLogo} alt=""
                                        style={{ height: "20px", width: "20px" }} />
                                </span>
                                <span style={{ marginLeft: "-5px" }}>
                                    {currentDataIdref?.current?.kyc_photo ?
                                        <img src={ImageIcon} alt=""
                                            onClick={(e) => viewPdf(currentDataIdref.current.kyc_photo)}
                                            style={{ height: "30px", width: "30px", cursor: "pointer" }}
                                        />
                                        : <img src={AddIcon} alt=""
                                            style={{ height: "35px", width: "35px", cursor: "not-allowed" }}
                                        />}
                                </span>
                            </div>
                            <div className="col-12 mt-3 d-flex justify-content-between">
                                <span>KYC <strong>(Aadhaar)</strong></span>
                                <span style={{ marginLeft: "-28px" }}>
                                    <img
                                        src={currentDataIdref?.current?.kyc_aadhar ? SuccessLogo : CancelLogo} alt=""
                                        style={{ height: "20px", width: "20px" }} />
                                </span>
                                <span>
                                    {currentDataIdref?.current?.kyc_aadhar ?
                                        <img src={PdfLogo} alt=""
                                            onClick={(e) => viewPdf(currentDataIdref.current.kyc_aadhar)}
                                            style={{ height: "30px", width: "30px", cursor: "pointer" }}
                                        />
                                        : <img src={AddIcon} alt=""
                                            style={{ height: "35px", width: "35px", cursor: "not-allowed" }}

                                        />}
                                </span>
                            </div>
                            <div className="col-12 mt-3 d-flex justify-content-between">
                                <span>Banking Documents</span>
                                <span style={{ marginLeft: "-70px" }}>
                                    <img
                                        src={currentDataIdref?.current?.bank_document ? SuccessLogo : CancelLogo} alt=""
                                        style={{ height: "20px", width: "20px" }} />
                                </span>
                                <span>
                                    {currentDataIdref?.current?.bank_document ?
                                        <img src={PdfLogo} alt=""
                                            onClick={(e) => viewPdf(currentDataIdref.current.bank_document)}
                                            style={{ height: "30px", width: "30px", cursor: "pointer" }}
                                        />
                                        : <img src={AddIcon} alt=""
                                            style={{ height: "35px", width: "35px", cursor: "not-allowed" }}

                                        />}
                                </span>
                            </div>

                            <div className="col-12 mt-3 d-flex justify-content-between">
                                <span>Income Documents</span>

                                <span style={{ marginLeft: "10px" }}>
                                    <img
                                        src={(currentDataIdref?.current?.income_ss1 || currentDataIdref?.current?.income_ss2 || currentDataIdref?.current?.income_ss3) ? SuccessLogo : CancelLogo} alt=""
                                        style={{ height: "20px", width: "20px" }}
                                    />
                                </span>


                                <div style={{ display: "flex" }}>

                                    {[
                                        currentDataIdref?.current?.income_ss1,
                                        currentDataIdref?.current?.income_ss2,
                                        currentDataIdref?.current?.income_ss3
                                    ].map((value, index) => {
                                        return <span style={{ marginRight: index != 2 ? "4px" : "0px" }}>

                                            {value ? <img src={PdfLogo} alt=""
                                                onClick={(e) => viewPdf(value)}
                                                style={{ height: "30px", width: "30px", cursor: "pointer" }}
                                            />
                                                :
                                                <img src={AddIcon} alt=""
                                                    style={{ height: "35px", width: "35px", cursor: "not-allowed" }}
                                                />}

                                        </span>
                                    })
                                    }
                                </div>
                            </div>

                            <div className="col-12 mt-3 d-flex justify-content-between">
                                <span>Other Documents</span>
                                <span style={{ marginLeft: "-55px" }}>
                                    <img
                                        src={currentDataIdref?.current?.other_documents ? SuccessLogo : CancelLogo} alt=""
                                        style={{ height: "20px", width: "20px" }}
                                    />
                                </span>
                                <span>
                                    {currentDataIdref?.current?.other_documents ?
                                        <img src={PdfLogo} alt=""
                                            onClick={(e) => viewPdf(currentDataIdref.current.other_documents)}
                                            style={{ height: "30px", width: "30px", cursor: "pointer" }}
                                        />
                                        :
                                        <img src={AddIcon} alt=""
                                            style={{ height: "35px", width: "35px", cursor: "not-allowed" }}
                                        />}
                                </span>
                            </div>
                            <div className="col-12 mt-3">
                                <div className="mb-3"><b>Remarks:</b></div>
                                <div>
                                    {
                                        currentDataIdref?.current?.remarks ? currentDataIdref?.current?.remarks : "N/A"
                                    }
                                </div>

                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
                <CreditFooter />
            </Container >
        </section >
    </>
}

export default PersonalLoan