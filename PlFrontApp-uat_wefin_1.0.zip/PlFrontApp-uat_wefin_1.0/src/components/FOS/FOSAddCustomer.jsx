import React from "react";
import { ReactComponent as PersonIcon } from "../../include/assets/Profile.svg";
import { ReactComponent as LocalPhoneIcon } from "../../include/assets/phoneIcon.svg";
import { ReactComponent as LoanAmountIcon } from "../../include/assets/personalLoan/loanAm.svg";
import { ReactComponent as EmailIcon } from "../../include/assets/emailIcon.svg";
// import USER_ICON from "../../include/assets/1/smartphone@2x.png";
import BackDropComponent from "../../common/BackDropComponent";
import LeftMenuDecider from "../../common/leftMenuContent";
import { ReactComponent as CardMembershipIcon } from "../../include/assets/panIcon.svg";
// import Back from "../../components/common/back";
import Joi from "joi-browser";
import Gender from "../common/gender";
import Form from "../common/form";
import DateComponent from "../common/date";
import Pincode from "../common/pincode";
import PersonalInput from "../common/personalInput";
import { withRouter } from "react-router";
import { Container, Row, Col } from "react-bootstrap";
import {

    getpanName,
    loadPanName,
    panVerification,
    loadCheckDedupe,
} from "../../store/panName";
import {
    credit_marital_status,
} from "../common/fullerTonDropdown";
import { connect } from "react-redux";
import { getpinCode, loadPinCode } from "../../store/pincode";
import Swal from "sweetalert2";
import { decryptStore } from "../../Utils/store";
import Moment from "moment";
import {
    getAccount,
    setAccountInfo,
    getAccountInfo,
} from "../../store/account";
import { getExperian, loadExperianCheck } from "../../store/experian";
import OTPModal from "../HomeProducts/OTPModal";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import SelectSearch from "../common/select";
import { ReactComponent as Marriage } from "../../include/assets/personalLoan/marriage.svg";
import {
    myprofile_marital_status,
} from "../common/fullerTonDropdown";
import mapGender from "../common/mapGender"
import { dropdown_gender_values } from "../common/dropdownValues";
import cardRedirection from "../creditCard/cardRedirection";
import { fosAddCustomer, getASM, loadLeadStatus } from "../../store/asm";
import OtpForm from "./OtpForm";
import TopNavBar from "./FOSNavBar";
import PersonalAmountInput from "../common/personalAmountInput";
import { ReactComponent as Money } from "../../include/assets/money.svg";
class FOSAddCustomer extends Form {
    constructor(props) {
        super(props);
        ////by default male is selected///////
        this.state = {
            data: {
                gender: '1',
                mobile: "",
                email: "",
                amount: "",
                credit_card_required: "",
                pan: "",
                lead_status: { label: "None", value: "" },
                pinCode: ""
            },
            errors: {},
            terms: true,
            stgOneHitId: "",
            stgTwoHitId: "",
            openOtp: false,
            btnIsActive: true,
            loader: false,
        };
        this.idRef = React.createRef(null);
    }

    schema = {
        pinCode: (this.props.location.state.lead_type === "Credit_card" && localStorage.getItem("role") === "FOS_CALL")
            ? Joi.string()
                .required()
                .min(6)
                .label("Pin Code")
                .error((errors) => {
                    errors.forEach((err) => {
                        switch (err.type) {
                            case "string.min":
                                err.message = this.state.data.pinCode.length ? "Pincode must be 6 digits" : "Pincode is required.";
                                break;
                        }
                    });
                    return errors;
                }) :
            Joi.string().allow(""),
        amount: Joi.string().allow(""),
        gender: Joi
            .string()
            .required()
            .label("Gender")
            .error(() => {
                return { message: "Gender field is required." };
            }),
        fullName: Joi.string()
            .required()
            .label("Full Name")
            .error(() => {
                return { message: "Full Name field is required." };
            }),
        pan: Joi.string()
            .required()
            .min(10)
            .max(10)
            .label("PAN Number")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "string.min":
                            err.message = "PAN Number must be 10 digits";
                            break;
                        case "string.max":
                            err.message = "PAN Number must be 10 digits";
                            break;
                    }
                });
                return errors;
            }).allow(""),
        email: Joi.string()
            .email()
            .max(50)
            .label("Email")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "any.empty":
                            err.message = "Email field is required";
                            break;
                        case "string.email":
                            err.message = "Email format is incorrect";
                            break;
                        case "string.max":
                            err.message = "Email must not exceeds 50 characters.";
                            break;
                        default:
                            err.message = "Email field is invalid";
                    }
                });
                return errors;
            }).allow(""),
        mobile: Joi.string()
            .required()
            .min(10)
            .max(10)
            .label("Mobile Number")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "any.empty":
                            err.message = "Mobile Number is required";
                            break;
                        case "string.min":
                            err.message = "Mobile Number must be 10 digits";
                            break;
                        case "string.max":
                            err.message = "Mobile Number must be 10 digits";
                            break;
                    }
                });
                return errors;
            }),
        lead_status: Joi.object()
            .required()
            .error(() => {
                return { message: "Lead status is required" };
            }),
        credit_card_required: Joi.string().allow("")
    };





    componentDidUpdate = () => {
        if (this.state.data.email === "null" || this.state.data.email === "undefined") {
            this.setState({ ...this.state, data: { ...this.state.data, email: "" } })
        }
    }

    doSubmit = () => {
        if (this.props.location.state.lead_type === "Personal_loan" && parseInt(this.state.data.amount) === 0) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: "Please enter a valid Loan Amount",
                showConfirmButton: true,
            });
            return;
        }

        try {
            let fos_id = localStorage.getItem("ASM_Id");
            let formData =
            {
                mobile_no: this.state.data.mobile,
                customer_name: this.state.data.fullName.trim(),
                pan_no: this.state.data.pan,
                customer_email: this.state.data.email.trim(),
                lead_type: this.props.location.state.lead_type,
                lead_status_id: this.state.data.lead_status.value,
                fos_id: fos_id,
                gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.state.data.gender.toLowerCase())[0].label,
                pincode: this.state.data.pinCode ? this.state.data.pinCode : ""
            };

            if (this.props.location.state.lead_type === "Personal_loan") {
                formData['required_loan_amount'] = this.state.data.amount
            } else {
                formData['required_credit_card'] = this.state.data.credit_card_required
            }
            if (this.props.location?.state?.data) {
                formData['isEdit'] = true
            }

            this.props.fosAddCustomer(formData, this.callbackAddCustomer);
        } catch (e) {
            this.setState({ loader: false });
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
            });
        }
    };
    __handlePANChange = (e) => {

        let panNumber = e.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();

        if (e.target.value.length <= 10) {
            this.setState((p) => ({
                ...p,
                data: {
                    ...p.data,
                    pan: panNumber
                },
                errors: { ...p.errors, pan: "" },
            }));
            if (e.target.value.length === 10) {
                ///////////////validate PAN///////////
            }
        }
    };
    callBackDedeupe = async (res) => {
        try {
            let r = await res;
            if (!r.data.isDuplicate && !r.data.isFinnOneDuplicate) {

                let mobile = this.state.data.mobile;
                let formData = {
                    mobile: mobile,
                    pan: this.state.data.pan,
                };
                this.props.loadPanName(formData, this.callback);
            } else {
                throw r.data.message.toString();
            }
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
                timer: 18000,
            });
        }
    };
    callback = async (res) => {
        try {
            let r = await res;
            if (r.data) {
                if (r.data.success) {
                    let data = r.data
                    localStorage.setItem("fullName", data.name);
                    localStorage.setItem("firstName", data.firstname);
                    localStorage.setItem("lastName", data.lastName);
                    localStorage.setItem("pan", this.state.data.pan);

                    this.setState((p) => ({
                        ...p,
                        data: {
                            ...p.data,
                            fullName: data.name,
                        },
                        errors: {
                            ...p.errors,
                            pan: "",
                            fullName: "",
                        },
                    }));
                } else {
                    this.setState(({ errors }) => ({
                        errors: {
                            ...errors,
                            pan: r.data.message,
                        },
                    }));
                }
            } else {
                throw r.data.message.toString();
            }
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };

    callbackAddCustomer = async (res) => {
        try {
            let r = await res;
            if (r.data) {
                if (r.data.success) {
                    let data = r.data;
                    this.idRef.current = data.data[0].id;

                    let role = localStorage.getItem("role");


                    if (role === "FOS_CALL" && this.props.location?.state?.data && this.props.location?.state?.data?.mobile_verification == "true" && this.props.location.state.lead_type === "Credit_card") {
                        this.props.history.push({
                            pathname: PATH.PUBLIC.GET_CREDIT_CARD, state: {
                                id: this.props.location.state.data.id,
                                isFOS: true,
                                mobile_no: this.state.data.mobile
                            }
                        });
                    }
                    else if (this.props.location?.state?.data?.mobile_verification == "true") {

                        localStorage.setItem("isMountedOnlyOnce", true);

                        this.props.history.push({
                            pathname: PATH.PRIVATE.FOS_UPLOAD_DOCS,
                            state: {
                                id: this.props.location.state.id,
                                data: this.props.location.state.data,
                                lead_type: this.props.location.state.lead_type
                            }
                        });
                    }
                    else {
                        this.setState((p) => ({
                            ...p,
                            data: {
                                ...p.data,
                            },
                            errors: {
                                ...p.errors,
                            },
                            openOtp: true
                        }));
                    }
                } else {
                    this.setState(({ errors }) => ({
                        errors: {
                            ...errors,
                        },
                    }));
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: res.data.message,
                        showConfirmButton: true,
                        confirmButtonColor: "rgb(76,175,80)",
                    }).then((res) => {
                        if (res.isConfirmed) {
                            this.props.history.push({
                                pathname: PATH.PRIVATE.FOS_DASHBOARD,
                            })
                        }
                    });
                }
            } else {
                throw r.data.message.toString();
            }
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: true,
                timer: 1800,
            });
        }
    };


    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");

        let data = { ...this.state.data };
        if (this.props.location?.state?.data?.pincode) {
            data['pinCode'] = this.props.location.state.data.pincode
        }
        if (this.props.location?.state?.data?.required_loan_amount) {
            data['amount'] = this.props.location.state.data.required_loan_amount
        }
        if (this.props.location?.state?.data?.gender) {
            data['gender'] = this.props.location.state.data.gender == "Male" ? "1" : this.props.location.state.data.gender == "Female" ? "2" : "3"
        }
        if (this.props.location?.state?.data?.customer_name) {
            data['fullName'] = this.props.location.state.data.customer_name
        }
        if (this.props.location?.state?.data?.pan_no) {
            data['pan'] = this.props.location.state.data.pan_no
        }
        if (this.props.location?.state?.data?.customer_email) {
            data['email'] = this.props.location.state.data.customer_email
        }
        if (this.props.location?.state?.data?.mobile_no) {
            data['mobile'] = this.props.location.state.data.mobile_no
        }
        if (this.props.location?.state?.data?.status) {
            let leadStatusDropdown = [{ status: "None", id: "" }, ...JSON.parse(localStorage.getItem("leadStatusDropdown"))[this.props.location.state.lead_type === "Personal_loan" ? 'Personal_loan' : 'Credit_card']].map((item) => ({
                label: item.status,
                value: item.id,
            }))
            data['lead_status'] = leadStatusDropdown.filter((data, index) => {
                return data.value == this.props.location.state.data.lead_status_id;
            })[0]
        }


        if (this.props.location?.state?.data?.required_credit_card) {
            data['credit_card_required'] = this.props.location.state.data.required_credit_card
        }

        this.setState({ data: data })
    };

    onDateChange = async (e) => {
        let d = await e.target.value;
        this.setState(({ data }) => ({
            data: {
                ...data,
                dob: d,
            },
        }));
        if (!this.state.data.dob.includes("_")) {
            if (Moment(this.state.data.dob, "DD-MM-YYYY", true).isValid()) {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "" },
                    btnIsActive: true,
                }));
            } else {
                this.setState(({ errors }) => ({
                    errors: { ...errors, dob: "Date of Birth field is invalid." },
                    btnIsActive: false,
                }));
            }
        } else {
            this.setState({ btnIsActive: false });
        }
    };

    handleCheckBoxChange = () => {
        this.setState({
            terms: !this.state.terms,
        });
    };

    __handlePinCode = (e) => {
        e.preventDefault();
        let mobile = localStorage.getItem("mobilenumber");
        if (e.target.value.length === 6) {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            this.setState({ data });
            let formData = { mobile: mobile, pincode: e.target.value };
            this.props.loadPinCode(formData, this.callbackPin);
        }
    };

    callbackPin = (res) => {
        if (res) {
            let errors = { ...this.state.errors };
            if (res.data.success === false) {
                errors.pincode = res.data.message;
                this.setState({ errors });
            } else if (res.data.success === true) {
                errors.pincode = "";
                this.setState({ errors });
            }
        }
    };

    onChangeGender = (e) => {
        if (e) {
            console.log(e.target.value)
            this.setState({ ...this.state, data: { ...this.state.data, gender: e.target.value } });
        }
    };

    closeOTPModal = () => {
        this.setState({
            openOtp: false
        });
    };


    _handleChange = (key, e) => {
        let data = {};
        switch (key) {
            case "pan":
                let pan = e.target.value.toUpperCase();
                if (pan.length <= 10) {
                    data = { ...this.state.data };
                    data.pan = pan.replace(/[^a-zA-Z0-9]/g, '');
                    this.setState({ data });
                }
                break;
            case "pinCode":
                const pinCode = e.target.value;
                if (pinCode.length <= 6) {
                    data = { ...this.state.data };
                    data.pinCode = pinCode.replace(/\D/g, '');
                    this.setState({ data });
                }
                break;
            case "fullName":
                const fullName = e.target.value;
                data = { ...this.state.data };
                data.fullName = fullName.replace(/[^a-zA-Z\s]+/, '');
                this.setState({ data });
                break;
            case "email":
                const email = e.target.value;
                data = { ...this.state.data };
                data.email = email;
                this.setState({ data });
                break;
            case 'amount':
                const amount = e.target.value;
                data = { ...this.state.data };
                data.amount = amount.replace(/\D+/g, "");
                this.setState({ data });
                break;
            case "mobile":
                const mobile = e.target.value;
                if (mobile.length <= 10) {
                    data = { ...this.state.data };
                    data.mobile = mobile.replace(/\D/g, '');
                    this.setState({ data });
                }
                break;
            case "credit_card_required":
                const credit_card_required = e.target.value;
                data = { ...this.state.data };
                data.credit_card_required = credit_card_required;
                this.setState({ data });
                break;
        }

        e.preventDefault();
    }

    render() {
        const { loading, loadingVerify, loadingCheck } = this.props.getpanName;
        const leadStatus = this.props.leadStatus
        return (
            <>
                {<TopNavBar />}
                <section className="bs-main-section">
                    <Container>
                        <Row>
                            <Col sm={12} md={12}>
                                {this.props.loadingCheck ||
                                    loading ||
                                    loadingVerify ||
                                    loadingCheck ||
                                    this.props.loading ||
                                    this.props.asmLoading ||
                                    this.state.loader ? (
                                    <BackDropComponent />
                                ) : (
                                    ""
                                )}
                                <div className="row">
                                    <div className="col-sm-12 text-center">
                                        <div className="bsFormHeader">

                                        </div>
                                    </div>
                                </div>
                                <div
                                    className="row insideFormBlock"
                                    style={{ marginBottom: "30px" }}
                                >
                                    <div className="col-sm-12">
                                        <form className="panVeryfyForm">
                                            <p className="title">Enter Customer's Personal Details</p>
                                            <div className="panFormFields">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <PersonalInput
                                                            value={this.state.data.mobile}
                                                            __handleChange={(e) => this._handleChange('mobile', e)}
                                                            error={this.state.errors.mobile}
                                                            icon={<LocalPhoneIcon />}
                                                            label="Mobile Number"
                                                            readOnly={this.props.location?.state?.data?.mobile_no ? true : false}
                                                        />

                                                    </div>
                                                    <div className="col-sm-6">

                                                        <PersonalInput
                                                            value={this.state.data.pan}
                                                            __handleChange={(e) => this._handleChange('pan', e)}
                                                            error={this.state.errors.pan}
                                                            icon={<CardMembershipIcon />}
                                                            label="PAN Number"
                                                            required={false}
                                                        />
                                                    </div>

                                                    <div className="col-sm-6">

                                                        <PersonalInput
                                                            value={this.state.data.fullName}
                                                            __handleChange={(e) => this._handleChange('fullName', e)}
                                                            error={this.state.errors.fullName}
                                                            icon={<PersonIcon />}
                                                            label="Name"
                                                        />
                                                    </div>

                                                    {this.props.location.state.lead_type === "Credit_card" && localStorage.getItem("role") === "FOS_CALL" ? <div className="col-sm-6">

                                                        <PersonalInput
                                                            value={this.state.data.pinCode}
                                                            __handleChange={(e) => this._handleChange('pinCode', e)}
                                                            error={this.state.errors.pinCode}
                                                            icon={<PersonIcon />}
                                                            label="Pincode"
                                                        />

                                                    </div> : ""}
                                                    <div className="col-sm-6">

                                                        <PersonalInput
                                                            value={this.state.data.email}
                                                            __handleChange={(e) => this._handleChange('email', e)}
                                                            error={this.state.errors.email}
                                                            icon={<EmailIcon />}
                                                            label="Email"
                                                            required={false}
                                                        />
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <Gender
                                                            onChangeGender={this.onChangeGender}
                                                            value={this.state?.data?.gender}
                                                            error={this.state.errors.gender}
                                                        />
                                                    </div>

                                                    {this.props.location.state.lead_type === "Personal_loan" ? <div className="col-sm-6">
                                                        <PersonalAmountInput
                                                            value={this.state.data.amount}
                                                            __handleChange={(e) => this._handleChange('amount', e)}
                                                            error={this.state.errors.amount}
                                                            icon={<Money />}
                                                            label="Required Loan Amount"
                                                            required={false}
                                                        />
                                                    </div> : ""}

                                                    {this.props.location.state.lead_type === "Credit_card" && localStorage.getItem("role") === "FOS" ? <div className="col-sm-6">
                                                        <PersonalInput
                                                            value={this.state.data.credit_card_required}
                                                            __handleChange={(e) => this._handleChange('credit_card_required', e)}
                                                            error={this.state.errors.credit_card_required}
                                                            icon={<LocalPhoneIcon />}
                                                            label="Credit Card Required"
                                                            required={false}
                                                        />
                                                    </div> : ""}

                                                    <div className="col-sm-6">
                                                        <SelectSearch
                                                            icon={
                                                                <LoanAmountIcon
                                                                    style={{ marginRight: "3px", marginTop: "2px" }}
                                                                />
                                                            }
                                                            placeholderValue={"Select Lead Status"}
                                                            label={"Lead Status"}
                                                            value={this.state?.data?.lead_status}
                                                            setSelectedOption={(e) => {
                                                                const data = { ...this.state.data };
                                                                const errors = { ...this.state.errors };
                                                                if (e) {
                                                                    data.lead_status = e;
                                                                    errors.lead_status = "";
                                                                    this.setState({ data, errors });
                                                                }
                                                            }}
                                                            dropDownOptions={[{ status: "None", id: "" }, ...JSON.parse(localStorage.getItem("leadStatusDropdown"))[this.props.location.state.lead_type === "Personal_loan" ? 'Personal_loan' : 'Credit_card']].map((item) => ({
                                                                label: item.status,
                                                                value: item.id,
                                                            }))}
                                                            error={this.state?.errors?.lead_status}
                                                            required={false}
                                                        ></SelectSearch>
                                                    </div>
                                                    <div className="col-sm-12 text-center">
                                                        {this.state.terms === true &&
                                                            this.state.btnIsActive ? (
                                                            <button
                                                                type="submit"
                                                                onClick={this.handleSubmit}
                                                                variant="contained"
                                                                className="nextButton"
                                                            >
                                                                Next
                                                            </button>
                                                        ) : (
                                                            <button
                                                                type="submit"
                                                                onClick={this.handleSubmit}
                                                                variant="contained"
                                                                className="nextButton"
                                                                disabled
                                                                style={{
                                                                    opacity: "0.5",
                                                                    cursor: "not-allowed",
                                                                }}
                                                            >
                                                                Next
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>


                                        </form>
                                    </div>
                                </div>

                            </Col>

                        </Row>

                    </Container >


                </section >
                {
                    this.state.openOtp === true ? (
                        <OtpForm
                            show={this.state.openOtp}
                            data={this.state.data}
                            setData={this.setState}
                            handleCloseOTP={this.closeOTPModal}
                            lead_type={this.props.location.state.lead_type}
                            id={this.idRef.current}
                            edit_data={this.props.location?.state?.data}
                        />
                    ) : ""
                }
            </>
        );
    }
}
function reverseDateString(str) {
    var splitString = str.split("-");
    var reverseArray = splitString.reverse();
    var joinArray = reverseArray.join("-");
    joinArray = joinArray + "T00:00:00.000Z";
    return joinArray;
}
const mapStateToProps = (state) => ({
    leadStatus: getASM(state).leadStatus,
    asmLoading: getASM(state).asmLoading,
    getpanName: getpanName(state),
    getpinCode: getpinCode(state),
    getAccount: getAccount(state),
    panVerify: getpanName(state).panVerify,
    checkDedupe: getpanName(state).checkDedupe,
    experian: getExperian(state),
    loadingCheck: getExperian(state).loadingCheck,
    getCustomerDetail: getAccount(state).customerDetail,
    loading: getpinCode(state).loading
});

const mapDispatchToProps = (dispatch) => ({
    fosAddCustomer: (params, callback) => dispatch(fosAddCustomer(params, callback)),
    loadLeadStatus: (params, callback) => dispatch(loadLeadStatus(params, callback)),
    loadPanName: (params, callback) => dispatch(loadPanName(params, callback)),
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
    setAccountInfo: (params, callback) =>
        dispatch(setAccountInfo(params, callback)),
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    panVerification: (params, callback) =>
        dispatch(panVerification(params, callback)),
    loadCheckDedupe: (params, callback) =>
        dispatch(loadCheckDedupe(params, callback)),
    loadExperianCheck: (params, callback) =>
        dispatch(loadExperianCheck(params, callback)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(FOSAddCustomer)
);
