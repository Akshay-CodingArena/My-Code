import React, { Component } from "react";
import Swal from "sweetalert2";
import SecureLS from "secure-ls";
import { cleanObject } from "../../common/helperCells";
import LogoutIcon from "../../include/assets/logoutIcon.svg";
import UserIcon from "../../include/assets/icons/user.svg";
import LoanIcon from "../../include/assets/myloanIcon.svg";
import MyProfileIcon from "../../include/assets/myProfile.svg";
import CreditScoreIcon from "../../include/assets/mycreditScore.svg";
import FeedbackIconIcon from "../../include/assets/myfeedback.svg"
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getAccount, setAccountInfo } from "../../store/account";
import {
    Navbar,
    Container,
    Nav,
    Form,
    Dropdown,
    Button,
} from "react-bootstrap";
import { getExperian, loadExperianCheck } from "../../store/experian";
import { Link } from "react-router-dom";
import BackDropComponent from "../../common/BackDropComponent";
import PATH from "../../paths/Paths";
import { Modal } from "react-bootstrap";
import ReferIfon from "../../include/assets/icons/referIcon.png";
import { sendReferCode } from "../../store/sendReferCode";
import { getCustomer, logout } from "../../store/login";
import {
    getBase64Encryption,
    getHashEncryption,
} from "../../Utils/crypto";
import LocationIcon from "../../include/assets/moneyPlus/location.svg"
import LocationDropDown from "../../common/LocationDropDown";

let localStore = new SecureLS({
    encodingType: "aes",
    isCompression: true,

});

class TopNavBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dropdownDisplay: false,
            loading: false,
            isOpen: false,
            isOpenCheckBalance: false,
            mobileNumber: "",
            MobileNumberError: "",
            referMobileNumber: "",
            name: "",
            referCode: "",
            disable: true,
        };
    }

    componentDidMount = () => {
        document.body.classList.remove("TwScrool");
        document.body.classList.add("variantScroll");
        if (window) {
            if (window.location.href.indexOf("asm-dashboard") >= 0) {
                this.setState({
                    ...this.state,
                    pin: localStorage.getItem("pin"),
                    city: localStorage.getItem("city"),
                    addCustomer: true
                })
            } else {
                this.setState({
                    ...this.state,
                    pin: localStorage.getItem("pin"),
                    city: localStorage.getItem("city"),
                    addCustomer: false
                })
            }
        }
    };

    componentDidUpdate = () => {
        // console.log("Customer details are", this.props.getCustomerDetail)
    }
    // logout function

    logoutSubmit = () => {
        Swal.fire({
            icon: "warning",
            title: "Are you sure you want to exit?",
            showCancelButton: true,
            confirmButtonText: "Log Out",
            confirmButtonColor: "#d63031",
            cancelButtonColor: "#2e0080",
        }).then((res) => {
            if (res.isConfirmed) {
                this.props.logout(this.handleLogout);
            }
        });
    };

    handleLogout = (res) => {
        if (res?.data?.success) {
            localStorage.clear();
            localStore.removeAll();
            this.props.history.push(PATH.PUBLIC.ASM_LOGIN);
        } else {

            localStorage.clear();
            localStore.removeAll();
            this.props.history.push(PATH.PUBLIC.ASM_LOGIN);
        }
    }
    handleShow = () => {
        let formData = {
            mobile: localStorage.getItem("mobilenumber"),
            isExperian: true,
        };
        this.setState({ loading: true });
        this.props.loadExperianCheck(formData, this.callBackVerify);
    };
    callBackVerify = async (res) => {
        let r = await res;
        try {
            // if (res) {
            if (res.data) {
                if (r.data.status === "error" || r.data.success === false) {
                    this.setState({ loading: false });

                    this.props.history.push(PATH.PRIVATE.CIBIL_SCORE_ANALYSIS);
                } else if (
                    r.data.cibilData &&
                    r.data.cibilData.experianStatus === "success"
                ) {
                    this.setState({ loading: false });
                    let formData = {
                        mobile: r.data.cibilData?.userData?.[0].mobileno,
                        pincode: r.data.cibilData?.userData?.[0].pincode,
                        name: r.data.cibilData?.userData?.[0].name,
                        pan: r.data.cibilData?.userData?.[0].pan,
                        dob: r.data.cibilData?.userData?.[0].dob,
                        email: r.data.cibilData?.userData?.[0].email,
                        cibilcheck: "Y",
                        creditCode:
                            (r.data.cibilData?.experianScore === -1 && "A") ||
                            (r.data.cibilData?.experianScore >= 800 && "B") ||
                            (r.data.cibilData?.experianScore >= 750 &&
                                r.data.cibilData?.experianScore <= 799 &&
                                "C") ||
                            (r.data.cibilData?.experianScore >= 700 &&
                                r.data.cibilData?.experianScore <= 749 &&
                                "D") ||
                            (r.data.cibilData?.experianScore >= 650 &&
                                r.data.cibilData?.experianScore <= 699 &&
                                "E") ||
                            (r.data.cibilData?.experianScore >= 600 &&
                                r.data.cibilData?.experianScore <= 649 &&
                                "F") ||
                            (r.data.cibilData?.experianScore >= 0 &&
                                r.data.cibilData?.experianScore <= 599 &&
                                "G"),
                    };
                    this.setState({ loading: true });
                    this.props.setAccountInfo(formData, this.callBackAcc);
                }
            } else {
                throw r.data.message.toString();
            }
            // }
        } catch (e) {
            this.setState({ loading: false });
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: false,
                timer: 1800,
            });
        }
    };
    callBackAcc = async (res) => {
        try {
            let r = await res;
            // if (res) {
            if (r.data.success) {
                this.setState({ loading: false });
                this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
                localStorage.setItem("fullName", this.props.userData?.[0]?.name);
                localStorage.setItem("firstName", this.props.userData?.[0]?.name);
                localStorage.setItem("pan", this.props.userData?.[0]?.pan);
            } else {
                throw r.data.message.toString();
            }
            // }
        } catch (e) {
            this.setState({ loading: false });
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: false,
                timer: 1800,
            }); // Swal.fire({
            //     position: "center",
            //     icon: "warning",
            //     title: res?.data?.message,
            //     showConfirmButton: false,
            //     timer: 1800,
            // })
        }
    };
    __handleMobileNumber = (event) => {
        event.preventDefault();
        const mobile_number = event.target.value;
        if (Number(mobile_number) && mobile_number.length === 10) {
            this.setState({ disable: false });
        }
        if (mobile_number.length === 10 && !/^[6789]\d{9}$/.test(mobile_number)) {
            this.setState({
                disable: true,
                MobileNumberError: "Please enter a valid mobile number.",
            });
        } else if (
            mobile_number.length === 10 &&
            mobile_number === this.state.mobileNumber
        ) {
            this.setState({
                disable: true,
                MobileNumberError:
                    "Refer Mobile number and Register Mobile should not same",
            });
        } else {
            this.setState({
                MobileNumberError: "",
            });
        }
        if (
            (Number(mobile_number) && mobile_number.length < 10) ||
            event.target.value.length < 1
        ) {
            this.setState({ disable: true });
        }
        if (
            mobile_number.length <= 10 &&
            (/^[0-9]+$/.test(mobile_number) || mobile_number === "")
        ) {
            this.setState({ referMobileNumber: mobile_number });
        }
    };
    __handleKeyPress = (event, key) => {
        if (event.key === "Enter" && event.shiftKey === false) {
            event.preventDefault();
            switch (key) {
                case "Enter Mobile Number":
                    const mobile_number = event.target.value;
                    this.setState({ disable: true });
                    if (mobile_number.length === 10 && this.state.disable === false) {
                        this._semodalndReferCode(event);
                    } else {
                        let msg = "Ten digits not Entered !";
                    }
                    break;
            }
        }
    };
    _sendReferCode = (e) => {
        e.preventDefault();
        const referData = {
            mobile: this.state.mobileNumber,
            refermobile: this.state.referMobileNumber,
            refercode: this.state.referCode,
            name: this.state.name,
        };
        this.props.sendReferCode(referData, this.callbackRefer);
    };
    callbackRefer = (res) => {
        if (res) {
            if (res.data.success) {
                this.setState({ isOpen: false });
                this.setState({ referMobileNumber: "" });
                this.setState({ disable: true });
                Swal.fire({
                    position: "center",
                    icon: "success",
                    title: res.data.message,
                    showConfirmButton: true,
                    timer: 5000,
                });
            } else {
                this.setState({ isOpen: false });
                this.setState({ referMobileNumber: "" });
                this.setState({ disable: true });
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "Try after sometimes",
                    showConfirmButton: true,
                    timer: 5000,
                });
            }
        }
    };
    openModal = () => {
        this.setState({ isOpen: true });
        this.setState({ referCode: localStorage.getItem("referCode") });
        this.setState({ name: localStorage.getItem("fullName") });
        this.setState({ mobileNumber: localStorage.getItem("mobilenumber") });
    };
    closeModal = () => {
        this.setState({ isOpen: false });
        this.setState({ referMobileNumber: "" });
        this.setState({ disable: true });
    };

    closeModalCheckBalance = () => {
        this.setState({ isOpenCheckBalance: false });
    }

    checkBalance = () => {
        this.setState({ isOpenCheckBalance: true });
    }

    __handlePinCode = (e) => {
        e.preventDefault();
        if (e.target.value.length === 6) {
            let mobile = localStorage.getItem("ASM_mobilenumber");
            let formData = { mobile: mobile, pincode: e.target.value };
            this.props?.loadPinCode(formData, this.callBackPin);
        }
    };

    callBackPin = (res) => {
        if (res) {
            if (!res.data.success) {
                this.setState({ pinError: res.data.message });
            } else {
                this.setState({
                    pin: res.data.data.pincode,
                    city: res.data.data.cityname,
                    geoError: "",
                });
                localStorage.setItem("city", res.data.data.cityname);
                localStorage.setItem("pin", res.data.data.pincode);
            }
        }
    };


    render() {
        const name1 =
            localStorage.getItem("ASM_firstName")?.length > 1 &&
            localStorage.getItem("ASM_firstName")?.split(" ");
        const name2 =
            localStorage.getItem("ASM_fullName")?.length > 1 &&
            localStorage.getItem("ASM_fullName")?.split(" ");

        const userName = isNaN(localStorage?.getItem("ASM_lastName"))
            ? name1[0]
            : localStorage.getItem("name");
        const bool = cleanObject(userName);
        // getBase64Encryption(getHashEncryption(localStorage.getItem('mobilenumber')))
        // getBase64Encryption(getHashEncryption(localStorage.getItem('accessToken')))
        // getBase64Encryption(getHashEncryption(localStorage.getItem('deviceId')))
        let mobile = localStorage.getItem('ASM_mobilenumber');
        let access_token = localStorage.getItem('accessToken');
        let deviceId = localStorage.getItem('deviceId');
        let redirectUrl = `${process.env.REACT_APP_AAFRONTENDAPP}?deviceId=${deviceId}&mobile_number=${mobile}&access_token=${access_token}`;
        console.log(this.state.city)

        // console.log(getBase64Encryption(getHashEncryption(localStorage.getItem('mobilenumber'))));
        // console.log(getBase64Encryption(getHashEncryption(localStorage.getItem('accessToken'))));
        // console.log(getBase64Encryption(getHashEncryption(localStorage.getItem('deviceId'))));

        // let mobile = localStorage.getItem('mobilenumber');
        // let access_token = localStorage.getItem('accessToken');
        // let deviceId = localStorage.getItem('deviceId');
        // let redirectUrl = `${process.env.REACT_APP_AAFRONTENDAPP}?deviceId=${deviceId}&mobile_number=${mobile}&access_token=${access_token}`;

        return (
            <>
                {this.props.loadingLogout ?
                    <BackDropComponent />
                    :
                    ""
                }
                <header className="bsHeader">
                    <Navbar expand="lg" fixed="top">
                        <Container>
                            {this.props.loading ? <BackDropComponent /> : ""}
                            <Link to={PATH.PRIVATE.TELE_VERIFICATION_DASHBOARD}>
                                <Navbar.Brand>
                                    {" "}
                                    <img src="/wefin-logo.svg" alt={"logo"} className="topbarLogo" />
                                </Navbar.Brand>
                            </Link>

                            <Navbar.Toggle aria-controls="navbarScroll" className="x" />
                            <Navbar.Collapse id="navbarScroll">
                                <Nav className="me-auto my-2 my-lg-0" navbarScroll>

                                    {/* <Nav.Link
                                        onClick={() =>
                                            this.props.history.push(PATH.PRIVATE.PRODUCTS)
                                        }
                                        className={
                                            this.props.location.pathname === PATH.PRIVATE.PRODUCTS
                                                ? "active ml-5 d-flex "
                                                : "ml-5 d-flex"
                                        }
                                    >
                                        <img src={LocationIcon} className={"ml-5 pl-4 pr-2 h-2"} /><p>{`${localStorage.getItem("pin")}, ${localStorage.getItem("city")}`}</p>
                                    </Nav.Link> */}

                                </Nav>
                                <div className="asmNavFields">
                                    <div className="hide">

                                    </div>

                                </div>
                                <Form className="d-none d-flex display-mobile">
                                    <Dropdown>
                                        <Dropdown.Toggle
                                            id="dropdown-button-dark-example1"
                                            variant="secondary"
                                        >
                                            {/* this.props.customerDetail.photourl?.indexOf("http") >= 0 ? this.props.customerDetail.photourl : */}
                                            <img className="profileNavimg" src={this.props.customerDetail.photourl?.indexOf("http") >= 0 ? this.props.customerDetail.photourl + "?" + Math.random().toString() : UserIcon} alt="" width="20px" height="20px" />
                                            Hi,{" "}
                                            {bool === false
                                                ? localStorage.getItem("mobilenumber")
                                                : userName.toLowerCase()}

                                        </Dropdown.Toggle>

                                        <Dropdown.Menu>
                                            {/* <Dropdown.Item>
                        <div style={{ display: 'flex', gap: '10px' }}> */}
                                            {/* <img src={UserIcon} alt="" width="20px" height="20px" /> */}
                                            {/* <div>
                      <Dropdown.Item>
                        <div className="profileBar" style={{ display: 'flex', gap: '10px' }}>
                          <img className="profilePic" src={this.props.getCustomerDetail?.photourl ? this.props.getCustomerDetail?.photourl : UserIcon} alt="" />
                          <div>
                            {bool === false
                              ? localStorage.getItem("mobilenumber")
                              : userName.toLowerCase()}
                            <p>
                              {" "}
                              {localStorage.getItem("mobilenumber")
                                ? localStorage.getItem("mobilenumber")
                                : ""}
                            </p> */}
                                            {/* <Button id="viewbtn" onClick={() => this.props.history.push(PATH.PRIVATE.PROFILE)}>My profile</Button> */}
                                            {/* </div> */}
                                            {/* </div>
                      </Dropdown.Item> */}
                                            {/* <div className="dropdown-divider"></div> */}

                                            <div className="dropdown-divider"></div>
                                            <Dropdown.Item
                                                onClick={this.logoutSubmit}
                                                className="bsLogoutbtn"
                                                href="javascript:void(0)"
                                            >
                                                {/* <div style={{ paddingBottom: '20px' }}> */}
                                                <img src={LogoutIcon} alt="" />
                                                {"  "}Logout
                                                {/* </div> */}
                                            </Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </Form>
                            </Navbar.Collapse>
                            <div className="bsLogoutMobile d-block d-sm-none d-md-none d-lg-none">
                                <Dropdown>
                                    <Dropdown.Toggle
                                        id="dropdown-button-dark-example1"
                                        variant="secondary"
                                    >
                                        <img className="profileNavimgMob" src={this.props.customerDetail.photourl?.indexOf("http") >= 0 ? this.props.customerDetail.photourl + "?" + Math.random().toString() : UserIcon} alt="" width="10px" height="10px" />
                                        Hi,{" "}
                                        {bool === false
                                            ? localStorage.getItem("mobilenumber")
                                            : userName.toLowerCase()}
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu variant="dark">
                                        <Dropdown.Item>
                                            {bool === false
                                                ? localStorage.getItem("mobilenumber")
                                                : userName.toLowerCase()}
                                            <p>
                                                {" "}
                                                {localStorage.getItem("mobilenumber")
                                                    ? localStorage.getItem("mobilenumber")
                                                    : ""}
                                            </p>
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                            onClick={this.logoutSubmit}
                                            className="bsLogoutbtn"
                                            href="javascript:void(0)"
                                        >
                                            <img src={LogoutIcon} alt="" />
                                            Logout
                                        </Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                        </Container>
                    </Navbar>
                </header>
            </>
        );
    }
}
const mapStateToProps = (state) => ({
    getCustomerDetail: getAccount(state).customerDetail,
    customerDetail: getAccount(state).customerDetail,
    experian: getExperian(state),
    userData: getExperian(state).userData,
    loadingLogout: getCustomer(state).loadingLogout
});

const mapDispatchToProps = (dispatch) => ({
    loadExperianCheck: (params, callback) =>
        dispatch(loadExperianCheck(params, callback)),
    setAccountInfo: (params, callback) =>
        dispatch(setAccountInfo(params, callback)),
    sendReferCode: (params, callback) =>
        dispatch(sendReferCode(params, callback)),
    logout: (params, callback) =>
        dispatch(logout(params, callback))
});


export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(TopNavBar)
);
