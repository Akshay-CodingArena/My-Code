import React, { Component } from "react";
import { Card, Col, Container, Modal, Row } from "react-bootstrap";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import DashBoardAside from "../../common/dashboardAside";
import TopNavBar from "../../common/TopNavBar";
import CreditFooter from "../cibilFlow/footer";

import ExcellentIcon from "../../include/assets/myprofile/excellent.svg";
import GoodIcon from "../../include/assets/myprofile/good.svg";
import MediumIcon from "../../include/assets/myprofile/medium.svg";
import PoorIcon from "../../include/assets/myprofile/poor.svg";
import VeryBadIcon from "../../include/assets/myprofile/verybad.svg";
// import { FEEDBACK_FORM_DROPDOWN } from "../common/dropdownValues";
import { myprofile, setCustomerFeedback } from "../../store/myprofile";
import BackDropComponent from "../../common/BackDropComponent";
import happyFaceIcon from "../../include/assets/myprofile/happyface.svg";
import PATH from "../../paths/Paths";
import Swal from "sweetalert2";


let emotionsArr = [{ emotion: 'Very Bad', message: "We regret for falling short of your expectations and will use your feedback to improve." }, { emotion: 'Poor', message: "We regret for falling short of your expectations and will use your feedback to improve." }, { emotion: 'Medium', message: "Thank you for your valuable feedback and we'll use your suggestions to continue improving." }, { emotion: 'Good', message: "We're glad to have met your expectations and we'll use your suggestions to continue improving." }, { emotion: 'Excellent', message: "We are thrilled to hear that you had an excellent experience. We’ll further continue improving and keep meeting your expectations." }]

class FeedbackForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            rating: 5,
            // selectedArray: Array.apply(null, Array(FEEDBACK_FORM_DROPDOWN.length)).map(Number.prototype.valueOf, 0),
            suggestion: "",
            isOpen: false,
            currentImagePath: ExcellentIcon
        };
    }

    componentDidMount = () => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
    };

    feedbackPointsFunc = (index) => {
        let tempArr = this.state.selectedArray;
        if (tempArr[index])
            tempArr[index] = 0;
        else tempArr[index] = 1;
        this.setState({ selectedArray: [...tempArr] })
    }


    onSubmit = () => {
        let formData =
        {
            mobile: localStorage.getItem("mobilenumber"),
            rating: this.state.rating,
            comment: this.state.suggestion,
            // improve: FEEDBACK_FORM_DROPDOWN?.filter((data, index) => this.state.selectedArray[index] === 1)
        }
        console.log(formData)
        this.props.setCustomerFeedback(formData, this.callBackGet);
    }


    callBackGet = (res) => {
        if (res.data.success) {
            this.setState({ isOpen: true });

        } else {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: res?.data?.message,
                showConfirmButton: false,
                timer: 1800,
            })
        }
    }


    closeModalFeedback = () => {
        this.setState({ isOpen: false });
    }


    changeImage = (index) => {
        switch (index) {
            case 1: this.setState({ rating: index, currentImagePath: VeryBadIcon }); break;
            case 2: this.setState({ rating: index, currentImagePath: PoorIcon }); break;
            case 3: this.setState({ rating: index, currentImagePath: MediumIcon }); break;
            case 3: this.setState({ rating: index, currentImagePath: MediumIcon }); break;
            case 4: this.setState({ rating: index, currentImagePath: GoodIcon }); break;
            case 5: this.setState({ rating: index, currentImagePath: ExcellentIcon }); break;
        }
    }


    goHome = () => {
        this.props.history.push(PATH.PRIVATE.PRODUCTS);
    }

    render() {
        return (
            <>
                {" "}
                <section className="bs-main-section">
                    <TopNavBar />

                    <Container>
                        <Row>
                            <Col sm={12} md={3}>
                                <DashBoardAside />
                            </Col>
                            <Col sm={12} md={9}>
                                {this.props.loadingFeedback ? (
                                    <BackDropComponent />
                                ) : (
                                    ""
                                )}
                                <div className="feedback-form">
                                    <Card>
                                        <Card.Header>   <h1 className="text-center title">How do you rate our service?</h1></Card.Header>
                                        <hr />
                                        <Card.Body>


                                            <div className="container mb-3">
                                                <div className="row justify-content-center emoji-container">

                                                    <div onClick={() => { this.changeImage(1) }} className={`col-6 col-sm-6 col-md-6 col-lg-2 img-block ${this.state.rating === 1 ? 'img-block-isSelected' : ''}`}>
                                                        <img className="rounded mx-auto d-block" src={VeryBadIcon} />
                                                        <h1 className="text-center">Very Bad</h1>
                                                    </div>

                                                    <div onClick={() => { this.changeImage(2) }} className={`col-6 col-sm-6 col-md-6 col-lg-2 img-block ${this.state.rating === 2 ? 'img-block-isSelected' : ''}`}>
                                                        <img className="rounded mx-auto d-block" src={PoorIcon} />
                                                        <h1 className="text-center">Poor</h1>
                                                    </div>

                                                    <div onClick={() => { this.changeImage(3) }} className={`col-6 col-sm-6 col-md-6 col-lg-2 img-block ${this.state.rating === 3 ? 'img-block-isSelected' : ''}`}>
                                                        <img className="rounded mx-auto d-block" src={MediumIcon} />
                                                        <h1 className="text-center">Medium</h1>
                                                    </div>
                                                    <div onClick={() => { this.changeImage(4) }} className={`col-6 col-sm-6 col-md-6 col-lg-2 img-block ${this.state.rating === 4 ? 'img-block-isSelected' : ''}`}>
                                                        <img className="rounded mx-auto d-block" src={GoodIcon} />
                                                        <h1 className="text-center">Good</h1>
                                                    </div>
                                                    <div onClick={() => { this.changeImage(5) }} className={`col-6 col-sm-6 col-md-6 col-lg-2 img-block ${this.state.rating === 5 ? 'img-block-isSelected' : ''}`}>
                                                        <img className="rounded mx-auto d-block" src={ExcellentIcon} />
                                                        <h1 className="text-center">Excellent</h1>
                                                    </div>
                                                </div>
                                                {/* <h2 className="mt-3 mb-3 subtitle">Tell us what can be improved?</h2>

                                                <ul>
                                                    {FEEDBACK_FORM_DROPDOWN?.map((value, index) => {
                                                        return <li onClick={() => { this.feedbackPointsFunc(index) }} >
                                                            <div className={this.state.selectedArray[index] ? "feedbackBtnSelected" : "feedbackBtn"}>{value.label}</div>
                                                        </li>
                                                    })}
                                                </ul> */}

                                                <h2 className="mt-3 mb-3 subtitle">Any Suggestions?</h2>

                                                <div className="row d-flex justify-content-center ">

                                                    <div className="col-12">
                                                        <div class="form-group">
                                                            <textarea onChange={(e) => this.setState({ suggestion: e.target.value })} value={this.state.suggestion} class="form-control" placeholder="Write your review..." rows="4"></textarea>
                                                        </div>
                                                    </div>

                                                    <div className="col-12 col-md-6 col-sm-6 col-lg-6">
                                                        <button onClick={this.onSubmit} className="submitBtn">Submit</button>
                                                    </div>
                                                </div>
                                            </div>

                                        </Card.Body>
                                    </Card>
                                </div>


                                <Modal
                                    className="ReferFriendModal feedBackModal"
                                    show={this.state.isOpen}
                                    onHide={this.closeModalFeedback}
                                >
                                    <Modal.Body className="text-center">
                                        <div className="row d-flex justify-content-center ">
                                            <div className="col-12">
                                                <img className="rounded mx-auto d-block feedBackSubmitImage" alt="happy face" src={this.state.currentImagePath} />
                                                <h1 className="mt-3 feedbackThankyouMsg">Thank You!</h1>
                                            </div>

                                            <div className="col-12 col-md-8 col-sm-12 col-lg-12 ">
                                                <p className="feedbackSubmittedMsg">Feedback : <span>{emotionsArr[this.state.rating - 1].emotion + '!'}</span></p>
                                                <p className="feedbackSubmittedMsg1">{emotionsArr[this.state.rating - 1].message}</p>
                                            </div>

                                            <div className="col-12 col-md-8 col-sm-8 col-lg-8  ">
                                                <button onClick={this.goHome} className="feedbackGoHomeBtn">OK</button>
                                            </div>
                                        </div>
                                    </Modal.Body>
                                </Modal>
                            </Col>
                        </Row>


                    </Container>
                </section>
                <CreditFooter />
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    loadingFeedback: myprofile(state).loadingFeedback,
});
const mapDispatchToProps = (dispatch) => ({
    setCustomerFeedback: (params, callbackDetail) =>
        dispatch(setCustomerFeedback(params, callbackDetail)),
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(FeedbackForm)
);
