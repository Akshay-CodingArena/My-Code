import React, { Component } from "react";
import { ReactComponent as CreditScore } from "../include/assets/homepageIcons/credit-score.svg";
import { ReactComponent as ServiceRequest } from "../include/assets/homepageIcons/service-request.svg";
import { ReactComponent as FAQs } from "../include/assets/homepageIcons/faqs.svg";
import { ReactComponent as Path14301 } from "../include/assets/homepageIcons/home.svg";
import { SidebarList } from "../common/helperCells";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { getExperian, loadExperianCheck } from "../store/experian";
import { getAccount, setAccountInfo } from "../store/account";
import PATH from "../paths/Paths";

class TestSidebar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
    };
  }

  handleClose = () => {
    this.setState({ show: false });
  };
  handleShow = () => {
    let formData = {
      mobile: localStorage.getItem("mobilenumber"),
      isExperian: true,
    };
    this.props.loadExperianCheck(formData, this.callBackVerify);
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data) {
        if (res.data.status === "error" || res.data.success === false) {
          this.props.history.push(PATH.PRIVATE.CIBIL_SCORE_ANALYSIS);
        } else if (
          res.data.cibilData &&
          res.data.cibilData.experianStatus === "success"
        ) {
          let formData = {
            mobile: res.data.cibilData?.userData?.[0].mobileno,
            pincode: res.data.cibilData?.userData?.[0].pincode,
            name: res.data.cibilData?.userData?.[0].name,
            pan: res.data.cibilData?.userData?.[0].pan,
            dob: res.data.cibilData?.userData?.[0].dob,
            email: res.data.cibilData?.userData?.[0].email,
            cibilcheck: "Y",
            creditCode:
              (res.data.cibilData?.experianScore === -1 && "A") ||
              (res.data.cibilData?.experianScore >= 800 && "B") ||
              (res.data.cibilData?.experianScore >= 750 &&
                res.data.cibilData?.experianScore <= 799 &&
                "C") ||
              (res.data.cibilData?.experianScore >= 700 &&
                res.data.cibilData?.experianScore <= 749 &&
                "D") ||
              (res.data.cibilData?.experianScore >= 650 &&
                res.data.cibilData?.experianScore <= 699 &&
                "E") ||
              (res.data.cibilData?.experianScore >= 600 &&
                res.data.cibilData?.experianScore <= 649 &&
                "F") ||
              (res.data.cibilData?.experianScore >= 0 &&
                res.data.cibilData?.experianScore <= 599 &&
                "G"),
          };
          this.props.setAccountInfo(formData, this.callBackAcc);
        }
      }
    }
  };
  callBackAcc = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
        localStorage.setItem("fullName", this.props.userData?.[0]?.name);
        localStorage.setItem("pan", this.props.userData?.[0]?.pan);
      }
    }
  };
  render() {
    return (
      <div>
        <div
          className="relative flex w-full h-screen "
          style={{ overflowX: "hidden", marginTop: "10px" }}
        >
          <div className="flex flex-col w-56 bg-white rounded-r-3xl overflow-hidden sidebar">
            <ul className="flex flex-col py-4">
              <SidebarList
                icon={<Path14301 className="sidebarIcon" />}
                text={"Home"}
                onClick={() => this.props.history.push(PATH.PRIVATE.PRODUCTS)}
                hrefLink={"javascript:void(0)"}
              />
              <SidebarList
                icon={<CreditScore className="sidebarIcon" />}
                text={"Credit Score"}
                hrefLink={"javascript:void(0)"}
                onClick={() => this.handleShow()}
              />
              {/* <SidebarList
                icon={<EMICalculator className="sidebarIcon" />}
                text={"EMI Calculator"}
                hrefLink={"javascript:void(0)"}
              /> */}

              <SidebarList
                icon={<ServiceRequest className="sidebarIcon" />}
                text={"Service Request"}
                hrefLink={"javascript:void(0)"}
              />

              <SidebarList
                icon={<FAQs className="sidebarIcon" />}
                text={"FAQs"}
                onClick={() => this.props.history.push(PATH.PRIVATE.FAQ)}
                hrefLink={"javascript:void(0)"}
              />
            </ul>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  experian: getExperian(state),
  userData: getExperian(state).userData,
});
const mapDispatchToProps = (dispatch) => ({
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TestSidebar)
);
