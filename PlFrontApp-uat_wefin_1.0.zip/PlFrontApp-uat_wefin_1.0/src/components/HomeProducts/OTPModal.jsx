import React, { Component } from "react";
import { Modal, Row, Col } from "react-bootstrap";
import { getAccount, setAccountInfo, getAccountInfo } from "../../store/account";
import {
  getExperian,
  loadExperianOtp,
  loadExperianCheck,
} from "../../store/experian";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { ReactComponent as Close } from "../../include/assets/close.svg";
import { gaLogEvent } from "../../init-fcm";
import CONSTANTS from "../../constants/Constants";
import PATH from "../../paths/Paths";
import { decryptStore } from "../../Utils/store";
import { loadccApplyLoan } from "../../store/applyLoan";
import Swal from "sweetalert2";
import BackDropComponent from "../../common/BackDropComponent";
import cardRedirection from "../creditCard/cardRedirection";
import { dropdown_gender_values } from "../common/dropdownValues";
class OTPModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showOTP: false,
      otp: "",
      OTPError: "",
      stgOneHitId: "",
      stgTwoHitId: "",
      resend: false,
    };
  }

  OTPButton = (e) => {
    e.preventDefault();
    this.setState({ ...this.state, isLoading: true })
    let formData = {
      mobile: this.props.mobile,
      stgOneHitId: this.state.stgOneHitId
        ? this.state.stgOneHitId
        : this.props.stgOneHitId,
      stgTwoHitId: this.state.stgTwoHitId
        ? this.state.stgTwoHitId
        : this.props.stgTwoHitId,
      otp: this.state.otp,
    };
    this.props.loadExperianOtp(formData, this.callBackOtp);
  };
  callBackOtp = (res) => {
    if (res) {
      if (res.data.status === 203) {
        let formData = {
          mobile: this.props.mobile,
          pincode: this.props.data.pincode,
          name: this.props.data.fullName,
          pan: this.props.data.pan,
          dob: reverseDateString(this.props.data.dob),
          email: this.props.data.email,
          gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.props.data.gender.toLowerCase())[0].label,
          maritalStatus: this.props.data.maritalStatus.label,
          cibilcheck: "Y",
          creditCode: "A",
        };
        console.log(formData);
        this.props.setAccountInfo(formData, this.callBackAcc);
        this.setState({
          OTPError: "",
        });
      } else if (res.data.success) {
        if (res.data.experianData.responseData.errorString) {
          if (
            res.data.experianData.responseData.errorString ===
            "OTP validation failed, OTP is not match"
          ) {
            this.setState({
              resend: true,
              otp: "",
              OTPError: res.data.experianData.responseData.errorString,
              isLoading: false
            });
            let formData = {
              mobile: this.props.mobile,
              pincode: this.props.data.pincode,
              name: this.props.data.fullName,
              pan: this.props.data.pan,
              dob: reverseDateString(this.props.data.dob),
              email: this.props.data.email,
              isExperian: true,
            };
            this.props.loadExperianCheck(formData, this.callBackVerify);
          } else {
            this.setState({
              OTPError: res.data.experianData.responseData.errorString,
              isLoading: false
            });
          }
        } else {
          this.props?.handleCloseOTP();
          gaLogEvent(CONSTANTS.GA_EVENTS.CREDIT_SCORE_COMPLETED);
          gaLogEvent(CONSTANTS.GA_EVENTS.PAN_VERIFIED);
          let code =
            res.data.experianData?.responseData?.experianData?.SCORE
              ?.BureauScore?.[0];
          let formData = {
            mobile: this.props.mobile,
            pincode: this.props.data.pincode,
            name: this.props.data.fullName,
            pan: this.props.data.pan,
            dob: reverseDateString(this.props.data.dob),
            email: this.props.data.email,
            gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.props.data.gender.toLowerCase())[0].label,
            cibilcheck: "Y",
            gender: dropdown_gender_values?.filter((value, index) => value.value.toLowerCase() === this.props.data.gender.toLowerCase())[0].label,
            creditCode:
              (code === -1 && "A") ||
              (code >= 800 && "B") ||
              (code >= 750 && code <= 799 && "C") ||
              (code >= 700 && code <= 749 && "D") ||
              (code >= 650 && code <= 699 && "E") ||
              (code >= 600 && code <= 649 && "F") ||
              (code >= 0 && code <= 599 && "G"),
          };
          this.props.setAccountInfo(formData, this.callBackAcc);
          this.setState({
            OTPError: "",
          });
        }
      }
    }
  };
  callBackVerify = (res) => {
    if (res) {
      if (res.data.success) {
        this.setState({
          stgOneHitId: res.data.data.stgOneHitId,
          stgTwoHitId: res.data.data.stgTwoHitId,
          OTPError: "",
          resend: false,
        });
      }
    }
  };

  callbackLoan = (res) => {
    if (res) {
      //  console.log("my loan", res, "props", this.props)
      let appliedCard = this.props.appliedCard ?? JSON.parse(localStorage.getItem("appliedCard"))
      cardRedirection(this.props, appliedCard, this.props.getAccountInfo, true)
    }
  }

  callBackAcc = async (res) => {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    //  console.log("Loan type is", loanType, "should be", CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN)
    if (res) {
      if (res.data.success) {
        localStorage.setItem("fullName", this.props.data.fullName);
        if (this.props.cibil) {
          this.props.history.push(PATH.PRIVATE.CREDIT_REPORT_ANALYSIS);
        } else {
          if (loanType === CONSTANTS.LOAN_TYPE.BUSINESS_LOAN) {
            this.props.history.push(PATH.PRIVATE.APPLY_BUSINESS_LOAN);
          }

          else if (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN) {
            this.props.history.push(PATH.PRIVATE.APPLY_HOME_LOAN);
          }
          else if (loanType === CONSTANTS.LOAN_TYPE.CREDIT_CARD_LOAN) {
            if (this.props.locationData.state?.isASMFlow) {
              this.props.history.push({
                pathname: PATH.PUBLIC.GET_CREDIT_CARD
              })
            } else {
              //       console.log("Home Product Credit Card", this.props)
              let card = this.props.appliedCard ?? JSON.parse(localStorage.getItem("appliedCard"))
              //       console.log("applied card is", card, "props", this.props)
              console.log("card is", card, loanType)
              if (card) {
                if (this.props.ccformData) {
                  await this.props.loadccApplyLoan(this.props.ccformData, this.callbackLoan)
                }
                else {
                  cardRedirection(this.props, this.props.appliedCard, this.props.getAccountInfo, true)
                  //      await this.props.loadccApplyLoan(formData, this.callbackLoan);
                  //          this.props.history.push(PATH.PRIVATE.PRODUCTS)
                }
              }
              else {
                this.props.history.goBack();
              }
            }
          }
          else if (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN && this.props.location.state.bike.manufacturer__c === "REVOLT") {
            if (localStorage.getItem("isASM")) {
              this.props.history.push(
                {
                  pathname: `${PATH.PRIVATE.TWO_WHEELER_LOAN_OFFERS}`,
                  state: this.props.location.state
                });
            } else {
              this.props.history.push(
                {
                  pathname: PATH.PRIVATE.PERSONAL_DETAIL,
                  state: this.props.location.state
                });
            }
          }
          // else if()
          // {

          // }
          else {
            this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
          }
        }
      }
    }
  };
  render() {
    console.log("card is", this.props.appliedCard)
    return (
      <Modal className="bsOtpbox" show={this.props.show}>
        {this.state.isLoading ? <BackDropComponent /> : null}
        <Modal.Body style={{ textAlign: "center" }}>
          <p
            className="modalClose"
            onClick={() => {
              this.props.handleCloseOTP();
              this.setState({ otp: "", OTPError: "" });
            }}
          >
            <Close />
          </p>
          <form onSubmit={this.OTPButton}>
            <Row>
              <Col>
                <div className="logo-exp">
                  <img src="/experian.png" alt="experian logo" />
                </div>
                <h2>Enter OTP</h2>
                <p>
                  To check your Credit Score, Enter <br />
                  verification code sent to
                </p>
                <h4>
                  +91 {localStorage.getItem("mobilenumber")}
                  {/* {"  "}
                  <img src={Edit} alt="" style={{ paddingLeft: "10px" }} /> */}
                </h4>
              </Col>
            </Row>
            <br />
            <input
              placeholder="******"
              value={this.state.otp}
              onChange={(e) => this.setState({ otp: e.target.value })}
              autoFocus
              id="otpField"
              className="OtpField"
              name="otpField"
              maxLength="6"
            />
            {this.state.OTPError && (
              <span className="exp error-form">{this.state.OTPError}</span>
            )}

            <div className="otpBottomContainer">
              <div
                style={{
                  marginTop: "20px",
                  color: "#7C7C7C",
                  fontSize: "15px",
                  marginRight: "40px",
                }}
              ></div>
            </div>

            <div>
              <button type="submit" className="OtpSubmitBtn">
                {this.state.resend ? "Resend" : "Submit"}
              </button>
            </div>
          </form>
        </Modal.Body>
      </Modal>
    );
  }
}
function reverseDateString(str) {
  var splitString = str.split("-");
  var reverseArray = splitString.reverse();
  var joinArray = reverseArray.join("-");
  joinArray = joinArray + "T00:00:00.000Z";
  return joinArray;
}
const mapStateToProps = (state) => ({
  // experian: getExperian(state),
  getAccount: getAccount(state),
  getAccountDetail: getAccount(state).getAccountDetail,
  experian: getExperian(state),
});
const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  loadccApplyLoan: (params, callback) =>
    dispatch(loadccApplyLoan(params, callback)),
  loadExperianOtp: (params, callback) =>
    dispatch(loadExperianOtp(params, callback)),
  setAccountInfo: (params, callback) =>
    dispatch(setAccountInfo(params, callback)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(OTPModal)
);