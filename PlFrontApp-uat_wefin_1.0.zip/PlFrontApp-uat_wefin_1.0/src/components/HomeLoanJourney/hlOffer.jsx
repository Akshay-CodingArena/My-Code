import React, { Component } from "react";
import { numberFormat } from "../../Utils/numberFormat";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import Slider from "react-rangeslider";
import { decryptStore, encryptStore } from "../../Utils/store";
import TopNavBar from "../../common/TopNavBar";
import LeftMenuDecider from "../../common/leftMenuContent";
import selectIcon from "../../include/assets/select-icon.svg";
import ReactTooltip from "react-tooltip";
import { ReactComponent as ArrowForwardIosIcon } from "../../include/assets/buttonArrow.svg";
import { Table } from "react-bootstrap";
import {
    updateBankOffer,
    getBankOffer,
    setOfferList,
    setBankOfferList,
} from "../../store/bankOffer";
import BackDropComponent from "../../common/BackDropComponent";
import { getAccount, getAccountInfo } from "../../store/account";
import "react-rangeslider/lib/index.css";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../../components/cibilFlow/footer";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
class HomeLoanOffer extends Component {

    constructor(props) {
        super(props);
        this.state = {
            principal: "",
            tenure: "",
            bank: {},
            firstName: "",
            lastName: "",
            middleName: "",
        };
    }
    handleApply = (bank) => {
        this.setState({ bank: bank });
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        let { loansfid } = decryptedData;
        let formData = {
            lenderId: bank.lender_id__c,
            loanType: bank.loanType,
            mobile: localStorage.getItem("mobilenumber"),
            loanAmount: bank.appliedLoanAmount,
            offerId: bank.id,
            emi: bank.emi,
            roi: bank.IRR,
            tenure: bank.appliedTenure,
            pf: bank.PF,
            loanId: loansfid ? loansfid : "",
        };

        if (localStorage.getItem("isUTM")) {
            let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
            formData.utm_source = UTM_Data?.utm_source;
            formData.utm_medium = UTM_Data?.utm_medium;
            formData.utm_id = UTM_Data?.utm_id;
            formData.utm_campaign = UTM_Data?.utm_campaign;
        }

        this.props.setOfferList(formData, this.callBackSet);
    };
    callBackSet = (res) => {
        if (res) {
            if (res.data.success) {
                gaLogEvent(CONSTANTS.GA_EVENTS.HL_OFFER_SELECTED, {
                    Lender_Name: this.state.bank.lenderName,
                });
                const mobile = localStorage.getItem("mobilenumber");
                let storeData = {
                    loansfid: res.data.data.loansfid,
                    lenderName: this.state.bank.lenderName,
                    loanName: res.data.data.loanName
                };
                encryptStore(mobile, storeData);
                {
                    this.props.history.push({
                        pathname: `${PATH.PRIVATE.HOME_LOAN_BANK_SPECIFIC_DETAIL
                            }/${this.state.bank.loanType
                                .split(/\s/)
                                .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
                        state: this.state.bank,
                    });
                }
            }
        }
    };
    __handleEMI = (amount, time) => {
        this.setState({ principal: amount, tenure: time });
        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loansfid } = decryptedData;
        let formData = {
            mobile: mobile,
            loanType: CONSTANTS.LOAN_TYPE.HOME_LOAN,
            loanId: loansfid,
            loanAmount: amount.toString(),
            tenure: time.toString(),
        };
        this.props.updateBankOffer(formData, this.callBackUpdate);
    };
    callBackUpdate = (res) => {
        if (res?.success === false) {
        }
    };
    componentDidMount = () => {
        window.scrollTo(0, 0);
        gaLogEvent(CONSTANTS.GA_EVENTS.PL_OFFERS);
        let mobile = localStorage.getItem("mobilenumber");
        let fullName = localStorage.getItem("fullName");
        const name = fullName.split(" ");
        if (name.length > 2) {
            this.setState({
                firstName: name[0],
                lastName: name[2],
                middleName: name[1],
            });
        } else {
            this.setState({ firstName: name[0], lastName: name[1] });
        }

        this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
        const { breData } = this.props.updateOffer.appliedLoanAmount
            ? this.props.updateOffer
            : this.props.location && this.props.location.state;
        this.setState({
            principal:
                breData && breData.length > 0 ? breData[0].appliedLoanAmount : 0,
            tenure: breData && breData.length > 0 ? breData[0].appliedTenure : 10,
        });
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
    };
    render() {
        const { loading, updateOffer, loadingSet, loadingBank } =
            this.props;
        const { breData, minLoanAmount, maxLoanAmount } = updateOffer.appliedLoanAmount
            ? updateOffer
            : this.props.location && this.props.location.state;
        let maxTenure =
            breData && breData.length > 0 ? breData[0].max_tenure : 25;
        const defaultAmount =
            breData && breData.length > 0 ? breData[0].appliedLoanAmount : 0;
        let minTenure = breData && breData.length > 0 ? breData[0].min_tenure : 10;
        return (
            <>
                <TopNavBar />
                <section className="bs-main-section">
                    <Container>
                        <Row>
                            <Col sm={12} md={3}>
                                <LeftMenuDecider activeStep={2} />
                            </Col>
                            <Col sm={12} md={9}>
                                {loading || loadingSet || loadingBank ? (
                                    <BackDropComponent />
                                ) : (
                                    ""
                                )}

                                <div className="row">
                                    <div className="col-sm-12">
                                        <div className="bsEmiCalcBox">
                                            <div className="bsEmiCalcHeader">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="bsSliderTxt">
                                                            Requested Loan Amount:{" "}
                                                            <strong>
                                                                {" "}
                                                                {numberFormat(
                                                                    breData && breData.length > 0
                                                                        ? breData[0].appliedLoanAmount
                                                                        : ""
                                                                )}
                                                            </strong>
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-6">
                                                        <div className="bsSliderTxt">
                                                            Tenure:
                                                            <strong>
                                                                {" "}
                                                                {this.state.tenure
                                                                    ? this.state.tenure
                                                                    : maxTenure}{" "}
                                                                Years
                                                            </strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="bsEmiCalcSlider">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="bsSliderInpitBox text-right">
                                                            <span>₹</span>
                                                            <input
                                                                className="text-center"
                                                                type="text"
                                                                pattern="[0-9]*"
                                                                id="principal"
                                                                maxLength="7"
                                                                name="principal"
                                                                value={this.state.principal}
                                                                onChange={(e) => {
                                                                    let v = e.target.validity.valid
                                                                        ? e.target.value
                                                                        : "";
                                                                    this.setState({ principal: v });


                                                                }}
                                                                onBlur={() =>
                                                                    this.__handleEMI(
                                                                        this.state.principal,
                                                                        this.state.tenure
                                                                    )
                                                                }
                                                            />
                                                        </div>
                                                        <Slider
                                                            className="bsEmiSlider"
                                                            key={`slider-${defaultAmount}`}
                                                            tooltip={false}
                                                            min={minLoanAmount}
                                                            max={maxLoanAmount}
                                                            step={50000}
                                                            labels={{
                                                                minLoanAmount:
                                                                    "Min:" + " " + numberFormat(minLoanAmount),
                                                                2000000: "Max:" + " " + numberFormat(maxLoanAmount),
                                                            }}
                                                            value={
                                                                this.state.principal
                                                                    ? this.state.principal
                                                                    : defaultAmount
                                                            }
                                                            aria-label="Default"
                                                            valueLabelDisplay="on"
                                                            onChange={(v) => this.setState({ principal: v })}
                                                            onChangeComplete={(v) =>
                                                                this.__handleEMI(
                                                                    this.state.principal,
                                                                    this.state.tenure
                                                                )
                                                            }
                                                        />
                                                    </div>
                                                    <div className="col-sm-6 ">
                                                        <div className="bsSliderInpitBox text-right">
                                                            <span>Years</span>
                                                            <input
                                                                className="text-center bsMonth"
                                                                type="text"
                                                                id="tenure"
                                                                name="tenure"
                                                                pattern="[0-9]*"
                                                                maxLength="2"
                                                                value={this.state.tenure}
                                                                // onChange={(e) => {
                                                                //   this.setState({ tenure: e.target.value });
                                                                // }}
                                                                onChange={(e) => {
                                                                    let v = e.target.validity.valid
                                                                        ? e.target.value
                                                                        : "";
                                                                    this.setState({ tenure: v });


                                                                }}
                                                                onBlur={() =>
                                                                    this.__handleEMI(
                                                                        this.state.principal,
                                                                        this.state.tenure
                                                                    )
                                                                }
                                                            />
                                                        </div>
                                                        <Slider
                                                            className="bsEmiSlider"
                                                            key={`slider-${maxTenure}`}
                                                            tooltip={false}
                                                            min={10}
                                                            max={25}
                                                            step={1}
                                                            labels={{
                                                                maxTenure:
                                                                    "Max:" + " " + maxTenure + " " + "Years",
                                                                minTenure:
                                                                    "Min:" + " " + minTenure + " " + "Years",
                                                            }}
                                                            value={
                                                                this.state.tenure
                                                                    ? this.state.tenure
                                                                    : maxTenure
                                                            }
                                                            aria-label="Default"
                                                            valueLabelDisplay="on"
                                                            onChange={(v) => this.setState({ tenure: v })}
                                                            onChangeComplete={(v) =>
                                                                this.__handleEMI(
                                                                    this.state.principal,
                                                                    this.state.tenure
                                                                )
                                                            }
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-sm-12">
                                        <div>
                                            <div className="bsResponsiveTable">
                                                <Table className="bsLoanOfferTable striped bordered hover">
                                                    <thead>
                                                        <tr>
                                                            <th>Bank</th>
                                                            <th>Interest Rate</th>
                                                            <th>PF</th>
                                                            <th>
                                                                EMI{" "}
                                                                <p
                                                                    data-tip={
                                                                        "*T&C. The charges shown are indicative and the EMI figure is indicative for" +
                                                                        " " +
                                                                        maxTenure +
                                                                        " " +
                                                                        "years tenure ."
                                                                    }
                                                                    data-background-color="#2e0080"
                                                                    data-text-color="#FFF"
                                                                    data-place="top"
                                                                    style={{
                                                                        display: "inline-block",
                                                                        cursor: "pointer",
                                                                    }}
                                                                >
                                                                    (T&C)
                                                                </p>
                                                                <ReactTooltip />
                                                            </th>
                                                            <th>Prepayment Charges</th>
                                                            <th>Proceed</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {breData && breData.length > 0 ? (
                                                            breData
                                                                .slice()
                                                                .sort((a, b) => b.isInstant - a.isInstant)
                                                                .map((e, i) => (
                                                                    <tr key={i}>
                                                                        <td align="left">
                                                                            {e.isInstant === true ? (
                                                                                <div className="InstantApproveBox">
                                                                                    <img
                                                                                        src={selectIcon}
                                                                                        alt="select Icon"
                                                                                    />{" "}
                                                                                    2 Min Approval
                                                                                </div>
                                                                            ) : (
                                                                                ""
                                                                            )}
                                                                            {e.bankImage ? (
                                                                                <img
                                                                                    src={e.bankImage}
                                                                                    alt=""
                                                                                    width="100"
                                                                                    style={{ width: '70px' }}
                                                                                />
                                                                            ) : (
                                                                                <img
                                                                                    src="/bankLogos/default.svg"
                                                                                    alt=""
                                                                                    width="100"
                                                                                    style={{ width: "70px" }}
                                                                                />
                                                                            )}
                                                                        </td>
                                                                        <td align="left">{e.min_ROI}<span> - </span>{e.max_ROI} %</td>
                                                                        <td align="left">{e.PF}%<span>*</span></td>

                                                                        <td
                                                                            align="left"
                                                                            style={{
                                                                                color: "#2e0080",
                                                                                fontWeight: 600,
                                                                            }}
                                                                        >
                                                                            {numberFormat(e.emi)} <span>@</span>{e.IRR}%
                                                                        </td>

                                                                        <td align="left">
                                                                            <ul>
                                                                                {e.prePaymentCharges &&
                                                                                    e.prePaymentCharges
                                                                                        // .split("|")
                                                                                        .map((e1) => <li>{e1}</li>)}
                                                                            </ul>
                                                                        </td>
                                                                        <td align="left">
                                                                            <button
                                                                                onClick={() => this.handleApply(e)}
                                                                            >
                                                                                Apply <ArrowForwardIosIcon />
                                                                            </button>
                                                                        </td>
                                                                    </tr>
                                                                ))
                                                        ) : (
                                                            <tr>
                                                                <td align="left">No Record Found.</td>
                                                            </tr>
                                                        )}
                                                    </tbody>
                                                </Table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </section>
                <CreditFooter />
            </>
        )
    }
}

const mapStateToProps = (state) => ({
    updateOffer: getBankOffer(state).updateOffer,
    loading: getBankOffer(state).loadingUpdate,
    loadingSet: getBankOffer(state).loadingSet,
    customerDetail: getAccount(state).customerDetail,
    setBankOffer: getBankOffer(state).setBankOffer,
    loadingBank: getBankOffer(state).loadingBank,
});

const mapDispatchToProps = (dispatch) => ({
    updateBankOffer: (params, callBack) =>
        dispatch(updateBankOffer(params, callBack)),
    setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
    getAccountInfo: (params, callbackDetail) =>
        dispatch(getAccountInfo(params, callbackDetail)),
    setBankOfferList: (params, callBack) =>
        dispatch(setBankOfferList(params, callBack)),
});
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(HomeLoanOffer))