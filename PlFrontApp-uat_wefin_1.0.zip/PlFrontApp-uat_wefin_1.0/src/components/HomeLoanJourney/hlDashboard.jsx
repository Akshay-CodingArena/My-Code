import { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import PATH from "../../paths/Paths";
import Swal from "sweetalert2";
import TopNavBar from "../../common/TopNavBar";
import DashBoardAside from "../../common/dashboardAside";
import moment from "moment";
import { numberFormat } from "../../Utils/numberFormat";
import CreditFooter from "../cibilFlow/footer";
import { getAccountInfo, getAccount } from "../../store/account";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";

class HlDashboard extends Component {

  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    let mobile = localStorage.getItem("mobilenumber");
    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
  };
  callbackDetail = (res) => {
    if (res) {
      if (res?.data?.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };

  render() {
    const { loading, getAccountDetail } = this.props;

    const list =
      getAccountDetail &&
        getAccountDetail[0] &&
        getAccountDetail[0][this.props.match.params.name]
        ? getAccountDetail[0][this.props.match.params.name]
        : [];
    let responseList = list.filter((lists) => lists.loanStage !== "Offers");
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <DashBoardAside />
              </Col>
              <Col sm={12} md={9}>
                <div className="row bsFormBlock">
                  <div className="col-sm-12">
                    <div className="row g-0">
                      <div
                        className="col-6 col-sm-8"
                        style={{ paddingLeft: "0px" }}
                      >
                        <h3 className="bsLoanHeadline">Home Loans</h3>
                      </div>
                    </div>
                  </div>
                  {responseList.map((e, i) => (
                    <div className="col-sm-12 bsMyLoanSection">
                      <div className="row g-0 align-items-center bsMyLoanBox">
                        <div className="col-sm-9">
                          <div className="row g-0">
                            <div className="col-6 col-sm-3">
                              <p> Application No.</p>

                              <strong>{e.loanName}</strong>
                            </div>
                            <div className="col-6 col-sm-3">
                              <p>Applied Date</p>
                              <strong>
                                {moment(e.createddate).format("DD-MMM-YYYY")}
                              </strong>
                            </div>
                            <div className="col-6 col-sm-3">
                              <p>Loan Amount</p>

                              <strong>
                                {" "}
                                {e.appliedLoanAmount
                                  ? numberFormat(e.appliedLoanAmount)
                                  : "------"}
                              </strong>
                            </div>
                            <div className="col-6 col-sm-3">
                              <p>Interest Rate</p>

                              <strong>
                                {e.IRR ? e.IRR + " %*" : "------"}{" "}
                              </strong>
                            </div>
                          </div>

                          <hr className="bsBorder" />
                          <div className="row g-0 align-items-center">
                            <div className="col-6 col-sm-3">
                              <div>
                                {e.bankImage ? (
                                  <img
                                    src={e.bankImage}
                                    alt=""
                                    style={{ width: "70px" }}
                                  />
                                ) : (
                                  <img
                                    src="/bankLogos/default.svg"
                                    alt=""
                                    style={{ width: "60px" }}
                                  />
                                )}
                              </div>
                            </div>
                            <div className="col-6 col-sm-3">
                              <p>Loan Type</p>

                              <strong>{e.loanType.split("_").join(" ")}</strong>
                            </div>
                            <div className="col-6 col-sm-3">
                              {" "}
                              <p>Tenure</p>
                              <strong>
                                {e.pl_applied_tenure__c
                                  ? e.pl_applied_tenure__c + " " + "years"
                                  : "------"}
                              </strong>
                              <span></span>
                              {e.lenderName ? "" : <span></span>}
                            </div>
                          </div>
                        </div>
                        {/* 
                        <div className=" col-12 col-sm-3 text-center">
                          <p className="bsContinue">
                            Loan Status
                            <strong
                              style={{
                                fontWeight: "bolder",
                                color:
                                  e.loanStage === "Soft Approved"
                                    ? "#1aac7a"
                                    : e.loanStage === "Declined"
                                      ? "#ff5800"
                                      : " rgba(0, 0, 0, 0.87)",
                                fontSize: "16px",
                              }}
                            >
                              {e.offerId === this.state.offerId &&
                                this.state.loanStatus
                                ? this.state.loanStatus
                                : e.loanStage}
                            </strong>
                          </p>
                          <p className="bsContinue">
                            {e.loanStage === "Submitted" ? (
                              <button
                                variant="contained"
                                className="nextButton"
                                disabled
                                style={{
                                  opacity: "0.5",
                                  cursor: "not-allowed",
                                }}
                              >
                                Continue
                                <img alt="" src={newLoanArrow} />
                              </button>
                            ) : (
                              <button onClick={() => this.handleContinue(e)}>
                                Continue
                                <img alt="" src={newLoanArrow} />
                              </button>
                            )}
                          </p>
                        </div> */}
                      </div>
                    </div>
                  ))}
                </div>
              </Col>
            </Row>
          </Container>
        </section>
        <CreditFooter />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  getAccountDetail: getAccount(state).getAccountDetail,
  loading: getAccount(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(HlDashboard)
);
