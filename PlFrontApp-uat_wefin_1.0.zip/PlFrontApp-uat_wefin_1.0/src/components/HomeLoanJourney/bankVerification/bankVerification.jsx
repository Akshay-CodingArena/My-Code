import React, { useEffect } from "react";
import CONSTANTS from "../../../constants/Constants";
import PersonalAddress from "./personalAddress";
import TopNavBar from "../../../common/TopNavBar";
import LeftMenuDecider from "../../../common/leftMenuContent";
import { Container, Row, Col } from "react-bootstrap";
import { useLocation } from "react-router";
import CreditFooter from "../../cibilFlow/footer";
import HomeLoanAdditionalInfo from "../../HomeLoanJourney/BankDetailsVerification/HomeOffer";
import { useState } from "react";
import AdditionalInfoPropertyDetails from "./propertydetails";

const BankVerification = () => {
  const [hlData, setHLData] = useState([]);
  let location = useLocation();
  const [step, setStep] = React.useState(
    CONSTANTS.RENDER_HOME_LOAN_ADDITIONAL_INFO_CURRENT_ADDRESS
  );
  const updateStep = (e, page) => {
    if (e) e.preventDefault();
    setStep(page);
  };
  useEffect(() => {
    window.scrollTo(0, 0);
    document.body.classList.remove("variantScroll");
    document.body.classList.add("TwScrool");
  });

  const leftSideStep = () => {
    switch (step) {
      case CONSTANTS.RENDER_HOME_LOAN_ADDITIONAL_INFO_CURRENT_ADDRESS:
        return (
          <HomeLoanAdditionalInfo
            hlData={hlData}
            setHLData={setHLData}
            updateStep={updateStep}
            location={location}
          />
        );

      case CONSTANTS.RENDER_HOME_LOAN_ADDITIONAL_INFO_PROPERTY_DETAILS:
        return (
          <AdditionalInfoPropertyDetails
            hlData={hlData}
            setHLData={setHLData}
            updateStep={updateStep}
            location={location}
          />
        );
      default: break;
    }
  };
  return (
    <>
      <TopNavBar />
      <section className="bs-main-section">
        <Container>
          <Row>
            <Col sm={12} md={3}>
              <LeftMenuDecider activeStep={3} />
            </Col>
            <Col sm={12} md={9}>
              {leftSideStep()}
            </Col>
          </Row>
        </Container>
      </section>
      <CreditFooter />
    </>
  );
};

export default BankVerification;