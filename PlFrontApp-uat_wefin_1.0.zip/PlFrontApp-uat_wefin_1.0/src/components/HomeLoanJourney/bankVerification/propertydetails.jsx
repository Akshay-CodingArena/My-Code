import React from "react";
import Joi from "joi-browser";
import Form from "../../../components/common/form";
import Radio from "../../common/Radio";
import PersonalInput from "../../common/personalInput";
import Pincode from "../../common/pincode";
import { ReactComponent as LocationIcon } from "../../../include/assets/homepageIcons/icon-pincode.svg";
import { ReactComponent as EmailIcon } from "../../../include/assets/emailIcon.svg";
import { Thumbs } from "react-responsive-carousel";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { decryptStore, encryptStore } from "../../../Utils/store";
import { ReactComponent as Money } from "../../../include/assets/money.svg";
import PersonalAmountInput from "../../common/personalAmountInput";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import {
    updateBankOffer,
    getBankOffer,
    setOfferList,
    setBankOfferList,
} from "../../../store/bankOffer";
import PATH from "../../../paths/Paths";
import BackDropComponent from "../../../common/BackDropComponent";
class AdditionalInfoPropertyDetails extends Form {
    state = {
        data: {
            propertyIdentified: '0',
            propertyCity: '',
            email: ''
        }, errors: {}
    };

    schema = {
        propertyIdentified: Joi.string()
            .required("")
            .error(() => {
                return { message: "Property Identified is required" };
            }),
        propertyCity: Joi.string().allow(null).allow('').error(() => { return { message: "Property City is required." }; }),
        email: Joi.string()
            .email()
            .max(50)
            .required()
            .label("Email")
            .error((errors) => {
                errors.forEach((err) => {
                    switch (err.type) {
                        case "any.empty":
                            err.message = "Email field is required";
                            break;

                        case "string.email":
                            err.message = "Email field is invalid";
                            break;
                        case "string.max":
                            err.message = "Email field is invalid";
                            break;
                    }
                });
                return errors;
            }),
        propertyValue: Joi.string().allow(null).allow(''),
        pincode: Joi.string().allow(null).allow(''),
        propertyState: Joi.string().allow(null).allow(''),
    };





    onChangePropertyIdentified = (type) => {
        const data = { ...this.state.data };
        data.propertyIdentified = type;
        this.setState({ data })
    };

    _handlePropertyValue = (e) => {
        const propertyValue = e.target.value;
        let data = { ...this.state.data };
        data.propertyValue = propertyValue.replace(/\D+/g, "");
        this.setState({ data });
    }

    __handlePinCode = (e) => {
        e.preventDefault();
        let mobile = localStorage.getItem("mobilenumber");
        if (e.target.value.length === 6) {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            this.setState({ data });
            let formData = { mobile: mobile, pincode: e.target.value };
            this.props.loadPinCode(formData, this.callbackPin);
        }
        else {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            data.propertyCity = '';
            data.propertyState = '';
            this.setState({ data })
        }
    };


    callbackPin = (res) => {
        if (res) {
            let errors = { ...this.state.errors };
            if (res.data.success === false) {
                errors.pincode = res.data.message;
                errors.propertyCity = '';
                errors.propertyState = '';
                this.setState({ errors });
            } else if (res.data.success === true) {
                errors.pincode = "";
                let data = { ...this.state.data }
                data.propertyCity = res.data.data.cityname;
                data.propertyState = res.data.data.statename;
                errors.propertyCity = '';
                errors.propertyState = '';
                this.setState({ data })
                this.setState({ errors })
            }
        }

    };


    doSubmit = () => {
        let errors = { ...this.setState({ errors: {} }) }
        if (this.state.data.propertyIdentified === '1' && this.state.data.propertyCity.trim().length === 0) {
            errors.pincode = 'Pincode is required'
            this.setState({ errors });
            return;
        }
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        let { loansfid } = decryptedData;
        let bank = this.props.location.state
        let additionalInfo = this.props.hlData.data
        let data = this.state.data
        let setDetailsData = {
            loanId: loansfid,
            loanType: bank.loanType,
            mobile: localStorage.getItem("mobilenumber"),
            lenderId: bank.lender_id__c,
            propertyIdentified: data.propertyIdentified === '1' ? 'yes' : 'no',
            propertyCity: data.propertyCity,
            officeMailId: data.email,
            addLine1: additionalInfo.add1,
            addLine2: additionalInfo.add2,
            pincode: additionalInfo.pincode,
            city: additionalInfo.propertyCity,
            state: additionalInfo.propertyState,
            propertyValue: data.propertyValue
        };
        this.props.setBankOfferList(setDetailsData, this.callBackSetOffer);
    }

    callBackSetOffer = (res) => {
        let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
        let { loanName } = decryptedData;
        this.props.history.push({
            pathname: `${PATH.PRIVATE.CONGRATULATION_SCREEN}`, state:
            {
                loanType: this.props.location.state.loanType,
                leadId: res?.data?.bajajHlData?.productOffer?.leadId,
                loanName: loanName
            }
        })
    }




    render() {

        return (
            <>
                {this.props.loadingBank || this.props.pinCodeLoading
                    ? (
                        <BackDropComponent />
                    ) : (
                        ""
                    )}
                <div className="row insideFormBlock">
                    <div className="col-sm-12 text-center">
                        <div className="bsFormHeader">
                            <h1> Additional Information </h1>
                        </div>
                    </div>

                    <div className="col-sm-12">
                        <form className="panVeryfyForm">
                            <ul className="nav nav-pills bs-form-tab">
                                <li>
                                    <a className="active">Property Details</a>
                                </li>
                            </ul>
                            <div class="tab-content clearfix">
                                <div className="row">
                                    <div className="col-sm-12">
                                        <label htmlFor="EmployeeType">
                                            Property Identified
                                            <span style={{ color: "#FF4C30" }}>*</span>
                                        </label>
                                    </div>

                                    <div className="col-sm-6">
                                        <Radio
                                            value={'1'}
                                            label={'Yes'}
                                            groupValue={this.state.data.propertyIdentified}
                                            onClick={() => this.onChangePropertyIdentified('1')}
                                        />

                                        <Radio
                                            value={'0'}
                                            label={'No'}
                                            groupValue={this.state.data.propertyIdentified}
                                            onClick={() => {

                                                let data = this.state.data;
                                                data.pincode = '';
                                                data.propertyCity = '';
                                                data.propertyState = '';
                                                data.propertyValue = ''
                                                this.setState({ data })
                                                this.onChangePropertyIdentified('0')
                                            }}
                                        />
                                    </div>
                                    <div className="col-sm-6" style={{ marginTop: "-35px" }}>
                                        <PersonalAmountInput
                                            value={this.state.data.propertyValue}
                                            error={this.state.errors.propertyValue}
                                            icon={<Money />}
                                            label="Property Value"
                                            readOnly={
                                                this.state.data.propertyIdentified === '0' ? true : false
                                            }
                                            __handleChange={this._handlePropertyValue}

                                        />
                                    </div>


                                    <div className="col-sm-6" >
                                        <PersonalInput
                                            value={this.state.data.pincode}
                                            error={this.state.errors.pincode}
                                            icon={<LocationIcon />}
                                            label="Property Pincode"
                                            readOnly={
                                                this.state.data.propertyIdentified === '0' ? true : false
                                            }
                                            __handleChange={this.__handlePinCode}
                                        />
                                    </div>
                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.propertyCity}
                                            error={this.state.errors.propertyCity}
                                            icon={<LocationIcon />}
                                            label="Property City"
                                            readOnly={true}
                                        />
                                    </div>
                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.propertyState}
                                            error={this.state.errors.propertyState}
                                            icon={<LocationIcon />}
                                            label="Property state"
                                            readOnly={true}
                                        />
                                    </div>




                                    <div className="col-sm-6">
                                        {this.renderEmail(
                                            "email",
                                            "Email ID",
                                            <EmailIcon />,
                                            false
                                        )}
                                    </div>

                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Next
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    setBankOffer: getBankOffer(state).setBankOffer,
    loadingBank: getBankOffer(state).loadingBank,
    pinCodeLoading: getpinCode(state).loading,
});

const mapDispatchToProps = (dispatch) => ({
    setBankOfferList: (params, callBack) =>
        dispatch(setBankOfferList(params, callBack)),
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
});
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AdditionalInfoPropertyDetails))
