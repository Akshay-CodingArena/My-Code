import Joi from "joi-browser";
import Form from "../../../components/common/form";
import CONSTANTS from "../../../constants/Constants";
import { ReactComponent as LocationIcon } from "../../../../src/include/assets/homepageIcons/icon-pincode.svg";
import TopNavBar from "../../../common/TopNavBar";
import { Container, Row, Col } from "react-bootstrap";
import LeftMenuDecider from "../../../common/leftMenuContent";
import CreditFooter from "../../../../src/components/cibilFlow/footer";
import BackDropComponent from "../../../common/BackDropComponent";
import { ReactComponent as AddressLine1Icon } from "../../../include/assets/fullertonLogos/Group 16992.svg";
import Pincode from "../../common/pincode";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import PersonalInput from "../../common/personalInput";
import { decryptStore } from "../../../Utils/store";
import moment from "moment";
class HomeLoanAddtionalInfo extends Form {
  state = {
    data: {}, errors: {}
  };


  componentDidMount = () => {
    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

    if (decryptedData.isDropoff && decryptedData.lenderName === "HDFC") {
      let dropOffData = this.props.dropoffData;
      let data = { ...this.state.data };
      data.add1 = dropOffData.address1resi ? dropOffData.address1resi : "";
      data.add2 = dropOffData.address1resi ? dropOffData.address2resi : "";
      data.pincode = dropOffData.residence_pincode ? dropOffData.residence_pincode : "";
      data.propertyCity = dropOffData.city_residence ? dropOffData.city_residence : "";
      data.propertyState = dropOffData.state_residence ? dropOffData.state_residence : "";
      data.stayingSince = dropOffData.address_from_year ? dropOffData.address_from_year : "";
      data.stayingInCitySince = dropOffData.city_from_year ? dropOffData.city_from_year : "";

      this.setState({ data })
    }
  }
  schema = decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC" ? {
    buildingName: Joi.string().allow(null).allow(''),
    add1: Joi.string()
      .required("")
      .error(() => {
        return { message: "Address 1 is required." };
      }),
    add2: Joi.string()
      .required("")
      .error(() => {
        return { message: "Address 2 is required." };
      }),
    pincode: Joi.number()
      .required()
      .label("Pin Code")
      .error(() => {
        return { message: "Pincode field is required." };
      }),
    propertyCity: Joi.string()
      .required("")
      .error(() => {
        return { message: "Property City is required." };
      }),
    propertyState: Joi.string()
      .required("")
      .error(() => {
        return { message: "Property State is required." };
      }),
    stayingSince: Joi.string()
      .required("")
      .error(() => {
        return { message: "This field is required." };
      }),
    stayingInCitySince: Joi.string()
      .required("")
      .error(() => {
        return { message: "This field is required." };
      }),

  } : {
    add1: Joi.string().allow(null).allow(''),
    add2: Joi.string().allow(null).allow(''),
    pincode: Joi.number()
      .required()
      .label("Pin Code")
      .error(() => {
        return { message: "Pincode field is required." };
      }),
    propertyCity: Joi.string()
      .required("")
      .error(() => {
        return { message: "Property City is required." };
      }),
    propertyState: Joi.string()
      .required("")
      .error(() => {
        return { message: "Property State is required." };
      }),
  };


  doSubmit = () => {

    let errors = {};

    if (decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC") {

      const data = { ...this.state.data };

      if (!(data.stayingInCitySince >= 1970 && data.stayingInCitySince <= new Date().getFullYear())) {
        errors.stayingInCitySince = `Value must be between 1970 & ${new Date().getFullYear()}.`;
        this.setState({ errors: errors });
        return;
      }

      if (!(data.stayingSince >= 1970 && data.stayingSince <= new Date().getFullYear())) {
        errors.stayingSince = `Value must be between 1970 & ${new Date().getFullYear()}.`;
        this.setState({ errors: errors });
        return;
      }

      if (parseInt(data.stayingInCitySince) > parseInt(data.stayingSince)) {
        errors.stayingSince = `Value must be greater than or equal to ${data.stayingInCitySince}`;
        this.setState({ errors: errors });
        return;
      }

      localStorage.setItem("loanInfo", JSON.stringify({ ...this.props.stepperData, data }));

      this.props.setStepperData({ ...this.props.stepperData, data })
      this.props.updateStep(null, CONSTANTS.OFFICE_ADDRESS_HDFC);
    } else {
      const data = { ...this.state.data };
      this.props.setHLData({ ...this.props.hlData, data });
      this.props.updateStep(null, CONSTANTS.RENDER_HOME_LOAN_ADDITIONAL_INFO_PROPERTY_DETAILS);
    }
  };


  __handlePinCode = (e) => {
    e.preventDefault();
    let mobile = localStorage.getItem("mobilenumber");
    if (e.target.value.length === 6) {
      const data = { ...this.state.data };
      data.pincode = e.target.value;
      this.setState({ data });
      let formData = { mobile: mobile, pincode: e.target.value };
      this.props.loadPinCode(formData, this.callbackPin);
    }
    else {
      const data = { ...this.state.data };
      data.pincode = e.target.value;
      data.propertyCity = '';
      data.propertyState = '';
      this.setState({ data })
    }
  };

  callbackPin = (res) => {
    if (res) {
      let errors = { ...this.state.errors };
      if (res.data.success === false) {
        errors.pincode = res.data.message;
        errors.propertyState = '';
        errors.propertyCity = '';
        this.setState({ errors });
      } else if (res.data.success === true) {
        errors.pincode = "";
        let data = { ...this.state.data }
        data.propertyState = res.data.data.statename;
        data.propertyCity = res.data.data.cityname;
        errors.propertyState = '';
        errors.propertyCity = '';
        this.setState({ data })
        this.setState({ errors })
        if (decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC") {
          this.props.setStepperData({ ...this.props.stepperData, propertyCity: res.data.data.cityname, residenceStateId: res.data.data.state__c })
        }
      }
    }

  };

  render() {
    let decryptedData = decryptStore(localStorage.getItem("mobile"));
    return (
      <>
        {
          (this.props.pinCodeLoading) ? (
            <BackDropComponent />
          ) : (
            ""
          )}

        <div className="row insideFormBlock">
          <div className="col-sm-12 text-center">
            <div className="bsFormHeader">


              <h1> Additional Information </h1>
            </div>
          </div>

          <div className="col-sm-12">
            {this.state.loading ? <BackDropComponent /> : ""}
            <form className="panVeryfyForm">
              <ul className="nav nav-pills bs-form-tab">
                <li>
                  <a className="active">Current Address</a>
                </li>

              </ul>
              <div class="tab-content clearfix">
                <div className="row">
                  {decryptedData.lenderName === "HDFC" ?
                    <div className="col-sm-6">
                      {" "}
                      {this.renderInput(
                        "buildingName",
                        "Building Name",
                        < AddressLine1Icon />,
                        false,
                        20,
                        20,
                        "text",
                        false
                      )}
                    </div>
                    : null}
                  <div className="col-sm-6">
                    {" "}
                    {this.renderInput(
                      "add1",
                      "Address Line 1",
                      < AddressLine1Icon />,
                      false,
                    )}
                  </div>
                  <div className="col-sm-6">
                    {this.renderInput(
                      "add2",
                      "Address Line 2",
                      <AddressLine1Icon />,
                      false,

                    )}
                  </div>

                  <div className="col-sm-6">
                    <Pincode
                      __handlePinCode={this.__handlePinCode}
                      value={this.state.data.pincode}
                      error={this.state.errors.pincode}
                    />
                  </div>

                  <div className="col-sm-3">
                    <PersonalInput
                      value={this.state.data.propertyCity}
                      error={this.state.errors.propertyCity}
                      icon={<LocationIcon />}
                      label="City"
                      readOnly={true}
                    />
                  </div>

                  <div className="col-sm-3">
                    <PersonalInput
                      value={this.state.data.propertyState}
                      error={this.state.errors.propertyState}
                      icon={<LocationIcon />}
                      label="State"
                      readOnly={true}
                    />
                  </div>
                  {
                    decryptStore(localStorage.getItem("mobilenumber")).lenderName === "HDFC" ?
                      <>
                        <div className="col-sm-6">
                          <PersonalInput
                            value={this.state.data?.stayingInCitySince}
                            error={this.state.errors?.stayingInCitySince}
                            icon={<AddressLine1Icon />}
                            label="Residing in the city from year(YYYY)"
                            readOnly={false}
                            placeholder="YYYY"
                            __handleChange={(e) => {

                              let newString = e.target.value.replace(/[^0-9]/ig, "")
                              let errors = { ...this.state.errors }
                              if (newString.length <= 4) {
                                this.setState({
                                  ...this.state,
                                  data: { ...this.state.data, stayingInCitySince: newString },
                                  errors: errors
                                })
                              }
                            }
                            }
                          />


                        </div>

                        <div className="col-sm-6">
                          <PersonalInput

                            value={this.state.data?.stayingSince}
                            error={this.state.errors?.stayingSince}
                            icon={<AddressLine1Icon />}
                            label="The Year you moved at address(YYYY)"
                            placeholder="YYYY"
                            readOnly={false}
                            __handleChange={(e) => {

                              let newString = e.target.value.replace(/[^0-9]/ig, "")

                              if (newString.length <= 4) {
                                let errors = { ...this.state.errors }
                                errors.stayingSince = ""
                                this.setState({
                                  ...this.state,
                                  data: { ...this.state.data, stayingSince: newString },
                                  errors: errors
                                })
                              }
                            }
                            }
                          />


                        </div>
                      </>
                      : null
                  }

                  <div className="col-sm-12 text-center">
                    <button
                      type="submit"
                      onClick={this.handleSubmit}
                      variant="contained"
                      className="nextButton"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  pinCodeLoading: getpinCode(state).loading
});

const mapDispatchToProps = (dispatch) => ({
  loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(HomeLoanAddtionalInfo)
);