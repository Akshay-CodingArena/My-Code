import React from "react";
import CONSTANTS from "../../../constants/Constants";
import { useHistory, useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import ReactLottie from "../../common/reactLotte";
import PATH from "../../../paths/Paths";
import { useEffect } from "react";
import TickLogo from "../../../include/assets/icons/newticklogo.svg";
import TopNavBar from "../../../common/TopNavBar";
import CreditFooter from "../../../components/cibilFlow/footer";
import { useState } from "react";


const Congratulation = (props) => {

    const [nameDetails, setNameDetails] = useState({
        fullName: ''
    });
    const history = useHistory();
    const location = useLocation();

    useEffect(() => {
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");

        let OrgName = '';
        let name = localStorage.getItem('fullName') ? localStorage.getItem('fullName').split(" ") : [];
        for (let i = 0; i < name.length; ++i) {
            OrgName += name[i].charAt(0).toUpperCase() + name[i].slice(1).toLowerCase() + " ";
        }
        setNameDetails({ ...nameDetails, fullName: OrgName });
    }, [])

    return (<React.Fragment>
        <TopNavBar />
        <div className="CongratsContainer backImage">
            <div className="mt-3" style={{ position: "absolute" }}>
                <ReactLottie keyIndex={1} />
            </div>

            <div className="CongratsMain">
                <div className="mt-3" style={{ margin: "auto", width: "65%" }}>
                    <div>
                        <div
                            style={{
                                padding: "40px 20px 0px 20px",
                                marginBottom: "30px",
                                textAlign: "center",
                                color: "#2E0080",
                                fontWeight: "600",
                                fontSize: "35px",
                            }}
                        >
                            Thank You!
                            <div>{nameDetails.fullName}</div>
                        </div>
                    </div>
                    {props?.location?.state &&
                        props?.location?.state?.lenderName === "Fullerton India Credit" ? (
                        <div
                            style={{
                                textAlign: "center",
                                color: "#4E4E4E",
                                fontWeight: "400",
                                fontSize: "22px",
                            }}
                        >
                            Dear {localStorage.getItem("firstName")}, Your loan application
                            has been
                            <br />
                            approved Complete Your KYC for Disbursal.
                        </div>
                    ) : props?.location?.state?.card &&
                        props?.location?.state?.card?.bank_name === "SCB" ? (
                        <div
                            style={{
                                textAlign: "center",
                                color: "#4E4E4E",
                                fontWeight: "400",
                                fontSize: "22px",
                            }}
                        >
                            Dear {localStorage.getItem("firstName")}, Your Credit Card
                            application has been approved !!
                            <br />
                            You will shortly receive a call from the bank to complete your
                            process to issue your Card.
                        </div>
                    ) : props?.location?.state &&
                        props?.location?.state?.lenderName === "Standard Chartered" ? (
                        <div
                            style={{
                                textAlign: "center",
                                color: "#4E4E4E",
                                fontWeight: "400",
                                fontSize: "22px",
                            }}
                        >
                            Dear {localStorage.getItem("firstName")}, Your Loan Application
                            has been approved !!
                            <br />
                            You will shortly receive a call from the bank to complete your
                            loan disbursal.
                        </div>
                    ) : props?.location?.state &&
                        props?.location?.state?.lenderName === "Equitas" ? (
                        <div
                            style={{
                                textAlign: "center",
                                color: "#4E4E4E",
                                fontWeight: "400",
                                fontSize: "22px",
                            }}
                        >
                            Dear {localStorage.getItem("firstName")}, Your Loan Application
                            for Personal Loan
                            <br /> has been generated !!
                        </div>
                    ) :
                        (
                            <>
                                <div
                                    style={{
                                        textAlign: "center",
                                        color: "#4E4E4E",
                                        fontWeight: "400",
                                        fontSize: "24px",
                                    }}
                                >
                                    Thank you for showing interest. Our BankSe Loan Expert Team will get back to you shortly.
                                    <div className="mt-3">{location?.state?.loan_application_number ? `Application No : ${location?.state?.loan_application_number}` : ``}</div>
                                </div>
                                <div style={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center"
                                }}>
                                    <img src={TickLogo} alt="congratulation_tickmark" />
                                </div>
                            </>
                        )}

                    {props?.location?.state &&
                        props?.location?.state?.lenderName === "Fullerton India Credit" ? (
                        <h2
                            onClick={(e) => {
                                props.updateStep(e, CONSTANTS?.RENDER_UPLOAD_DOCUMENTS);
                            }}
                        >
                            Upload Your Documents
                        </h2>
                    ) : props?.location?.state &&
                        props?.location?.state?.lenderName === "Equitas" ? (
                        <h2
                            style={{
                                padding: "40px 20px 0px 20px",
                                marginBottom: "20px",
                                textAlign: "center",
                                color: "#2E0080",
                                fontSize: "21px",
                                lineHeight: "0px",
                                textDecoration: "underline",
                                cursor: "pointer",
                            }}
                            onClick={() => {
                                history.push({
                                    pathname: `${PATH.PRIVATE.UPLOAD_BANK_STATEMENT}${PATH.PRIVATE.LOAN_TYPE_PERSONAL_LOAN}`,
                                    state: props.location.state,
                                });
                            }}
                        >
                            Submit Your Income Proof{" "}
                        </h2>
                    ) : (
                        <Link to={PATH.PRIVATE.PRODUCTS}>
                            <h2
                                style={{
                                    padding: "40px 20px 0px 20px",
                                    marginBottom: "20px",
                                    textAlign: "center",
                                    color: "#2E0080 ",
                                    fontSize: "21px",
                                    lineHeight: "0px",
                                    textDecoration: "underline",
                                    fontWeight: "600"
                                }}
                            >
                                Go to Home
                            </h2>
                        </Link>
                    )}
                </div>
            </div>
        </div>
        <CreditFooter />
    </React.Fragment>
    );
};
export default Congratulation;
