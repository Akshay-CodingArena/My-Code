import React, { Component } from "react";
import EmployeeType from "../../common/employeeType";
import PersonalAmountInput from "../../common/personalAmountInput";
import { ReactComponent as Money } from "../../../include/assets/money.svg";
import SelectSearch from "../../common/select";
import { HL_LoanAmountDropdown, HL_PropertyTypeDropdown } from "../../common/dropdownValues";
import { ReactComponent as BusinessCenterIcon } from "../../../include/assets/business.svg";
import PersonalInput from "../../common/personalInput";
import Pincode from "../../common/pincode";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { getpinCode, loadPinCode } from "../../../store/pincode";
import Joi, { displayStack } from "joi-browser";
import Form from "../../common/form";
import PATH from "../../../paths/Paths";
import TopNavBar from "../../../common/TopNavBar";
import CreditFooter from "../../../components/cibilFlow/footer";
import { decryptStore } from "../../../Utils/store";
import { applyHomeLoan, getHomeLoanDetails } from "../../../store/homeLoan";
import Swal from "sweetalert2";
import BackDropComponent from "../../../common/BackDropComponent";
import { ReactComponent as LocationIcon } from "../../../include/assets/homepageIcons/icon-pincode.svg";
import { ReactComponent as PropertyIcon } from "../../../include/assets/icons/property.svg";
import { ReactComponent as PropertyValueIcon } from "../../../include/assets/icons/propertyvalue.svg";
import Radio from "../../common/Radio";
import CONSTANTS from "../../../constants/Constants";

class ApplyHomeLoan extends Form {
    constructor(props) {
        super(props);
        this.state = {
            data: {},
            errors: {},
            loading: true
        };
    }


    schema = {
        monthlyIncome: Joi.string()
            .required("")
            .error(() => {
                return { message: "Monthly Income is required" };
            }),
        employeeType: Joi.string()
            .required("")
            .error(() => {
                return { message: "Employee Type is required" };
            }),
        propertyType: Joi.object()
            .required()
            .error(() => {
                return { message: "Property Type is required" };
            }),
        propertyAddress: Joi.string()
            .required()
            .error(() => {
                return { message: "Property Address is required." };
            }),
        loanAmount: Joi.object()
            .required("")
            .error(() => {
                return { message: "Loan Amount is required." };
            }),
        propertyValue: Joi.string()
            .required("")
            .error(() => {
                return { message: "Property Value is required." };
            }),
        propertyCity: Joi.string()
            .required("")
            .error(() => {
                return { message: "Property City is required." };
            }),
        propertyState: Joi.string()
            .required("")
            .error(() => {
                return { message: "Property State is required." };
            }),
        pincode: Joi.number()
            .required()
            .min(6)
            .error((error) => {
                return { message: "Pin Code is required." };
            })
    };


    componentDidMount = () => {
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");

        window.scrollTo(0, 0);
        const data = { ...this.state.data };
        data.employeeType = "1";
        data.loanAmount = "";
        data.propertyValue = "";
        data.propertyType = "";
        data.propertyAddress = "";
        data.pincode = "";
        data.propertyCity = "";
        data.propertyState = "";
        data.monthlyIncome = "";
        this.setState({ data: data, loading: false });
    };


    doSubmit = () => {
        let data = this.state.data;

        let mobile = localStorage.getItem("mobilenumber");
        let decryptedData = decryptStore(mobile);
        let { loansfid, loanType } = decryptedData;

        let formData =
        {
            mobile: localStorage.getItem('mobilenumber'),
            propType: data.propertyType.value,
            propValue: data.propertyValue,
            loanAmount: data.loanAmount.value,
            applicantType: data.employeeType,
            loanId: loansfid,
            propPin: data.pincode,
            addLine1: data.propertyAddress,
            monthlyIncome: data.monthlyIncome,
            loanType: loanType
        }
        this.props.applyHomeLoan(formData, this.applyHomeLoanCallback)
    }

    applyHomeLoanCallback = async (res) => {
        try {
            let r = await res;

            if (r.data.success) {
                this.props.history.push({
                    pathname: `${PATH.PRIVATE.CONGRATULATION_SCREEN}`, state:
                    {
                        loan_application_number: r?.data?.data?.loanName,
                        loan_type: CONSTANTS.LOAN_TYPE.HOME_LOAN
                    }
                })
            } else throw r.data.message.toString();
        } catch (e) {
            Swal.fire({
                position: "center",
                icon: "warning",
                title: e?.message ? e.message.toString() : e.toString(),
                showConfirmButton: false,
                timer: 1800,
            });
        }
    }

    onChangeEmploymentType = (type) => {
        const data = { ...this.state.data };
        data.employeeType = type;
        this.setState({ data })
    };

    _handleChange = (key, e) => {
        let data = {};


        switch (key) {
            case 'propertyValue':
                const propertyValue = e.target.value;
                data = { ...this.state.data };
                data.propertyValue = propertyValue.replace(/\D+/g, "");
                this.setState({ data });
                break;
            case 'monthlyIncome':
                const monthlyIncome = e.target.value;
                data = { ...this.state.data };
                data.monthlyIncome = monthlyIncome.replace(/\D+/g, "");
                this.setState({ data });
                break;

            case 'propertyAddress':
                const propertyAddress = e.target.value;
                data = { ...this.state.data };
                data.propertyAddress = propertyAddress;
                this.setState({ data });
                break;

        }

        e.preventDefault();
    }


    __handlePinCode = (e) => {
        console.log(e.target.value)

        let mobile = localStorage.getItem("mobilenumber");
        if (e.target.value.length === 6) {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            this.setState({ data });
            let formData = { mobile: mobile, pincode: e.target.value };
            this.props.loadPinCode(formData, this.callbackPin);
        }
        else {
            const data = { ...this.state.data };
            data.pincode = e.target.value;
            data.propertyCity = '';
            data.propertyState = '';
            this.setState({ data })
        }


    };

    callbackPin = (res) => {

        if (res) {
            let errors = { ...this.state.errors };
            if (res.data.success === false) {
                errors.pincode = res.data.message;
                errors.propertyState = '';
                errors.propertyCity = '';
                this.setState({ errors });
            } else if (res.data.success === true) {
                errors.pincode = "";
                let data = { ...this.state.data }
                data.propertyState = res.data.data.statename;
                data.propertyCity = res.data.data.cityname;
                errors.propertyState = '';
                errors.propertyCity = '';
                this.setState({ data })
                this.setState({ errors })
            }
        }

    };


    render() {
        return <React.Fragment>
            {
                (this.props.loading || this.props.pinCodeLoading || this.state.loading) ? (
                    <BackDropComponent />
                ) : (
                    ""
                )}
            <TopNavBar />
            <section className="bs-main-section">
                <div className="row insideFormBlock">
                    <div className="col-sm-12 text-center">
                        <div className="bsFormHeader">
                            <h1>We will check Home Loan offer against your details.</h1>
                        </div>
                    </div>
                    <div className="col-sm-12">
                        <form className="panVeryfyForm">
                            <div className="panFormFields">
                                <div className="row">
                                    <div className="col-sm-12">

                                        <label htmlFor="EmployeeType">
                                            Employment Type
                                            <span style={{ color: "#FF4C30" }}>*</span>
                                        </label>
                                    </div>

                                    <div className="col-sm-12">
                                        <Radio
                                            value={'1'}
                                            label={'Salaried'}
                                            groupValue={this.state.data.employeeType}
                                            onClick={() => this.onChangeEmploymentType('1')}
                                        />

                                        <Radio
                                            value={'2'}
                                            label={'Self Employed Business'}
                                            groupValue={this.state.data.employeeType}
                                            onClick={() => this.onChangeEmploymentType('2')}
                                        />

                                        <Radio
                                            value={'3'}
                                            label={'Self Employed Professional'}
                                            groupValue={this.state.data.employeeType}
                                            onClick={() => this.onChangeEmploymentType('3')}
                                        />
                                    </div>

                                    <div className="col-sm-6 mt-3">
                                        <SelectSearch
                                            style={{ margin: "15px 8px 20px" }}
                                            placeholderValue={"Loan Amount"}
                                            label={"Loan Amount"}
                                            value={this.state.data.loanAmount}
                                            page="personal"
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.loanAmount = e;
                                                    errors.loanAmount = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={HL_LoanAmountDropdown}
                                            error={this.state.errors.loanAmount}
                                            icon={
                                                <Money
                                                    style={{ marginRight: "5px", marginTop: "2px" }}
                                                />
                                            }
                                        ></SelectSearch>
                                    </div>

                                    <div className="col-sm-6 mt-3">
                                        <PersonalAmountInput
                                            value={this.state.data.monthlyIncome}
                                            __handleChange={(e) => this._handleChange('monthlyIncome', e)}
                                            error={this.state.errors.monthlyIncome}
                                            icon={<Money />}
                                            label="Monthly Income"
                                            required={true}
                                        />
                                    </div>



                                    <div className="col-sm-6">
                                        <SelectSearch
                                            style={{ margin: "15px 8px 20px" }}
                                            placeholderValue={"Select Property Type"}
                                            label={"Property Type"}
                                            value={this.state.data.propertyType}
                                            page="personal"
                                            setSelectedOption={(e) => {
                                                const data = { ...this.state.data };
                                                const errors = { ...this.state.errors };
                                                if (e) {
                                                    data.propertyType = e;
                                                    errors.propertyType = "";
                                                    this.setState({ data, errors });
                                                }
                                            }}
                                            dropDownOptions={HL_PropertyTypeDropdown}
                                            error={this.state.errors.propertyType}
                                            icon={
                                                <PropertyIcon
                                                    style={{ marginRight: "5px", marginTop: "2px" }}
                                                />
                                            }
                                        ></SelectSearch>

                                    </div>
                                    <div className="col-sm-6">
                                        <PersonalAmountInput
                                            value={this.state.data.propertyValue}
                                            __handleChange={(e) => this._handleChange('propertyValue', e)}
                                            error={this.state.errors.propertyValue}
                                            icon={<PropertyValueIcon />}
                                            label="Property Value"
                                            required={true}
                                        />
                                    </div>
                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.propertyAddress}
                                            error={this.state.errors.propertyAddress}
                                            icon={<LocationIcon />}
                                            label="Property Address"
                                            readOnly={false}
                                            __handleChange={(e) => this._handleChange('propertyAddress', e)}
                                        />
                                    </div>
                                    <div className="col-sm-6">
                                        <Pincode
                                            value={this.state.data.pincode}
                                            __handlePinCode={this.__handlePinCode}
                                            error={this.state.errors.pincode}
                                        />
                                    </div>
                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.propertyCity}
                                            error={this.state.errors.propertyCity}
                                            icon={<LocationIcon />}
                                            label="City"
                                            readOnly={true}
                                        />
                                    </div>

                                    <div className="col-sm-6">
                                        <PersonalInput
                                            value={this.state.data.propertyState}
                                            error={this.state.errors.propertyState}
                                            icon={<LocationIcon />}
                                            label="State"
                                            readOnly={true}
                                        />
                                    </div>


                                    <div className="col-sm-12 text-center">
                                        <button
                                            type="submit"
                                            onClick={this.handleSubmit}
                                            variant="contained"
                                            className="nextButton"
                                        >
                                            Submit
                                        </button>

                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <CreditFooter />
            </section>

        </React.Fragment>
    }
}

const mapStateToProps = (state) =>
({
    loading: getHomeLoanDetails(state).loading,
    pinCodeLoading: getpinCode(state).loading

});
const mapDispatchToProps = (dispatch) => ({
    loadPinCode: (params, callback) => dispatch(loadPinCode(params, callback)),
    applyHomeLoan: (params, callback) => dispatch(applyHomeLoan(params, callback))
});

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ApplyHomeLoan)
);
