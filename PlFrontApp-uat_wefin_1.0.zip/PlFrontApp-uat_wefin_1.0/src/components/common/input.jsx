import React from "react";
import * as DOMPurify from 'dompurify';

const Input = ({
  name,
  label,
  icon,
  readOnly,
  max,
  min,
  type,
  required,
  error,
  value,
  decapitalize,
  ...rest
}) => {
  return (
    <div className="form-group">
      <label htmlFor={label}>
        {label}
        <span style={{ color: "#FF4C30" }}>{required === false ? '' : '*'}</span>
      </label>
      <input
        className="form-control"
        style={{ textTransform: decapitalize ? "none" : "capitalize" }}
        placeholder={label}
        name={name}
        id={name}
        value={DOMPurify.sanitize(value)}
        readOnly={readOnly}
        maxLength={max}
        minLength={min}
        type={type}
        {...rest}
      />

      <span className="input-icon">{icon}</span>
      {error && <p className="error-form">{error}</p>}
    </div>
  );
};
export default Input;
