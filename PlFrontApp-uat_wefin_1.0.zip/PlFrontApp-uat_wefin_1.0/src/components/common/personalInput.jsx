import React from "react";
import * as DOMPurify from 'dompurify';

const PersonalInput = (props) => {
  return (
    <div className="form-group" autocomplete="false">
      <label htmlFor={props.label}>
        {props.label}
        <span style={{ color: "#FF4C30" }}>{props.required === false ? '' : '*'}</span>
      </label>
      <input
        className="form-control"
        placeholder={props.placeholder ? props.placeholder : props.label}
        value={DOMPurify.sanitize(props.value)}
        onChange={(e) => props.__handleChange(e)}
        readOnly={props.readOnly}
        maxLength={props.max}
        minLength={props.min}
      />

      <span className="input-icon">{props.icon}</span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default PersonalInput;
