import React from "react";
import InputMask from "react-input-mask";
import { ReactComponent as DocExpiry } from "../../include/assets/homepageIcons/icon-dob.svg";

const InputWithMask = (props) => (
  <InputMask mask="99-99-9999" value={props.value} onChange={props.onChange}>
    {(inputProps) => <input  {...props} type="tel" disableUnderline />}
  </InputMask>
);
const Date = (props) => {

  return (
    <div className="form-group">
      <label htmlFor={props.label}>
        {props.label}
        <span style={{ color: "#FF4C30" }}>*</span>
      </label>
      <InputWithMask
        className="form-control"
        placeholder="DD-MM-YYYY"
        value={props.value ? props.value : ""}
        onChange={(e) => {
          props.onDateChange(e);
        }}
      />
      <span className="input-icon">
        {" "}
        <DocExpiry />
      </span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default Date;
