import React from "react";
import Select, { components } from "react-select";
import { decryptStore } from "../../Utils/store";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getEmploersForHdfc } from "../../store/personalLoan/hdfc";


const { Option } = components;

export const selectStyles = {
  control: (provided) => ({
    ...provided,
    height: "40px",
    paddingLeft: "5px",
    borderColor: "#E0E0E0",
    borderWidth: "1px",
    boxShadow: "0 0 0 0px #2e0080",
    width: "100%",
    "&:hover": {
      borderColor: "#2e0080",
      borderWidth: "1px",
    },
    "&:focus": {
      borderColor: "#2e0080",
      borderWidth: "1px",
    },
  }),
  option: (provided, state) => ({
    ...provided,
    borderBottom: "0.5px solid rgba(46, 0, 128, 0.5)",
    // textAlign: "left",
    fontSize: "15px",
    padding: "7px 10px",
    width: "100% !important",
    maxWidth: "100% !important",
    backgroundColor: state.isSelected
      ? "#2e0080"
      : state.isFocused
        ? "rgba(46, 0, 128, 0.12)"
        : "#eae4f9",
  }),
  menu: (provided) => ({
    ...provided,
    borderRadius: "5px",
    color: "#5E5E5E",
    background: "#eae4f9",
    zIndex: 12,
    width: "100%",
  }),
  dropdownIndicator: (base) => ({
    ...base,
    marginTop: "6px",
  }),
};

const IconOption = (props) => (
  <Option {...props}>
    {props.optionIcon ? props.optionIcon : ""}
    {props.data.label}
  </Option>
);

const CustomSelectValue = (props) => (
  <div>
    {props.optionIcon ? props.optionIcon : ""}
    {props.data.label}
  </div>
);

class SelectSearch extends React.Component {
  state = {
    selectedOption: null,
  };
  handleChange = (selectedOption) => {
    this.setState({ selectedOption });
    this.props.setSelectedOption(selectedOption);
  };


  onKeyUpFunc = (e) => {
    let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
    if (decryptedData.lenderName === "HDFC") {
      let formData = {
        companyStr: e.target.value
      }
      this.props.getEmploersForHdfc(formData, this.callbackEmployersDetails)
    }
  }

  callbackEmployersDetails = (res) => { }


  render() {
    const { selectedOption } = this.state;
    const placeholder = <div> {this.props.placeholderValue}</div>;
    return (
      <div className="form-group" style={{ height: '100%' }} onKeyUp={this.onKeyUpFunc}>
        {this.props?.removeLabel ? null : <label htmlFor={this.props.label}>
          {this.props.label}
          {this.props.required === false ? "" : <span style={{ color: "#FF4C30" }}>*</span>}
        </label>}
        <Select
          style={{ marginTop: "12px" }}
          className="isSelect"
          styles={selectStyles}
          placeholder={placeholder}
          closeMenuOnSelect={true}
          onChange={this.handleChange}
          options={this.props.dropDownOptions}
          value={this.props.value ? this.props.value : selectedOption}
          maxMenuHeight={185}
          onInputChange={this.props.onInputChange}
          components={{ Option: IconOption, SingleValue: CustomSelectValue }}

        />
        <span className="dropIcon">
          {" "}
          {this.props.icon
            ? // <BusinessIcon style={{ marginBottom: "-6px", marginRight: "5px" }} />
            this.props.icon
            : ""}{" "}
        </span>
        {this.props.error && <p className="bsInputErr">{this.props.error}</p>}
      </div >
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  getEmploersForHdfc: (params, callbackDetail) =>
    dispatch(getEmploersForHdfc(params, callbackDetail))
});

const mapStateToProps = (state) => ({

});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SelectSearch)
);


