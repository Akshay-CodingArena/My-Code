export const selectStyles = {
  option: (provided, state) => ({
    ...provided,
    width: "95%",

    padding: "0px",
    color: "#707070",
    fontWeight: 500,
    backgroundColor: state.isSelected
      ? "#2e0080"
      : state.isFocused
      ? "#E5F6FD"
      : "#fff",
  }),
  menu: (provided) => ({
    ...provided,
    borderRadius: "28px",

    padding: "15px 0px 15px 28px",
    backgroundColor: "#fff",
    zIndex: 12,
  }),
  dropdownIndicator: (base) => ({
    ...base,
  }),
  control: (base) => ({
    ...base,
    border: 0,
    borderRadius: 28,
    boxShadow: "none",
  }),
  // control: (base) => ({
  //   ...base,
  //   border: 0,
  //   borderRadius: 28,
  //   boxShadow: "none",
  // }),

  bsRadio: {
    "&$checked": {
      color: "#4B8DF8",
    },
  },
};
