import React, { Component } from "react";
import pageNotFound from "../../include/assets/pagenot-found.png";
import TopNavBar from "../../common/TopNavBar";
import CreditFooter from "../../components/cibilFlow/footer";
import PATH from "../../paths/Paths";

class NotFound extends Component {
  constructor(props) {
    super(props);
    this.state = {
      otpSeconds: 5,
    };
  }

  handleOTPTimer = () => {
    let myInterval = setInterval(() => {
      if (this.state.otpSeconds > 0) {
        this.setState((state) => {
          return { otpSeconds: state.otpSeconds - 1 };
        });
      } else {
        if (this.props.isAuth) {
          (() => {
            this.props.history.goBack();
          })();
          
        } else {
          this.props.history.push(PATH.PUBLIC.INDEX);
        }

        clearInterval(myInterval);
      }
    }, 1000);
    return myInterval;
  };

  componentDidMount = () => {
    this.handleOTPTimer();
  };

  componentWillUnmount = () => {
    clearInterval(this.handleOTPTimer);
  };

  render() {
    return (
      <>
        {this.props.isAuth && <TopNavBar />}
        <section className={this.props.isAuth && "bs-cs-section"}>
          {" "}
          <div className="pageNotFoundBlock">
            <div className="container">
              <div className="row align-items-center">
                <div className="col-12 col-sm-12 col-md-6 col-lg-6 order-2 order-md-1 ">
                  <h1> Page Not Found</h1>
                  <p>
                    Something went wrong, Looks like this page doesn't exist
                    anymore.
                  </p>
                  <p>
                    Redirecting to back in{" "}
                    {this.state.otpSeconds.toString().length < 2
                      ? `0${this.state.otpSeconds}`
                      : this.state.otpSeconds}{" "}
                    secs
                  </p>
                </div>
                <div className="col-12 col-sm-12 col-md-6 col-lg-6 order-1 order-sm-2 order-md-2">
                  <img src={pageNotFound} alt="" />
                </div>
              </div>
            </div>
          </div>
          <CreditFooter />
        </section>
      </>
    );
  }
}

export default NotFound;
