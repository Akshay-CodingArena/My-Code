import React from "react";
import * as DOMPurify from 'dompurify';

const Email = ({
  name,
  label,
  icon,
  readOnly,
  max,
  min,
  error,
  value,
  ...rest
}) => {
  return (
    <div className="form-group">
      <label htmlFor={label}>
        {label}
        <span style={{ color: "#FF4C30" }}>*</span>
      </label>
      <input
        className="form-control"
        placeholder={label}
        name={name}
        id={name}
        value={DOMPurify.sanitize(value)}
        readOnly={readOnly}
        {...rest}
      />

      <span className="input-icon">{icon}</span>
      {error && <p className="error-form">{error}</p>}
    </div>
  );
};
export default Email;
