export default function mapGender(gender) {
    if (gender) {
        if (gender === "Male") {
            return '1'
        }
        if (gender == "Female") {
            return '2'
        }
        if (gender == "Other") {
            return '3'
        }
    } else {
        return undefined
    }
}