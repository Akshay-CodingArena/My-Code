import React, { Component } from "react";
import DashBoardAside from "../../common/dashboardAside";
import TopNavBar from "../../common/TopNavBar";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import { Container, Row, Col } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
class FAQ extends Component {
  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
  };
  state = { show1: true, show2: false, show3: false };
  render() {
    return (
      <>
        <TopNavBar />
        <section className="bs-main-section bs-faqs-section ">
          <Container>
            <Row>
              <Col sm={12} md={3}>
                <DashBoardAside />
              </Col>
              <Col sm={12} md={9}>
                <h3>Frequently Asked Questions</h3>
                <Accordion allowZeroExpanded>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        Is wefin a Bank or NBFC and How do wefin help me?
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        wefin is a premier digital marketplace which helps you
                        compare products, such as loans, insurance plans, and
                        credit cards , offered by leading banks & NBFCs. We
                        simplify fine print and inform you about the eligibility
                        criteria, repayment options, types of interest rates,
                        and other parameters.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        After I submit my application on wefin, what’s next?
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        Once you submit the application form, your application
                        will be matched with the best financial institution
                        based on your credit profile and will be securely sent
                        to them.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        What is a credit score?
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        It is a report based on your performance on loans. Banks
                        & NBFC use this information to assess your loan
                        applications and it is one of the primary criteria for
                        assessing your loan application. You can get a FREE
                        credit report on the wefin app & website.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How my information is treated and is it secure?
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        All your personal information is fully secured and
                        strong measures are adopted to ensure its security.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        What is an EMI and how to calculate it?
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        The full form of EMI is equated monthly instalment. It
                        is the amount of money that is paid back to the lender
                        on a monthly basis. The EMI is always paid up to the
                        bank or lender on a fixed date each month until the
                        total amount due is paid up during the tenure. You can
                        calculate your EMI for FREE on the wefin app and
                        website EMI Calculator.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How much amount can I get in personal loan and what Is
                        the turn around time.
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        You can get unsecured personal loan up to 25 Lacs as per
                        your eligibility in 2 hours subject to fulfillment of
                        lending partner criteria.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>

                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How can I get best deals for personal loans
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        You can visit wefin.in or download wefin application
                        from Play Store & App store to explore competitive
                        offers from India’s leading Banks & NBFCs.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How can I get best deals for Two Wheeler loans
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        You can visit wefin.in or download wefin application
                        from Play Store & App store to explore competitive
                        offers from India’s leading Banks.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How can I get best deals for Credit Cards
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        You can visit wefin.in or download wefin application
                        from Play Store & App store to explore competitive
                        offers from India’s leading Banks.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How can I get best deals for Business Loans
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        You can visit wefin.in or download wefin application
                        from Play Store & App store to explore competitive
                        offers from India’s leading Banks & NBFs.
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>

                  <AccordionItem>
                    <AccordionItemHeading>
                      <AccordionItemButton>
                        How can I contact wefin
                      </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                      <p>
                        You can contact wefin on{" "}
                        <a href="tel:011-40724283">011-40724283</a> & can also
                        write at{" "}
                        <a href="mailto:support@wefin.in">support@wefin.in</a>
                      </p>
                    </AccordionItemPanel>
                  </AccordionItem>
                </Accordion>
              </Col>
            </Row>
          </Container>
        </section>
        <CreditFooter />
      </>
    );
  }
}
export default FAQ;
