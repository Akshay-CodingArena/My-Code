export const creditScoreGetOtp = () => {
  fbq("track", "credit-Score-GetOtp");
};

export const enterCreditScoreOtp = () => {
  fbq("track", "enter-Credit-Score-Otp");
};
export const enterEmailId = () => {
  fbq("track", "enter-Email-Id");
};

export const enterExperionOtp = () => {
  fbq("track", "enter-Experion-Otp");
};
