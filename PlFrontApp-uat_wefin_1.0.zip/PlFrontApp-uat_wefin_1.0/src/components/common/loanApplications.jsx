import React, { Component } from "react";
import { numberFormat } from "../../Utils/numberFormat";
import Swal from "sweetalert2";
import { encryptStore, decryptStore, clearStore } from "../../Utils/store";
import Back from "../common/back";
import newLoanArrow from "../../include/assets/newLoanArrow.svg";
import AddIcon from "../../include/assets/personalLoan/icons8-add-96.png";
import moment from "moment";
import { ReactComponent as ArrowForwardIosIcon } from "../../include/assets/buttonArrow.svg";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getAccountInfo, getAccount } from "../../store/account";
import BackDropComponent from "../../common/BackDropComponent";
import selectIcon from "../../include/assets/select-icon.svg";
import {
  getBankOffer,
  getOffer,
  setOfferList,
  setBankOfferList,
  setIdfcStatus,
  creditSaisonDedupe,
} from "../../store/bankOffer";
import { loadApplyLoan, getApplyLoan } from "../../store/applyLoan";
import DashBoardAside from "../../common/dashboardAside";
import TopNavBar from "../../common/TopNavBar";
import { Container, Row, Col, Card } from "react-bootstrap";
import CreditFooter from "../cibilFlow/footer";
import { gaLogEvent } from "../../init-fcm";
import PATH from "../../paths/Paths";
import CONSTANTS from "../../constants/Constants";
import { axisPL, moneyViewRedirection, earlySalaryRedirection, getFibeStatus } from "../../store/personalLoan/axis";
import { getExperian, loadExperianCheck } from "../../store/experian";
import { paysensePL, paysenseGetPlans } from "../../store/personalLoan/paysense";

class LoanApplications extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bank: {},
      count: 0,
      bankSubStatus: "",
      continue: true,
      offerId: "",
      loanStatus: "",
      list: [],
      fibeIndex: 0
    };
  }

  componentDidMount = () => {
    document.body.classList.remove("variantScroll");
    document.body.classList.add("NoScrool");
    let mobile = localStorage.getItem("mobilenumber");

    this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
  };
  callbackDetail = (res) => {
    if (res) {
      if (res?.data?.success === false) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
      else {

        let formData = {
          mobile: localStorage.getItem("mobilenumber"),
          isExperian: true,
        };
        this.props.loadExperianCheck(formData, this.callBackVerify);
      }
    }
  };

  callBackVerify = (res) => {
    if (res.data.success) {
      const list =
        this.props.getAccountDetail &&
          this.props.getAccountDetail[0] &&
          this.props.getAccountDetail[0][this.props.match.params.name]
          ? this.props.getAccountDetail[0][this.props.match.params.name]
          : [];
      let responseList = list.filter(
        (lists) => lists.loanStage != "Offers"
      );

      this.setState({ list: responseList })
    }
    else {

    }

  }


  callbackRedirection = (res) => {

    if (res.data.success) {
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      if (decryptedData.lenderName === "Money View") {
        window.open(res.data.redirectionUrl, "_blank")
        this.props.history.push(PATH.PRIVATE.PRODUCTS)
      }
      else if (decryptedData.lenderName === "Fibe") {
        window.open(res.data.data.earlySalaryIngestion.responseData.redirectionUrl, "_blank")
        this.props.history.push(PATH.PRIVATE.PRODUCTS)
      }
    } else {

      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      if (decryptedData.lenderName === "Fibe") {

        Swal.fire({
          position: "center",
          icon: "warning",
          title: res.data?.data?.earlySalaryIngestion?.responseData?.reason ? res.data.data.earlySalaryIngestion.responseData.reason : "",
          position: "center",
          showConfirmButton: true,
        })
      }
      else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: `<div>${res.data?.message ? res.data.message : ""}</div><div>${res.data?.leadResponse?.responseData?.message ? res.data.leadResponse.responseData.message : ""}</div>`,
          position: "center",
          showConfirmButton: true,
        })

      }
    }
  }

  handleApply = (bank) => {

    if (bank.lenderName === "Fibe") {
      bank = { ...bank }
      delete bank.utmUrl
    }

    this.setState({ bank: bank });
    let formData = {
      lenderId: bank.lender_id__c,
      loanType: bank.loanType,
      mobile: localStorage.getItem("mobilenumber"),
      loanAmount: bank.appliedLoanAmount,
      offerId: bank.id,
      emi: bank.emi,
      roi: bank.IRR,
      tenure: bank.max_tenure,
      pf: bank.PF,
      loanId: bank ? bank.loanId : "",
    };

    if (localStorage.getItem("isUTM")) {
      let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
      formData.utm_source = UTM_Data?.utm_source;
      formData.utm_medium = UTM_Data?.utm_medium;
      formData.utm_id = UTM_Data?.utm_id;
      formData.utm_campaign = UTM_Data?.utm_campaign;
    }
    this.props.setOfferList(formData, this.callBackSet);
  };


  callbackGetPlans = (res) => {
    if (res.data.success) {
      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));
      this.props.history.push({
        pathname: PATH.PRIVATE.PAYSENSE_PL_FLOW,
        state: {
          step: CONSTANTS.GET_PLANS_SCREEN_PAYSENSE,
          stepperData: { ...decryptedData },
          data: res.data.response
        }
      })
    } else {
      Swal.fire({
        position: "center",
        icon: "error",
        title: res.data.message,
        position: "center",
        showConfirmButton: true,
      })
    }
  }

  callBackSet = (res) => {
    if (res) {
      if (res.data.success) {
        gaLogEvent(CONSTANTS.GA_EVENTS.PL_OFFER_SELECTED, {
          Lender_Name: this.state.bank.lenderName,
        });
        localStorage.setItem("loansfid", res.data.data.loansfid);
        let storeData = {
          loansfid: res?.data?.data?.loansfid,
          loanName: res?.data?.data?.loanName,
          loanType: res?.data?.loanType,
          lenderName: this.state.bank.lenderName,
          lenderId: res.data.data.lenderId
        };
        const mobile = localStorage.getItem("mobilenumber");
        encryptStore(mobile, storeData);
        if (this.state.bank.utmUrl) {
          window.open(this.state.bank.utmUrl, "_blank");
        } else if (this.state.bank.lenderName === "Axis Bank") {
          const formData = {
            firstName:
              this.props.customerDetail && this.props.customerDetail.firstname,
            middleName:
              this.props.customerDetail && this.props.customerDetail.middlename,
            lastName:
              this.props.customerDetail && this.props.customerDetail.lastname,
            loanId: res.data.data.loansfid,
            loanType: res.data.loanType,
            lenderId: this.state.bank.lender_id__c,
            mobile: mobile,
            offerId:
              this.state.bank.offerId && this.state.bank.offerId.toString(),
          };
          this.props.setBankOfferList(formData, this.callBackSetOffer);
        } else if (this.state.bank.lenderName === "HDFC") {

          let storeData = {
            loanAmount: this.state.bank.appliedLoanAmount,
            proposedEmi: this.state.bank.emi,
            tenure: this.state.bank.max_tenure,
            monthlySalary: this.props.customerDetail.monthlysalary,
            employerNameCode: this.props.customerDetail.pl_employer__pc,

          };
          encryptStore(mobile, storeData);
          this.props.history.push({
            pathname: PATH.PRIVATE.HDFC_PL_FLOW, state: {
              step: CONSTANTS.ADDITIONAL_INFO_HDFC_PL,
              stepperData: {},
              appliedLoanInfo: { ...this.state.bank }
            }
          })
        }
        else if (this.state.bank.lenderName === "Pay Sense") {
          let formData = {
            lenderId: this.state.bank.lender_id__c,
            loanName: res.data.data.loanName
          }
          this.props.paysenseGetPlans(formData, this.callbackGetPlans)
        }
        else if (this.state.bank.lenderName === "Fibe") {
          let formData = {
            mobilenumber: localStorage.getItem("mobilenumber"),
            firstname: this.props.customerDetail?.firstname ? this.props.customerDetail.firstname : "",
            lastname: this.props.customerDetail?.lastname ? this.props.customerDetail.lastname : "",
            gender: this.props.customerDetail?.gender ? this.props.customerDetail.gender : "",
            profession: this.props.customerDetail?.emptype__c ? this.props.customerDetail.emptype__c : "",
            pincode: this.props?.userData?.length ? this.props?.userData[0].pincode.toString() : "",
            pan: this.props?.userData?.length ? this.props?.userData[0].pan : "",
            dob: this.props.customerDetail?.dob ? this.props.customerDetail.dob.split("T")[0] : "",
            emailid: localStorage.getItem("email"),
            officepincode: this.props?.userData?.length ? this.props?.userData[0].pincode.toString() : "",
            salary: this.props.customerDetail?.monthlysalary ? this.props.customerDetail.monthlysalary.toString() : "",
            loanname: res.data.data.loanName
          }
          this.props.earlySalaryRedirection(formData, this.callbackRedirection)
        }
        else if (this.state.bank.lenderName === "Money View") {
          let formData =
          {
            phone: localStorage.getItem("mobilenumber"),
            loanName: res.data.data.loanName,
            lenderId: this.state.bank.lender_id__c,
            sfid: res.data.data.sfid,
            gender: this.props.customerDetail?.gender ? this.props.customerDetail.gender.toLowerCase() : "",
            email: this.props.customerDetail?.personemail ? this.props.customerDetail.personemail : "",
            declaredIncome: this.props.customerDetail?.monthlysalary
              ? this.props.customerDetail.monthlysalary
                .toString() : "",
            dateOfBirth: this.props.customerDetail?.dob ? this.props.customerDetail.dob.split("T")[0] : "",
            pincode: this.props?.userData?.length ? this.props?.userData[0].pincode : "",
            name: this.props.customerDetail?.name ? this.props.customerDetail.name : "",
            pan: this.props?.userData?.length ? this.props?.userData[0].pan : "",
            employmentType: this.props.customerDetail?.emptype__c ? this.props.customerDetail.emptype__c : "Salaried"
          }
          this.props.moneyViewRedirection(formData, this.callbackRedirection)
        }
        else if (this.state.bank.lenderName === "Credit Saison") {
          const formData = {
            loanId: res.data.data.loansfid,
            loanType: res.data.loanType,
            lenderId: this.state.bank.lender_id__c,
            mobile: mobile,
            offerId: this.state.bank.id && this.state.bank.id.toString(),
            loanName: res.data.data.loanName,
          };
          this.props.creditSaisonDedupe(formData, this.callBackDedupe);
        } else {
          this.props.history.push({
            pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
              }/${this.state.bank.loanType
                .split(/\s/)
                .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
            state: this.state.bank,
          });
        }
      }
    }
  };

  callBackDedupe = (res) => {
    try {
      if (res.data.success) {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SPECIFIC_DETAILS
            }/${this.state.bank.loanType
              .split(/\s/)
              .join("-")}/${this.state.bank.lenderName.split(/\s/).join("-")}`,
          state: this.state.bank,
        });
      } else if (
        res.data.description.toString().toLowerCase() === "entity exists"
      ) {
        throw new Error(
          "We are unable to proceed with this application as one of your's previous  application is already in queue with Credit Saison"
        );
      } else {
        throw new Error(res.data.description);
      }
    } catch (e) {
      Swal.fire({
        position: "center",
        icon: "info",
        title: e?.message ? e.message.toString() : e.toString(),
        showConfirmButton: true,
      }).then((res) => {
        if (res.isConfirmed) {
          this.props.history.push(PATH.PRIVATE.PRODUCTS);
        }
      });
    }
  };

  callBackSetOffer = (res) => {
    if (res) {
      if (res.data.success) {
        let mobile = localStorage.getItem("mobilenumber");
        this.props.getAccountInfo({ mobile: mobile }, this.callbackDetail);
        const url =
          res.data.axisData &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted.Response &&
          res.data.axisData.OfferGenerationStatusEnquiryResponse
            .offerGenerationStatusEnquiryResponseBodydecrypted.Response
            .productUrl;
        window.open(url, "_blank");
        let setDetailsData = {
          loanName: this.state.bank.loanName,
          lenderName: this.state.bank.lenderName,
          offerId:
            this.state.bank.offerId && this.state.bank.offerId.toString(),
        };
        var interval = setInterval(() => {
          if (this.state.count <= 5) {
            this.props.setIdfcStatus(setDetailsData, this.callBackIdfc);
          } else {
            clearInterval(interval);
          }
        }, 30000);
      }
    }
  };

  getOfferFunc = (mobile, loanId, loanType) => {
    let formData =
      "mobile=" +
      mobile +
      "&loanId=" +
      loanId +
      "&loanType=" +
      loanType;
    this.props.getOffer(formData, this.callBackGet);
  }

  callBackIdfc = (res) => {
    if (res) {
      this.setState({
        bankSubStatus: res?.data?.axisData && res?.data?.axisData?.bankSubStatus,
        offerId: this.state.bank.offerId,
      });
      if (!res.data.success) {
        let url = process.env.REACT_APP_AXIS_PL_URL;
        if (
          this.state.continue &&
          res.data.axisData.bankSubStatus === "No active application found"
        ) {
          window.open(url, "_blank");
          this.setState({ continue: false });
        }
        this.setState({ count: 6 });
      } else if (res.data.success) {
        this.setState({ count: this.state.count + 1 });
      }
    }
  };
  callBackMoneyIdfc = (res) => {
    if (res) {
      this.setState({
        bankSubStatus:
          res.data.moneyTapData && res.data.moneyTapData.bankSubStatus,
        loanStatus: res.data.moneyTapData && res.data.moneyTapData.loanStage,
        offerId: this.state.bank.offerId,
      });
    }
  };
  handleHlContinue = (bank) => {
    this.props.history.push({
      pathname: `${PATH.PRIVATE.HOME_LOAN_BANK_SPECIFIC_DETAIL
        }/${bank.loanType
          .split(/\s/)
          .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
      state: bank,

    });
  }
  handleContinue = (bank) => {
    let mobile = localStorage.getItem("mobilenumber");
    let storeData = {
      loansfid: bank.loanId,
      loanName: bank.loanName,
      loanType: bank.loanType,
      lenderName: bank.lenderName
    };
    encryptStore(mobile, storeData);

    this.setState({ bank: bank });
    if (bank.loanStage.toString().toLowerCase() === "declined") {
      this.props.history.push({
        pathname: `${PATH.PRIVATE.LOAN_APP_FAILED}`,
        state: bank,
      });
    } else if (bank.lenderName === "HDFC") {
      let storeData = {
        loanAmount: bank.appliedLoanAmount,
        proposedEmi: bank.emi,
        tenure: parseInt(bank.pl_applied_tenure__c),
        monthlySalary: this.props.customerDetail.monthlysalary,
        employerNameCode: this.props.customerDetail.pl_employer__pc,
        stageName: bank.loanStage,
        isDropoff: true,
        lenderName: bank.lenderName,
        applicationId: bank.application_id ? bank.application_id : "",
        loanName: bank.loanName ? bank.loanName : "",
        lenderId: bank.lender_id__c ? bank.lender_id__c : "",
        sfid: bank.loanSfid ? bank.loanSfid : "",
        platform: "Website"
      }
      encryptStore(mobile, storeData);
      let appliedLoanInfo =
      {
        IRR: bank.IRR,
        PF: bank.PF,
        appliedLoanAmount: bank.appliedLoanAmount,
        bankImage: bank.bankImage,
        emi: bank.emi,
        pl_applied_tenure__c: bank.pl_applied_tenure__c,
      }
      if (bank.loanStage === "Application in Review" ||
        bank.loanStage === "Under Process" ||
        bank.loanStage === "Case Initiated" ||
        bank.loanStage === "Duplicate Case" ||
        bank.loanStage === "Pre-Sanction Document Check" ||
        bank.loanStage === "Decision Awaited" ||
        bank.loanStage === "Disbursement Under Process" ||
        bank.loanStage === "Disbursed" ||
        bank.loanStage === "Approved" ||
        bank.loanStage === "Additional Documents / Check pending" ||
        bank.loanStage === "Reject"
      ) {

        let dataToEncrypt = {
          Filler1: bank.filler1_as_resp ? bank.filler1_as_resp : "",
          Filler4: bank.filler1_as_resp ? bank.filler1_as_resp : "",
          deviceId: bank.device_id ? bank.device_id : "",
        }

        encryptStore(mobile, dataToEncrypt);

        this.props.history.push({
          pathname: PATH.PRIVATE.HDFC_PL_FLOW,
          state: {
            step: CONSTANTS.CONGRATULATIONS_HDFC,
            stepperData: {},
            appliedLoanInfo: appliedLoanInfo,
            dropoffData: bank,
            stepperStep: 6
          }
        })

      } else {
        this.props.history.push({
          pathname: PATH.PRIVATE.HDFC_PL_FLOW,
          state: {
            step: CONSTANTS.ADDITIONAL_INFO_HDFC_PL,
            stepperData: {},
            appliedLoanInfo: appliedLoanInfo,
            dropoffData: bank
          }
        })
      }
    }

    else if (bank.lenderName === "Pay Sense") {

      let data = {
        lenderName: bank.lenderName,
        loanStage: bank.loanStage,
        lenderId: bank.lender_master__c,
        sfid: bank.loanSfid,
        appliedLoanAmount: bank.appliedLoanAmount,
        emi: bank.emi,
        bankImage: bank.bankImage,
        IRR: bank.IRR,
        PF: bank.pl_processing_fee_amount__c ? bank.pl_processing_fee_amount__c : bank.PF,
        pl_applied_tenure__c: bank.pl_applied_tenure__c,
        pl_roi__c: bank.pl_roi__c,
        pl_revised_emi__c: bank.pl_revised_emi__c ? bank.pl_revised_emi__c : "",
        pl_revised_tenure__c: bank.pl_revised_tenure__c ? bank.pl_revised_tenure__c : "",
        pl_revised_loan_amount__c: bank.pl_revised_loan_amount__c ? bank.pl_revised_loan_amount__c : "",
        pl_approved_interest_rate__c: bank.pl_approved_interest_rate__c ? bank.pl_approved_interest_rate__c : ""
      }
      encryptStore(mobile, { ...storeData, ...data });


      let decryptedData = decryptStore(localStorage.getItem("mobilenumber"));

      if (
        bank.loanStage === "Approval Pending" ||
        bank.loanStage === "Hard Approved"
      ) {
        this.props.history.push({
          pathname: PATH.PRIVATE.PAYSENSE_PL_FLOW,
          state: {
            step: CONSTANTS.CONGRATS_SCREEN_PAYSENSE,
            stepperData: {
              ...decryptedData
            },
            stepperStep: 4
          }
        })
      }
      else {
        let formData = {
          lenderId: bank.lender_master__c,
          loanName: bank.loanName
        }
        this.props.paysenseGetPlans(formData, this.callbackGetPlans)
      }

    }
    else if (bank.lenderName === "Fibe") {
      let data = {
        lenderName: bank.lenderName,
        loanStage: bank.loanStage,
        lenderId: bank.lender_master__c,
        sfid: bank.loanSfid
      }
      encryptStore(mobile, { ...storeData, ...data });
      if (bank.loanStage === "Bank Offer Generated") { window.open(bank.redirectionurl__c, "_blank") }

      else if (bank.loanStage === "Assigned") {
        this.getOfferFunc(localStorage.getItem("mobilenumber"), bank.loanId, bank.loanType);
      }
      else if (bank.loanStage === "Hold") {
        this.getOfferFunc(localStorage.getItem("mobilenumber"), bank.loanId, bank.loanType);
      }
      else if (bank.loanStage === "Declined") {
        this.getOfferFunc(localStorage.getItem("mobilenumber"), bank.loanId, bank.loanType);
      }
    }
    else if (bank.lenderName === "Money View") {
      let data = {
        lenderName: bank.lenderName,
        loanStage: bank.loanStage,
        lenderId: bank.lender_master__c,
        sfid: bank.loanSfid
      }
      encryptStore(mobile, { ...storeData, ...data });

      if (data.loanStage === "Assigned")
        this.getOfferFunc(localStorage.getItem("mobilenumber"), bank.loanId, bank.loanType);

      else if (data.loanStage === "Bank Offer Generated") {
        window.open(bank.redirectionurl__c, "_blank")
      }
    }
    else if (bank.loanStage === "Assigned") {
      if (bank.utmUrl) {
        window.open(bank.utmUrl, "_blank");
      } else if (bank.lenderName === "Axis Bank") {
        let setDetailsData = {
          loanName: bank.loanName,
          lenderName: bank.lenderName,
          offerId: bank.offerId && bank.offerId.toString(),
        };
        this.props.setIdfcStatus(setDetailsData, this.callBackIdfc);
        var interval = setInterval(() => {
          this.setState({ count: this.state.count + 1 });
          if (this.state.count <= 5) {
            this.props.setIdfcStatus(setDetailsData, this.callBackIdfc);
          } else {
            clearInterval(interval);
          }
        }, 30000);
      }
      else {
        this.props.history.push({
          pathname: `/bank-specific-details/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      }
    } else if (bank.loanStage === "Offers") {
      let formData =
        "mobile=" +
        localStorage.getItem("mobilenumber") +
        "&loanId=" +
        bank.loanId +
        "&loanType=" +
        bank.loanType;
      this.props.getOffer(formData, this.callBackGet);
    } else if (bank.lenderName === "MoneyTap") {
      if (bank.loanStage !== "Assigned") {
        let setDetailsData = {
          loanName: bank.loanName,
          lenderName: bank.lenderName,
          offerId: bank.offerId && bank.offerId.toString(),
          lenderId: bank.lender_id__c,
        };
        this.props.setIdfcStatus(setDetailsData, this.callBackMoneyIdfc);
      } else {
        this.props.history.push({
          pathname: `/bank-specific-details/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      }
    } else if (bank.loanStage === "Soft Approved") {
      if (bank.lenderName === "Credit Saison") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.AADHAR_DETAILS}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else {
        let formData =
          "mobile=" +
          localStorage.getItem("mobilenumber") +
          "&loanId=" +
          bank.loanId +
          "&loanType=" +
          bank.loanType;
        this.props.getOffer(formData, this.callBackGet);
      }
    } else if (bank.lenderName === "Credit Saison") {
      if (bank.loanStage === "Financial Check") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.UPLOAD_SALARY_SLIP}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "KYC Completed") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.BANK_SELFIE_UPLOAD}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "Selfie Captured") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.VERIFY_BANK_DETAILS}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (
        bank.loanStage.toLowerCase() === "bank detail validation failed"
      ) {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.VERIFY_BANK_DETAILS}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "Bank Detail Validated") {
        if (bank.appliedLoanAmount > 100000) {
          this.props.history.push({
            pathname: `${PATH.PRIVATE.VERIFY_INCOME_PERFIOS}/${bank.loanType
              .split(/\s/)
              .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
            state: bank,
          });
        } else {
          this.props.history.push({
            pathname: `${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}/${bank.loanType
              .split(/\s/)
              .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
            state: bank,
          });
        }
      } else if (bank.loanStage === "Perfios Rejected") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.VERIFY_INCOME_PERFIOS}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "Perfios Initiated") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.VERIFY_INCOME_PERFIOS}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "Perfios Completed") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.ADD_PRIMARY_REFERENCE}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "DAAS1 Initiated") {
        Swal.fire({
          position: "center",
          icon: "info",
          title:
            "Your application has been initiated, awaiting go-ahead from Credit.",
          showConfirmButton: true,
        });
      } else if (bank.loanStage === "Hard Approved" || bank.loanStage === "Set Consent") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.EMANDATE_DETAILS}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "E-Mandate Completed") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.ESIGN_AGREEMENT}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "E-Sign Rejected") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.ESIGN_AGREEMENT}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (bank.loanStage === "E-Sign Initiated") {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.ESIGN_AGREEMENT}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else if (
        bank.loanStage.toLowerCase() === "disbursement" ||
        bank.loanStage.toLowerCase() === "pre-disbursement"
      ) {
        this.props.history.push({
          pathname: `${PATH.PRIVATE.EQUITAS_CONGRATULATION}/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      } else {
        this.props.history.push({
          pathname: `/bank-specific-details/${bank.loanType
            .split(/\s/)
            .join("-")}/${bank.lenderName.split(/\s/).join("-")}`,
          state: bank,
        });
      }
    } else {
      this.props.history.push("/personal-detail");
    }
  };
  callBackGet = (res) => {
    if (res) {
      if (res.data.success) {
        this.props.history.push({
          pathname: PATH.PRIVATE.PERSONAL_LOAN_OFFERS,
          state: res.data,
        });
      }
    }
  };
  loanCall = (id) => {
    const mobile = localStorage.getItem("mobilenumber");

    let formData = { mobile: mobile, loanType: id, newLoan: true };

    if (localStorage.getItem("isUTM")) {
      let UTM_Data = JSON.parse(localStorage.getItem("UTM"));
      formData.utm_source = UTM_Data?.utm_source;
      formData.utm_medium = UTM_Data?.utm_medium;
      formData.utm_id = UTM_Data?.utm_id;
      formData.utm_campaign = UTM_Data?.utm_campaign;
    }
    this.props.loadApplyLoan(formData, this.callbackLoan);
  };
  callbackLoan = (res) => {
    if (res) {
      const mobile = localStorage.getItem("mobilenumber");
      if (res.data.success) {
        let {
          data: { loanName, loansfid },
          loanType,
        } = res.data;
        let storeData = {
          loansfid: loansfid,
          loanName: loanName,
          loanType: loanType,
        };
        encryptStore(mobile, storeData);

        if (this.props.customerDetail.pan_verified__c === true) {
          this.props.history.push(PATH.PRIVATE.PERSONAL_DETAIL);
        } else {
          this.props.history.push(PATH.PRIVATE.PAN_VERIFY);
        }
      } else {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: res && res.data.message,
          showConfirmButton: false,
          timer: 1800,
        }).then(() => {
          this.props.history.push(PATH.PUBLIC.INDEX);
        });
      }
    }
  };


  callbackStatusFibe = (res) => {
    if (res?.data?.success) {
      let data = [...this.state.list];
      let newObj = { ...data[this.state.fibeIndex] };
      newObj.showStatus = res.data.data.responseData.customerStatus;
      data[this.state.fibeIndex] = { ...newObj }
      this.setState({ list: [...data] })
    }
    else {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: res.data.message,
        position: "center",
        showConfirmButton: true,
      })
    }
  }



  checkStatusFibe = (data, index) => {
    console.log(data)
    console.log(index);

    this.setState({ fibeIndex: index })

    let formData = {
      lender_application_id: data.lender_application_id__c,
      loanName: data.loanName,
      lenderid: data.lender_master__c,
      opportunitySfid: data.loanSfid
    }
    this.props.getFibeStatus(formData, this.callbackStatusFibe)
  }

  render() {
    let mobile = localStorage.getItem("mobilenumber");
    let decryptedData = decryptStore(mobile);
    let { loanType } = decryptedData;
    const {
      loading,
      getAccountDetail,
      offers,
      loadingGet,
      loadingLoan,
      loadingSet,
      loadingBank,
      loadingIdfc,
    } = this.props;
    const list =
      getAccountDetail &&
        getAccountDetail[0] &&
        getAccountDetail[0][this.props.match.params.name]
        ? getAccountDetail[0][this.props.match.params.name]
        : [];
    const offerList =
      offers && offers[0] && offers[0][this.props.match.params.offer]
        ? offers[0][this.props.match.params.offer]
        : [];
    let responseList = list.filter(
      (lists) => lists.loanStage !== "Offers"
    );

    return (
      <>
        <TopNavBar />
        <section className="bs-main-section">
          {loading ||
            loadingGet ||
            loadingLoan ||
            loadingSet ||
            loadingBank ||
            loadingIdfc ||
            this.props.loadingEarlySalary ||
            this.props.loadingMoneyView ||
            this.props.loadingFibeStatus ||
            this.props.loadingCheck ||
            this.props.loadingPaysense

            ? (
              <BackDropComponent />
            ) : (
              ""
            )}

          <Container>
            <Row>
              <Col sm={12} md={3}>
                <DashBoardAside />
              </Col>
              <Col sm={12} md={9}>
                <div className="row bsFormBlock">
                  <div className="col-sm-12">
                    <div className="row g-0">
                      <div className="col-6 col-sm-8" style={{ paddingLeft: "0px" }}>
                        <h3 className="bsLoanHeadline">{loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? "Home Loans" : (loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ? "Two Wheeler Loan" : "Personal Loans")}</h3>
                      </div>
                      {loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN || loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ? "" :
                        <div
                          className="col-6 col-sm-4 text-right"
                          style={{ paddingRight: "0px" }}
                        >
                          <button
                            className="ApplyLoanBtn"
                            onClick={() =>
                              this.loanCall(CONSTANTS.LOAN_TYPE.PERSONAL_LOAN)
                            }
                          >
                            Apply New Loan
                            <img
                              alt=""
                              style={{ height: "25px", width: "25px" }}
                              src={AddIcon}
                            />
                          </button>
                        </div>}
                    </div>
                  </div>
                  {this.state.list.map((e, i) => (
                    <div className="container-fluid col-sm-12 bsMyLoanSection">
                      <div className="row g-0 align-items-center bsMyLoanBox">
                        <div className="col-sm-10">
                          <div className="row g-0">
                            <div className="col-6 col-sm-3">
                              <p> Application No.</p>

                              <strong>{e.loanName}</strong>
                            </div>
                            <div className="col-6 col-sm-3">
                              <p>Applied Date</p>
                              <strong>
                                {e.createddate ? moment(e.createddate).format(
                                  "DD-MMM-YYYY"
                                ) : "-"}
                              </strong>
                            </div>
                            <div className="col-6 col-sm-2">
                              <p>Loan Amount</p>

                              <strong>
                                {" "}
                                {e.appliedLoanAmount
                                  ? numberFormat(e?.pl_revised_loan_amount__c ? e.pl_revised_loan_amount__c : e.appliedLoanAmount)
                                  : "------"}
                              </strong>
                            </div>
                            <div className="col-6 col-0-2">
                              <p>Interest Rate</p>

                              <strong>
                                {e.IRR ? e?.pl_approved_interest_rate__c ? e.pl_approved_interest_rate__c + " %*" : e.IRR + " %*" : "------"}{" "}
                              </strong>
                            </div>
                            {e.loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? <div className="col-6 col-sm-2">
                              <p>Reference No</p>

                              <strong>
                                <strong>{e.loanStage === "Submitted" ? e.recordId : ""}</strong>
                              </strong>
                            </div> : ""}
                          </div>

                          <hr className="bsBorder" />
                          <div className="row g-0 align-items-center">
                            <div className="col-6 col-sm-3">
                              <div>
                                {e.bankImage ? (
                                  <img
                                    src={e.bankImage}
                                    alt=""
                                    style={{ width: "70px" }}
                                  />
                                ) : (
                                  <img
                                    src="/bankLogos/default.svg"
                                    alt=""
                                    style={{ width: "60px" }}
                                  />
                                )}
                              </div>
                            </div>
                            <div className="col-6 col-sm-3">
                              <p>Loan Type</p>

                              <strong>{e.loanType.split("_").join(" ")}</strong>
                            </div>
                            <div className="col-6 col-sm-3">
                              {" "}
                              <p>Tenure</p>
                              <strong>
                                {e.loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ?
                                  e.pl_applied_tenure__c
                                    ? e.pl_applied_tenure__c + " " + "years"
                                    : "------"
                                  : e?.pl_revised_tenure__c ? e.pl_revised_tenure__c + " " + "months" : e?.pl_applied_tenure__c ? e.pl_applied_tenure__c + " " + "months" : "------"}
                              </strong>
                              <span></span>
                              {e.lenderName ? "" : <span></span>}
                            </div>
                            <div className="col-6 col-sm-3">
                              {" "}
                              <p>EMI</p>
                              <strong>
                                {(e?.pl_revised_emi__c || e?.emi) ? numberFormat(e?.pl_revised_emi__c ? e.pl_revised_emi__c : e.emi) : "------"}
                              </strong>
                              <span></span>
                              {e.lenderName ? "" : <span></span>}
                            </div>

                          </div>
                        </div>

                        <div className=" col-12 col-sm-2 text-center">
                          <p className="bsContinue">
                            Loan Status
                            <strong
                              style={{
                                fontWeight: "bolder",
                                color:
                                  e.loanStage === "Soft Approved"
                                    ? "#1aac7a"
                                    : e.loanStage === "Declined"
                                      ? "#ff5800"
                                      : " rgba(0, 0, 0, 0.87)",
                                fontSize: "16px",
                              }}
                            >
                              {e.offerId === this.state.offerId &&
                                this.state.loanStatus
                                ? this.state.loanStatus
                                : e.loanStage}
                            </strong>
                          </p>

                          {e?.lenderName?.toLowerCase() === "fibe" ? <p style={{
                            color: "#5200bb",
                            cursor: "pointer",
                            fontSize: "14px"
                          }}
                            onClick={(event) => {
                              this.checkStatusFibe(e, i)
                            }}
                          >Check Bank Status</p> : ""}

                          {loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? "" : this.state.bankSubStatus ||
                            e.bankSubStatus ||
                            e.bankStatus ? (
                            <p className="bsContinue">
                              Bank Status
                              <strong
                                style={{
                                  color:
                                    this.state.bankSubStatus === "Declined" ||
                                      e.bankSubStatus === "Declined" ||
                                      e.bankStatus === "Declined"
                                      ? "#e74d10"
                                      : " #047c4c",
                                  fontSize: "14px",
                                  // marginLeft: "-30px"
                                }}
                              >
                                {e.offerId === this.state.offerId
                                  ? this.state.bankSubStatus
                                  : e.bankSubStatus
                                    ? e.showStatus
                                    : e.showStatus}
                              </strong>
                            </p>
                          ) : (
                            ""
                          )}
                          {loanType === CONSTANTS.LOAN_TYPE.TWO_WHEELER_LOAN ? "" : (loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? <p className="bsContinue">
                            {e.loanStage === "Submitted" ?
                              <button
                                variant="contained"
                                className="nextButton"
                                disabled
                                style={{
                                  opacity: "0.5",
                                  cursor: "not-allowed",
                                }}
                              >
                                Continue
                                <img alt="" src={newLoanArrow} />
                              </button> : <button
                                onClick={() => this.handleHlContinue(e)}>
                                Continue
                                <img alt="" src={newLoanArrow} />
                              </button>}
                          </p> :
                            <p className="bsContinue">
                              {e.loanStage === 'NSTP Actions' ?
                                <button
                                  variant="contained"
                                  className="nextButton"
                                  disabled
                                  style={{
                                    opacity: "0.5",
                                    cursor: "not-allowed",
                                  }}
                                >
                                  Continue
                                  <img alt="" src={newLoanArrow} />
                                </button> :
                                e.loanStage === "Disbursement" ? "" : <button
                                  onClick={() => this.handleContinue(e)}>
                                  Continue
                                  <img alt="" src={newLoanArrow} />
                                </button>
                              }
                            </p>)}
                        </div>
                      </div>
                    </div>
                  ))}
                  {offerList.length > 0 && (
                    <div className="col-sm-12">
                      <h3 className="bsLoanHeadline other">Other Offers</h3>
                    </div>
                  )}

                  {offerList.map((e, i) => (
                    <div className="col-sm-12 bsMyOfferSection">
                      <div className="row g-0 bsMyOfferBox align-items-center">
                        <div className="col-6 col-sm-2 " key={i}>
                          {e.isInstant === true ? (
                            <div className="InstantApproveBox">
                              <img src={selectIcon} alt="select icon" /> 2 Min
                              Disbursal
                            </div>
                          ) : (
                            ""
                          )}
                          {e.bankImage ? (
                            <img
                              src={e.bankImage}
                              alt=""
                              style={{ width: "100px" }}
                            />
                          ) : (
                            <img
                              src="/bankLogos/default.svg"
                              alt=""
                              style={{ width: "60px" }}
                            />
                          )}
                        </div>
                        <div className="col-6 col-sm-2 ">
                          {" "}
                          <p>Interest Rate</p>
                          <strong>{e.IRR} %*</strong>
                        </div>
                        <div className="col-6 col-sm-2 ">
                          <p>Loan Amount</p>
                          <strong> {numberFormat(e.appliedLoanAmount)}</strong>
                        </div>
                        <div className="col-6 col-sm-2 ">
                          <p>EMI</p>
                          <strong> {numberFormat(e.emi)}</strong>
                        </div>
                        <div className="col-6 col-sm-2">
                          <p>Tenure</p> <strong>{e.max_tenure} {e.loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? 'Years' : 'Months'} </strong>
                        </div>
                        <div className="col-12 col-sm-2 text-center">
                          <button
                            className="BsApplyLoanBtn"
                            onClick={() => this.handleApply(e)}
                          >
                            Apply <ArrowForwardIosIcon />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Col>
            </Row>
          </Container>
        </section>
        <CreditFooter />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  getAccountDetail: getAccount(state).getAccountDetail,
  offers: getAccount(state).getOffer,
  customerDetail: getAccount(state).customerDetail,
  loading: getAccount(state).loading,
  offerGet: getBankOffer(state).getBreOffer,
  loadingGet: getBankOffer(state).loadingGet,
  loadingLoan: getApplyLoan(state).loadingLoan,
  getApplyLoan: getApplyLoan(state),
  loadingSet: getBankOffer(state).loadingSet,
  setBankOffer: getBankOffer(state).setBankOffer,
  loadingBank: getBankOffer(state).loadingBank,
  setIdfc: getBankOffer(state).setIdfc,
  loadingIdfc: getBankOffer(state).loadingIdfc,
  loadingEarlySalary: axisPL(state).loadingEarlySalary,
  loadingMoneyView: axisPL(state).loadingMoneyView,
  loadingFibeStatus: axisPL(state).loadingFibeStatus,
  loadingCheck: getExperian(state).loadingCheck,
  userData: getExperian(state).userData,
  loadingPaysense: paysensePL(state).loadingPaysense,
});

const mapDispatchToProps = (dispatch) => ({
  getAccountInfo: (params, callbackDetail) =>
    dispatch(getAccountInfo(params, callbackDetail)),
  getOffer: (params, callback) => dispatch(getOffer(params, callback)),
  loadApplyLoan: (params, callback) =>
    dispatch(loadApplyLoan(params, callback)),
  setOfferList: (params, callBack) => dispatch(setOfferList(params, callBack)),
  setBankOfferList: (params, callBack) =>
    dispatch(setBankOfferList(params, callBack)),
  setIdfcStatus: (params, callBack) =>
    dispatch(setIdfcStatus(params, callBack)),
  creditSaisonDedupe: (params, callBack) =>
    dispatch(creditSaisonDedupe(params, callBack)),
  moneyViewRedirection: (params, callbackDetail) =>
    dispatch(moneyViewRedirection(params, callbackDetail)),
  earlySalaryRedirection: (params, callbackDetail) =>
    dispatch(earlySalaryRedirection(params, callbackDetail)),
  getFibeStatus: (params, callbackDetail) =>
    dispatch(getFibeStatus(params, callbackDetail)),
  loadExperianCheck: (params, callback) =>
    dispatch(loadExperianCheck(params, callback)),
  paysenseGetPlans: (params, callback) =>
    dispatch(paysenseGetPlans(params, callback)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(LoanApplications)
);
