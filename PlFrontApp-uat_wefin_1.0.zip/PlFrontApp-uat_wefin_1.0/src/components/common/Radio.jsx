import React from 'react';

const Radio = (props) => {
    const { label, value, groupValue, onClick, disabled } = props;
    return <React.Fragment>
        <div onClick={onClick} className="form-check form-check-inline radioBtn">
            <input
                className="form-check-input"
                disabled={disabled}
                type="radio"
                value={value}
                checked={groupValue === value}
            />
            <label className={`${disabled ? "form-check-label disabled" : "form-check-label"}`} htmlFor={label}>
                {label}{" "}
            </label>
        </div>
    </React.Fragment>
}
export default Radio;