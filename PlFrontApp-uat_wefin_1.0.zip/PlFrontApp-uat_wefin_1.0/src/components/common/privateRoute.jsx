import { Route, Redirect } from "react-router-dom";
import PATH from "../../paths/Paths";

function PrivateRoute({ children, ...rest }) {
  const auth = localStorage.getItem("accessToken") || localStorage.getItem("ASM_accessToken") || localStorage.getItem('TeleVerify_accessToken');
  // console.log("props are", rest, rest.location.state)
  const deviceId = "6ebc0c18e7609755"
  if (!localStorage.getItem("deviceId")) {
    localStorage.setItem("deviceId", deviceId)
  }
  return (
    <Route
      {...rest}
      render={() =>
        auth ? (
          {
            ...children,
            props: {
              ...children.props,
              mobileNumber: localStorage.getItem("mobilenumber"),
              isAuth: auth ? true : false,
              ...rest
            },
          }
        ) : (
          sessionStorage.getItem("logout") ? window.location.href = sessionStorage.getItem("logout") :
            <Redirect to={PATH.PUBLIC.INDEX} />
        )
      }
    />
  );
}
export default PrivateRoute;
