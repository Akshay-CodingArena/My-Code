import React from "react";
import Webcam from "react-webcam";
import { Row, Col } from "react-bootstrap";
import SelfieIcon from "../../include/assets/icons/camera.svg";
import RetakeIcon from "../../include/assets/icons/retake.svg";

export default class WebcamCapture extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      captureImg: null,
      viewCaptureImg: false,
      fileImg: null,
    };
  }

  setRef = (webcam) => {
    this.webcam = webcam;
  };

  capture = () => {
    this.detectWebcam((hasWebcam) => {
      if (hasWebcam) {
        this.setState({ captureImg: this.webcam.getScreenshot() });
        this.setState({ viewCaptureImg: true });
      }
      let { recieveFileType } = this.props;
      if (recieveFileType === "file") {
        this.state.captureImg && recieveFileType(this.state.captureImg);
      } else {
        this.state.captureImg && this.sendImgToUpload();
      }
    });
  };

  detectWebcam = (callback) => {
    let md = navigator.mediaDevices;
    if (!md || !md.enumerateDevices) return callback(false);
    md.enumerateDevices().then((devices) => {
      callback(devices.some((device) => "videoinput" === device.kind));
    });
  };

  handleImages = (files) => {
    let validImages = [...files].filter((file) =>
      ["image/jpeg", "image/png", "image/jpg"].includes(file.type)
    );
    validImages.forEach(this.convertFileImageToBase64String);
  };

  readFile = (file, callback) => {
    var reader = new FileReader();
    reader.onload = function () {
      callback(reader.result);
    };
    reader.readAsDataURL(file);
  };

  convertFileImageToBase64String = (image) => {
    this.readFile(image, (v) => {
      this.setState({ fileImg: v });
      this.state.fileImg && this.sendImgToUpload();
    });
  };

  sendImgToUpload = async () => {
    // let contentType = this.state.viewCaptureImg
    //   ? this.state.captureImg
    //       .split("base64")[0]
    //       .split(":")[1]
    //       .split(";")[0]
    //       .toString()
    //   : this.state.fileImg
    //       .split("base64")[0]
    //       .split(":")[1]
    //       .split(";")[0]
    //       .toString();
    let { recievedBlobFile } = this.props;
    if (this.state.viewCaptureImg) {
      let base64Response = await fetch(this.state.captureImg);
      let blob = await base64Response.blob();
      recievedBlobFile(blob);
    } else {
      let base64Response = await fetch(this.state.fileImg);
      let blob = await base64Response.blob();
      recievedBlobFile(blob);
    }
  };

  render() {
    const videoConstraints = {
      width: 830,
      height: 550,
      facingMode: "user",
    };

    return (
      <>
        <Row>
          <Col sm={12}>
            <div className="passport">
              <Row>
                <Col sm={12}>
                  {this.state.viewCaptureImg || this.state.fileImg ? (
                    <img
                      className="bsCaptureImg"
                      src={this.state.captureImg || this.state.fileImg}
                      alt={"camera"}
                      width={480}
                      height={640}
                      imageSmoothing={true}
                      mirrored={true}
                      minScreenshotHeight={640}
                      minScreenshotWidth={480}
                    />
                  ) : (
                    <Webcam
                      audio={false}
                      height={640}
                      ref={this.setRef}
                      screenshotFormat="image/jpeg"
                      width={480}
                      videoConstraints={videoConstraints}
                      className="UploadImage"
                      imageSmoothing={true}
                      mirrored={true}
                      minScreenshotHeight={640}
                      minScreenshotWidth={480}
                    />
                  )}
                </Col>
              </Row>

              <Row>
                <Col sm={12}>
                  <div className="camera_check_box">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="checkedG"
                        id="checkedG"
                        onChange={this.props.handleCheckBoxChange}
                        checked={this.props.terms}
                      />
                      <label className="form-check-label" htmlFor="checkedG">
                        I agree to capture and share the footage with our
                        service provider as part of the KYC process.
                      </label>
                    </div>
                  </div>
                </Col>
                <Col sm={12}>
                  {this.state.viewCaptureImg || this.state.fileImg ? (
                    <div className="mainContainerUploadClick">
                      <img
                        className="uploadIcon"
                        alt="Retake Icon"
                        onClick={() => {
                          this.setState({
                            viewCaptureImg: false,
                            captureImg: null,
                            fileImg: null,
                          });
                          this.props.recievedBlobFile(null);
                        }}
                        src={RetakeIcon}
                      />
                    </div>
                  ) : (
                    <div className="mainContainerUploadClick">
                      {this.props.terms === true ? (
                        <img
                          className="uploadIcon"
                          alt="camera icon"
                          src={SelfieIcon}
                          onClick={this.capture}
                        />
                      ) : (
                        <img
                          className="uploadIcon"
                          alt="camera icon"
                          src={SelfieIcon}
                          style={{
                            opacity: "0.5",
                            cursor: "not-allowed",
                          }}
                        />
                      )}

                      <span className="hiddenFileInputOnPassPortPhoto">
                        <input
                          type="file"
                          accept="image/png, image/jpeg"
                          onChange={(e) => this.handleImages(e.target.files)}
                        />
                      </span>
                    </div>
                  )}
                </Col>
              </Row>
            </div>
          </Col>
        </Row>
      </>
    );
  }
}
