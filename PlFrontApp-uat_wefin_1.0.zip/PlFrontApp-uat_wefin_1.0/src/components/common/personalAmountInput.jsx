import React from "react";
import { numberToWord } from "../../Utils/numberToWord";
import { numberFormat } from "../../Utils/numberFormat";
const PersonalAmountInput = (props) => {
  return (
    <div className="form-group">
      <label htmlFor={props.label}>
        {props.label}
        {props.required === true ? (
          <span style={{ color: "#FF4C30" }}>*</span>
        ) : (
          ""
        )}{" "}
      </label>
      <input
        className="form-control"
        placeholder={props.label}
        value={props.value ? numberFormat(props.value) : ""}
        readOnly={props.readOnly}
        onChange={(e) => props.__handleChange(e)}
      />

      <span className="input-icon">{props.icon}</span>
      {props.value ? (
        <p style={{ fontSize: "10px" }}>
          {numberToWord(props.value.replace(/\D+/g, ""))}
        </p>
      ) : (
        ""
      )}
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default PersonalAmountInput;
