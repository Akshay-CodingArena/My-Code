import React from "react";
const Gender = (props) => {
  console.log("gender tick", props.value)
  return (
    <div className="form-group">
      <label htmlFor="Gender">
        Gender
        <span style={{ color: "#FF4C30" }}>*</span>
      </label>
      <div onChange={(e) => props.onChangeGender(e)}>
        <div className="form-check form-check-inline radioBtn">
          <input
            key={Math.random().toString()}
            className="form-check-input"
            id="male"
            type="radio"
            value="1"
            name="gender"
            defaultChecked={props.value == "1" ? true : false}
          />
          <label className="form-check-label" htmlFor="male">
            Male{" "}
          </label>
        </div>
        <div className="form-check form-check-inline radioBtn">
          <input
            key={Math.random().toString()}
            className="form-check-input"
            type="radio"
            id="female"
            value="2"
            name="gender"
            defaultChecked={props.value == "2" ? true : false}
          />{" "}
          <label className="form-check-label" htmlFor="female">
            {" "}
            Female
          </label>
        </div>
        {props.hideOther ? null : <div className="form-check form-check-inline radioBtn">
          <input
            key={Math.random().toString()}
            className="form-check-input"
            type="radio"
            id="other"
            value="3"
            name="gender"
            defaultChecked={props.value == "3" ? true : false}
          />{" "}
          <label className="form-check-label" htmlFor="other">
            {" "}
            Other
          </label>
        </div>}
      </div>
      <span className="input-icon">{props.icon}</span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default Gender;
