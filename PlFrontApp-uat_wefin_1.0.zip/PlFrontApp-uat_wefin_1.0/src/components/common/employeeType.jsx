import React from "react";
import { decryptStore } from "../../Utils/store";
import CONSTANTS from "../../constants/Constants";

const EmployeeType = (props) => {
  let mobile = localStorage.getItem("mobilenumber");
  let decryptedData = decryptStore(mobile);
  let { loanType } = decryptedData;
  return (
    <div className="form-group">
      <label htmlFor="EmployeeType">
        Employment Type
        <span style={{ color: "#FF4C30" }}>*</span>
      </label>
      <div onChange={(e) => props.onChangeEmployeeType(e)}>
        <div className="form-check form-check-inline radioBtn">
          <input
            className="form-check-input"
            type="radio"
            id="Salaried"
            value="1"
            name="employeetype"
            checked={props.employeetype === '1'}

          />
          <label className="form-check-label" htmlFor="Salaried">
            Salaried{" "}
            <span>Earn a fixed income monthly</span>
          </label>
        </div>
        <div className="form-check form-check-inline radioBtn">
          <input
            className="form-check-input"
            type="radio"
            id="SelfEmpBus"
            value="2"
            name="employeetype"
            checked={props.employeetype === '2'}
          />{" "}
          {loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN || props.showAll ? (<label className="form-check-label" htmlFor="SelfEmpBus">
            {" "}
            Self Employed Business
            <span>Run a Business</span>
          </label>) : <label className="form-check-label disabled" htmlFor="SelfEmpBus">
            {" "}
            Self Employed Business
            <span>Run a Business</span>
          </label>}

        </div>
        {loanType === CONSTANTS.LOAN_TYPE.HOME_LOAN ? ("") : (
          props.showAll ? <div className="form-check form-check-inline radioBtn">
            <input
              className="form-check-input"
              type="radio"
              id="SelfEmpPro"
              value="3"
              name="employeetype"
              checked={props.employeetype === '3'}
            />{" "}
            <label className="form-check-label" htmlFor="SelfEmpPro">
              Self Employed Professional
              <span>Practice a Profession (Eg. Doctor, Lawyers, CA)</span>
            </label>
          </div> :
            <div className="form-check form-check-inline radioBtn">
              <input
                disabled
                className="form-check-input"
                type="radio"
                id="SelfEmpPro"
                value="3"
                name="employeetype"
                checked={props.employeetype === '3'}
              />{" "}
              <label className="form-check-label disabled" htmlFor="SelfEmpPro">
                Self Employed Professional
                <span>Practice a Profession (Eg. Doctor, Lawyers, CA)</span>
              </label>
            </div>
        )}

      </div>

      <span className="input-icon">{props.icon}</span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default EmployeeType;
