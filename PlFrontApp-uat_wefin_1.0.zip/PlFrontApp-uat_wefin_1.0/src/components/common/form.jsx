import React, { Component } from "react";
import Joi from "joi-browser";
import Input from "./input";
import Email from "./email";
import CreditInput from "./creditInput";
import MaleIcon from "../../include/assets/userIcons/male.svg"
import FemaleIcon from "../../include/assets/userIcons/female.svg"
import OtherIcon from "../../include/assets/userIcons/other.svg"
import SingleIcon from "../../include/assets/userIcons/single.svg"
import MarriedIcon from "../../include/assets/userIcons/married.svg"
import DivorceIcon from "../../include/assets/userIcons/divorce.svg"
import TickIcon from "../../include/assets/userIcons/tick.svg"

class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
      errors: {},
    };
  }
  validate = () => {
    const options = { abortEarly: false };
    const { error } = Joi.validate(this.state.data, this.schema, options);
    if (!error) return null;
    const errors = {};
    for (let item of error.details) errors[item.path[0]] = item.message;
    return errors;
  };

  validateProperty = ({ name, value }) => {
    const obj = { [name]: value };
    const schema = { [name]: this.schema[name] };
    const { error } = Joi.validate(obj, schema, { abortEarly: false });
    return error ? error.details[0].message : null;
  };

  setErrors = (input) => {
    const errors = { ...this.state.errors };
    const errorMessage = this.validateProperty(input);
    if (errorMessage) {
      errors[input.name] = errorMessage;
    } else {
      delete errors[input.name];
    }
    this.setState({ errors });
  };



  handleSubmit = (e) => {

    if (e) e.preventDefault();
    const errors = this.validate();

    this.setState({ errors: errors || {} });
    console.log("errors are", errors)

    if (errors) return;

    this.doSubmit();
  };

  handleChange = ({ currentTarget: input }) => {
    const errors = { ...this.state.errors };
    const errorMessage = this.validateProperty(input);
    if (errorMessage) errors[input.name] = errorMessage;
    else delete errors[input.name];
    if (input.name === "reAccNo") {
      if (
        this.state.data.accNo === input.value ||
        this.state.data.accNo === input.value
      ) {
        delete errors[input.name];
      }
    }
    const data = { ...this.state.data };
    data[input.name] = input.value;

    this.setState({ data, errors });
  };


  handleBlur = ({ currentTarget: input }) => {
    this.setErrors(input);
  };

  renderInput(
    name,
    label,
    icon,
    readOnly,
    max,
    min,
    type = "text",
    required,
    decapitalize
  ) {
    const { data, errors } = this.state;
    return (
      <Input
        name={name}
        value={data[name]}
        label={label}
        onChange={this.handleChange}
        error={errors[name]}
        readOnly={readOnly}
        icon={icon}
        max={max}
        min={min}
        type={type}
        required={required}
        decapitalize={decapitalize}
      />
    );
  }
  show = (name, option, value, readOnly) => {
    console.log("change in ", name)
    return (<>{
      option.value == value ? <div className="card"  >
        <img className="cardIcon" src={option.icon} />
        <p>{option.name}</p>
        <div disable={readOnly} style={{ display: 'none' }}>Btn</div>
        <img className="selectIcon" src={TickIcon} />
      </div> : (name === "gender" ? <button disabled={readOnly} onClick={() => this.setState({ ...this.state, data: { ...this.state.data, gender: option.value } })} className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px', border: '1px solid #568AC375', borderRadius: '5px', width: '90px', height: '70px', opacity: '0.5' }}>
        <img className="cardIcon" src={option.icon} />
        <p>{option.name}</p>
      </button> : <button disabled={readOnly} onClick={() => this.setState({ ...this.state, data: { ...this.state.data, relationship: option.value } })} className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px', border: '1px solid #568AC375', borderRadius: '5px', width: '90px', height: '70px' }}>
        <img className="cardIcon" src={option.icon} />
        <p>{option.name}</p>
      </button>)
    }
    </>
    )
  }


  renderPersonInfo = (props) => {
    let genderList = [{ name: "Male", icon: MaleIcon, value: "Male" }, { name: "Female", icon: FemaleIcon, value: "Female" }, { name: "Other", icon: OtherIcon, value: "Other" }]
    let marriageStatusList = [{ name: "Single", icon: SingleIcon, value: "Single" }, { name: "Married", icon: MarriedIcon, value: 'Married' }, { name: "Other", icon: DivorceIcon, value: 'Other' }]
    return (<div className="personInfo form-group">
      <p className="heading">{props.variant === 'gender' ? "Gender" : "Marital Status"} <span style={{ color: "#FF4C30" }}>*</span></p>
      <div className="box" >
        {props.variant === "gender" ? genderList.map(option => this.show("gender", option, props.value, props.readOnly))
          : marriageStatusList.map(option => this.show("relationship", option, props.value, props.readOnly)
          )}
      </div>
      {props.error && <p className="exp  error-form">{props.error}</p>}
    </div>
    )
  }
  renderIncome(name,
    label,
    icon,
    readOnly = false,
    max,
    min,
    type = "text",
    required) {
    return
  }
  renderEmail(
    name,
    label,
    icon,
    readOnly = false,
    cibil,
    max,
    min,
    type = "email"
  ) {
    const { data, errors } = this.state;

    return (
      <Email
        type={type}
        name={name}
        value={data[name]}
        label={label}
        onChange={this.handleChange}
        error={errors[name]}
        readOnly={readOnly}
        icon={icon}
        max={max}
        min={min}
      />
    );
  }
  renderCreditInput(name, label, type = "text", readOnly = false) {
    const { data, errors } = this.state;

    return (
      <CreditInput
        type={type}
        name={name}
        value={data[name]}
        label={label}
        onChange={this.handleChange}
        error={errors[name]}
        readOnly={readOnly}
      />
    );
  }
}
export default Form;
