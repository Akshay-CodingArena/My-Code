import React from "react";
import { ReactComponent as LocationIcon } from "../../include/assets/homepageIcons/icon-pincode.svg";
import CONSTANTS from "../../constants/Constants";


const Pincode = (props) => {

  return (
    <div className="form-group">
      <label htmlFor="pincode">
        Pin Code
        <span style={{ color: "#FF4C30" }}>*</span>
      </label>

      {props.step === CONSTANTS.RENDER_PERMANENT_ADDRESS ? (
        <input
          className="form-control"
          placeholder="Pin Code"
          value={props.value}
          onChange={(e) => props.__handlePinCode(e)}
          maxLength="6"
          minLength="6"
          disabled={props.disabled ? true : false}
        />
      ) : (
        <input
          // key={Math.random(10).toString()}
          className="form-control"
          placeholder="Pin Code"
          defaultValue={props.value}
          onChange={(e) => props.__handlePinCode(e)}
          maxLength="6"
          minLength="6"
          type="text"
          disabled={props.disabled ? true : false}
        />
      )}
      <span className="input-icon">
        {" "}
        <LocationIcon />
      </span>
      {props.error && <p className="error-form">{props.error}</p>}
    </div>
  );
};
export default Pincode;
