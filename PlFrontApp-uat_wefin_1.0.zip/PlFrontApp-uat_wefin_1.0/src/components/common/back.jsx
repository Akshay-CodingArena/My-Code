import React from "react";
import BackIcon from "../../include/assets/back_icon.png";

const Back = (props) => {
  return (
    <div
      className="bsBackBtn"
      onClick={(e) => {
        props.onClick(e);
      }}
      
    >
      <img src={BackIcon} alt="" />
      Back
    </div>
  );
};
export default Back;
