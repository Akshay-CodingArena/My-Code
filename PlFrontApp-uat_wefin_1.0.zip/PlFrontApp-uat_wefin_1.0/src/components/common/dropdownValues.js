export const mailing = [
  {
    value: "RES",
    label: "Residence",
  },
  {
    value: "PER",
    label: "Permanent",
  },
  {
    value: "OFF",
    label: "Office",
  },
];
export const designation = [
  {
    value: "20",
    label: "Junior Management",
  },
  {
    value: "30",
    label: "Middle Management",
  },
  {
    value: "40",
    label: "Senior Management",
  },
  {
    value: "50",
    label: "Other",
  },
];

export const workTypeField = [
  {
    value: "F",
    label: "Service -Private Sector (Controller/Owner/Director)",
  },
  {
    value: "E",
    label: "Self Employed",
  },
  {
    value: "G",
    label: "Service -Private Sector (General)",
  },
  {
    value: "I",
    label: "Service -Public Sector (Controller/Owner/Director)",
  },
  {
    value: "J",
    label: "Service -Public Sector (General)",
  },
  {
    value: "K",
    label: "Service -Government Sector (Controller/Owner/Director)",
  },
  {
    value: "L",
    label: "Service -Government Sector (General)",
  },
  {
    value: "Y",
    label: "Business",
  },
  {
    value: "P",
    label: "Professional",
  },
];
export const residential = [
  {
    value: "CT",
    label: "Citizen",
  },
  {
    value: "FR",
    label: "Foreigner",
  },
  {
    value: "PR",
    label: "Permanent resident",
  },
  {
    value: "MW",
    label: "Migrant worker",
  },
  {
    value: "RE",
    label: "Refugee/Stateless",
  },
  {
    value: "TO",
    label: "Tourist",
  },
];
export const titleFields = [
  {
    value: "MR",
    label: "Mr",
  },
  {
    value: "MRS",
    label: "Mrs",
  },
  {
    value: "MS",
    label: "Ms",
  },
  {
    value: "DR",
    label: "Doctor",
  },
];

export const relationship_type = [
  {
    value: "1",
    label: "Salary Account",
  },
  {
    value: "2",
    label: "Saving Account",
  },
  {
    value: "3",
    label: "Current Account",
  },
  {
    value: "4",
    label: "Term Deposit",
  },
  {
    value: "5",
    label: "Credit Card",
  },
  {
    value: "6",
    label: "Personal Loan",
  },
  {
    value: "7",
    label: "Home Loan",
  },
  {
    value: "8",
    label: "Overdraft Account",
  },
  {
    value: "9",
    label: "Business Loan",
  },
];
export const income_proof = [
  {
    value: "T0235",
    label: "Payslip (Recommended Document)",
  },
  {
    value: "T0356",
    label: "ITR Document",
  },
  {
    value: "T0356",
    label: "ITR Document",
  },
];

export const industryField = [
  {
    value: "1",
    label: "ACCOUNTANCY",
  },
  {
    value: "3",
    label: "ADVERTISING",
  },
  {
    value: "9",
    label: "AIRLINES",
  },
  {
    value: "11",
    label: "BPO",
  },
  {
    value: "12",
    label: "AUTOMOBILES",
  },
  {
    value: "13",
    label: "BUREAU",
  },
  {
    value: "16",
    label: "BANKING",
  },
  {
    value: "17",
    label: "INSURANCE",
  },
  {
    value: "18",
    label: "CONSUMER GOODS",
  },
  {
    value: "24",
    label: "ENTERTAINMENT",
  },
  {
    value: "26",
    label: "COLLEGE INSTITUTE",
  },
  {
    value: "28",
    label: "HOSPITALS",
  },
  {
    value: "29",
    label: "NGO",
  },
  {
    value: "31",
    label: "PETROLEUM",
  },
  {
    value: "32",
    label: "PHARMA",
  },
  {
    value: "33",
    label: "OTHERS",
  },
  {
    value: "39",
    label: "RAILWAYS",
  },
  {
    value: "40",
    label: "SCHOOLS",
  },
  {
    value: "41",
    label: "REAL ESTATE",
  },
  {
    value: "42",
    label: "ENGINEERING/INFRASTRUCTURE",
  },
  {
    value: "43",
    label: "TELECOM",
  },
  {
    value: "44",
    label: "TRADING",
  },
  {
    value: "45",
    label: "SOFTWARE / IT",
  },
  {
    value: "46",
    label: "EXPORT/ IMPORT",
  },
  {
    value: "47",
    label: "TRANSPORTATION",
  },
  {
    value: "55",
    label: "HOTEL",
  },
  {
    value: "56",
    label: "MANUFACTURING",
  },
  {
    value: "57",
    label: "MINISTRIES",
  },
  {
    value: "67",
    label: "POLICE",
  },
  {
    value: "70",
    label: "POST",
  },
  {
    value: "74",
    label: "POWER",
  },
  {
    value: "78",
    label: "SHARE / BROKERAGE",
  },
  {
    value: "90",
    label: "TRAVEL",
  },
  {
    value: "92",
    label: "ECOMMERCE",
  },
];
export const accomodation_type = [
  {
    value: "1",
    label: "1 room apartment",
  },
  {
    value: "2",
    label: "2 room apartment",
  },
  {
    value: "3",
    label: "1 BHK apartment",
  },
  {
    value: "4",
    label: "2 BHK apartment",
  },
  {
    value: "5",
    label: "3/4 BHK apartment",
  },
  {
    value: "6",
    label: "Row House / Villa / Bunglow",
  },
];
export const residence_type = [
  {
    value: "SO",
    label: "Self Owned",
  },
  {
    value: "LR",
    label: "Living with Relatives/Parents",
  },
  {
    value: "RE",
    label: "Rented",
  },
  {
    value: "BA",
    label: "Bachelor accommodation",
  },
  {
    value: "LO",
    label: "Lodge",
  },
  {
    value: "CO",
    label: "Company / Employer Quarter",
  },
];
export const residence_type_credit_saison = [
  {
    value: "RE",
    label: "Rented",
  },
  {
    value: "SO",
    label: "Self Owned",
  },
  {
    value: "LP",
    label: "Staying with Parents",
  },
  {
    value: "PG",
    label: "Pg",
  },
];
export const qualificationField = [
  {
    value: "UND",
    label: "Under Graduate",
  },
  {
    value: "SEC",
    label: "SSC/HSC",
  },
  {
    value: "PSC",
    label: "Primary School",
  },
  {
    value: "DIP",
    label: "Diploma holder",
  },
  {
    value: "GRD",
    label: "Graduate",
  },
  {
    value: "PGD",
    label: "Post-Graduate",
  },
  {
    value: "PRF",
    label: "Professional qualification",
  },
];

export const SEP_profession = [
  {
    value: "3",
    label: "Architect (B.Arch)",
  },
  {
    value: "4",
    label: "CA",
  },
  {
    value: "5",
    label: "Consultant",
  },
  {
    value: "6",
    label: "Doctor",
  },
  {
    value: "7",
    label: "Employee (Central/State Govt.)",
  },
  {
    value: "8",
    label: "Engineer (B.Tech / B.E)",
  },
  {
    value: "9",
    label: "Lawyer",
  },
  {
    value: "10",
    label: "Others",
  },
  {
    value: "11",
    label: "Retainer",
  },
  {
    value: "12",
    label: "Teacher (Govt. Recognized Institution)",
  },
];
export const applicant_type = [
  {
    value: "1",
    label: "Proprietor",
  },
  {
    value: "2",
    label: "Partner applying as as individual",
  },
  {
    value: "3",
    label: "Director applying as as individual",
  },
  {
    value: "4",
    label: "Partnership Firm",
  },
  {
    value: "5",
    label: "Employee of company",
  },
];
export const employment_type = [
  {
    value: "1",
    label: "Salaried",
  },
  {
    value: "2",
    label: "Self Employed Business",
  },
  // {
  //   value: "3",
  //   label: "Self Employed Professional",
  // },
];
export const total_wrk_exp = [
  {
    value: "1",
    label: "Less than 1 Year",
  },
  {
    value: "2",
    label: "1-2 years",
  },
  {
    value: "3",
    label: "2-3 years",
  },
  {
    value: "4",
    label: "3-4 years",
  },
  {
    value: "5",
    label: "4-5 years",
  },
  {
    value: "6",
    label: "5-6 years",
  },
  {
    value: "7",
    label: "Greater than 6 years",
  },
];

export const other_doc_type = [
  {
    value: "passport",
    label: "Passport",
  },
  {
    value: "drivingLicence",
    label: "Driving Licence",
  },
  {
    value: "voterId",
    label: "Voter ID",
  },
];
export const loan_purpose_acc = [
  {
    value: "1",
    label: "Children education",
  },
  {
    value: "2",
    label: "House Renovation",
  },
  {
    value: "3",
    label: "Vehicle",
  },
  {
    value: "4",
    label: "Consumer Durable",
  },
  {
    value: "5",
    label: "Medical Expenses",
  },
  {
    value: "6",
    label: "Marriage in family",
  },
  {
    value: "7",
    label: "Travel/Holiday",
  },
  {
    value: "8",
    label: "Others",
  },
];
export const genderField = [
  {
    value: "1",
    label: "Male",
  },
  {
    value: "2",
    label: "Female",
  },
];

export const cityField = [
  {
    value: "22",
    label: "Ahmedabad",
  },
  {
    value: "707",
    label: "Baroda",
  },
  {
    value: "19",
    label: "Bengaluru",
  },
  {
    value: "9",
    label: "Chandigarh",
  },
  {
    value: "21",
    label: "Chennai",
  },
  {
    value: "241",
    label: "Cochin",
  },
  {
    value: "69",
    label: "Coimbatore",
  },
  {
    value: "87",
    label: "Ghaziabad",
  },
  {
    value: "704",
    label: "Greater Noida",
  },
  {
    value: "7",
    label: "Gurgaon",
  },
  {
    value: "7",
    label: "Gurugram",
  },
  {
    value: "15",
    label: "Hyderabad",
  },
  {
    value: "106",
    label: "Indore",
  },
  {
    value: "100",
    label: "Jaipur",
  },
  {
    value: "64",
    label: "Kolkata",
  },
  {
    value: "25",
    label: "Mumbai",
  },
  {
    value: "135",
    label: "Nagpur",
  },
  {
    value: "163",
    label: "Navi mumbai",
  },
  {
    value: "318",
    label: "New Delhi",
  },
  {
    value: "318",
    label: "DELHI",
  },
  {
    value: "78",
    label: "Noida",
  },
  {
    value: "26",
    label: "Pune",
  },
  {
    value: "94",
    label: "Secunderabad",
  },
  {
    value: "190",
    label: "Surat",
  },
  {
    value: "640",
    label: "Thane",
  },
  {
    value: "1035",
    label: "Rajkot",
  },
  {
    value: "623",
    label: "Bhopal",
  },
  {
    value: "10",
    label: "Cuttak",
  },
  {
    value: "11",
    label: "Bhubaneshwar",
  },
  {
    value: "981",
    label: "Faridabad",
  },
];

export const bankName = [
  { value: "10", label: "Abhyudaya Co-op. Bank Ltd." },
  { value: "20", label: "ACE Co-Operative Bank Ltd." },
  { value: "30", label: "Allahabad Bank" },
  { value: "40", label: "Amanath Co-op. Bank Ltd." },
  { value: "50", label: "American Express Banking Corporation" },
  { value: "60", label: "Andhra Bank" },
  { value: "70", label: "Apna Sahakari Bank Ltd." },
  { value: "80", label: "Axis Bank" },
  { value: "90", label: "Bank of America N.A." },
  { value: "100", label: "Bank of Baroda" },
  { value: "110", label: "Bank of India" },
  { value: "120", label: "Bank of Maharashtra" },
  { value: "130", label: "Barclays Bank" },
  { value: "140", label: "Canara Bank" },
  { value: "150", label: "Capital Local Area Bank Ltd." },
  { value: "160", label: "Central Bank of India" },
  { value: "170", label: "Citibank N.A." },
  { value: "180", label: "City Union Bank Ltd." },
  { value: "190", label: "Coastal Local Area Bank Ltd." },
  { value: "200", label: "Corporation Bank" },
  { value: "210", label: "Dena Bank" },
  { value: "220", label: "Deutsche Bank AG" },
  { value: "230", label: "Development Credit Bank Ltd." },
  { value: "240", label: "Dhanlaxmi Bank Ltd." },
  { value: "250", label: "HDFC Bank" },
  { value: "260", label: "HSBC Bank" },
  { value: "270", label: "ICICI Bank" },
  { value: "280", label: "IDBI Bank Ltd." },
  { value: "290", label: "Indian Bank" },
  { value: "300", label: "Indian Overseas Bank" },
  { value: "310", label: "IndusInd Bank Ltd." },
  { value: "320", label: "ING Vysya Bank Ltd." },
  { value: "330", label: "Jammu &amp; Kashmir Bank Ltd." },
  { value: "340", label: "Karnataka Bank Ltd." },
  { value: "350", label: "Karur Vysya Bank Ltd." },
  { value: "360", label: "Kotak Mahindra Bank Ltd." },
  { value: "370", label: "Krishna Bhima Samruddhi Local Area Bank Ltd." },
  { value: "380", label: "New India Co-op. Bank Ltd." },
  { value: "390", label: "Oriental Bank of Commerce" },
  { value: "400", label: "Punjab & Maharashtra Co-op. Bank Ltd." },
  { value: "410", label: "Punjab & Sind Bank" },
  { value: "420", label: "Punjab National Bank" },
  { value: "430", label: "Royal Bank of Scotland" },
  { value: "440", label: "SBI Commercial and International" },
  { value: "450", label: "South Indian Bank Ltd." },
  { value: "460", label: "Standard Chartered Bank" },
  { value: "470", label: "State Bank of Bikaner & Jaipur" },
  { value: "480", label: "State Bank of India" },
  { value: "490", label: "State Bank of Mysore" },
  { value: "500", label: "State Bank of Patiala" },
  { value: "510", label: "State Bank of Travancore" },
  { value: "520", label: "Syndicate Bank" },
  { value: "530", label: "Tamilnad Mercantile Bank Ltd." },
  { value: "540", label: "The Bank of Rajasthan Ltd." },
  { value: "550", label: "The Catholic Syrian Bank Ltd." },
  { value: "560", label: "The Federal Bank Ltd." },
  { value: "570", label: "The Lakshmi Vilas Bank Ltd." },
  { value: "580", label: "The Nainital Bank Ltd." },
  { value: "590", label: "The Ratnakar Bank Ltd." },
  { value: "600", label: "The Saraswat Co-op. Bank Ltd." },
  { value: "610", label: "UCO Bank" },
  { value: "620", label: "Union Bank of India" },
  { value: "630", label: "United Bank of India" },
  { value: "640", label: "Vijaya Bank" },
  { value: "650", label: "Yes Bank" },
  { value: "999", label: "Others" },
];
export const occupationField = [
  { value: "1", label: "Medical Officer" },
  { value: "2", label: "Judge/Lawyer/Barrister/Solicitor" },
  { value: "3", label: "Chartered Architect" },
  { value: "5", label: "Pilot/ Aircraft Captain/ Ship Captain" },
  { value: "7", label: "SCB Staff" },
  { value: "8", label: "Chartered Surveyor/Surveyor/Valuer" },
  { value: "9", label: "CONSULATE/COUNCIL MEMBER" },
  { value: "10", label: "Doctor/Dentist/Medical & Healthcare Specialist" },
  { value: "11", label: "Chartered Accountant" },
  { value: "13", label: "Chartered Engineer/Engineer" },
  {
    value: "15",
    label: "Director/President/ Chairman/ Chief Executive Offi...",
  },
  { value: "16", label: "Nurse" },
  { value: "19", label: "Lecturer/Professor/Headmaster/Principal" },
  { value: "22", label: "Computer PROGRAMMER/System ANALYST/System ENGINEER" },
  {
    value: "23",
    label: "Optician/Pharmacist/Laboratory Operator/Radiograph...",
  },
  { value: "24", label: "Reportor/ Editor/ Journalist/ Translator" },
  { value: "26", label: "Social Worker" },
  { value: "30", label: "Computer Operater" },
  { value: "32", label: "Retail Sales Person/Promoter" },
  {
    value: "34",
    label: "Teacher Kindergarden/Primary & Secondary School/Tu...",
  },
  { value: "38", label: "Beauty Consultant/ Hair Stylist" },
  {
    value: "43",
    label: "Industrial Quality Control Staff/ Warehouse Worker...",
  },
  { value: "45", label: "CIVIL SERVANT (Non Civil Service/Contract)" },
  { value: "48", label: "Artist/Actor/Entertainer/Model" },
  {
    value: "49",
    label: "Film Producer/ Film Director/Camera Man/ Light Boa...",
  },
  { value: "51", label: "Cabin Crew/Gound Staff" },
  { value: "60", label: "Marketing Executive" },
  {
    value: "71",
    label: "Money Transmition Agent/ Foreign Currency Exchange...",
  },
  { value: "72", label: "Insurance Agent/ Insurance Broker/ Insurance Sales" },
  { value: "73", label: "CIVIL SERVANT (Civil Service Gov't Disciplinary)" },
  {
    value: "74",
    label: "CIVIL SERVANT (Civil Service Non Gov't Disciplinar...",
  },
  { value: "75", label: "Stock Broker/ Stock Dealer" },
  { value: "77", label: "Property Negotiator/Real Estate Agent" },
  {
    value: "80",
    label: "Personal Financial Consultant/ Investment Consulta...",
  },
  { value: "81", label: "Litigation Cleck/Legal Clerk" },
  { value: "84", label: "Private Tutorial" },
  { value: "89", label: "Coaching Staff/ Athlete / Trainer" },
  { value: "90", label: "Chinese Physician / Chinese Medical Dcotor" },
  { value: "91", label: "AIRFORCE/ Navy" },
  { value: "93", label: "Company Secretary" },
  { value: "94", label: "Manager/Executive" },
  { value: "95", label: "Officer/ Supervisor/ Administrator" },
];
export const industryIsicField = [
  { value: "RS01", label: "ART, ENTERTAINMENT, RECREATION & SPORTS" },
  { value: "RS03", label: "INVESTMENT & SECURITIES" },
  { value: "RS04", label: "INSURANCE" },
  { value: "RS05", label: "MONEY SERVICES AND INSURANCE AGENTS" },
  { value: "RS06", label: "BANKING, ACCOUNTING & FINANCE" },
  { value: "RS07", label: "BUILDING SERVICES & CONSTRUCTION" },
  { value: "RS08", label: "HOSPITALITY & TOURISM" },
  { value: "RS10", label: "EDUCATIONAL SERVICES" },
  { value: "RS11", label: "CATERING, RESTAURANT & FOOD SERVICES" },
  { value: "RS13", label: "LOCAL NON-PROFIT ORGANIZATION" },
  { value: "RS15", label: "LOCAL GOVERNMENT & PUBLIC UTILITIES" },
  { value: "RS16", label: "INFORMATION TECHNOLOGY" },
  { value: "RS17", label: "TELECOMMUNICATION" },
  { value: "RS19", label: "MANUFACTURING / INDUSTRIAL" },
  { value: "RS21", label: "DEFENCE AND WEAPONS" },
  { value: "RS23", label: "MEDIA & COMMUNICATION" },
  { value: "RS24", label: "MEDICAL & HEALTH CARE SERVICES" },
  { value: "RS25", label: "PERSONAL SERVICES, RETAIL & WHOLESALE" },
  { value: "RS26", label: "RETAIL JEWELRY, TOBACCO IMPORT AND EXPORT" },
  { value: "RS27", label: "PRECIOUS METALS AND DIAMONDS" },
  { value: "RS28", label: "PROPERTY MANAGEMENT & REAL ESTATE" },
  { value: "RS29", label: "PUBLIC TRANSPORTATION & LOGISTIC" },
  { value: "RS30", label: "LOGGING" },
  { value: "RS32", label: "AGRICULTURE AND FISHING" },
  { value: "RS33", label: "FORESTRY" },
  { value: "RS34", label: "OIL, GAS AND MINING INDUSTRY" },
  { value: "RS35", label: "Speciality" },
  { value: "RS36", label: "Textile" },
  { value: "RS37", label: "Automobile" },
  { value: "RS38", label: "Chemical Products" },
];

export const employerField = [
  {
    value: "C4439",
    label: "1 LOTUS MARKETING RESEARCH SERVICES",
  },
  {
    value: "C8340",
    label: "1 POINT HR SOLUTIONS (P) LIMITED",
  },
  {
    value: "C9401",
    label: "11ND AMERICAN BRIAN and SPINE CENTRE",
  },
  {
    value: "C6394",
    label: "11TH HOUR INNOVATIONS PRIVATE LIMITED",
  },
  {
    value: "C0491",
    label: "123 SIGNUP SOLUTIONS",
  },
  {
    value: "C6479",
    label: "159 TECHNOLOGY SOLUTIONS PRIVATE LIMITED",
  },
  {
    value: "C6837",
    label: "159 TECHNOLOGY SOLUTIONS PRIVATE LIMITED",
  },
  {
    value: "C9402",
    label: "20 MICRONS LIMITED",
  },
  {
    value: "C9403",
    label: "21ST CENTURY HEALTH MANAGEMENT SOLUTIONS PRIVATE. LIMITED",
  },
  {
    value: "C9404",
    label: "21ST CENTURY MANAGEMENT SERVICES LIMITED",
  },
];
export const organization_type = [
  {
    value: "Partnership Firm",
    label: "Partnership Firm",
  },
  {
    value: "Private Limited Company",
    label: "Private Limited Company",
  },
  {
    value: "Public Limited Company",
    label: "Public Limited Company",
  },
];
export const self_organization_type = [
  {
    value: "Partnership Firm",
    label: "Partnership Firm",
  },
];
export const propertyStatus = [
  {
    value: "O",
    label: "Corporate Provided",
  },
  {
    value: "C",
    label: "Mortgaged",
  },
  {
    value: "M",
    label: "Owned",
  },
  {
    value: "H",
    label: "Relatives House",
  },
  {
    value: "R",
    label: "Rented",
  },
];
export const relation_to_applicant = [
  {
    value: "1",
    label: "Father",
  },
  {
    value: "2",
    label: "Mother",
  },
  {
    value: "3",
    label: "Brother",
  },
  {
    value: "4",
    label: "Sister",
  },
  {
    value: "5",
    label: "Wife",
  },
  {
    value: "6",
    label: "Husband",
  },
  {
    value: "7",
    label: "Son",
  },
  {
    value: "8",
    label: "Daughter",
  },
  {
    value: "9",
    label: "Neighbour",
  },
  {
    value: "10",
    label: "Colleague",
  },
  {
    value: "11",
    label: "Friend",
  },
  {
    value: "12",
    label: "Uncle",
  },
  {
    value: "13",
    label: "Aunt",
  },
  {
    value: "14",
    label: "Others",
  },
];

export const relation_to_primary_app = [
  {
    value: "1",
    label: "Father",
  },
  {
    value: "2",
    label: "Mother",
  },
  {
    value: "3",
    label: "Brother",
  },
  {
    value: "4",
    label: "Sister",
  },
  {
    value: "5",
    label: "Wife",
  },
  {
    value: "6",
    label: "Husband",
  },
  {
    value: "7",
    label: "Son",
  },
  {
    value: "8",
    label: "Daughter",
  },
];

export const HL_LoanAmountDropdown = [
  {
    label: "₹ 1,500,000 - 2,500,000",

    value: "2500000",
  },

  {
    label: "₹ 2,600,000 - 3,500,000",

    value: "3500000",
  },

  {
    label: "₹ 3,600,000 - 4,500,000",

    value: "4500000",
  },

  {
    label: "₹ 4,600,000 - 5,500,000",

    value: "5500000",
  },

  {
    label: "₹ 5,600,000 - 6,500,000",

    value: "6500000",
  },
  {
    label: "₹ 6,600,000 - 7,500,000",

    value: "7500000",
  },
];

export const HL_PropertyTypeDropdown = [
  {
    value: "H",
    label: "House",
  },

  {
    value: "F",

    label: "Flat",
  },

  {
    value: "L",

    label: "Land",
  },
];

export const BUSINESS_LOAN_DROPDOWNS = {
  loanAmount: [
    {
      label: "₹ 1,500,000 - 2,500,000",

      value: "2500000",
    },

    {
      label: "₹ 2,600,000 - 3,500,000",

      value: "3500000",
    },

    {
      label: "₹ 3,600,000 - 4,500,000",

      value: "4500000",
    },

    {
      label: "₹ 4,600,000 - 5,500,000",

      value: "5500000",
    },

    {
      label: "₹ 5,600,000 - 6,500,000",

      value: "6500000",
    },

    {
      label: "₹ 6,600,000 - 7,500,000",

      value: "7500000",
    },
  ],

  companyType: [
    {
      label: "Sole Proprietorship",

      value: "SP",
    },

    {
      label: "Partnership",

      value: "P",
    },

    {
      label: "LLC",

      value: "L",
    },
  ],

  businessNature: [
    {
      label: "Retail",

      value: "R",
    },

    {
      label: "Manufacturing",

      value: "M",
    },

    {
      label: "Whole Selling",

      value: "WS",
    },

    {
      label: "Consignee",

      value: "C",
    },
  ],

  yearsInCurBussiness: [
    {
      label: "1-3 Years",

      value: "3",
    },

    {
      label: "3-6 Years",

      value: "6",
    },

    {
      label: "6-9 Years",

      value: "9",
    },

    {
      label: "9-12 Years",

      value: "12",
    },

    {
      label: "12-15 Years",
      value: "15",
    },
  ],
  annualTurnover: [
    {
      label: "Upto 5 Lacs",
      value: "500000",
    },
    {
      label: "5 Lacs - 10 Lacs",
      value: "1000000",
    },
    {
      label: "10 Lacs - 25 Lacs",
      value: "2500000",
    },
    {
      label: "25 Lacs - 50 Lacs",
      value: "5000000",
    },
    {
      label: "50 Lacs - 75 Lacs",
      value: "7500000",
    },
    {
      label: "75 Lacs - 1 Cr",
      value: "10000000",
    },
    {
      label: "1 Cr - 3 Cr",
      value: "30000000",
    },
    {
      label: "3 Cr - 5 Cr",
      value: "50000000",
    },
  ],
};

export const NATURE_OF_BUSINESS = [
  {
    label: "Manufacturing",
    value: "Manufacturing",
  },
  {
    label: "Trading",
    value: "Trading",
  },
  {
    label: "Services",
    value: "Services",
  },
];

export const FEEDBACK_FORM_DROPDOWN = [
  {
    label: "Overall Service",
    value: 1
  },
  {
    label: "Customer Service",
    value: 2
  },
  {
    label: "Online Support",
    value: 3
  },
  {
    label: "More Transparency",
    value: 4
  },
]

export const entries = [
  {
    value: 10,
    label: 10
  }, {
    value: 20,
    label: 20
  }, {
    value: 30,
    label: 30
  }, {
    value: 40,
    label: 40
  }, {
    value: 50,
    label: 50
  }]

export const employmentTypeFilter = { 1: "Salaried", 2: "Self Employed Business", 3: "Self Employed Professional" }

export const dropdown_gender_values = [{ value: '1', label: "Male" }, { value: '2', label: 'Female' }, { value: '3', label: 'Others' }]

export const send_link_type = [
  {
    label: "SMS",
    value: 0
  },
  {
    label: "E-SMS",
    value: 1
  }
]

export const RTO_values = [
  {
    value: "10026",
    label: "10026"
  },
  {
    value: "128",
    label: "128"
  },
  {
    value: "457",
    label: "457"
  },
  {
    value: "274",
    label: "274"
  },
  {
    value: "804",
    label: "804"
  },
  {
    value: "842",
    label: "842"
  }
]


export const HDFC_Educational_Qualification_Dropdown = [
  {
    value: "GRAD",
    label: "Graduate"
  },
  {
    value: "DOCTRATE",
    label: "Doctorate"
  },
  {
    value: "POSTGRAD",
    label: "Post-graduate"
  },
  {
    value: "OTHERS",
    label: "Others"
  }
]

export const Loan_Type_ASM = [
  { label: "PERSONAL_LOAN", value: "Personal_Loan" },
  { label: "HOME_LOAN", value: "Home_Loan" },
  { label: "BUSINESS_LOAN", value: "Business_Loan" }
]

export const sourceTypeFOSDropdown = [
  {
    value: "FOS_ADMIN",
    label: "ALL DATA"
  },
  {
    value: "FOS",
    label: "FOS"
  },
  {
    value: "FOS_CALL",
    label: "CALL CENTER"
  }
]