import React, { Component } from "react";

class CreditInput extends Component {
  render() {
    const { name, label, error, readOnly, ...rest } = this.props;
    return (
      <div className="group form-group">
        <input
          name={name}
          id={name}
          className="form-control"
          readOnly={readOnly}
          {...rest}
          required
        />
        {error && <span className="error-form">{error}</span>}
        <span className="highlight"></span>
        <span className="bar"></span>
        <label htmlFor={name}>
          {label}
          <span>*</span>
        </label>
      </div>
    );
  }
}

export default CreditInput;
