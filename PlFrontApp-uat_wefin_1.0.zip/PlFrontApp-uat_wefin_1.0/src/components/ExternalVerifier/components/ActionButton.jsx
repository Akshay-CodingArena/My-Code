const ActionButton = (props) => {

    const handleApprove = () => {
        props.setAction({
            type: "approve",
        })
        // Swal.fire({
        //     icon: "success",
        //     title: "Approved",
        //     showConfirmButton: true,
        //     confirmButtonColor: "#2e0080 !important",
        // })
    }

    const handleReject = () => {
        props.setAction({
            type: "reject",
        })
    }
    return (<>
        {props.action !== "Reject" ? <div className="action approvebtn" style={{ cursor: "pointer" }} onClick={handleApprove} >
            <p>{props.action}</p>
        </div> : <div className="action rejectbtn" style={{ cursor: "pointer" }} onClick={handleReject}>
            <p>{props.action}</p>
        </div>}
    </>
    )
}
export default ActionButton