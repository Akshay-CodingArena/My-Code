import { useEffect } from "react"

function CustomUpload(props) {

    return (
        <div className="d-flex" style={{ alignSelf: 'centers' }}>
            <label className="extVerifierFileUpload" >
                Choose File
            </label>
            <p className="fileNameUploaded ml-4" onClick={() => props.viewPdf(URL.createObjectURL(props?.fileName))}>{props.fileName ? props.fileName.name : ""}</p>
        </div >
    )
}
export default CustomUpload