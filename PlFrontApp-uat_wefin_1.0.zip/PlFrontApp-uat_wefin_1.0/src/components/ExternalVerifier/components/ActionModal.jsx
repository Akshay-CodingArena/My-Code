import { useState } from "react";
import { Modal } from "react-bootstrap";

const ActionModal = (props) => {
    useState()
    return (<>
        <Modal className="bsOtpbox ccLoginBox" show={true}>
            <Modal.Body style={{ textAlign: "center" }}>
                {props.type === "approve" ? <div>
                    <h3 style={{ textAlign: 'center' }}>Approved</h3>
                    <p style={{ paddingLeft: '5px', paddingRight: '5px' }}>Dummy hjagsudsagusa sadkjsaudbsa dasduhasiudhsa sdausdhiasu Text asdsa sadwqjbd ewf df dsfdsfbsa asd asbdc amscbsajd</p>
                    <div style={{ margin: "auto" }} className="action approvebtn">OK</div>
                </div> : <div style={{ padding: "auto", background: "white", width: '300px' }}>
                    <h3 style={{ textAlign: 'center' }}>Approved</h3>
                    <p style={{ paddingLeft: '5px', paddingRight: '5px' }}>Dummy hjagsudsagusa sadkjsaudbsa dasduhasiudhsa sdausdhiasu Text asdsa sadwqjbd ewf df dsfdsfbsa asd asbdc amscbsajd</p>
                    <div style={{ margin: "auto" }} className="action approvebtn">OK</div>
                </div>}
            </Modal.Body></Modal>
    </>)
}

export default ActionModal
