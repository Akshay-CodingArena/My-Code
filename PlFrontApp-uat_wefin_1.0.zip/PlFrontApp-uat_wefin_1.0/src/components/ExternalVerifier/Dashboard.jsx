import { useEffect, useState } from "react";
import { Col, Container, ModalFooter, Row, Table } from "react-bootstrap";
import { useHistory, useLocation } from "react-router-dom";
import PATH from "../../paths/Paths";
import CustomerLogin from "./AddCustomer/CustomerLogin";
import ASMNavBar from "./ASMNavBar";
import UsersIcon from "../../include/assets/moneyPlus/users.svg"
import LocationIcon from "../../include/assets/moneyPlus/location.svg"
import { useDispatch, useSelector } from "react-redux";
import { loadPinCode } from "../../store/pincode";
import CreditFooter from "../cibilFlow/footer";
import DateRangePicker from
    '@wojtekmaj/react-daterange-picker'
import { getFullDay, getMonthName } from "./DateConverter";
import { numberFormat, numberFormatASM } from "../../Utils/numberFormat";
import CreatableSelect from "react-select/creatable";
import SelectSearch from "../common/select";
import ShowEntries from "../../common/ShowEntries";
import SearchBar from "../../common/SearchBar";
import Paging from "../../common/Pagination";
import CalenderIcon from "../../include/assets/moneyPlus/calendar.svg"
import ArrowDown from "../../include/assets/moneyPlus/down-arrow.svg"
import ApprovedIcon from "../../include/assets/moneyPlus/approvedApplication.svg"
import DisbursedIcon from "../../include/assets/moneyPlus/disbursedApplication.svg"
import ProgressIcon from "../../include/assets/moneyPlus/inProgressApplication.svg"
import RejectedIcon from "../../include/assets/moneyPlus/rejectedApplication.svg"
import TotalIcon from "../../include/assets/moneyPlus/totalApplication.svg"
import fileIcon from "../../include/assets/moneyPlus/doc.svg"
import editIcon from "../../include/assets/moneyPlus/edit.svg"
import IconsGenerator from "./IconsGenerator";
import Swal from "sweetalert2";
import ActionButton from "./components/ActionButton";
import ActionModal from "./components/ActionModal";
import BackDropComponent from "../../common/BackDropComponent";
import { fetchNstp, fetchNstpExternal, viewData } from "../../store/teleVerifier";
import { useRef } from "react";

const Dashboard = () => {
    // const history = useHistory()
    const [login, setLogin] = useState()
    const pinCodeLoader = useDispatch()
    const [state, setState] = useState({})
    const [dateFilter, setDateFilter] = useState([])
    const [calender, setCalender] = useState(false)
    const [currPage, setCurrPage] = useState(1)
    const [action, setAction] = useState(false)
    const history = useHistory()
    const nstpFetch = useDispatch()
    const loanApplication = useRef()
    const [offset, setOffset] = useState(10)
    const [totalPage, setTotalPage] = useState(1)
    const [readMore, setReadMore] = useState(2)

    const handleAddCustomer = () => {
        setLogin(true)
        //  history.push({ pathname: PATH.PRIVATE.ASM_ADD_CUSTOMER })
    }

    const dummy = [["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Approved"],
    ["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Pending"], ["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Approved"],
    ["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Approved"], ["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Approved"],
    ["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Approved"], ["12/02/2023", "LA-409090", "Naresh Singh", "Naresh Singh", "120000", "90000", "Approved"],]

    const callBackFetchNstp = (res) => {
        if (res) {
            let { teleVerificationInternalCount } = res.data?.data
            let { approveCount, pendingCount, rejectCount, totalCount } = teleVerificationInternalCount
            setState({
                ...state,
                data: res.data.data,
                pin: localStorage.getItem("pin"),
                city: localStorage.getItem("city"),
                totalCount,
                approveCount,
                pendingCount,
                rejectCount
            })
            setTotalPage(Math.ceil(approveCount / offset))
        }
    }
    useEffect(() => {

        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("TwScrool");
        if (!localStorage.getItem("TeleVerify_accessToken")) {
            if (window) {
                window.location.href = (window.location.origin + "/backoffice-login")
            }
        }

        let fromDate = new Date()
        fromDate.setDate(fromDate.getDate() - 7)
        setDateFilter([dateFormatter(fromDate), dateFormatter(new Date())])
        //  nstpFetch(fetchNstpExternal({ verifierRole: "external_verifier", page: currPage - 1, offset }, callBackFetchNstp))
    }, [])

    useEffect(() => {

        nstpFetch(fetchNstpExternal({ verifierRole: "external_verifier", page: currPage - 1, offset }, callBackFetchNstp))
    }, [offset, currPage])
    const dateFormatter = (date) => {
        const fromDay = getFullDay(date.getDate())

        const fromMonth = getMonthName(date.getMonth() + 1)
        const fromYear = date.getFullYear()
        return `${fromDay} ${fromMonth} ${fromYear}`
    }
    const changeDate = (range) => {
        if (range) {
            const fromDay = getFullDay(range[0].getDate())
            const toDay = getFullDay(range[1].getDate())
            const fromMonth = getMonthName(range[0].getMonth() + 1)
            const toMonth = getMonthName(range[1].getMonth() + 1)
            const fromYear = range[0].getFullYear()
            const toYear = range[1].getFullYear()

            setDateFilter([`${fromDay} ${fromMonth} ${fromYear}`, `${toDay} ${toMonth} ${toYear}`])
        }
    }

    const handleApprove = () => {
        Swal.fire({
            icon: "success",
            title: "Approved",
            showConfirmButton: true,
            confirmButtonColor: "#2e0080 !important",
        })
    }


    const callBackViewData = async (res) => {
        if (res.data) {
            history.push({ pathname: `${PATH.PRIVATE.VIEW_LOAN_APP_EXTERNAL}/${loanApplication.current}`, state: res.data })
        }
    }

    const handleView = (data) => {
        // let formData = {
        //     loanSfid: data?.loan_application_id__c
        // }
        loanApplication.current = data?.oppid
        history.push({ pathname: `${PATH.PRIVATE.VIEW_LOAN_APP_EXTERNAL}/${loanApplication.current}`, state: { loanSfid: data?.loan_application_id__c } })

    }

    const handleReadMore = (index) => {
        if (readMore === index) {
            setReadMore(-1)
        } else {
            setReadMore(index)
        }
    }

    return <>
        {action ? <ActionModal type={action?.type} onShow={true} /> : null}
        {useSelector(state => state.entities.asm.asmLoading) ? < BackDropComponent /> : null}
        {/* (action?.type === "approve" ? <div className="teleVerifyActionPopUp">
            <div style={{ padding: "auto", background: "white", width: '300px' }}>
                <h3 style={{ textAlign: 'center' }}>Approved</h3>
                <p style={{ paddingLeft: '5px', paddingRight: '5px' }}>Dummy hjagsudsagusa sadkjsaudbsa dasduhasiudhsa sdausdhiasu Text asdsa sadwqjbd ewf df dsfdsfbsa asd asbdc amscbsajd</p>
                <div style={{ margin: "auto" }} className="action approvebtn">OK</div>
            </div>
        </div> : <div className="teleVerifyActionPopUp">
            <div>
                <h3>Rejected</h3>
                <p style={{ paddingLeft: '5px', paddingRight: '5px' }}>Dummy hjagsudsagusa sadkjsaudbsa dasduhasiudhsa sdausdhiasu Text asdsa sadwqjbd ewf df dsfdsfbsa asd asbdc amscbsajd</p>
                <button>OK</button>
            </div>
        </div>) : null} */}
        <section className="bs-main-section asmDashBoard asm" >
            <ASMNavBar
                pin={state.pin}
                city={state.city}
                pinError={state.pinError}
                geoError={state.geoError}
                handleAddCustomer={handleAddCustomer} />
            <CustomerLogin show={login} handleCloseLogin={() => setLogin(false)} />
            <Container>
                <Row>
                    <div className="col-sm-8"><p className="font-weight-bolder">Welcome !<span className="ml-1" style={{ fontWeight: 'bold' }}> {` ${localStorage.getItem("ASM_firstName")}`}</span></p> </div>
                    <div className="col-sm-4" style={{ height: '30px' }}>
                        {/* {calender ? <div className="d-flex justify-content-end">
                            <DateRangePicker calendarIcon={<img src={CalenderIcon} />} clearIcon={<img src={ArrowDown} />} onCalendarClose={() => setCalender(false)} isOpen={calender} id="dateSelector" returnValue="range" value={dateFilter} onChange={changeDate} maxDate={new Date()} />
                        </div> :
                            <div className="d-flex justify-content-end" onClick={() => setCalender(true)}><img className="calenderIcon" src={CalenderIcon} /><p className="calenderDate">{`${dateFilter[0]} - ${dateFilter[1]}`}</p><img src={ArrowDown} className="calenderClearIcon" /></div>} */}
                    </div>
                    {/* <div className="col-sm-12 d-flex  justify-content-space-between flex-row-reverse mt-4 pb-4 asmDashoardShadow mobileBlock" >
                        <div className="d-flex align-items-center justify-content-end mt-4 mobileCenter" style={{ width: '100%' }}>
                            <img style={{ height: '100%' }} className="mr-4" src={UsersIcon} alt="" />
                        </div>
                        <div className="col-sm-6 pt-4 mobileCenter">
                            <h2 style={{ fontWeight: 'bold' }}>What is Personal Loan</h2>
                            <h4>hafhweoifweknanflk isahioewqhfa fds fkjbsgjbsd sajffw ef ds ds f fjdsf s jdsdsfsddsfdsf f dsfds fs</h4>
                            <button
                                type="submit"
                                onClick={handleAddCustomer}
                                variant="contained"
                                className="nextButton addCustomerBtn"
                            >
                                Add Customer
                            </button>
                        </div>

                    </div> */}
                    <div className="col-sm-12"><p className="font-weight-bolder mt-4">Tele Verification <span className="font-weight-bold">Status List</span></p></div>
                    <div class="container mt-1">
                        <div class="row" >
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6 " >
                                <div className="pt-4 pb-4 asmCard">
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={TotalIcon} />
                                        {/* <img className="mr-1 " src={UsersIcon} alt="" /> */}
                                        <p className="asmAppCount">{state.totalCount ? numberFormatASM(state.totalCount) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Total Request</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6" >
                                <div className="pt-4 pb-4 asmCard">
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={ProgressIcon} />
                                        <p className="asmAppCount">{state.pendingCount ? numberFormatASM(state.pendingCount) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Total Request Pending</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6 " >
                                <div className="pt-4 pb-4 asmCard">
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={ApprovedIcon} />
                                        <p className="asmAppCount">{state.approveCount ? numberFormatASM(state.approveCount) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Total Request Verified</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6" >
                                <div className="pt-4 pb-4 asmCard">
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={RejectedIcon} />
                                        <p className="asmAppCount">{state.rejectCount ? numberFormatASM(state.rejectCount) : "0"}</p>
                                    </div>
                                    <p className="asmAppTitle">Total Request Rejected</p>
                                </div>
                            </div>
                            {/* <div class="col-6 col-md-4 col-lg col-sm-6 col-xs-6" >
                                <div className="pt-4 pb-4 asmCard">
                                    <div className="pb-2 d-flex align-items-center justify-content-space-between">
                                        <IconsGenerator icon={RejectedIcon} />
                                        <p className="asmAppCount">{numberFormatASM(2000)}</p>
                                    </div>
                                    <p className="asmAppTitle">Application Rejected1</p>
                                </div>
                            </div> */}
                        </div>
                    </div>
                    <div class="container mt-1">
                        <div className="mt-4"><p className="font-weight-bolder">User Loan <span className="font-weight-bold">View</span></p></div>
                        <div className="col-12 mt-3 pt-2 pb-4 asmDashoardShadow" style={{ overflow: "auto" }} >
                            <div className="row">
                                {/* <div className="col-md-6 order-xs-1 order-md-2 col-sm-7 pt-4 asmmobileSearchBar">
                                    <SearchBar />
                                </div> */}
                                <div className="col-md-6 order-xs-2 order-md-1 col-sm-6 d-flex pt-4">
                                    <p className="font-weight-bolder asm">Show</p>
                                    <div style={{ marginTop: "-6px", marginLeft: "15px" }}>
                                        <ShowEntries totalApplication={state.approveCount} offset={state?.approveCount < 10 ? state.approveCount : offset} setOffset={setOffset} setCurrPage={setCurrPage} />
                                    </div>
                                    <p className="font-weight-bolder ml-2">Entries</p>
                                </div>
                            </div>
                            <Table className="asmLoansTable striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Loan Id</th>
                                        <th>Applicant Name</th>
                                        <th>NSTP Flag</th>
                                        <th>External Approval</th>
                                        <th>External Remarks</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {state?.data?.nstp?.map((data, index) => (
                                        <tr >
                                            <td align="left">
                                                {dateFormatter(new Date(data?.createddate))}
                                            </td>
                                            <td align="left">
                                                {data?.oppid}
                                            </td>
                                            <td align="left">
                                                {data?.accname}
                                            </td>
                                            <td align="left">
                                                {data?.flag__c === null ? "Pending" : (data?.flag__c === true ? "Approved" : "Rejected")}
                                            </td>
                                            <td align="left">
                                                {data?.external_verified__c === null ? "Pending" : (data?.external_verified__c === "TRUE" ? "Approved" : "Rejected")}
                                            </td>
                                            <td style={{ maxWidth: "300px" }}>
                                                {data?.external_remark__c ? (data.external_remark__c.length <= 40 ? data.external_remark__c : readMore === index ? <p>{data?.external_remark__c}<span className={'readMore'} onClick={handleReadMore}>...Less</span></p> : (<p>{data.external_remark__c.slice(0, 40)}<span onClick={() => handleReadMore(index)} className="readMore">...More</span></p>)) : ""}
                                            </td>
                                            <td align="left">
                                                <div className="action approvebtn" style={{ cursor: "pointer" }} onClick={() => handleView(data)} >
                                                    <img className="viewTeleVerifier" src={fileIcon} />
                                                </div>
                                            </td>
                                        </tr>
                                    ))}

                                </tbody>

                            </Table>
                            <div className="row mt-2">
                                {state.approveCount ? <p className="asmFontSmall col-6">{`Showing ${(offset * (currPage - 1)) + 1} to ${state.approveCount < (offset * currPage) ? state.approveCount : offset * currPage} of ${state.approveCount} entries`}</p> : <p>No Entries Found</p>}
                                <div className="col-6 d-flex" style={{ flexDirection: 'row-reverse' }}>
                                    {totalPage > 1 ? <Paging pages={totalPage} currPage={currPage} setCurrPage={setCurrPage} /> : null}
                                </div>
                            </div>
                        </div>
                    </div>
                </Row>
                <CreditFooter />
            </Container>
        </section >
    </>
}

export default Dashboard