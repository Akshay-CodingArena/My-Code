import { useEffect, useState } from "react"
import { Col, Container, Modal, Row, Tab, Tabs, Form, Button, Card } from "react-bootstrap"
import { useDispatch, useSelector } from "react-redux"
import { Link, useHistory, useLocation } from "react-router-dom"
import BackDropComponent from "../../common/BackDropComponent"
import { getExperian, loadExperianCheck3 } from "../../store/experian"
import { adminSubmit, externalSubmit, getASM, updateNstpAction, viewData } from "../../store/teleVerifier"
import { numberFormat, numberFormatASM } from "../../Utils/numberFormat"
import ASMNavBar from "./ASMNavBar"
import ActionButton from "./components/ActionButton"
import CreditFooter from "../cibilFlow/footer";
import { getFullDay, getMonthName } from "./DateConverter"
import BackIcon from "../../include/assets/back_icon.png"
import pdfIcon from "../../include/assets/icons/pdf.svg"
import Swal from "sweetalert2"
import PATH from "../../paths/Paths"
import CustomUpload from "./components/CustomUpload"

const LoanApplication = () => {
    const location = useLocation()
    const history = useHistory()
    const [state, setState] = useState({})
    const [pdf, setPdf] = useState(false)
    const [remarks, setRemarks] = useState({})
    const [creditScore, setCreditScore] = useState({})
    const [file, setFile] = useState([])
    const [finalRemarks, setFinalRemarks] = useState("")
    const [approvedAmount, setApprovedAmount] = useState(0)
    const [transactionId, setTransactionId] = useState()
    const [approvalTenure, setApprovalTenure] = useState(0)

    const dispatch = useDispatch()
    const extUploads = {
        1: "Office CPV",
        2: "Residence CPV",
        3: "Tele-verification Office",
        4: "Tele-verification Residence"
    }
    Object.freeze(extUploads)
    const updateViewData = () => {
        let formData = {
            loanSfid: state.data.loanData[0].sfid
        }
        dispatch(viewData(formData, callBackViewData))
    }

    const adminAction = (action) => {
        let formData = {
            loanId: state?.data?.loanData?.[0]?.sfid,
            loanSfid: state?.data?.loanData?.[0]?.sfid,
            loanApprovalAmount: approvedAmount,
            remarks: remarks["Approval Remarks"],
            moneyplusVerified: action,
            transactionId
        }
    }

    const callBackNstpApprove = (res) => {
        if (res.data.success) {
            Swal.fire({
                position: "center",
                icon: "success",
                title: "NSTP Approved",
                showConfirmButton: false,
                timer: 1000,
            }).then(
                () => { history.push(PATH.PRIVATE.EXTERNAL_TELE_VERIFICATION_DASHBOARD) }
            )
            //then(updateViewData())
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Error Occured While Updating",
                showConfirmButton: false,
                timer: 1000,
            })
        }
    }

    const callBackNstpReject = (res) => {
        if (res.data?.success) {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "NSTP Rejected",
                showConfirmButton: false,
                timer: 1000,
            }).then(() => { history.push(PATH.PRIVATE.EXTERNAL_TELE_VERIFICATION_DASHBOARD) })
            //updateViewData()
        } else {
            Swal.fire({
                position: "center",
                icon: "error",
                title: "Error Occured While Updating",
                showConfirmButton: false,
                timer: 1000,
            })
        }
    }

    const handleAction = (action) => {
        let formData = {
            loanSfid: state?.data?.loanData[0]?.sfid,
            nstpFlag: action.action,
            nstp_type: action.type,
            remarks: remarks[action.type]
        }
        if (action.action) {
            dispatch(updateNstpAction(formData, callBackNstpApprove))
        }
        else {
            dispatch(updateNstpAction(formData, callBackNstpReject))
        }
    }


    const callBackCheck3 = (res) => {
        if (res) {
            setCreditScore({ data: { creditData: res.data?.cibilData } })
            console.log(res)
        }
    }

    useEffect(() => {
        window.scrollTo(0, 0);
        document.body.classList.remove("variantScroll");
        document.body.classList.add("NoScrool");
        console.log(location.state)

        let formData = {
            mobile: "9599959794",
            isExperian: true,
        };
        dispatch(loadExperianCheck3(formData, callBackCheck3))
        console.log(location.state)

    }, [])

    const callBackViewData = (res) => {
        if (res) {
            setState({ ...state, data: { ...creditScore.data, ...res.data?.data } })
        }
    }

    useEffect(() => {
        let formData = {
            loanSfid: location.state.loanSfid,
        }
        dispatch(viewData(formData, callBackViewData))
    }, [creditScore])

    useEffect(() => {
        console.log(remarks)
    }, [remarks])

    // const handleRemove = (index) => {
    //     let files = file.filter((file, item) => item != index)
    //     setFile(files)

    // }

    const dateFormatter = (date) => {
        const fromDay = getFullDay(date.getDate())
        const fromMonth = getMonthName(date.getMonth() + 1)
        const fromYear = date.getFullYear()
        return `${fromDay} ${fromMonth} ${fromYear}`
    }

    const viewPdf = (link) => {

        setPdf(link)
    }

    const checkFiles = () => {
        let status = true
        let arr = [1, 2, 3, 4]
        arr.map((key, index) => {
            if (status) {
                if (!file[index]) {
                    Swal.fire({
                        position: "center",
                        icon: "warning",
                        title: `Please upload ${extUploads[key]} file`,
                        timer: 3000
                    });
                    status = false
                }
            }
        })
        return status
    }

    const handleFinalAction = (action) => {
        const formData = new FormData();
        formData.append("loanSfid", state?.data?.loanData?.[0]?.sfid)
        formData.append("loanName", state?.data?.loanData?.[0]?.name)
        formData.append("external_verified", action)
        formData.append("external_remark", finalRemarks)
        const status = checkFiles()
        if (status) {
            [1, 2, 3, 4].map((key, index) => {
                formData.append(`file${index + 1}`, file[index])
            })
            if (action) {
                dispatch(externalSubmit(formData, callBackNstpApprove))
            }
            else {
                dispatch(externalSubmit(formData, callBackNstpReject))
            }
        }
    }


    const callBackAdminSubmit = (res) => {
        if (res) {
            if (res.data.success) {
                Swal.fire({
                    position: "center",
                    icon: "success",
                    title: "Loan Details Updated Successfully",
                    timer: 3000
                });
                let formData = {
                    loanSfid: location.state.loanSfid,
                }
                dispatch(viewData(formData, callBackViewData))
            }
        }
    }

    const updateLoan = (action) => {

        const formData = {
            loanId: state?.data?.loanData[0]?.pl_sync_heroku_id__c,
            loanSfid: state?.data?.loanData[0]?.sfid,
            loanApprovalAmount: approvedAmount,
            remarks: remarks["Approval Remarks"],
            moneyplusVerified: action,
            transactionId,
            approvalTenure
        }
        dispatch(adminSubmit(formData, callBackAdminSubmit))
    }

    const setEvFiles = (index, inpfile) => {
        let newfile = file
        newfile[index] = inpfile
        setFile({ ...newfile })
    }

    return (
        <>
            {pdf ? <Modal
                style={{ overflow: 'hidden', width: '100vw' }}
                show={pdf}
                onHide={() => setPdf(false)}
            > <Modal.Body style={{ padding: '0px', display: 'flex', justifyContent: 'center', marginTop: '-65px', width: '550px', marginLeft: '0px' }}><object className="pdfModal" data={pdf} type="application/pdf" width="100%" height="100%">
                <p>Alternative text - include a link <a href={pdf}>to the PDF!</a></p>
            </object ></Modal.Body></Modal > : null
            }<>
                {useSelector(state => (getExperian(state).loadingCheck || getASM(state)?.asmLoading)) ? <BackDropComponent /> : null}
                <section className="bs-main-section asmSsection" >
                    <ASMNavBar />
                    <Container>
                        <Row>
                            <div className="col-sm-12">
                                <div className="asmBackBlock" style={{ cursor: "pointer", width: "fit-content" }} onClick={() => history.push(PATH.PRIVATE.EXTERNAL_TELE_VERIFICATION_DASHBOARD)}>
                                    <img src={BackIcon} width="20" height="" /> Back
                                </div>
                            </div>
                        </Row>

                        <section className="asmVerBlock">
                            <Row>
                                <Col className="col-sm-6">
                                    <Card>
                                        <Card.Header>
                                            Account
                                        </Card.Header>
                                        <Card.Body>
                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                <Form.Label>Create Date:</Form.Label>
                                                <strong>{state?.data?.userData?.[0]?.createddate ? `${dateFormatter(new Date(state?.data?.userData?.[0]?.createddate))}` : ""}</strong>
                                            </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                <Form.Label>Name:</Form.Label>
                                                <strong>{state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData?.[0]?.firstname} ${state?.data?.userData[0].middlename ?? ""} ${state?.data?.userData[0]?.lastname}` : ""} </strong>
                                            </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                <Form.Label>Phone:</Form.Label>
                                                <strong>{state?.data?.userData?.[0]?.createddate ? ` ${state?.data?.userData?.[0]?.phone}` : ""}</strong>
                                            </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>Email:</Form.Label>   <strong>{state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData[0]?.personemail}` : ""}</strong> </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>City :</Form.Label><strong>{state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData[0]?.city__c}` : ""}</strong></Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>Company Name:</Form.Label> <strong>{state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData[0]?.company_name__c}` : ""}</strong></Form.Group>
                                            {/* <Form.Group  controlId="exampleForm.ControlInput1">Company Type <Form.Control type="text" placeholder= { } </Form.Group> */}
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>Bank Name:</Form.Label> <strong>{state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData[0]?.salary_bank__c}` : ""} </strong></Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>Pan No. :</Form.Label><strong> {state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData[0]?.pl_pan_number__pc}` : ""} </strong>

                                            </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>Aadhaar No.:</Form.Label> <strong> {state?.data?.userData?.[0]?.createddate ? `${state?.data?.userData[0]?.aadhar_number__c}` : ""} </strong>  </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlInput1"> <Form.Label>Monthly Salary :</Form.Label><strong>{state?.data?.userData?.[0]?.createddate ? `${numberFormat(state?.data?.userData[0]?.professional_income__c)}` : ""} </strong>
                                            </Form.Group>
                                        </Card.Body>
                                    </Card>
                                </Col>
                                <Col className="col-sm-6">   <Card>
                                    <Card.Header>
                                        Loan Details
                                    </Card.Header>
                                    <Card.Body>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>Loan Name:</Form.Label>
                                            <strong>{state?.data?.loanData[0]?.name} </strong>
                                        </Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>Applied Loan Amount:</Form.Label>
                                            <strong>{state?.data?.loanData?.[0]?.pl_applied_loan_amount__c ? numberFormat(state?.data?.loanData?.[0]?.pl_applied_loan_amount__c) : ""} </strong>

                                        </Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>Tenure :</Form.Label>
                                            <strong>{state?.data?.loanData[0]?.pl_applied_tenure__c} Months</strong></Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>EMI :</Form.Label><strong>{state?.data?.userData?.[0]?.createddate ? numberFormat(state?.data?.loanData[0]?.pl_applied_emi__c) : ""}</strong></Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>Stage Name:</Form.Label> <strong>{state?.data?.loanData[0]?.stagename} </strong></Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>ASM Id :</Form.Label><strong>{state?.data?.loanData[0]?.asm_id__c} </strong></Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1"><Form.Label>Lender Name:</Form.Label><strong>{state?.data?.lenderData[0]?.name}</strong></Form.Group>

                                    </Card.Body>
                                </Card>
                                </Col>
                            </Row>
                        </section>
                        <section className="asmVerBlock">
                            <Row>
                                <Col className="col-sm-6">   <Card>
                                    <Card.Header>
                                        Address
                                    </Card.Header>
                                    <Card.Body>
                                        <Form.Group controlId="exampleForm.ControlInput1">
                                            <Form.Label>Current Address:</Form.Label>
                                            <strong>{`${state?.data?.addData?.[0]?.pl_address_type__c === "Residential" ? (state?.data?.addData?.[0]?.pl_address_line1__c + " " + state?.data?.addData[0]?.pl_address_line_2__c) : (state?.data?.addData[1]?.pl_address_line1__c + " " + state?.data?.addData[1]?.pl_address_line_2__c)}`}</strong>
                                        </Form.Group>
                                        <Form.Group controlId="exampleForm.ControlInput1">
                                            <Form.Label>Permanent Address:</Form.Label>
                                            <strong>{`${state?.data?.addData?.[0]?.pl_address_type__c === "Permanent" ? (state?.data?.addData?.[0]?.pl_address_line1__c + " " + state?.data?.addData[0]?.pl_address_line_2__c) : (state?.data?.addData[1]?.pl_address_line1__c + " " + state?.data?.addData[1]?.pl_address_line_2__c)}`} </strong>
                                        </Form.Group>
                                    </Card.Body>
                                </Card>
                                </Col>
                                <Col className="col-sm-6">   <Card>
                                    <Card.Header>
                                        Credit Report
                                    </Card.Header>
                                    <Card.Body>
                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                            <Form.Label>Credit Score:</Form.Label>
                                            <strong>{state?.data?.creditData?.experianScore}</strong>
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                            <Form.Label>Credit Score Report:</Form.Label>
                                            {/* <a href={state?.data?.creditData?.experianData?.data[0].cs_pdfpath} target="_blank">Download</a> */}
                                            <div className="salaryBlock nstp" style={{ width: 'fit-content' }}>
                                                <span onClick={() => window.open(state?.data?.creditData?.experianData?.data[0].cs_pdfpath)}>
                                                    <img src={pdfIcon} />
                                                </span>
                                            </div></Form.Group>
                                    </Card.Body>
                                </Card>
                                </Col>
                            </Row>
                        </section>
                        <section className="asmVerBlock">
                            <Row><Col>
                                <Card>
                                    <Card.Header>
                                        NSTP
                                    </Card.Header>
                                    <Card.Body>
                                        <Row>
                                            {state?.data?.nstpData.map((nstp, i) => (<>
                                                <Col className="col-sm-6">
                                                    <h3 className="asmAppTitle teleVerifierHeading">{nstp.nstp_type__c}</h3>
                                                    <div className="nstp" style={{ marginTop: '10px' }}>
                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                            <Form.Label>NSTP Flag Status:</Form.Label>
                                                            <strong>{nstp.action_flag__c === null ? "Pending" : (nstp.action_flag__c === "TRUE" ? "Approved" : "Rejected")}</strong>
                                                        </Form.Group>
                                                        {nstp.nstp_type__c === 'Name NSTP' ?
                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Name as per Aadhaar:</Form.Label>
                                                                <strong>{nstp.name_as_per_aadhaar__c ?? "-"}</strong>
                                                            </Form.Group>
                                                            : null}
                                                        {nstp.nstp_type__c === 'Name NSTP' ?
                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Name as per Pan:</Form.Label>
                                                                <strong>{nstp.name_as_per_pan__c ?? "-"}</strong>
                                                            </Form.Group>
                                                            : null}
                                                        {/* <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
<Form.Label>NSTP Type:</Form.Label>
<Form.Control type="text" placeholder={nstp.nstp_type__c} readOnly />
</Form.Group> */}

                                                        {nstp.nstp_type__c === 'Name NSTP' ? <><Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                            <Form.Label>Remarks:</Form.Label>
                                                            {nstp.action_flag__c === "TRUE" ? <strong>{nstp.remarks__c}</strong> :
                                                                <Form.Control onChange={(e) => setRemarks({ ...remarks, "Name NSTP": e.target.value })} as="textarea" rows={2} placeholder={nstp.remarks__c ?? "Please enter your remarks"} />}

                                                            {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                        </Form.Group>
                                                            {/* <div className="asmInsideBtnSection"><Button type="submit" className="action approvebtn" onClick={() => handleAction({ type: nstp.nstp_type__c, action: true })}>Approve</Button>
<Button type="submit" className="action rejectbtn" onClick={() => handleAction({ type: nstp.nstp_type__c, action: false })} >Reject</Button></div> */}
                                                        </> : null}
                                                        {nstp.nstp_type__c === "Salary NSTP" ? <>
                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Last 3 Months Salary Slip:</Form.Label>
                                                                <div className="salaryBlock nstp">
                                                                    {[1, 2, 3].map((item) => (
                                                                        nstp[`salary_slip_${item}__c`] ? <span onClick={() => viewPdf(nstp[`salary_slip_${item}__c`])} ><img src={pdfIcon} /></span> : null
                                                                    ))}
                                                                </div>
                                                                {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                            </Form.Group>

                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Remarks:</Form.Label>
                                                                {nstp.action_flag__c === "TRUE" ? <strong>{nstp.remarks__c}</strong> :
                                                                    <Form.Control onChange={(e) => setRemarks({ ...remarks, "Salary NSTP": e.target.value })} as="textarea" rows={2} placeholder={nstp.remarks__c ?? "Please enter your remarks"} />}
                                                                {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                            </Form.Group>
                                                            {/* <div className="asmInsideBtnSection"><Button type="submit" className="action approvebtn" onClick={() => handleAction({ type: nstp.nstp_type__c, action: true })}>Approve</Button>
<Button type="submit" className="action rejectbtn" onClick={() => handleAction({ type: nstp.nstp_type__c, action: false })} >Reject</Button></div> */}

                                                            {/* <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
<Form.Label>Salary Slip 2:</Form.Label>

{/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> 
</Form.Group>
<Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
<Form.Label>Salary Slip 3</Form.Label>

{/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> 
</Form.Group> */}
                                                            {/* <p><strong>Salary Slip 1</strong> : <span onClick={() => viewPdf(nstp.salary_slip_1__c)} >View</span></p>
<p><strong>Salary Slip 2 </strong>: <span onClick={() => viewPdf(nstp.salary_slip_2__c)} >View</span></p>
<p><strong>Salary Slip 3</strong> : <span onClick={() => viewPdf(nstp.salary_slip_3__c)} >View</span></p></> : null}
{nstp.nstp_type__c === "Bank Statement NSTP" ? <p><strong>Bank Statement </strong>: <span onClick={() => viewPdf(nstp.bank_statement__c)}>View</span></p> 
*/}</> : null}
                                                        {nstp.nstp_type__c === "Bank Statement NSTP" ? <>

                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Bank Statement</Form.Label>
                                                                <div className="salaryBlock nstp">
                                                                    {[1, 2, 3].map(item => (
                                                                        nstp[`bank_statement_${item}__c`] ? <span onClick={() => viewPdf(nstp[`bank_statement_${item}__c`])}>
                                                                            <img src={pdfIcon} />
                                                                        </span> : null
                                                                    ))}
                                                                </div>

                                                            </Form.Group>
                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Password</Form.Label>
                                                                <strong>{nstp.statement_password__c}</strong></Form.Group>
                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Remarks</Form.Label>
                                                                {nstp.action_flag__c === "TRUE" ? <strong>{nstp.remarks__c}</strong> :
                                                                    <Form.Control onChange={(e) => setRemarks({ ...remarks, "Bank Statement NSTP": e.target.value })} as="textarea" rows={2} placeholder={nstp.remarks__c ?? "Please enter your remarks"} />}

                                                                {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                            </Form.Group>
                                                        </> : null}
                                                        {/* {!nstp.action_flag__c === "TRUE" ? <>
                                                            <div className="asmInsideBtnSection">
                                                                <Button type="submit" className="action approvebtn" onClick={() => handleAction({ type: nstp.nstp_type__c, action: true })}>Approve</Button>
                                                                <Button type="submit" className="action rejectbtn" onClick={() => handleAction({ type: nstp.nstp_type__c, action: false })} >Reject</Button>
                                                            </div>
                                                        </> : null} */}
                                                        {/* // <> <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                        //     <Form.Label>External Verification Status</Form.Label>
                                                        //     <strong>{nstp.check ?? "Pending"}</strong>
                                                        // </Form.Group>
                                                        //     <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                        //         <Form.Label>External Verification Remarks</Form.Label>

                                                        //         <strong>{nstp.check ?? ""}</strong>
                                                        //     </Form.Group> </>} */}


                                                    </div>
                                                </Col>
                                            </>))}
                                        </Row>
                                    </Card.Body>
                                </Card></Col></Row>
                        </section>
                        {localStorage.getItem("isMoneyPlusAdmin") ?
                            <section className="asmVerBlock">
                                <Row>
                                    <Col className="col-sm-6">
                                        <Card>
                                            <Card.Header>Loan Disbursement</Card.Header>
                                            <Card.Body>
                                                {state?.data?.nstpData[0].moneyplus_verified__c === "TRUE" ? <Form.Group controlId="formFile" className="mb-3" >
                                                    <Form.Label>Approval Status:</Form.Label>
                                                    <strong>Approved</strong>
                                                </Form.Group> : (state?.data?.nstpData[0].moneyplus_verified__c === "FALSE" ? <Form.Group controlId="formFile" className="mb-3" >
                                                    <Form.Label>Approval Status:</Form.Label>
                                                    <strong>Rejected</strong>
                                                </Form.Group> : null)}
                                                <Form.Group controlId="formFile" className="ChooseFile mb-3" >
                                                    {state?.data?.nstpData[0].moneyplus_verified__c === "TRUE" ? <>
                                                        <Form.Label className="form-label">Approved Loan Amount:</Form.Label>
                                                        <strong>{numberFormat(state?.data?.loanData?.[0]?.pl_revised_loan_amount__c)}</strong>
                                                    </> :
                                                        (<>
                                                            <Form.Label className="form-label">Approved amount</Form.Label>
                                                            <Form.Control onChange={(e) => setApprovedAmount(e.target.value.replace(/\D+/g, ""))} type="text" value={numberFormat(approvedAmount)} />
                                                        </>)}
                                                </Form.Group>
                                                <Form.Group controlId="formFile" className="mb-3" >
                                                    {state?.data?.nstpData[0].moneyplus_verified__c === "TRUE" ? <><Form.Label className="form-label">Remarks:</Form.Label>
                                                        <strong>{state?.data?.nstpData?.[0].moneyplus_remark__c}</strong></> : <><Form.Label className="form-label">Remarks:</Form.Label>
                                                        <Form.Control onChange={(e) => setRemarks({ ...remarks, "Approval Remarks": e.target.value })} as="textarea" style={{ width: '100%' }} rows={2} placeholder="" />
                                                    </>} </Form.Group>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col className="sm-6">
                                        <Card>
                                            <Card.Header style={{ visibility: 'hidden' }}>i</Card.Header>
                                            <Card.Body>
                                                <Form.Group controlId="formFile" className="mb-3" >
                                                    {state?.data?.nstpData[0].moneyplus_verified__c ? <>
                                                        <Form.Label className="form-label">Reference Loan Id:</Form.Label>
                                                        <strong>{state?.data?.loanData?.[0]?.moneyplus_transaction_id__c}</strong>
                                                    </> : <>
                                                        <Form.Label className="form-label">Reference Loan Id:</Form.Label>
                                                        <Form.Control type="text" style={{ width: '95%' }} onChange={(e) => setTransactionId(e.target.value)} />
                                                    </>}
                                                </Form.Group>
                                                <Form.Group>
                                                    {state?.data?.nstpData[0].moneyplus_verified__c === "TRUE" ? <>
                                                        <Form.Label className="form-label">Loan Tenure:</Form.Label>
                                                        <strong>{state?.data?.loanData?.[0]?.pl_revised_tenure__c} Months</strong>
                                                    </> : <>
                                                        <Form.Label className="form-label">Loan Tenure</Form.Label>
                                                        <Form.Control type="text" style={{ width: '35%' }} onChange={(e) => setApprovalTenure(e.target.value)} />
                                                        <span style={{ position: "absolute", bottom: "32px", right: "280px" }}>Months</span>
                                                    </>}

                                                </Form.Group>
                                            </Card.Body>
                                        </Card>
                                    </Col>

                                    <div className="col-sm-12 text-right">
                                        {state?.data?.nstpData[0].moneyplus_verified__c === "TRUE" ? null :
                                            <div className="asmBtnSection">
                                                <ActionButton action="Approve" setAction={() => updateLoan(true)} />
                                                <ActionButton action="Reject" setAction={() => updateLoan(false)} />
                                            </div>}

                                    </div>
                                </Row>


                            </section>
                            :
                            <section className="asmVerBlock">
                                <Row>
                                    <Col className="col-sm-6">
                                        <Card>
                                            <Card.Header>Final Approval</Card.Header>
                                            <Card.Body>
                                                {state?.data?.nstpData[0].external_verified__c === "TRUE" || state?.data?.nstpData[0].external_verified__c === "FALSE" ? state?.data?.nstpData[0].external_verified__c === "TRUE" ? <Form.Group controlId="formFile" className="mb-3" >
                                                    <Form.Label>Approval Status:</Form.Label>
                                                    <strong>Approved</strong>
                                                </Form.Group> : state?.data?.nstpData[0].external_verified__c === "FALSE" ? <Form.Group controlId="formFile" className="mb-3" >
                                                    <Form.Label>Approval Status:</Form.Label>
                                                    <strong>Rejected</strong>
                                                </Form.Group> : null : <Form.Group controlId="formFile" className="mb-3" >
                                                    <Form.Label>Approval Status:</Form.Label>
                                                    <strong>Pending</strong>
                                                </Form.Group>}
                                                {state?.data?.nstpData[0].external_verified__c === "TRUE" ? <>
                                                    {Object.keys(extUploads).slice(0, 2).map((key) => <>
                                                        <Form.Group controlId="formFile" className="ChooseFile mb-3" >
                                                            <Form.Label className="form-label">{extUploads[key]}</Form.Label>
                                                            <span className="exVerFiles" onClick={() => viewPdf(state?.data?.nstpData[0][`external_report_path_${key}__c`])} >
                                                                <img src={pdfIcon} />
                                                            </span>
                                                        </Form.Group>
                                                    </>)}
                                                    <Form.Group controlId="formFile" className="mb-3" style={{ display: `${state?.data?.nstpData[0].external_verified__c === "TRUE" ? "none" : "inherit"}` }} >
                                                        <Form.Label>Over All Remarks:</Form.Label>
                                                        {state?.data?.nstpData[0].external_verified__c === "FALSE" || state?.data?.nstpData[0].external_verified__c === null ? <Form.Control onChange={(e) => setFinalRemarks(e.target.value)} as="textarea" rows={2} placeholder="" /> : <strong>{state?.data?.nstpData[0].external_remark__c}</strong>}

                                                        {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                    </Form.Group></> :
                                                    <>
                                                        <Form.Group controlId="formFile" className="ChooseFile mb-3">
                                                            <Form.Label className="form-label">Upload Office CPV File</Form.Label>
                                                            <Form.Control name="uploadFile1" id="uploadFile1" onChange={(e) => setEvFiles(0, e.target.files[0])} type="file" accept=".pdf, .xls, .xlsm" className="form-control" style={{ display: 'none' }} />
                                                            <CustomUpload id={1} fileName={file[0]} viewPdf={viewPdf} />

                                                        </Form.Group>
                                                        <Form.Group controlId="formFile" className="ChooseFile mb-3">
                                                            <Form.Label className="form-label">Upload Residence CPV File</Form.Label>
                                                            <Form.Control name="uploadFile2" id="uploadFile2" onChange={(e) => setEvFiles(1, e.target.files[0])} type="file" accept=".pdf, .xls, .xlsm" className="form-control" style={{ display: 'none' }} />
                                                            <CustomUpload id={2} fileName={file[1]} viewPdf={viewPdf} />
                                                        </Form.Group>
                                                        <Form.Group controlId="formFile" className="mb-3" >
                                                            <Form.Label>Over All Remarks:</Form.Label>
                                                            {state?.data?.nstpData[0].external_verified__c === "FALSE" || state?.data?.nstpData[0].external_verified__c === null ? <Form.Control onChange={(e) => setFinalRemarks(e.target.value)} as="textarea" rows={2} placeholder="" /> : <strong>{state?.data?.nstpData[0].external_remark__c}</strong>}

                                                            {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                        </Form.Group>
                                                    </>}
                                            </Card.Body>
                                        </Card>
                                    </Col>

                                    <Col className="col-sm-6"><Card>
                                        <Card.Header style={{ visibility: 'hidden' }}>i</Card.Header>
                                        <Card.Body>

                                            {state?.data?.nstpData[0].external_verified__c === "TRUE" ? <>
                                                <Form.Group controlId="formFile" className="mb-3" >
                                                    <Form.Label>Over All Remarks:</Form.Label>
                                                    {state?.data?.nstpData[0].external_verified__c === "FALSE" || state?.data?.nstpData[0].external_verified__c === null ? <Form.Control onChange={(e) => setFinalRemarks(e.target.value)} as="textarea" rows={2} placeholder="" /> : <strong>{state?.data?.nstpData[0].external_remark__c}</strong>}

                                                    {/* <Form.Control type="text" placeholder={nstp.nstp_check__c === null ? "Pending" : (nstp.nstp_check__c ? "Approve" : "Reject")} readOnly /> */}
                                                </Form.Group>
                                                {Object.keys(extUploads).slice(-2).map((key) => <>
                                                    <Form.Group controlId="formFile" className="ChooseFile mb-3" >
                                                        <Form.Label className="form-label">{extUploads[key]}</Form.Label>
                                                        <span className="exVerFiles" onClick={() => viewPdf(state?.data?.nstpData[0][`external_report_path_${key}__c`])} >
                                                            <img src={pdfIcon} />
                                                        </span>
                                                    </Form.Group>
                                                </>)}
                                            </> : <>
                                                <Form.Group style={{ visibility: 'hidden' }} controlId="formFile" className="mb-3" >
                                                    <Form.Label>Approval Status:</Form.Label>
                                                    <strong>Pending</strong>
                                                </Form.Group>
                                                < Form.Group controlId="formFile" className="ChooseFile mb-3">
                                                    <Form.Label className="form-label">Upload Televerification Office File</Form.Label>
                                                    <Form.Control style={{ display: 'none' }} name="uploadFile3" id="uploadFile3" onChange={(e) => setEvFiles(2, e.target.files[0])} type="file" accept=".pdf, .xls, .xlsm" className="form-control" />
                                                    <CustomUpload id={3} fileName={file[2]} viewPdf={viewPdf} />
                                                </Form.Group>
                                                <Form.Group controlId="formFile" className="ChooseFile mb-3">
                                                    <Form.Label className="form-label">Upload Televerification Residence File</Form.Label>
                                                    <Form.Control style={{ display: 'none' }} name="uploadFile4" id="uploadFile4" onChange={(e) => setEvFiles(3, e.target.files[0])} type="file" accept=".pdf, .xls, .xlsm" className="form-control" />
                                                    <CustomUpload id={4} fileName={file[3]} viewPdf={viewPdf} />
                                                </Form.Group>
                                            </>}
                                        </Card.Body>
                                    </Card>
                                    </Col>
                                    <div className="col-sm-12 text-right">
                                        {state?.data?.nstpData[0].external_verified__c === "TRUE" ? null :
                                            <div className="asmBtnSection">
                                                <ActionButton action="Approve" setAction={() => handleFinalAction(true)} />
                                                <ActionButton action="Reject" setAction={() => handleFinalAction(false)} />
                                            </div>}

                                    </div>
                                </Row>
                            </section>
                        }
                    </Container>
                </section >
                <CreditFooter />
            </>

        </>
    )
}

export default LoanApplication








