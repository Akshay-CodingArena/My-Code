import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "perfios",

  initialState: {
    perfiosDetail: {},
    loadingPerfios: false,
    lastFetch: null,
  },

  reducers: {
    perfiosRequested: (perfios, action) => {
      perfios.loadingPerfios = true;
    },

    perfiosReceived: (perfios, action) => {
      perfios.perfiosDetail = action.payload.data;
      perfios.loadingPerfios = false;
      perfios.lastFetch = Date.now();
    },

    perfiosRequestFailed: (perfios, action) => {
      perfios.loadingPerfios = false;
    },
  },
});

export const { perfiosRequested, perfiosReceived, perfiosRequestFailed } =
  slice.actions;

export default slice.reducer;

const url = "/cs/perfios";
const url2 = "employerAndPerfiosCheck"
// To receive the data
export const getPerfiosDetails = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,

      method: "POST",

      data: params,

      callback,

      onStart: perfiosRequested.type,

      onSuccess: perfiosReceived.type,

      onError: perfiosRequestFailed.type,
    })
  );
};

export const perfiosCheck = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: perfiosRequested.type,
      onSuccess: perfiosReceived.type,
      onError: perfiosRequestFailed.type,
    })
  );
};

// // To manage the state

export const perfiosData = createSelector(
  (state) => state.entities.perfios,
  (perfios) => perfios
);
