import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";


const slice = createSlice({
    name: "myprofile",
    initialState: {
        loadingFeedback: false
    },
    reducers: {
        feedbackRequested: (myprofile, action) => {
            myprofile.loadingFeedback = true;
        },
        feedbackReceived: (myprofile, action) => {
            myprofile.loadingFeedback = false;
        },
        feedbackRequestFailed: (myprofile, action) => {
            myprofile.loadingFeedback = false;
        },

    },
});

export const {
    feedbackRequested,
    feedbackReceived,
    feedbackRequestFailed
} = slice.actions;
export default slice.reducer;

const url = "customerFeedback";

export const setCustomerFeedback = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: feedbackRequested.type,
            onSuccess: feedbackReceived.type,
            onError: feedbackRequestFailed.type,
        })
    );
};

export const myprofile = createSelector(
    (state) => state.entities.myprofile,
    (myprofile) => myprofile
);
