import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "panName",
  initialState: {
    panName: {},
    creditpanName: {},
    loading: false,
    panVerify: {},
    checkDedupe: {},
    loadingVerify: false,
    loadingCheck: false,
    creditloading: false,
    lastFetch: null,
  },
  reducers: {
    panNameRequested: (panName, action) => {
      panName.loading = true;
    },
    panNameReceived: (panName, action) => {
      panName.panName = action.payload.data;
      panName.loading = false;
      panName.lastFetch = Date.now();
    },
    panNameRequestFailed: (panName, action) => {
      panName.loading = false;
    },
    creditpanNameRequested: (panName, action) => {
      panName.creditloading = true;
    },
    creditpanNameReceived: (panName, action) => {
      panName.creditpanName = action.payload.data;
      panName.creditloading = false;
      panName.lastFetch = Date.now();
    },
    creditpanNameRequestFailed: (panName, action) => {
      panName.creditloading = false;
    },
    checkRequested: (panName, action) => {
      panName.loadingCheck = true;
    },
    checkReceived: (panName, action) => {
      panName.checkDedupe = action.payload.data;
      panName.loadingCheck = false;
      panName.lastFetch = Date.now();
    },
    checkRequestFailed: (panName, action) => {
      panName.loadingCheck = false;
    },
    verifyRequested: (panName, action) => {
      panName.loadingVerify = true;
    },
    verifyReceived: (panName, action) => {
      panName.panVerify = action.payload.data;
      panName.loadingVerify = false;
      panName.lastFetch = Date.now();
    },
    verifyRequestFailed: (panName, action) => {
      panName.loadingVerify = false;
    },
  },
});

export const {
  panNameRequested,
  panNameReceived,
  panNameRequestFailed,
  creditpanNameRequested,
  creditpanNameReceived,
  creditpanNameRequestFailed,
  verifyRequested,
  verifyReceived,
  verifyRequestFailed,
  checkRequested,
  checkReceived,
  checkRequestFailed,
} = slice.actions;
export default slice.reducer;

const url = "panName";
const url2 = "PANVerification1";
const url3 = "checkDedupe";
const url4 = "pan/name";

export const loadPanName = (params, callback) => (dispatch, getState) => {
  let newParams = { ...params };
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: newParams,
      callback,
      onStart: panNameRequested.type,
      onSuccess: panNameReceived.type,
      onError: panNameRequestFailed.type,
    })
  );
};
export const loadcreditPanName = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      method: "POST",
      data: params,
      callback,
      onStart: creditpanNameRequested.type,
      onSuccess: creditpanNameReceived.type,
      onError: creditpanNameRequestFailed.type,
    })
  );
};
export const loadCheckDedupe = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: params,
      callback,
      onStart: checkRequested.type,
      onSuccess: checkReceived.type,
      onError: checkRequestFailed.type,
    })
  );
};
export const panVerification = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: verifyRequested.type,
      onSuccess: verifyReceived.type,
      onError: verifyRequestFailed.type,
    })
  );
};

export const getpanName = createSelector(
  (state) => state.entities.panName,
  (panName) => panName
);
