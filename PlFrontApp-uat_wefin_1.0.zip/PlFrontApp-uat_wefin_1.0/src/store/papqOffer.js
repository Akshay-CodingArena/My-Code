import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "papqOffer",

  initialState: {
    checkoffer: {},
    getoffer: {},
    setOffer: {},
    loadingCheckOffer: false,
    loadingGetOffer: false,
    loadingsetOffer: false,
    lastFetch: null,
  },

  reducers: {
    checkofferRequested: (papqOffer, action) => {
      papqOffer.loadingCheckOffer = true;
    },

    checkofferReceived: (papqOffer, action) => {
      papqOffer.checkoffer = action.payload;

      papqOffer.loadingCheckOffer = false;

      papqOffer.lastFetch = Date.now();
    },

    checkofferRequestFailed: (papqOffer, action) => {
      papqOffer.loadingCheckOffer = false;
    },
    getofferRequested: (papqOffer, action) => {
      papqOffer.loadingGetOffer = true;
    },

    getofferReceived: (papqOffer, action) => {
      papqOffer.getoffer = action.payload;

      papqOffer.loadingGetOffer = false;

      papqOffer.lastFetch = Date.now();
    },

    getofferRequestFailed: (papqOffer, action) => {
      papqOffer.loadingGetOffer = false;
    },
    setofferRequested: (papqOffer, action) => {
      papqOffer.loadingsetOffer = true;
    },

    setofferReceived: (papqOffer, action) => {
      papqOffer.setOffer = action.payload;

      papqOffer.loadingsetOffer = false;

      papqOffer.lastFetch = Date.now();
    },

    setofferRequestFailed: (papqOffer, action) => {
      papqOffer.loadingsetOffer = false;
    },
  },
});

export const {
  setofferRequested,
  setofferReceived,
  setofferRequestFailed,
  checkofferRequested,
  checkofferReceived,
  checkofferRequestFailed,
  getofferRequested,
  getofferReceived,
  getofferRequestFailed,
} = slice.actions;

export default slice.reducer;

const url = "/check/pa/pq";
const url1 = "/get/pa/offers";
const url2 = "/set/pa/offer";

// To receive the data

export const checkPaPqOffer = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: checkofferRequested.type,
      onSuccess: checkofferReceived.type,
      onError: checkofferRequestFailed.type,
    })
  );
};
export const getPaPqOffer = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: getofferRequested.type,
      onSuccess: getofferReceived.type,
      onError: getofferRequestFailed.type,
    })
  );
};
export const setPaPqOffer = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: setofferRequested.type,
      onSuccess: setofferReceived.type,
      onError: setofferRequestFailed.type,
    })
  );
};
export const papqData = createSelector(
  (state) => state.entities.papqOffer,
  (papqOffer) => papqOffer
);
