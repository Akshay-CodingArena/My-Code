import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "account",
  initialState: {
    setAccount: {},
    getAccountDetail: {},
    getOffer: {},
    customerDetail: {},
    profileDetail: {},
    loadingACC: false,
    loading: false,
    profileLoading: false,
    lastFetch: null,
  },
  reducers: {
    updatePhoto: (account, action) => {
      account.customerDetail.photourl = action.payload
    },
    accountRequested: (account, action) => {
      account.loadingACC = true;
    },
    accountReceived: (account, action) => {
      account.setAccount = action.payload.data;
      account.loadingACC = false;
      account.lastFetch = Date.now();
    },

    accountRequestFailed: (account, action) => {
      account.loadingACC = false;
    },
    accountGetRequested: (account, action) => {
      account.loading = true;
    },
    accountGetReceived: (account, action) => {
      account.getAccountDetail = action.payload.details.loanData;
      account.getOffer = action.payload.details.offers;
      account.customerDetail = action.payload.customer;
      account.loading = false;
      account.lastFetch = Date.now();
    },
    accountGetRequestFailed: (account, action) => {
      account.loading = false;
    },
    profileRequested: (account, action) => {
      account.profileLoading = true;
    },
    profileReceived: (account, action) => {
      account.profileDetail = action.payload.data;
      account.profileLoading = false;
      account.lastFetch = Date.now();
    },
    profileRequestFailed: (account, action) => {
      account.profileLoading = false;
    },
  },
});

export const {
  updatePhoto,
  accountRequested,
  accountReceived,
  accountRequestFailed,
  accountGetRequested,
  accountGetReceived,
  accountGetRequestFailed,
  profileRequested,
  profileReceived,
  profileRequestFailed,
} = slice.actions;
export default slice.reducer;

const url = "saveAccInfo";
const url1 = "getAccDetails";
const url2 = "setProfileDetails1";
const url3 = "saveProfileDetails";
const url4 = "updateProfileImage"

export const setAccountInfo = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: accountRequested.type,
      onSuccess: accountReceived.type,
      onError: accountRequestFailed.type,
    })
  );
};

export const setProfilePhoto = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      method: "POST",
      data: params,
      callback,
      onStart: accountRequested.type,
      onSuccess: accountReceived.type,
      onError: accountRequestFailed.type,
    })
  );
};

export const setProfileInfo = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: params,
      callback,
      onStart: accountRequested.type,
      onSuccess: accountReceived.type,
      onError: accountRequestFailed.type,
    })
  );
};
export const setProfileDetail = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: profileRequested.type,
      onSuccess: profileReceived.type,
      onError: profileRequestFailed.type,
    })
  );
};
export const getAccountInfo = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: accountGetRequested.type,
      onSuccess: accountGetReceived.type,
      onError: accountGetRequestFailed.type,
    })
  );
};

export const getAccount = createSelector(
  (state) => state.entities.account,
  (account) => account
);
