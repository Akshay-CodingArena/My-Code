import { createSlice } from "@reduxjs/toolkit";
// import { act } from "react-dom/test-utils";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "referCode",
  initialState: {
    loadingSendReferCode: false,
    referCodeStatus: {},
  },
  reducers: {
    sendReferCodeRequested: (referCode, action) => {
      referCode.loadingSendReferCode = true;
    },
    sendReferCodeRecevied: (referCode, action) => {
      referCode.referCodeStatus = action.payload.data;
    },
    sendReferCodeFailed: (referCode, action) => {
      referCode.loadingSendReferCode = true;
    },
  },
});

export const {
  sendReferCodeRequested,
  sendReferCodeRecevied,
  sendReferCodeFailed,
} = slice.actions;

export default slice.reducer;

const url = "sendrefercode";

// To receive the data

export const sendReferCode = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: sendReferCodeRequested.type,
      onSuccess: sendReferCodeRecevied.type,
      onError: sendReferCodeFailed.type,
    })
  );
};

// // To manage the state

export const referCode = createSelector(
  (state) => state.entities.referCode,
  (referCode) => referCode
);
