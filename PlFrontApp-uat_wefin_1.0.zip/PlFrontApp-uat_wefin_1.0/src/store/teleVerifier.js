import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
    name: "teleVerifier",
    initialState: {
        asmLogin: {},
        asmLoading: false,
        lastFetch: null
    },
    reducers: {
        asmLoginRequested: (login, action) => {
            login.asmLoading = true;
        },
        asmLoginReceived: (login, action) => {
            login.asmLogin = action.payload.data;
            login.asmLoading = false;
            login.lastFetch = Date.now();
        },
        asmLoginRequestFailed: (login, action) => {
            login.asmLoading = false;
        },
        logoutRequested: (login, action) => {
            login.asmLoading = true
        },
        logoutReceived: (login, action) => {
            login.asmLoading = false;
            login.asmLogin = false
        },
        logoutRequestFailed: (login, action) => {
            login.asmLoading = false
        },
    },
});

export const {
    asmLoginRequested,
    asmLoginReceived,
    asmLoginRequestFailed,
    logoutRequested,
    logoutReceived,
    logoutRequestFailed
} = slice.actions;
export default slice.reducer;

const url = "fetchNstpAction"
const url2 = "viewData"
const url3 = "updateNstpAction"
const url4 = "onExternalSubmit"
const url5 = "UserLoanRevised"

export const fetchNstp = (params, callback) => (dispatch, getState) => {
    let { page, offset } = params
    return dispatch(
        apiCallBegan({
            url: url + `/?pageNo=${page}&offset=${offset}`,
            method: "GET",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const fetchNstpExternal = (params, callback) => (dispatch, getState) => {
    let { page, offset, verifierRole } = params
    return dispatch(
        apiCallBegan({
            url: url + `/?pageNo=${page}&offset=${offset}&verifierRole=${verifierRole}`,
            method: "GET",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const viewData = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url2,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const updateNstpAction = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url3,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const externalSubmit = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url4,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
}

export const adminSubmit = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url5,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
}

export const getASM = createSelector(
    (state) => state.entities.televerifier,
    (televerifier) => televerifier
);
