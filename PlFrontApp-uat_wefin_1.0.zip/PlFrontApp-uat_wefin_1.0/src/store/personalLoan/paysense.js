import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "../api";


const slice = createSlice({
    name: "paysense",
    initialState: {
        loadingPaysense: false,
        loadingReApplyGetPlans: false,
        loadingFinalApplyPlans: false,
        loadingPaysenseGetStatus: false
    },
    reducers: {
        paysenseRequested: (hdfcPL, action) => {
            hdfcPL.loadingPaysense = true;
        },
        paysenseReceived: (hdfcPL, action) => {
            hdfcPL.loadingPaysense = false;
        },
        paysenseFailed: (hdfcPL, action) => {
            hdfcPL.loadingPaysense = false;
        },
        paysenseReApplyGetPlansRequested: (hdfcPL, action) => {
            hdfcPL.loadingReApplyGetPlans = true;
        },
        paysenseReApplyGetPlansReceived: (hdfcPL, action) => {
            hdfcPL.loadingReApplyGetPlans = false;
        },
        paysenseReApplyGetPlansFailed: (hdfcPL, action) => {
            hdfcPL.loadingReApplyGetPlans = false;
        },

        paysenseFinalApplyGetPlansRequested: (hdfcPL, action) => {
            hdfcPL.loadingFinalApplyPlans = true;
        },
        paysenseFinalApplyGetPlansReceived: (hdfcPL, action) => {
            hdfcPL.loadingFinalApplyPlans = false;
        },
        paysenseFinalApplyGetPlansFailed: (hdfcPL, action) => {
            hdfcPL.loadingFinalApplyPlans = false;
        },

        paysenseStatusRequested: (hdfcPL, action) => {
            hdfcPL.loadingPaysenseGetStatus = true;
        },
        paysenseStatusReceived: (hdfcPL, action) => {
            hdfcPL.loadingPaysenseGetStatus = false;
        },
        paysenseStatusFailed: (hdfcPL, action) => {
            hdfcPL.loadingPaysenseGetStatus = false;
        },
    },
});

export const {
    paysenseRequested,
    paysenseReceived,
    paysenseFailed,
    paysenseReApplyGetPlansRequested,
    paysenseReApplyGetPlansReceived,
    paysenseReApplyGetPlansFailed,
    paysenseFinalApplyGetPlansRequested,
    paysenseFinalApplyGetPlansReceived,
    paysenseFinalApplyGetPlansFailed,
    paysenseStatusRequested,
    paysenseStatusReceived,
    paysenseStatusFailed
} = slice.actions;

export default slice.reducer;

const url1 = "paySense";
const url2 = "amountGetPlan";
const url3 = "paySenseApplyPlan";
const url4 = "paySenseGetStatus"

export const paysenseGetPlans = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url1,
            method: "POST",
            data: params,
            callback,
            onStart: paysenseRequested.type,
            onSuccess: paysenseReceived.type,
            onError: paysenseFailed.type,
        })
    );
};

export const paysenseReApplyGetPlans = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url2,
            method: "POST",
            data: params,
            callback,
            onStart: paysenseReApplyGetPlansRequested.type,
            onSuccess: paysenseReApplyGetPlansReceived.type,
            onError: paysenseReApplyGetPlansFailed.type,
        })
    );
};

export const paysenseFinalApplyGetPlans = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url3,
            method: "POST",
            data: params,
            callback,
            onStart: paysenseFinalApplyGetPlansRequested.type,
            onSuccess: paysenseFinalApplyGetPlansReceived.type,
            onError: paysenseFinalApplyGetPlansFailed.type,
        })
    );
};


export const paysenseStatus = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url4,
            method: "POST",
            data: params,
            callback,
            onStart: paysenseStatusRequested.type,
            onSuccess: paysenseStatusReceived.type,
            onError: paysenseStatusFailed.type,
        })
    );
};

export const paysensePL = createSelector(
    (state) => state.entities.paysensePL,
    (paysensePL) => paysensePL
);
