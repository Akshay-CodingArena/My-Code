import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "../api";


const slice = createSlice({
    name: "axisPL",
    initialState: {
        loadingInit: false,
        axisInitData: {},
        loadingConsent: false,
        consentData: {},
        loadingGetOffer: false,
        offerData: {},
        loadingKycInit: false,
        kycInitData: {},
        loadingGenerateToken: false,
        generateTokenData: {},
        loadingKycValidate: false,
        kycValidateData: {},
        loadingFetchKycStatus: false,
        fetchKycStatusData: {},
        getOfferData: {},
        loadingCDD: false,
        cddData: {},
        loadingKfs: false,
        kfsData: {},
        loadingResendOtp: false,
        resendOtpData: {},
        loadingEnachInit: false,
        loadingEnachValidate: false,
        loadingApplicationProcess: false,
        loadingApplicationStatus: false,
        loadingMoneyView: false,
        loadingEarlySalary: false,
        loadingFibeStatus: false
    },
    reducers: {
        axisInitRequested: (axisPL, action) => {
            axisPL.loadingInit = true;
        },
        axisInitReceived: (axisPL, action) => {
            axisPL.loadingInit = false;
            axisPL.axisInitData = action.payload.data;
        },
        axisInitFailed: (axisPL, action) => {
            axisPL.loadingInit = false;
        },
        consentRequested: (axisPL, action) => {
            axisPL.loadingConsent = true;
        },
        consentReceived: (axisPL, action) => {
            axisPL.loadingConsent = false;
            axisPL.consentData = action.payload.data;
        },
        consentFailed: (axisPL, action) => {
            axisPL.loadingConsent = false;
        },
        getOfferDataRequested: (axisPL, action) => {
            axisPL.loadingGetOffer = true;
        },
        getOfferDataReceived: (axisPL, action) => {
            axisPL.loadingGetOffer = false;
            axisPL.offerData = action.payload.data;
        },
        getOfferDataFailed: (axisPL, action) => {
            axisPL.loadingGetOffer = false;
        },
        kycInitRequested: (axisPL, action) => {
            axisPL.loadingKycInit = true;
        },
        kycInitReceived: (axisPL, action) => {
            axisPL.loadingKycInit = false;
            axisPL.kycInitData = action.payload.data;
        },
        kycInitFailed: (axisPL, action) => {
            axisPL.loadingKycInit = false;
        },
        generateTokenRequested: (axisPL, action) => {
            axisPL.loadingGenerateToken = true;
        },
        generateTokenReceived: (axisPL, action) => {
            axisPL.loadingGenerateToken = false;
            axisPL.generateTokenData = action.payload.data;
        },
        generateTokenFailed: (axisPL, action) => {
            axisPL.loadingGenerateToken = false;
        },
        kycValidateRequested: (axisPL, action) => {
            axisPL.loadingKycValidate = true;
        },
        kycValidateReceived: (axisPL, action) => {
            axisPL.loadingKycValidate = false;
            axisPL.kycValidateData = action.payload.data;
        },
        kycValidateFailed: (axisPL, action) => {
            axisPL.loadingKycValidate = false;
        },
        fetchKycStatusRequested: (axisPL, action) => {
            axisPL.loadingFetchKycStatus = true;
        },
        fetchKycStatusReceived: (axisPL, action) => {
            axisPL.loadingFetchKycStatus = false;
            axisPL.fetchKycStatusData = action.payload.data;
        },
        fetchKycStatusFailed: (axisPL, action) => {
            axisPL.loadingFetchKycStatus = false;
        },
        getOfferRequested: (axisPL, action) => {
            axisPL.loadingGetOffer = true;
        },
        getOfferReceived: (axisPL, action) => {
            axisPL.loadingGetOffer = false;
            axisPL.getOfferData = action.payload.data;
        },
        getOfferFailed: (axisPL, action) => {
            axisPL.loadingGetOffer = false;
        },
        CDDRequested: (axisPL, action) => {
            axisPL.loadingCDD = true;
        },
        CDDReceived: (axisPL, action) => {
            axisPL.loadingCDD = false;
            axisPL.cddData = action.payload.data;
        },
        CDDFailed: (axisPL, action) => {
            axisPL.loadingCDD = false;
        },
        fetchKfsRequested: (axisPL, action) => {
            axisPL.loadingKfs = true;
        },
        fetchKfsReceived: (axisPL, action) => {
            axisPL.loadingKfs = false;
            if (action.payload.data) {
                axisPL.kfsData = action.payload.data;
            }
        },
        fetchKfsFailed: (axisPL, action) => {
            axisPL.loadingKfs = false;
        },
        genearateOtpRequested: (axisPL, action) => {
            axisPL.loadingGenerateOtp = true;
        },
        genearateOtpReceived: (axisPL, action) => {
            axisPL.loadingGenerateOtp = false;
        },
        genearateOtpFailed: (axisPL, action) => {
            axisPL.loadingGenerateOtp = false;
        },
        resendOtpRequested: (axisPL, action) => {
            axisPL.loadingResendOtp = true;
        },
        resendOtpReceived: (axisPL, action) => {
            axisPL.loadingResendOtp = false;
            axisPL.resendOtpData = action.payload.data.data;
        },
        resendOtpFailed: (axisPL, action) => {
            axisPL.loadingResendOtp = false;
        },
        enachInitRequested: (axisPL, action) => {
            axisPL.loadingEnachInit = true;
        },
        enachInitReceived: (axisPL, action) => {
            axisPL.loadingEnachInit = false;
        },
        enachInitFailed: (axisPL, action) => {
            axisPL.loadingEnachInit = false;
        },
        enachValidateRequested: (axisPL, action) => {
            axisPL.loadingEnachValidate = true;
        },
        enachValidateReceived: (axisPL, action) => {
            axisPL.loadingEnachValidate = false;
        },
        enachValidateFailed: (axisPL, action) => {
            axisPL.loadingEnachValidate = false;
        },
        applicationProcessRequested: (axisPL, action) => {
            axisPL.loadingApplicationProcess = true;
        },
        applicationProcessReceived: (axisPL, action) => {
            axisPL.loadingApplicationProcess = false;
        },
        applicationProcessFailed: (axisPL, action) => {
            axisPL.loadingApplicationProcess = false;
        },
        applicationStatusRequested: (axisPL, action) => {
            axisPL.loadingApplicationStatus = true;
        },
        applicationStatusReceived: (axisPL, action) => {
            axisPL.loadingApplicationStatus = false;
        },
        applicationStatusFailed: (axisPL, action) => {
            axisPL.loadingApplicationStatus = false;
        },
        moneyViewLinkRequested: (axisPL, action) => {
            axisPL.loadingMoneyView = true;
        },
        moneyViewLinkReceived: (axisPL, action) => {
            axisPL.loadingMoneyView = false;
        },
        moneyViewLinkFailed: (axisPL, action) => {
            axisPL.loadingMoneyView = false;
        },
        earlySalaryLinkRequested: (axisPL, action) => {
            axisPL.loadingEarlySalary = true;
        },
        earlySalaryLinkReceived: (axisPL, action) => {
            axisPL.loadingEarlySalary = false;
        },
        earlySalaryLinkFailed: (axisPL, action) => {
            axisPL.loadingEarlySalary = false;
        },
        fibeStatusRequested: (axisPL, action) => {
            axisPL.loadingFibeStatus = true;
        },
        fibeStatusReceived: (axisPL, action) => {
            axisPL.loadingFibeStatus = false;
        },
        fibeStatusFailed: (axisPL, action) => {
            axisPL.loadingFibeStatus = false;
        },


    },
});

export const {
    axisInitRequested,
    axisInitReceived,
    axisInitFailed,
    consentRequested,
    consentReceived,
    consentFailed,
    getOfferDataRequested,
    getOfferDataReceived,
    getOfferDataFailed,
    kycInitReceived,
    kycInitRequested,
    kycInitFailed,
    generateTokenRequested,
    generateTokenReceived,
    generateTokenFailed,
    kycValidateRequested,
    kycValidateReceived,
    kycValidateFailed,
    fetchKycStatusRequested,
    fetchKycStatusReceived,
    fetchKycStatusFailed,
    getOfferRequested,
    getOfferReceived,
    getOfferFailed,
    CDDRequested,
    CDDReceived,
    CDDFailed,
    fetchKfsRequested,
    fetchKfsReceived,
    fetchKfsFailed,
    genearateOtpRequested,
    genearateOtpReceived,
    genearateOtpFailed,
    resendOtpRequested,
    resendOtpReceived,
    resendOtpFailed,
    enachInitRequested,
    enachInitReceived,
    enachInitFailed,
    enachValidateRequested,
    enachValidateReceived,
    enachValidateFailed,
    applicationProcessRequested,
    applicationProcessReceived,
    applicationProcessFailed,
    applicationStatusRequested,
    applicationStatusReceived,
    applicationStatusFailed,
    moneyViewLinkRequested,
    moneyViewLinkReceived,
    moneyViewLinkFailed,
    earlySalaryLinkRequested,
    earlySalaryLinkReceived,
    earlySalaryLinkFailed,
    fibeStatusRequested,
    fibeStatusReceived,
    fibeStatusFailed,
} = slice.actions;


const url = "axis/init";
const url2 = "axis/consent";
const url3 = "axis/getOffer";
const url4 = "axis/kyc/init";
const url5 = "axis/generateToken";
const url6 = "axis/consent";
const url7 = "axis/fetchKYC";
const url8 = "axis/getOffer";
const url9 = "axis/cdd";
const url10 = "axis/fetch/kfs";
const url11 = "axis/generate/otp";
const url12 = "axis/resend/otp";
const url13 = "axis/enach/init";
const url14 = "axis/enach/validate";
const url15 = "axis/application/process";
const url16 = "axis/status";
const url17 = "moneyViewRedirection"
const url18 = "fibeWebApi";
const url19 = "fibeStatus"


export const axisInit = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: axisInitRequested.type,
            onSuccess: axisInitReceived.type,
            onError: axisInitFailed.type,
        })
    );
};

export const consentAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url2,
            method: "POST",
            data: params,
            callback,
            onStart: consentRequested.type,
            onSuccess: consentReceived.type,
            onError: consentFailed.type,
        })
    );
};

export const getOfferAxisPL = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url3,
            method: "POST",
            data: params,
            callback,
            onStart: getOfferDataRequested.type,
            onSuccess: getOfferDataReceived.type,
            onError: getOfferDataFailed.type,
        })
    );
};

export const kycInitAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url4,
            method: "POST",
            data: params,
            callback,
            onStart: kycInitRequested.type,
            onSuccess: kycInitReceived.type,
            onError: kycInitFailed.type,
        })
    );
};


export const generateTokenAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url5,
            method: "POST",
            data: params,
            callback,
            onStart: generateTokenRequested.type,
            onSuccess: generateTokenReceived.type,
            onError: generateTokenFailed.type,
        })
    );
};

export const consentAPIAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url6,
            method: "POST",
            data: params,
            callback,
            onStart: kycValidateRequested.type,
            onSuccess: kycValidateReceived.type,
            onError: kycValidateFailed.type,
        })
    );
};

export const fetchKycStatusAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url7,
            method: "POST",
            data: params,
            callback,
            onStart: fetchKycStatusRequested.type,
            onSuccess: fetchKycStatusReceived.type,
            onError: fetchKycStatusFailed.type,
        })
    );
};

export const getOfferAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url8,
            method: "POST",
            data: params,
            callback,
            onStart: getOfferRequested.type,
            onSuccess: getOfferDataReceived.type,
            onError: getOfferFailed.type,
        })
    );
};


export const CDDAxis = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url9,
            method: "POST",
            data: params,
            callback,
            onStart: CDDRequested.type,
            onSuccess: CDDReceived.type,
            onError: CDDFailed.type,
        })
    );
};


export const fetchKfs = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url10,
            method: "POST",
            data: params,
            callback,
            onStart: fetchKfsRequested.type,
            onSuccess: fetchKfsReceived.type,
            onError: fetchKfsReceived.type,
        })
    );
};


export const generateOtp = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url11,
            method: "POST",
            data: params,
            callback,
            onStart: genearateOtpRequested.type,
            onSuccess: genearateOtpReceived.type,
            onError: genearateOtpFailed.type,
        })
    );
};


export const resendOtp = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url12,
            method: "POST",
            data: params,
            callback,
            onStart: resendOtpRequested.type,
            onSuccess: resendOtpReceived.type,
            onError: resendOtpFailed.type,
        })
    );
};

export const enachInit = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url13,
            method: "POST",
            data: params,
            callback,
            onStart: enachInitRequested.type,
            onSuccess: enachInitReceived.type,
            onError: enachInitFailed.type,
        })
    );
};


export const enachValidate = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url14,
            method: "POST",
            data: params,
            callback,
            onStart: enachValidateRequested.type,
            onSuccess: enachValidateReceived.type,
            onError: enachValidateFailed.type,
        })
    );
};


export const applicationProcess = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url15,
            method: "POST",
            data: params,
            callback,
            onStart: applicationProcessRequested.type,
            onSuccess: applicationProcessReceived.type,
            onError: applicationProcessRequested.type,
        })
    );
};

export const applicationStatus = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url16,
            method: "POST",
            data: params,
            callback,
            onStart: applicationStatusRequested.type,
            onSuccess: applicationStatusReceived.type,
            onError: applicationStatusRequested.type,
        })
    );
};


export const moneyViewRedirection = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url17,
            method: "POST",
            data: params,
            callback,
            onStart: moneyViewLinkRequested.type,
            onSuccess: moneyViewLinkReceived.type,
            onError: moneyViewLinkFailed.type,
        })
    );
};

export const earlySalaryRedirection = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url18,
            method: "POST",
            data: params,
            callback,
            onStart: earlySalaryLinkRequested.type,
            onSuccess: earlySalaryLinkReceived.type,
            onError: earlySalaryLinkFailed.type,
        })
    );
};


export const getFibeStatus = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url19,
            method: "POST",
            data: params,
            callback,
            onStart: fibeStatusRequested.type,
            onSuccess: fibeStatusReceived.type,
            onError: fibeStatusFailed.type,
        })
    );
};
export default slice.reducer;

export const axisPL = createSelector(
    (state) => state.entities.axisPL,
    (axisPL) => axisPL
);
