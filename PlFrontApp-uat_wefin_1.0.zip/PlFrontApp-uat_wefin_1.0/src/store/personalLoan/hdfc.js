import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "../api";


const slice = createSlice({
    name: "hdfcPL",
    initialState: {
        hdfcLoadingStatus: false,
        hdfcData: {},
        loadingReferenceDetailsHdfc: false,
        loadingFileHdfc: false,
        loadingFileCompleteHdfc: false,
        loadingHdfcStatus: false,
        loadingGetEmployers: false,
        employerData: []
    },
    reducers: {
        hdfcRequested: (hdfcPL, action) => {
            hdfcPL.hdfcLoadingStatus = true;
        },
        hdfcReceived: (hdfcPL, action) => {
            hdfcPL.hdfcLoadingStatus = false;
            hdfcPL.hdfcData = action.payload.data;
        },
        hdfcFailed: (hdfcPL, action) => {
            hdfcPL.hdfcLoadingStatus = false;
        },
        hdfcReferenceRequested: (hdfcPL, action) => {
            hdfcPL.loadingReferenceDetailsHdfc = true;
        },
        hdfcReferenceReceived: (hdfcPL, action) => {
            hdfcPL.loadingReferenceDetailsHdfc = false;
        },
        hdfcReferenceFailed: (hdfcPL, action) => {
            hdfcPL.loadingReferenceDetailsHdfc = false;
        },
        hdfcFileRequested: (hdfcPL, action) => {
            hdfcPL.loadingFileHdfc = true;
        },
        hdfcFileReceived: (hdfcPL, action) => {
            hdfcPL.loadingFileHdfc = false;
        },
        hdfcFileFailed: (hdfcPL, action) => {
            hdfcPL.loadingFileHdfc = false;
        },
        hdfcFileCompleteRequested: (hdfcPL, action) => {
            hdfcPL.loadingFileCompleteHdfc = true;
        },
        hdfcFileCompleteReceived: (hdfcPL, action) => {
            hdfcPL.loadingFileCompleteHdfc = false;
        },
        hdfcFileCompleteFailed: (hdfcPL, action) => {
            hdfcPL.loadingFileCompleteHdfc = false;
        },
        hdfcStatusRequested: (hdfcPL, action) => {
            hdfcPL.loadingHdfcStatus = true;
        },
        hdfcStatusReceived: (hdfcPL, action) => {
            hdfcPL.loadingHdfcStatus = false;
        },
        hdfcStatusFailed: (hdfcPL, action) => {
            hdfcPL.loadingHdfcStatus = false;
        },
        getEmployersHDFCRequested: (hdfcPL, action) => {
            hdfcPL.loadingGetEmployers = true;
        },
        getEmployersHDFCReceived: (hdfcPL, action) => {
            hdfcPL.loadingGetEmployers = false;
            hdfcPL.employerData = action.payload.data;
        },
        getEmployersHDFCFailed: (hdfcPL, action) => {
            hdfcPL.loadingGetEmployers = false;
        },
    },
});

export const {
    hdfcRequested,
    hdfcReceived,
    hdfcFailed,
    hdfcReferenceRequested,
    hdfcReferenceReceived,
    hdfcReferenceFailed,
    hdfcFileRequested,
    hdfcFileReceived,
    hdfcFileFailed,
    hdfcFileCompleteRequested,
    hdfcFileCompleteReceived,
    hdfcFileCompleteFailed,
    hdfcStatusRequested,
    hdfcStatusReceived,
    hdfcStatusFailed,
    getEmployersHDFCRequested,
    getEmployersHDFCReceived,
    getEmployersHDFCFailed
} = slice.actions;


const url = "hdfcValidatePartner";
const url1 = "hdfcApplyForLoan";
const url2 = "hdfcAddReference";
const url3 = "hdfcUploadDocument";
const url4 = "hdfcCompleteDocUpload";
const url5 = "hdfcLoanStatus";
const url6 = "getEmploersForHdfc";


export const validatePartner = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: hdfcRequested.type,
            onSuccess: hdfcReceived.type,
            onError: hdfcFailed.type,
        })
    );
};

export const hdfcApplyForLoan = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url1,
            method: "POST",
            data: params,
            callback,
            onStart: hdfcRequested.type,
            onSuccess: hdfcReceived.type,
            onError: hdfcFailed.type,
        })
    );
};

export const hdfcReference = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url2,
            method: "POST",
            data: params,
            callback,
            onStart: hdfcReferenceRequested.type,
            onSuccess: hdfcReferenceReceived.type,
            onError: hdfcReferenceFailed.type,
        })
    );
};


export const hdfcFileUpload = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url3,
            method: "POST",
            data: params,
            callback,
            onStart: hdfcFileRequested.type,
            onSuccess: hdfcFileReceived.type,
            onError: hdfcFileFailed.type,
        })
    );
};

export const hdfcFileUploadComplete = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url4,
            method: "POST",
            data: params,
            callback,
            onStart: hdfcFileCompleteRequested.type,
            onSuccess: hdfcFileCompleteReceived.type,
            onError: hdfcFileCompleteFailed.type,
        })
    );
};

export const hdfcStatus = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url5,
            method: "POST",
            data: params,
            callback,
            onStart: hdfcStatusRequested.type,
            onSuccess: hdfcStatusReceived.type,
            onError: hdfcStatusFailed.type,
        })
    );
};

export const getEmploersForHdfc = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url6,
            method: "POST",
            data: params,
            callback,
            onStart: getEmployersHDFCRequested.type,
            onSuccess: getEmployersHDFCReceived.type,
            onError: getEmployersHDFCFailed.type,
        })
    );
};


export default slice.reducer;

export const hdfcPL = createSelector(
    (state) => state.entities.hdfcPL,
    (hdfcPL) => hdfcPL
);
