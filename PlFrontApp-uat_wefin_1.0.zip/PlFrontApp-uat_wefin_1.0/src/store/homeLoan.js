import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "homeLoan",
  initialState: {
    loading: false
  },
  reducers: {
    homeLoanRequested: (homeLoan, action) => 
    {
        homeLoan.loading = true;
    },
    homeLoanReceived: (homeLoan, action) => 
    {
      homeLoan.loading = false;
    },
    homeLoanRequestFailed: (homeLoan, action) => {
        homeLoan.loading = false;
    }
  },
});

export const {
    homeLoanRequested,
    homeLoanReceived,
    homeLoanRequestFailed
} = slice.actions;

export default slice.reducer;

const homeLoanApplyUrl = "set/hl/details";

export const applyHomeLoan =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: homeLoanApplyUrl,
        method: "POST",
        data: params,
        callback,
        onStart: homeLoanRequested.type,
        onSuccess: homeLoanReceived.type,
        onError: homeLoanRequestFailed.type,
      })
    );
  };

export const getHomeLoanDetails = createSelector(
  (state) => state.entities.homeLoan,
  (homeLoan) => homeLoan
);
