import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "login",
  initialState: {
    customerLogin: {},
    customerOtp: {},
    getOTP: {},
    setEmail: {},
    IVRData: {},
    loadingOtp: false,
    loadingIVR: false,
    loadingLogin: false,
    loadingGet: false,
    loadingEmail: false,
    loadingLogout: false,
    lastFetch: null,
  },
  reducers: {
    ivrLoading: (login, action) => {
      login.loadingIVR = true;
    },
    ivrSuccess: (login, action) => {
      login.IVRData = action.payload.data;
      login.loadingIVR = false;
      login.lastFetch = Date.now();
    },
    ivrError: (login, action) => {
      login.loadingIVR = false;
    },
    customerLoginRequested: (login, action) => {
      login.loadingLogin = true;
    },
    customerLoginReceived: (login, action) => {
      login.customerLogin = action.payload.data;
      login.loadingLogin = false;
      login.lastFetch = Date.now();
    },
    customerLoginRequestFailed: (login, action) => {
      login.loadingLogin = false;
    },
    setEmailRequested: (login, action) => {
      login.loadingEmail = true;
    },
    setEmailReceived: (login, action) => {
      login.setEmail = action.payload.data;
      login.loadingEmail = false;
      login.lastFetch = Date.now();
    },
    setEmailRequestFailed: (login, action) => {
      login.loadingEmail = false;
    },
    getOTPRequested: (login, action) => {
      login.loadingGet = true;
    },
    getOTPReceived: (login, action) => {
      login.getOTP = action.payload.data;
      login.loadingGet = false;
      login.lastFetch = Date.now();
    },
    getOTPRequestFailed: (login, action) => {
      login.loadingGet = false;
    },
    customerOtpRequested: (login, action) => {
      login.loadingOtp = true;
    },
    customerOtpReceived: (login, action) => {
      login.customerOtp = action.payload.data;
      login.loadingOtp = false;
      login.lastFetch = Date.now();
    },
    customerOtpRequestFailed: (login, action) => {
      login.loadingOtp = false;
    },
    logoutRequested: (login, action) => {
      login.loadingLogout = true;
    },
    logoutReceived: (login, action) => {
      login.loadingLogout = false;
    },
    logoutRequestFailed: (login, action) => {
      login.loadingLogout = false;
    },
  },
});

export const {
  ivrLoading,
  ivrSuccess,
  ivrError,
  customerLoginRequested,
  customerLoginReceived,
  customerLoginRequestFailed,
  customerOtpRequested,
  customerOtpReceived,
  customerOtpRequestFailed,
  getOTPReceived,
  getOTPRequestFailed,
  getOTPRequested,
  setEmailReceived,
  setEmailRequestFailed,
  setEmailRequested,
  logoutRequested,
  logoutReceived,
  logoutRequestFailed
} = slice.actions;
export default slice.reducer;

const url = "customerSignup";
const url1 = "customerLogin";
const url2 = "sendotp/";
const url3 = "setEmail";
const url4 = 'logout';
const url5 = 'updateIvrStatus'

export const setCustomerLogin = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: customerLoginRequested.type,
      onSuccess: customerLoginReceived.type,
      onError: customerLoginRequestFailed.type,
    })
  );
};
export const setCustomerEmail = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: params,
      callback,
      onStart: setEmailRequested.type,
      onSuccess: setEmailReceived.type,
      onError: setEmailRequestFailed.type,
    })
  );
};
export const getCustomerOTP = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2 + params,
      method: "GET",
      callback,
      onStart: getOTPRequested.type,
      onSuccess: getOTPReceived.type,
      onError: getOTPRequestFailed.type,
    })
  );
};
export const setCustomerOtp = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: customerOtpRequested.type,
      onSuccess: customerOtpReceived.type,
      onError: customerOtpRequestFailed.type,
    })
  );
};

export const logout = (callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      method: "POST",
      callback,
      onStart: logoutRequested.type,
      onSuccess: logoutReceived.type,
      onError: logoutRequestFailed.type,
    })
  );
};

export const updateCampaignIVR = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url5,
      method: "POST",
      data: params,
      callback,
      onStart: ivrLoading.type,
      onSuccess: ivrSuccess.type,
      onError: ivrError.type,
    })
  );
};


export const getCustomer = createSelector(
  (state) => state.entities.login,
  (login) => login
);
