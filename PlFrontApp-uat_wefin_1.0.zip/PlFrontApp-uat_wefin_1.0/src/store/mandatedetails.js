import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "mandate",
  initialState: {
    initiateMandateData: {},
    saveMandateData: {},
    prePayement: {},
    loadingSaveMandateData: false,
    loadingMandateData: false,
    loadingPrePayment: false,
    lastFetch: null,
    loadingRevoltEmandate: false,
    emandateDataRevolt: {}
  },
  reducers: {
    initiateMandateRequested: (mandate, action) => {
      mandate.loadingMandateData = true;
    },
    initiateMandateReceived: (mandate, action) => {
      mandate.initiateMandateData = action.payload.data;
      mandate.loadingMandateData = false;
      mandate.lastFetch = Date.now();
    },
    initiateMandateFailed: (mandate, action) => {
      mandate.loadingMandateData = false;
    },
    submitMandateRequested: (mandate, action) => {
      mandate.loadingSaveMandateData = true;
    },
    submitMandateReceived: (mandate, action) => {
      mandate.saveMandateData = action.payload.data;
      mandate.loadingSaveMandateData = false;
      mandate.lastFetch = Date.now();
    },
    submitMandateFailed: (mandate, action) => {
      mandate.loadingSaveMandateData = false;
    },
    prePaymentRequested: (mandate, action) => {
      mandate.loadingPrePayment = true;
    },
    prePaymentReceived: (mandate, action) => {
      mandate.prePaymentData = action.payload.data;
      mandate.loadingPrePayment = false;
      mandate.lastFetch = Date.now();
    },
    prePaymentFailed: (mandate, action) => {
      mandate.loadingPrePayment = false;
    },
    revoltMoneyplusEmandateRequested: (mandate, action) => {
      mandate.loadingRevoltEmandate = true;
    },
    revoltMoneyplusEmandateReceived: (mandate, action) => {
      mandate.emandateDataRevolt = action.payload.data;
      mandate.loadingRevoltEmandate = false;
    },
    revoltMoneyplusEmandateFailed: (mandate, action) => {
      mandate.loadingRevoltEmandate = false;
    },
  },
});

export const {
  initiateMandateRequested,
  initiateMandateReceived,
  initiateMandateFailed,
  submitMandateRequested,
  submitMandateReceived,
  submitMandateFailed,
  prePaymentRequested,
  prePaymentReceived,
  prePaymentFailed,
  revoltMoneyplusEmandateRequested,
  revoltMoneyplusEmandateReceived,
  revoltMoneyplusEmandateFailed
} = slice.actions;
export default slice.reducer;

const url = "emandatePreData";
// const url2 = "submitPayment";
const url1 = "initiatePayment";
const url3 = "cs/emandate";
/////////revolt emandate///////
const url4 = "ra/emandate";

export const prePaymentData = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: prePaymentRequested.type,
      onSuccess: prePaymentReceived.type,
      onError: prePaymentFailed.type,
    })
  );
};

export const initiateMandateData = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: initiateMandateRequested.type,
      onSuccess: initiateMandateReceived.type,
      onError: initiateMandateFailed.type,
    })
  );
};

export const loadCreditSaisonMandateData = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: params,
      callback,
      onStart: submitMandateRequested.type,
      onSuccess: submitMandateReceived.type,
      onError: submitMandateFailed.type,
    })
  );
};

export const moneyplusRevoltEmandate = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      method: "POST",
      data: params,
      callback,
      onStart: revoltMoneyplusEmandateRequested.type,
      onSuccess: revoltMoneyplusEmandateReceived.type,
      onError: revoltMoneyplusEmandateFailed.type,
    })
  );
};

export const mandateData = createSelector(
  (state) => state.entities.mandateDetails,
  (mandateDetails) => mandateDetails
);
