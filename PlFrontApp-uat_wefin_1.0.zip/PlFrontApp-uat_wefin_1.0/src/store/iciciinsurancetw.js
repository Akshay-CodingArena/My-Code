import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";


const slice = createSlice({
    name: "iciciinsurancetw",
    initialState: {
        loadingChassisData: false,
        loadingGetQuote: false,
        getQuoteData: {},
        updatedData: {},
        loadingSaveQuote: false,
        saveQuoteData: {},
        loadingProposal: false,
        loadingPolicyStatus: false,
        loadingGetCerticate: false,
        loadingOVDInitaite: false,
        loadingGetInfoFromRCNo: false,
        vehicleData: {}
    },
    reducers: {
        fetchChesisDataRequested: (icici, action) => {
            icici.loadingChassisData = true;
        },
        fetchChesisDataReceived: (icici, action) => {
            icici.loadingChassisData = false;
        },
        fetchChesisDataFailed: (icici, action) => {
            icici.loadingChassisData = false;
        },
        getQuoteRequested: (icici, action) => {
            icici.loadingGetQuote = true;
        },
        getQuoteReceived: (icici, action) => {
            icici.loadingGetQuote = false;
            icici.getQuoteData = action.payload.data;
            icici.updatedData = action.payload.updatedData;
        },
        getQuoteFailed: (icici, action) => {
            icici.loadingGetQuote = false;
        },
        saveQuoteRequested: (icici, action) => {
            icici.loadingSaveQuote = true;
        },
        saveQuoteReceived: (icici, action) => {
            icici.loadingSaveQuote = false;
            icici.saveQuoteData = action.payload.data;
        },
        saveQuoteFailed: (icici, action) => {
            icici.loadingSaveQuote = false;
        },
        proposalRequested: (icici, action) => {
            icici.loadingProposal = true;
        },
        proposalReceived: (icici, action) => {
            icici.loadingProposal = false;
        },
        proposalFailed: (icici, action) => {
            icici.loadingProposal = false;
        },
        policyStatusRequested: (icici, action) => {
            icici.loadingPolicyStatus = true;
        },
        policyStatusReceived: (icici, action) => {
            icici.loadingPolicyStatus = false;
        },
        policyStatusFailed: (icici, action) => {
            icici.loadingPolicyStatus = false;
        },
        getCertificateRequested: (icici, action) => {
            icici.loadingGetCerticate = true;
        },
        getCertificateReceived: (icici, action) => {
            icici.loadingGetCerticate = false;
        },
        getCertificateFailed: (icici, action) => {
            icici.loadingGetCerticate = false;
        },
        OVDInitiateRequested: (icici, action) => {
            icici.loadingOVDInitaite = true;
        },
        OVDInitiateReceived: (icici, action) => {
            icici.loadingOVDInitaite = false;
        },
        OVDInitiateFailed: (icici, action) => {
            icici.loadingOVDInitaite = false;
        },
        getInfoFromRCNoRequested: (icici, action) => {
            icici.loadingGetInfoFromRCNo = true;
        },
        getInfoFromRCNoReceived: (icici, action) => {
            icici.loadingGetInfoFromRCNo = false;
            icici.vehicleData = action.payload?.data?.result;
        },
        getInfoFromRCNoFailed: (icici, action) => {
            icici.loadingGetInfoFromRCNo = false;
        },
    },
});

export const {
    fetchChesisDataRequested,
    fetchChesisDataReceived,
    fetchChesisDataFailed,
    getQuoteRequested,
    getQuoteReceived,
    getQuoteFailed,
    saveQuoteRequested,
    saveQuoteReceived,
    saveQuoteFailed,
    proposalRequested,
    proposalReceived,
    proposalFailed,
    policyStatusRequested,
    policyStatusReceived,
    policyStatusFailed,
    getCertificateRequested,
    getCertificateReceived,
    getCertificateFailed,
    OVDInitiateRequested,
    OVDInitiateReceived,
    OVDInitiateFailed,
    getInfoFromRCNoRequested,
    getInfoFromRCNoReceived,
    getInfoFromRCNoFailed
} = slice.actions;

export default slice.reducer;

const url = "icici/fetchChesisData";
const url2 = "icici/getQuotes";
const url3 = "icici/ckyc";
const url4 = "icici/revoltProposal";
const url5 = "icici/revoltPolicy";
const url6 = "icici/coiCertificate";
const url7 = "icici/OVDInitiate";
const url8 = "getVehicleRegInfo"


export const getInfoFromRCNo = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url8,
            method: "POST",
            data: params,
            callback,
            onStart: getInfoFromRCNoRequested.type,
            onSuccess: getInfoFromRCNoReceived.type,
            onError: getInfoFromRCNoFailed.type,
        })
    );
};

export const fetchChesisData = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: fetchChesisDataRequested.type,
            onSuccess: fetchChesisDataReceived.type,
            onError: fetchChesisDataFailed.type,
        })
    );
};

export const getQuote = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url2,
            method: "POST",
            data: params,
            callback,
            onStart: getQuoteRequested.type,
            onSuccess: getQuoteReceived.type,
            onError: getQuoteFailed.type,
        })
    );
};

export const saveQuote = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url3,
            method: "POST",
            data: params,
            callback,
            onStart: saveQuoteRequested.type,
            onSuccess: saveQuoteReceived.type,
            onError: saveQuoteFailed.type,
        })
    );
};

export const iciciProposal = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url4,
            method: "POST",
            data: params,
            callback,
            onStart: proposalRequested.type,
            onSuccess: proposalReceived.type,
            onError: proposalFailed.type,
        })
    );
};

export const policyStatus = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url5,
            method: "POST",
            data: params,
            callback,
            onStart: policyStatusRequested.type,
            onSuccess: policyStatusReceived.type,
            onError: policyStatusFailed.type,
        })
    );
};

export const getCertificate = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url6,
            method: "POST",
            data: params,
            callback,
            onStart: getCertificateRequested.type,
            onSuccess: getCertificateReceived.type,
            onError: getCertificateFailed.type,
        })
    );
};


export const OVDInitiate = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url7,
            method: "POST",
            data: params,
            callback,
            onStart: OVDInitiateRequested.type,
            onSuccess: OVDInitiateReceived.type,
            onError: OVDInitiateFailed.type,
        })
    );
};


export const getICICI = createSelector(
    (state) => state.entities.icici,
    (icici) => icici
);
