import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "pincode",
  initialState: {
    pincode: {},
    creditpincode: {},
    geoLocation: {},
    loading: false,
    pinloading: false,
    loadingGeo: false,
    lastFetch: null,
  },
  reducers: {
    pincodeRequested: (pincode, action) => {
      pincode.loading = true;
    },

    pincodeReceived: (pincode, action) => {
      pincode.pincode = action.payload.data;
      pincode.loading = false;
      pincode.lastFetch = Date.now();
    },

    pincodeRequestFailed: (pincode, action) => {
      pincode.loading = false;
    },
    creditpincodeRequested: (pincode, action) => {
      pincode.pinloading = true;
    },

    creditpincodeReceived: (pincode, action) => {
      pincode.creditpincode = action.payload.data;
      pincode.pinloading = false;
      pincode.lastFetch = Date.now();
    },

    creditpincodeRequestFailed: (pincode, action) => {
      pincode.pinloading = false;
    },
    geoRequested: (pincode, action) => {
      pincode.loadingGeo = true;
    },

    geoReceived: (pincode, action) => {
      pincode.geoLocation = action.payload;
      pincode.loadingGeo = false;
      pincode.lastFetch = Date.now();
    },

    geoRequestFailed: (pincode, action) => {
      pincode.loadingGeo = false;
    },
  },
});

export const {
  pincodeRequested,
  pincodeReceived,
  pincodeRequestFailed,
  creditpincodeRequested,
  creditpincodeReceived,
  creditpincodeRequestFailed,
  geoRequested,
  geoReceived,
  geoRequestFailed,
} = slice.actions;
export default slice.reducer;
const url = "getPincodeInfo";
const url1 = "getGeoLoc";
const url2 = "pin/info";

export const loadPinCode = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: { ...params },
      callback,
      onStart: pincodeRequested.type,
      onSuccess: pincodeReceived.type,
      onError: pincodeRequestFailed.type,
    })
  );
};
export const loadcreditPinCode = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: creditpincodeRequested.type,
      onSuccess: creditpincodeReceived.type,
      onError: creditpincodeRequestFailed.type,
    })
  );
};
export const loadGeoLocation = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1 + "?" + params,
      method: "POST",
      callback,
      onStart: geoRequested.type,
      onSuccess: geoReceived.type,
      onError: geoRequestFailed.type,
    })
  );
};

export const getpinCode = createSelector(
  (state) => state.entities.pincode,
  (pincode) => pincode
);
