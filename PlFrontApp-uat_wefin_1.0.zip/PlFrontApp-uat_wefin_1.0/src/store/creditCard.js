import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "creditCard",
  initialState: {
    ccData: [],
    filters: {
      checkValue: [],
      checkBankValue: []
    },
    bankCheckValues: [],
    loading: false,
    lastFetch: null,
  },
  reducers: {
    listRequested: (creditCard, action) => {
      creditCard.loading = true;
    },
    listReceived: (creditCard, action) => {
      creditCard.ccData = action.payload.data;
      creditCard.loading = false;
      creditCard.lastFetch = Date.now();
    },
    listRequestFailed: (creditCard, action) => {
      creditCard.loading = false;
    },
    setFilters: (creditCard, action) => {
      creditCard.filters = action.payload
    }
  },
});

export const { listRequested, listReceived, listRequestFailed, setFilters } = slice.actions;

export default slice.reducer;

const url = "getcreditdarddetails";

export const loadCreditCardList = () => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "GET",
      onStart: listRequested.type,
      onSuccess: listReceived.type,
      onError: listRequestFailed.type,
    })
  );
};

export const getCreditCard = createSelector(
  (state) => state.entities.creditCard,
  (creditCard) => creditCard,
  (filters) => filters
);
