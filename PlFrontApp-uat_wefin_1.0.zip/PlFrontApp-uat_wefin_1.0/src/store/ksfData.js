import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "ksfData",

  initialState: {
    ksfDetail: {},
    setksfDetail: {},
    loadingKsf: false,
    loadingsetKsf: false,
    lastFetch: null,
  },

  reducers: {
    ksfDetailsRequested: (ksfData, action) => {
      ksfData.loadingKsf = true;
    },
    ksfDetailsReceived: (ksfData, action) => {
      ksfData.ksfDetail = action.payload;
      ksfData.loadingKsf = false;
    },
    ksfDetailRequestFailed: (ksfData, action) => {
      ksfData.loadingKsf = false;
    },
    ksfsetDetailsRequested: (ksfData, action) => {
      ksfData.loadingsetKsf = true;
    },
    ksfsetDetailsReceived: (ksfData, action) => {
      ksfData.setksfDetail = action.payload;
      ksfData.loadingsetKsf = false;
    },
    ksfsetDetailRequestFailed: (ksfData, action) => {
      ksfData.loadingsetKsf = false;
    },
  },
});

export const {
  ksfDetailsRequested,
  ksfDetailsReceived,
  ksfDetailRequestFailed,
  ksfsetDetailsRequested,
  ksfsetDetailsReceived,
  ksfsetDetailRequestFailed,
} = slice.actions;

export default slice.reducer;

const url = "/cs/ksf/details";
const url1 = "/cs/ksf/customer/confirm";
export const getKsfData = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      onStart: ksfDetailsRequested.type,
      onSuccess: ksfDetailsReceived.type,
      onError: ksfDetailRequestFailed.type,
    })
  );
};
export const setKsfData = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: ksfsetDetailsRequested.type,
      onSuccess: ksfsetDetailsReceived.type,
      onError: ksfsetDetailRequestFailed.type,
    })
  );
};
export const getKsf = createSelector(
  (state) => state?.entities?.ksfData,
  (ksfData) => ksfData
);
