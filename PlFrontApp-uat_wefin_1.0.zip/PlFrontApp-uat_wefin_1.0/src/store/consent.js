import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "consents",
  initialState: {
    consent: {},
    loadingConsent: false,
    lastFetch: null,
  },
  reducers: {
    consentRequested: (consents, action) => {
      consents.loadingConsent = true;
    },
    consentReceived: (consents, action) => {
      consents.consent = action.payload.data;
      consents.loadingConsent = false;
      consents.lastFetch = Date.now();
    },
    consentRequestFailed: (consents, action) => {
      consents.loadingConsent = false;
    },
  },
});

export const { consentRequested, consentReceived, consentRequestFailed } =
  slice.actions;
export default slice.reducer;

const url = "userconsent";

export const loadConsents = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: consentRequested.type,
      onSuccess: consentReceived.type,
      onError: consentRequestFailed.type,
    })
  );
};

export const getConsent = createSelector(
  (state) => state.entities.consents,
  (consents) => consents
);
