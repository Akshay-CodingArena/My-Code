import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
    name: "aadhar",
    initialState: {
        initiateKycStatus: {},
        validateKycStatus: {},
        loadingInitiateKyc: false,
        loadingValidateKyc: false,
        lastFetch: null,
    },
    reducers: {
        initiateKycRequested: (kyc, action) => {
            kyc.loadingInitiateKyc = true;
        },
        initiateKycReceived: (kyc, action) => {
            kyc.initiateKycStatus = action.payload.data;
            kyc.loadingInitiateKyc = false;
            kyc.lastFetch = Date.now();
        },
        initiateKycFailed: (kyc, action) => {
            kyc.loadingInitiateKyc = false;
        },
        validateKycRequested: (kyc, action) => {
            kyc.loadingValidateKyc = true;
        },
        validateKycReceived: (kyc, action) => {
            kyc.validateKycStatus = action.payload.data;
            kyc.loadingValidateKyc = false;
            kyc.lastFetch = Date.now();
        },
        validateKycFailed: (kyc, action) => {
            kyc.loadingValidateKyc = false;
        },
    },
});

export const {
    initiateKycRequested,
    initiateKycReceived,
    initiateKycFailed,
    validateKycRequested,
    validateKycReceived,
    validateKycFailed
} = slice.actions;
export default slice.reducer;

const url = "aadhaarValidate"

export const validateAadhar = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: validateKycRequested.type,
            onSuccess: validateKycReceived.type,
            onError: validateKycFailed.type,
        })
    );
};


export const getKycStatus = createSelector(
    (state) => state.entities.adhaar,
    (adhaar) => adhaar
);
