import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "kyc",
  initialState: {
    initiateKycStatus: {},
    validateKycStatus: {},
    loadingInitiateKyc: false,
    loadingValidateKyc: false,
    lastFetch: null,
  },
  reducers: {
    initiateKycRequested: (kyc, action) => {
      kyc.loadingInitiateKyc = true;
    },
    initiateKycReceived: (kyc, action) => {
      kyc.initiateKycStatus = action.payload.data;
      kyc.loadingInitiateKyc = false;
      kyc.lastFetch = Date.now();
    },
    initiateKycFailed: (kyc, action) => {
      kyc.loadingInitiateKyc = false;
    },
    validateKycRequested: (kyc, action) => {
      kyc.loadingValidateKyc = true;
    },
    validateKycReceived: (kyc, action) => {
      kyc.validateKycStatus = action.payload.data;
      kyc.loadingValidateKyc = false;
      kyc.lastFetch = Date.now();
    },
    validateKycFailed: (kyc, action) => {
      kyc.loadingValidateKyc = false;
    },
  },
});

export const {
  initiateKycRequested,
  initiateKycReceived,
  initiateKycFailed,
  validateKycRequested,
  validateKycReceived,
  validateKycFailed
} = slice.actions;
export default slice.reducer;

const url = "kyc";
const url1 = "cs/doc/upload";
const url2 = "uploadSelfie_mp"

export const initiateKyc = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: initiateKycRequested.type,
      onSuccess: initiateKycReceived.type,
      onError: initiateKycFailed.type,
    })
  );
};

export const validateKyc = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: validateKycRequested.type,
      onSuccess: validateKycReceived.type,
      onError: validateKycFailed.type,
    })
  );
};

export const initiateCreditKyc = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: initiateKycRequested.type,
      onSuccess: initiateKycReceived.type,
      onError: initiateKycFailed.type,
    })
  );
};

export const validateCreditKyc = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: validateKycRequested.type,
      onSuccess: validateKycReceived.type,
      onError: validateKycFailed.type,
    })
  );
};

export const uploadAadhaarSelfie = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: validateKycRequested.type,
      onSuccess: validateKycReceived.type,
      onError: validateKycFailed.type,
    })
  );
};

export const getKycStatus = createSelector(
  (state) => state.entities.kyc,
  (kyc) => kyc
);
