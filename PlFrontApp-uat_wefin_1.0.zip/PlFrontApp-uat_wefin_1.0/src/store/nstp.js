import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
    name: "nstp",
    initialState: {
        nstpDataRevolt: {},
        loadingNstpRevolt: false
    },
    reducers: {
        nstpRevoltRequested: (nstp, action) => {
            nstp.loadingNstpRevolt = true;
        },
        nstpRevoltReceived: (nstp, action) => {
            nstp.loadingNstpRevolt = false;
            nstp.nstpDataRevolt = action.payload.data;
        },
        nstpRevoltFailed: (nstp, action) => {
            nstp.loadingNstpRevolt = false;
        },
    },
});

export const {
    nstpRevoltRequested,
    nstpRevoltReceived,
    nstpRevoltFailed,
} = slice.actions;

export default slice.reducer;

const url = "updateNameNstp"

export const nstpRevolt = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: nstpRevoltRequested.type,
            onSuccess: nstpRevoltReceived.type,
            onError: nstpRevoltFailed.type,
        })
    );
};

export const nstpActions = createSelector(
    (state) => state.entities.nstpActions,
    (kyc) => kyc
);
