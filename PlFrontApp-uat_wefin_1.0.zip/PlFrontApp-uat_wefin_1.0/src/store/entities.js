import { combineReducers } from "redux";
import twoWheelerReducer from "./twoWheeler";
import panNameReducer from "./panName";
import pincodeReducer from "./pincode";
import accountReducer from "./account";
import employerReducer from "./employer";
import applicantReducer from "./applicantDetail";
import applyLoanReducer from "./applyLoan";
import creditCardReducer from "./creditCard";
import bankOfferReducer from "./bankOffer";
import uploadReducer from "./upload";
import experianReducer from "./experian";
import loginReducer from "./login";
import papqOffer from "./papqOffer";
import homeLoanReducer from "./homeLoan";
import businessLoanReducer from "./businessLoan";
import ksfDataReducer from "./ksfData";
import consentsReducer from "./consent";
import myprofileReducer from "./myprofile";
import asmReducer from "./asm"
import validateAadharReducer from "./validateAadhar";
import perfiosReducer from "./perfios";
import bankDetailsReducer from "./bankdetails";
import mandateDetailsReducer from "./mandatedetails";
import nstpActionsReducer from "./nstp";
import eSignReducer from "./eSignAgreement";
import teleVerifierReducer from "./teleVerifier";
import iciciinsurancetw from "./iciciinsurancetw";
import axisPL from "./personalLoan/axis";
import hdfcPL from "./personalLoan/hdfc";
import paysensePL from "./personalLoan/paysense";

export default combineReducers({
  twoWheeler: twoWheelerReducer,
  panName: panNameReducer,
  pincode: pincodeReducer,
  account: accountReducer,
  employer: employerReducer,
  applicant: applicantReducer,
  applyLoan: applyLoanReducer,
  creditCard: creditCardReducer,
  bankOffer: bankOfferReducer,
  upload: uploadReducer,
  experian: experianReducer,
  login: loginReducer,
  papqOffer: papqOffer,
  homeLoan: homeLoanReducer,
  businessLoan: businessLoanReducer,
  ksfData: ksfDataReducer,
  myprofile: myprofileReducer,
  asm: asmReducer,
  televerifier: teleVerifierReducer,
  adhaar: validateAadharReducer,
  perfios: perfiosReducer,
  bankDetails: bankDetailsReducer,
  mandateDetails: mandateDetailsReducer,
  nstpActions: nstpActionsReducer,
  eSignAgreement: eSignReducer,
  icici: iciciinsurancetw,
  axisPL: axisPL,
  hdfcPL: hdfcPL,
  paysensePL: paysensePL
});
