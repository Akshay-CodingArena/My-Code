import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "bankOffer",
  initialState: {
    updateOffer: [],
    setOffer: [],
    getBreOffer: [],
    setBankOffer: [],
    creditDedupe: [],
    setIdfc: [],
    loadingUpdate: false,
    loadingSet: false,
    loadingGet: false,
    loadingBank: false,
    loadingIdfc: false,
    loadingDedupe: false,
    lastFetch: null,
  },
  reducers: {
    updateOfferRequested: (bankOffer, action) => {
      bankOffer.loadingUpdate = true;
    },
    updateOfferReceived: (bankOffer, action) => {
      bankOffer.updateOffer = action.payload;
      bankOffer.loadingUpdate = false;
      bankOffer.lastFetch = Date.now();
    },
    updateOfferRequestFailed: (bankOffer, action) => {
      bankOffer.loadingUpdate = false;
    },
    setOfferRequested: (bankOffer, action) => {
      bankOffer.loadingSet = true;
    },
    setOfferReceived: (bankOffer, action) => {
      bankOffer.setOffer = action.payload.data;
      bankOffer.loadingSet = false;
      bankOffer.lastFetch = Date.now();
    },
    setOfferRequestFailed: (bankOffer, action) => {
      bankOffer.loadingSet = false;
    },
    getOfferRequested: (bankOffer, action) => {
      bankOffer.loadingGet = true;
    },
    getOfferReceived: (bankOffer, action) => {
      bankOffer.getBreOffer = action.payload;
      bankOffer.loadingGet = false;
      bankOffer.lastFetch = Date.now();
    },
    getOfferRequestFailed: (bankOffer, action) => {
      bankOffer.loadingGet = false;
    },
    setBankOfferRequested: (bankOffer, action) => {
      bankOffer.loadingBank = true;
    },
    setBankOfferReceived: (bankOffer, action) => {
      bankOffer.setBankOffer = action.payload.data;
      bankOffer.loadingBank = false;
      bankOffer.lastFetch = Date.now();
    },
    setBankOfferRequestFailed: (bankOffer, action) => {
      bankOffer.loadingBank = false;
    },
    creditDedupeRequested: (bankOffer, action) => {
      bankOffer.loadingDedupe = true;
    },
    creditDedupeReceived: (bankOffer, action) => {
      bankOffer.creditDedupe = action.payload.data;
      bankOffer.loadingDedupe = false;
      bankOffer.lastFetch = Date.now();
    },
    creditDedupeRequestFailed: (bankOffer, action) => {
      bankOffer.loadingDedupe = false;
    },
    setIdfcRequested: (bankOffer, action) => {
      bankOffer.loadingIdfc = true;
    },
    setIdfcReceived: (bankOffer, action) => {
      bankOffer.setIdfc = action.payload;
      bankOffer.loadingIdfc = false;
      bankOffer.lastFetch = Date.now();
    },
    setIdfcRequestFailed: (bankOffer, action) => {
      bankOffer.loadingIdfc = false;
    },
  },
});

export const {
  updateOfferRequested,
  updateOfferReceived,
  updateOfferRequestFailed,
  setOfferRequested,
  setOfferReceived,
  setOfferRequestFailed,
  getOfferRequested,
  getOfferReceived,
  getOfferRequestFailed,
  setBankOfferRequested,
  setBankOfferReceived,
  setBankOfferRequestFailed,
  setIdfcRequested,
  setIdfcReceived,
  setIdfcRequestFailed,
  creditDedupeRequested,
  creditDedupeReceived,
  creditDedupeRequestFailed,
} = slice.actions;
export default slice.reducer;

const url = "updateOffer";
const url1 = "setOffer";
const url2 = "getOffers?";
const url3 = "setBankOffer";
const url4 = "IDFCStatusCheck";
const url5 = "/cs/dedupe";
export const updateBankOffer = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      onStart: updateOfferRequested.type,
      onSuccess: updateOfferReceived.type,
      onError: updateOfferRequestFailed.type,
    })
  );
};
export const setIdfcStatus = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      method: "POST",
      data: params,
      callback,
      onStart: setIdfcRequested.type,
      onSuccess: setIdfcReceived.type,
      onError: setIdfcRequestFailed.type,
    })
  );
};
export const setOfferList = (params, callback) => (dispatch, getState) => {

  let newParams = { ...params };

  if (localStorage.getItem("ASM_Id")) {
    newParams['asm_id'] = localStorage.getItem("ASM_Id");
  }

  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: newParams,
      callback,
      onStart: setOfferRequested.type,
      onSuccess: setOfferReceived.type,
      onError: setOfferRequestFailed.type,
    })
  );
};
export const setBankOfferList = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: params,
      callback,
      onStart: setBankOfferRequested.type,
      onSuccess: setBankOfferReceived.type,
      onError: setBankOfferRequestFailed.type,
    })
  );
};
export const creditSaisonDedupe =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url5,
        method: "POST",
        data: params,
        callback,
        onStart: creditDedupeRequested.type,
        onSuccess: creditDedupeReceived.type,
        onError: creditDedupeRequestFailed.type,
      })
    );
  };
export const getOffer = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2 + params,
      method: "GET",
      callback,
      onStart: getOfferRequested.type,
      onSuccess: getOfferReceived.type,
      onError: getOfferRequestFailed.type,
    })
  );
};
export const getBankOffer = createSelector(
  (state) => state.entities.bankOffer,
  (bankOffer) => bankOffer
);
