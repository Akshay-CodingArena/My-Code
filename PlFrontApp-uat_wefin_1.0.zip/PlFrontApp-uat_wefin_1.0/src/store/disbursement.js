import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "disbursement",

  initialState: {
    getDisbursement: {},
    saveDisbursementStatus: {},
    loadingDisbursement: false,
    loadingSaveDisbursement: false,
    lastFetch: null,
  },

  reducers: {
    disbursementRequested: (disbursement, action) => {
      disbursement.loadingDisbursement = true;
    },

    disbursementReceived: (disbursement, action) => {
      disbursement.getDisbursement = action.payload;

      disbursement.loadingDisbursement = false;

      disbursement.lastFetch = Date.now();
    },

    disbursementRequestFailed: (disbursement, action) => {
      disbursement.loadingDisbursement = false;
    },
    saveDisbursementRequested: (disbursement, action) => {
      disbursement.loadingSaveDisbursement = true;
    },

    saveDisbursementReceived: (disbursement, action) => {
      disbursement.getDisbursement = action.payload;

      disbursement.loadingSaveDisbursement = false;

      disbursement.lastFetch = Date.now();
    },

    saveDisbursementRequestFailed: (disbursement, action) => {
      disbursement.loadingSaveDisbursement = false;
    },
  },
});

export const {
  disbursementRequested,
  disbursementReceived,
  disbursementRequestFailed,
  saveDisbursementRequested,
  saveDisbursementReceived,
  saveDisbursementRequestFailed,
} = slice.actions;

export default slice.reducer;

const url = "/getDisbursementOverview";
const url1 = "saveDisbursementDetails";

// To receive the data

export const getDisbursementData =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url,

        method: "POST",

        data: params,

        callback,

        onStart: disbursementRequested.type,

        onSuccess: disbursementReceived.type,

        onError: disbursementRequestFailed.type,
      })
    );
  };

export const saveDisbursementDetails =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url1,

        method: "POST",

        data: params,

        callback,

        onStart: saveDisbursementRequested.type,

        onSuccess: saveDisbursementReceived.type,

        onError: saveDisbursementRequestFailed.type,
      })
    );
  };

// To manage the state

export const disbursementData = createSelector(
  (state) => state.entities.disbursement,
  (disbursement) => disbursement
);
