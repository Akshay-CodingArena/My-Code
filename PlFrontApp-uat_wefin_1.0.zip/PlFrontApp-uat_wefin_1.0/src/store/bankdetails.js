import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "bankdetails",

  initialState: {
    BankAddressDetails: {},
    getBankIfsc: {},
    loadingBankAddressDetails: false,
    loadingBankIfsc: false,
    saveBankDetails: {},
    loadingSaveBankDetails: false,
    lastFetch: null,
  },

  reducers: {
    bankAddressDetailsRequested: (bankdetails, action) => {
      bankdetails.loadingBankAddressDetails = true;
    },

    bankAddressDetailsReceived: (bankdetails, action) => {
      bankdetails.BankAddressDetails = action.payload.data;

      bankdetails.loadingBankAddressDetails = false;

      bankdetails.lastFetch = Date.now();
    },

    bankAddressDetailsRequestFailed: (bankdetails, action) => {
      bankdetails.loadingBankAddressDetails = false;
    },

    bankIfscRequested: (bankifsc, action) => {
      bankifsc.loadingBankIfsc = true;
    },

    bankIfscReceived: (bankifsc, action) => {
      bankifsc.getBankIfsc = action.payload;
      bankifsc.loadingBankIfsc = false;
      bankifsc.lastFetch = Date.now();
    },

    bankIfscRequestFailed: (bankifsc, action) => {
      bankifsc.loadingBankIfsc = false;
    },

    saveBankDetailsRequested: (saveBankDetails, action) => {
      saveBankDetails.loadingSaveBankDetails = true;
    },

    saveBankDetailsReceived: (saveBankDetails, action) => {
      saveBankDetails.saveBankDetails = action.payload;
      saveBankDetails.loadingSaveBankDetails = false;
      saveBankDetails.lastFetch = Date.now();
    },

    saveBankDetailsRequestFailed: (saveBankDetails, action) => {
      saveBankDetails.loadingSaveBankDetails = false;
    },
  },
});

export const {
  bankAddressDetailsRequested,
  bankAddressDetailsReceived,
  bankAddressDetailsRequestFailed,
  bankIfscRequested,
  bankIfscReceived,
  bankIfscRequestFailed,
  saveBankDetailsRequested,
  saveBankDetailsReceived,
  saveBankDetailsRequestFailed,
} = slice.actions;

export default slice.reducer;

// const url = "/setBankDetails1";
const url2 = "/getIFSCdetails";
const url3 = "/setBankDetails1";
const url4 = "/cs/set/bank/details";
const url5 = "/mp/pennydrop"
const url6 = "financialEmploymentCheck"

// To receive the data

export const getIfscDetails = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,

      method: "POST",

      data: params,

      callback,

      onStart: bankIfscRequested.type,

      onSuccess: bankIfscReceived.type,

      onError: bankIfscRequestFailed.type,
    })
  );
};

export const saveBankDetailsInfo =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url3,

        method: "POST",

        data: params,

        callback,

        onStart: saveBankDetailsRequested.type,

        onSuccess: saveBankDetailsReceived.type,

        onError: saveBankDetailsRequestFailed.type,
      })
    );
  };

export const saveBankDetailsInfoCreditSaison =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url4,

        method: "POST",

        data: params,

        callback,

        onStart: saveBankDetailsRequested.type,

        onSuccess: saveBankDetailsReceived.type,

        onError: saveBankDetailsRequestFailed.type,
      })
    );
  };

export const pennyDrop =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url5,

        method: "POST",

        data: params,

        callback,

        onStart: saveBankDetailsRequested.type,

        onSuccess: saveBankDetailsReceived.type,

        onError: saveBankDetailsRequestFailed.type,
      })
    );
  };

export const financialEmploymentCheck = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url6,
      method: "POST",
      data: params,
      callback,
      onStart: saveBankDetailsRequested.type,
      onSuccess: saveBankDetailsReceived.type,
      onError: saveBankDetailsRequestFailed.type,
    })
  );
};

// export const getBankIfscData = (params, callback) => (dispatch, getState) => {
//   console.log(params);
//   return dispatch(
//     apiCallBegan({
//       url: url2,

//       method: "POST",

//       data: params,

//       callback,

//       onStart: bankIfscRequested.type,

//       onSuccess: bankIfscReceived.type,

//       onError: bankIfscRequestFailed.type,
//     })
//   );
// };
// // To manage the state

export const bankDetailsData = createSelector(
  (state) => state.entities.bankDetails,
  (bankDetails) => bankDetails
);
