import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
    name: "asm",
    initialState: {
        asmLogin: {},
        asmLoading: false,
        lastFetch: null,
        leadStatus: [],
        loadingUpdateLeadStatusFOS: false,
        loadingResendOtpFOS: false,
        loadingIsInterestedFOS: false,
        loadingRemoveFileFOS: false,
        loadingApplyLoanCCFOS: false
    },
    reducers: {
        asmLoginRequested: (login, action) => {
            login.asmLoading = true;
        },
        asmLoginReceived: (login, action) => {
            login.asmLogin = action.payload.data;
            login.asmLoading = false;
            login.lastFetch = Date.now();
        },
        asmLoginRequestFailed: (login, action) => {
            login.asmLoading = false;
        },
        loadLeadStatusRequested: (login, action) => {
            login.asmLoading = true;
        },
        loadLeadStatusReceived: (login, action) => {
            login.leadStatus = action.payload.data;
            login.asmLoading = false;
            login.lastFetch = Date.now();
        },
        loadLeadStatusFailed: (login, action) => {
            login.asmLoading = false;
        },
        logoutRequested: (login, action) => {
            login.asmLoading = true
        },
        logoutReceived: (login, action) => {
            login.asmLoading = false;
            login.asmLogin = false
        },
        logoutRequestFailed: (login, action) => {
            login.asmLoading = false
        },
        updateLeadStatusFOSRequested: (login, action) => {
            login.loadingUpdateLeadStatusFOS = true
        },
        updateLeadStatusFOSReceived: (login, action) => {
            login.loadingUpdateLeadStatusFOS = false;
        },
        updateLeadStatusFOSFailed: (login, action) => {
            login.loadingUpdateLeadStatusFOS = false
        },

        resendOtpFOSRequested: (login, action) => {
            login.loadingResendOtpFOS = true
        },
        resendOtpFOSReceived: (login, action) => {
            login.loadingResendOtpFOS = false;
        },
        resendOtpFOSFailed: (login, action) => {
            login.loadingResendOtpFOS = false
        },
        isInterestedFOSRequested: (login, action) => {
            login.loadingIsInterestedFOS = true
        },
        isInterestedFOSReceived: (login, action) => {
            login.loadingIsInterestedFOS = false;
        },
        isInterestedFOSFailed: (login, action) => {
            login.loadingIsInterestedFOS = false
        },
        removeFileFOSRequested: (login, action) => {
            login.loadingRemoveFileFOS = true
        },
        removeFileFOSReceived: (login, action) => {
            login.loadingRemoveFileFOS = false;
        },
        removeFileFOSFailed: (login, action) => {
            login.loadingRemoveFileFOS = false
        },
        applyLoanCCFOSRequested: (login, action) => {
            login.loadingApplyLoanCCFOS = true
        },
        applyLoanCCFOSReceived: (login, action) => {
            login.loadingApplyLoanCCFOS = false;
        },
        applyLoanCCFOSFailed: (login, action) => {
            login.loadingApplyLoanCCFOS = false
        },
    },
});

export const {
    asmLoginRequested,
    asmLoginReceived,
    asmLoginRequestFailed,
    logoutRequested,
    logoutReceived,
    logoutRequestFailed,
    loadLeadStatusRequested,
    loadLeadStatusReceived,
    loadLeadStatusFailed,
    updateLeadStatusFOSRequested,
    updateLeadStatusFOSReceived,
    updateLeadStatusFOSFailed,
    resendOtpFOSRequested,
    resendOtpFOSReceived,
    resendOtpFOSFailed,
    isInterestedFOSRequested,
    isInterestedFOSReceived,
    isInterestedFOSFailed,
    removeFileFOSRequested,
    removeFileFOSReceived,
    removeFileFOSFailed,
    applyLoanCCFOSRequested,
    applyLoanCCFOSReceived,
    applyLoanCCFOSFailed
} = slice.actions;
export default slice.reducer;

const url = "asmLogin";
const url2 = "asmAddCustomer"
const url3 = "asmSendOtp"
const url4 = "asmVerifyOtp"
const url5 = "asmEmail"
const url6 = "asmDashboard"
const url7 = "asmStateUpload"
const url8 = "asmGenerateToken";
const url9 = "icici/getInsuranceData"
const url10 = "leadsList"
const url11 = "addCustomerPersonalDetails"
const url12 = "getLeadStatusForFos"
const url13 = "verifyFosOtp";
const url14 = "fosStatusUpdate";
const url15 = "resendOtpForFos";
const url16 = "fosCustomerIntrested";
const url17 = "removeFosFile";
const url18 = "applyFosLoan";


export const setASMLogin = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmAddCustomer = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url2,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmSendOtp = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url3 + "/" + params,
            method: "GET",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmVerifyOtp = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url4,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmEmail = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url5,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmDashboard = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url6,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const fosDashboard = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url10,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmStateUpload = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url7,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmGenerateToken = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url8,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const asmDashboardInsurance = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url9,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const fosAddCustomer = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url11,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};

export const setFosOtp = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url13,
            method: "POST",
            data: params,
            callback,
            onStart: asmLoginRequested.type,
            onSuccess: asmLoginReceived.type,
            onError: asmLoginRequestFailed.type,
        })
    );
};


export const loadLeadStatus = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url12,
            method: "GET",
            data: params,
            callback,
            onStart: loadLeadStatusRequested.type,
            onSuccess: loadLeadStatusReceived.type,
            onError: loadLeadStatusFailed.type,
        })
    );
};


export const updateLeadStatusFOS = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url14,
            method: "POST",
            data: params,
            callback,
            onStart: updateLeadStatusFOSRequested.type,
            onSuccess: updateLeadStatusFOSReceived.type,
            onError: updateLeadStatusFOSFailed.type,
        })
    );
};

export const resendOTPFOS = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url15,
            method: "POST",
            data: params,
            callback,
            onStart: resendOtpFOSRequested.type,
            onSuccess: resendOtpFOSReceived.type,
            onError: resendOtpFOSFailed.type,
        })
    );
};


export const isInterestedFOS = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url16,
            method: "POST",
            data: params,
            callback,
            onStart: isInterestedFOSRequested.type,
            onSuccess: isInterestedFOSReceived.type,
            onError: isInterestedFOSFailed.type,
        })
    );
};


export const removeFileFOS = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url17,
            method: "POST",
            data: params,
            callback,
            onStart: removeFileFOSRequested.type,
            onSuccess: removeFileFOSReceived.type,
            onError: removeFileFOSFailed.type,
        })
    );
};


export const applyLoanCCFOS = (params, callback) => (dispatch, getState) => {
    return dispatch(
        apiCallBegan({
            url: url18,
            method: "POST",
            data: params,
            callback,
            onStart: applyLoanCCFOSRequested.type,
            onSuccess: applyLoanCCFOSReceived.type,
            onError: applyLoanCCFOSFailed.type,
        })
    );
};

export const getASM = createSelector(
    (state) => state.entities.asm,
    (asm) => asm
)