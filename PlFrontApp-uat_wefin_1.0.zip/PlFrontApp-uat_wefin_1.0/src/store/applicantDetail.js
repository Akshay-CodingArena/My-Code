import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "applicant",
  initialState: {
    setApplicant: {},
    bankName: [],
    reference: {},
    loading: false,
    loadingName: false,
    lastFetch: null,
    w: false,
    referenceDetails: {}
  },
  reducers: {
    applicantRequested: (applicant, action) => {
      applicant.loading = true;
    },
    applicantReceived: (applicant, action) => {
      applicant.setApplicant = action.payload.data;
      applicant.loading = false;
      applicant.lastFetch = Date.now();
    },
    applicantRequestFailed: (applicant, action) => {
      applicant.loading = false;
    },
    bankNameRequested: (applicant, action) => {
      applicant.loadingName = true;
    },
    bankNameReceived: (applicant, action) => {
      applicant.bankName = action.payload.data;
      applicant.loadingName = false;
      applicant.lastFetch = Date.now();
    },
    bankNameRequestFailed: (applicant, action) => {
      applicant.loadingName = false;
    },
    referenceRequested: (applicant, action) => {
      applicant.loading = true;
    },
    referenceReceived: (applicant, action) => {
      applicant.reference = action.payload.data;
      applicant.loading = false;
      applicant.lastFetch = Date.now();
    },
    referenceRequestFailed: (applicant, action) => {
      applicant.loading = false;
    },

    asmReferenceRequested: (applicant, action) => {
      applicant.loadingrAsmReference = true;
    },
    asmReferenceReceived: (applicant, action) => {
      applicant.referenceDetails = action.payload.data;
      applicant.loadingrAsmReference = false;
    },
    asmReferenceRequestFailed: (applicant, action) => {
      applicant.loadingrAsmReference = false;
    },

  },
});

export const {
  applicantRequested,
  applicantReceived,
  applicantRequestFailed,
  bankNameRequested,
  bankNameReceived,
  bankNameRequestFailed,
  referenceRequested,
  referenceReceived,
  referenceRequestFailed,
  asmReferenceRequested,
  asmReferenceReceived,
  asmReferenceRequestFailed
} = slice.actions;
export default slice.reducer;

const url = "applicantDetail";
const url1 = "salaryBankInfo?";
const url2 = "cs/form2";
const url3 = "asmForm2";

export const setApplicantDetail =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url,
        method: "POST",
        data: params,
        callback,
        onStart: applicantRequested.type,
        onSuccess: applicantReceived.type,
        onError: applicantRequestFailed.type,
      })
    );
  };
export const getBankName = (params) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1 + params,
      method: "GET",
      onStart: bankNameRequested.type,
      onSuccess: bankNameReceived.type,
      onError: bankNameRequestFailed.type,
    })
  );
};

export const setApplicantReference =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url2,
        method: "POST",
        data: params,
        callback,
        onStart: referenceRequested.type,
        onSuccess: referenceReceived.type,
        onError: referenceRequestFailed.type,
      })
    );
  };

export const setApplicantReferenceASM =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url3,
        method: "POST",
        data: params,
        callback,
        onStart: asmReferenceRequested.type,
        onSuccess: asmReferenceReceived.type,
        onError: asmReferenceRequestFailed.type,
      })
    );
  };

export const getApplicant = createSelector(
  (state) => state.entities.applicant,
  (applicant) => applicant
);
