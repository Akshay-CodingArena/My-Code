import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "esign",

  initialState: {
    loanAgreementData: {},
    updateAgreementData: {},
    loadingLoanAgreement: false,
    updateLoanAgreement: false,
    lastFetch: null,
    // --------------REVOLT-------------
    loadingMoneyplusRevoltAgreement: false,
    dataMoneyplusRevoltAgreement: {}
  },

  reducers: {
    generateLoanAgreementRequested: (esign, action) => {
      esign.loadingLoanAgreement = true;
    },

    generateLoanAgreementReceived: (esign, action) => {
      esign.loanAgreementData = action.payload;

      esign.loadingLoanAgreement = false;

      esign.lastFetch = Date.now();
    },

    generateLoanAgreementRequestFailed: (esign, action) => {
      esign.loadingLoanAgreement = false;
    },
    updateLoanAgreementRequested: (esign, action) => {
      esign.updateLoanAgreement = true;
    },

    updateLoanAgreementReceived: (esign, action) => {
      esign.loanAgreementData = action.payload;

      esign.updateLoanAgreement = false;

      esign.lastFetch = Date.now();
    },

    updateLoanAgreementRequestFailed: (esign, action) => {
      esign.updateLoanAgreement = false;
    },

    esignagreementMoneyplusRevoltRequested: (esign, action) => {
      esign.loadingMoneyplusRevoltAgreement = true;
    },
    esignagreementMoneyplusRevoltReceived: (esign, action) => {
      esign.loadingMoneyplusRevoltAgreement = false;
      esign.dataMoneyplusRevoltAgreement = action.payload;
    },
    esignagreementMoneyplusRevoltFailed: (esign, action) => {
      esign.loadingMoneyplusRevoltAgreement = false;
    },
  },


});

export const {
  generateLoanAgreementRequested,
  generateLoanAgreementReceived,
  generateLoanAgreementRequestFailed,
  updateLoanAgreementRequested,
  updateLoanAgreementReceived,
  updateLoanAgreementRequestFailed,
  esignagreementMoneyplusRevoltRequested,
  esignagreementMoneyplusRevoltReceived,
  esignagreementMoneyplusRevoltFailed
} = slice.actions;

export default slice.reducer;

const url = "getAgreementDetails1";
// const url1 = "saveDisbursementDetails";
const url2 = "cs/getAgreement";
const url3 = "updateEsignResult1";

const url4 = "mp/getAgreement"


// To receive the data

export const getLoanAgreementData =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url,

        method: "POST",

        data: params,

        callback,

        onStart: generateLoanAgreementRequested.type,

        onSuccess: generateLoanAgreementReceived.type,

        onError: generateLoanAgreementRequestFailed.type,
      })
    );
  };

export const getLoanAgreementDataCreditSaison =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url2,

        method: "POST",

        data: params,

        callback,

        onStart: generateLoanAgreementRequested.type,

        onSuccess: generateLoanAgreementReceived.type,

        onError: generateLoanAgreementRequestFailed.type,
      })
    );
  };

export const updateESignAgreementDataCreditSaison =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url3,

        method: "POST",

        data: params,

        callback,

        onStart: updateLoanAgreementRequested.type,

        onSuccess: updateLoanAgreementReceived.type,

        onError: updateLoanAgreementRequestFailed.type,
      })
    );
  };

export const esignAgreementRevoltMoneyplus =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url4,
        method: "POST",
        data: params,
        callback,
        onStart: esignagreementMoneyplusRevoltRequested.type,
        onSuccess: esignagreementMoneyplusRevoltReceived.type,
        onError: esignagreementMoneyplusRevoltFailed.type,
      })
    );
  };

// To manage the state

export const eSignAgreementData = createSelector(
  (state) => state.entities.eSignAgreement,
  (eSignAgreement) => eSignAgreement
);
