import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "experian",
  initialState: {
    experianCheck: {},
    accountData: [],
    graphData: {},
    userData: {},
    experianOTP: {},
    loadingCheck: false,
    loadingGraph: false,
    loadingOtp: false,
    lastFetch: null,
    aaData: {},
    loadingAaData: false,
  },
  reducers: {
    experianCheckRequested: (experian, action) => {
      experian.loadingCheck = true;
    },
    experianCheckReceived: (experian, action) => {
      experian.experianCheck = action.payload.cibilData;
      experian.accountData =
        action.payload.cibilData && action.payload.cibilData.experianData;
      experian.userData =
        action.payload.cibilData && action.payload.cibilData.userData;
      experian.loadingCheck = false;
      experian.lastFetch = Date.now();
    },
    experianCheckRequestFailed: (experian, action) => {
      experian.loadingCheck = false;
    },
    experianOtpRequested: (experian, action) => {
      experian.loadingOtp = true;
    },
    experianOtpReceived: (experian, action) => {
      experian.experianOTP = action.payload.experianData;
      experian.accountData =
        action.payload.experianData?.responseData?.experianData;
      experian.loadingOtp = false;
      experian.lastFetch = Date.now();
    },
    experianOtpRequestFailed: (experian, action) => {
      experian.loadingOtp = false;
    },
    experianGraphRequested: (experian, action) => {
      experian.loadingGraph = true;
    },
    experianGraphReceived: (experian, action) => {
      experian.graphData = action.payload.data;
      experian.loadingGraph = false;
      experian.lastFetch = Date.now();
    },
    experianGraphRequestFailed: (experian, action) => {
      experian.loadingGraph = false;
    },
    aaDataRequested: (experian, action) => {
      experian.loadingAaData = true;
    },
    aaDataReceived: (experian, action) => {
      experian.aaData = action.payload;
      experian.loadingAaData = false;
    },
    aaDataFailed: (experian, action) => {
      experian.loadingAaData = false;
    },
  },
});

export const {
  experianCheckRequested,
  experianCheckReceived,
  experianCheckRequestFailed,
  experianOtpRequested,
  experianOtpReceived,
  experianOtpRequestFailed,
  experianGraphRequested,
  experianGraphReceived,
  experianGraphRequestFailed,
  aaDataRequested,
  aaDataReceived,
  aaDataFailed
} = slice.actions;
export default slice.reducer;

const url = "cibil/check2";
const url1 = "/cibil/experianOTPValidation2";
const url2 = "/cibil/experianGraph2";
const url5 = "/aa/getDataWithConsent";
const url6 = "cibil/experianPdf"

export const getAAdata = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url5,
      method: "POST",
      data: params,
      callback,
      aa_api_call: true,
      onStart: aaDataRequested.type,
      onSuccess: aaDataReceived.type,
      onError: aaDataFailed.type,
    })
  );
};

export const loadExperianCheck = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      callback,
      cibil: true,
      onStart: experianCheckRequested.type,
      onSuccess: experianCheckReceived.type,
      onError: experianCheckRequestFailed.type,
    })
  );
};
export const loadExperianGraph = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      cibil: true,
      onStart: experianGraphRequested.type,
      onSuccess: experianGraphReceived.type,
      onError: experianGraphRequestFailed.type,
    })
  );
};
export const loadExperianOtp = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      cibil: true,
      onStart: experianOtpRequested.type,
      onSuccess: experianOtpReceived.type,
      onError: experianOtpRequestFailed.type,
    })
  );
};

export const loadExperianCheck3 = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url6,
      method: "POST",
      data: params,
      callback,
      cibil: true,
      onStart: experianOtpRequested.type,
      onSuccess: experianOtpReceived.type,
      onError: experianOtpRequestFailed.type,
    })
  );
};

export const getExperian = createSelector(
  (state) => state.entities.experian,
  (experian) => experian
);
