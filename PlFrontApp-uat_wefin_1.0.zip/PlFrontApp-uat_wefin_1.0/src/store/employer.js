import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "employer",
  initialState: {
    employerDetail: [],
    company: [],
    addEmployer: {},
    loadingDetail: false,
    loadingCompany: false,
    loadingAdd: false,
    lastFetch: null,
  },
  reducers: {
    employerDetailRequested: (employer, action) => {
      employer.loadingDetail = true;
    },

    employerDetailReceived: (employer, action) => {
      employer.employerDetail = action.payload.data;
      employer.loadingDetail = false;
      employer.lastFetch = Date.now();
    },

    employerDetailRequestFailed: (employer, action) => {
      employer.loadingDetail = false;
    },
    companyDetailRequested: (employer, action) => {
      employer.loadingCompany = true;
    },

    companyDetailReceived: (employer, action) => {
      employer.company = action.payload.data;
      employer.loadingCompany = false;
      employer.lastFetch = Date.now();
    },

    companyDetailRequestFailed: (employer, action) => {
      employer.loadingCompany = false;
    },
    employerAdded: (employer, action) => {
      employer.addEmployer = action.payload.data;
      employer.loadingAdd = false;
      employer.lastFetch = Date.now();
    },

    employerAddRequestFailed: (employer, action) => {
      employer.loadingAdd = false;
    },
  },
});

export const {
  employerDetailRequested,
  employerDetailReceived,
  employerDetailRequestFailed,
  companyDetailRequested,
  companyDetailReceived,
  companyDetailRequestFailed,
  employerAdded,
  employerAddRequestFailed,
} = slice.actions;
export default slice.reducer;

const url = "getMatchingEmployers";
const url1 = "getEmployerSC";
const url3 = "insertEmployerDetails";
let temp
let debounceTime = 1000

export const loadEmployerDetail = (params) => (dispatch) => {
  clearTimeout(temp)
  temp = setTimeout(() => {
    return dispatch(
      apiCallBegan({
        url: url,
        method: "POST",
        data: params,
        onStart: employerDetailRequested.type,
        onSuccess: employerDetailReceived.type,
        onError: employerDetailRequestFailed.type,
      })
    )
  }, debounceTime)
};
export const getCompanyDetail = (params) => (dispatch, getState) => {
  clearTimeout(temp)
  temp = setTimeout(() => {
    return dispatch(
      apiCallBegan({
        url: url1 + "?" + params,
        method: "GET",
        onStart: companyDetailRequested.type,
        onSuccess: companyDetailReceived.type,
        onError: companyDetailRequestFailed.type,
      })
    );
  }, debounceTime)
};

export const addEmployer = (param, callback) => (dispatch) => {
  return dispatch(
    apiCallBegan({
      callback,
      url: url3,
      method: "POST",
      data: param,
      onSuccess: employerAdded.type,
      onError: employerAddRequestFailed.type,
    })
  );
};
export const getEmployer = createSelector(
  (state) => state.entities.employer,
  (employer) => employer
);
