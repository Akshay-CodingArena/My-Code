import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "upload",
  initialState: {
    fullerton: {},
    uploadSelfie: {},
    verifySelfie: {},
    uploadSalary: {},
    loading: false,
    loadingSelfie: false,
    loadingSalary: false,
    lastFetch: null,
  },
  reducers: {
    fullertonRequested: (upload, action) => {
      upload.loading = true;
    },
    fullertonReceived: (upload, action) => {
      upload.fullerton = action.payload;
      upload.loading = false;
      upload.lastFetch = Date.now();
    },
    fullertonRequestFailed: (upload, action) => {
      upload.loading = false;
    },
    uploadFosDocsRequested: (upload, action) => {
      upload.loading = true;
    },
    uploadFosDocsReceived: (upload, action) => {
      upload.fullerton = action.payload;
      upload.loading = false;
      upload.lastFetch = Date.now();
    },
    uploadFosDocsFailed: (upload, action) => {
      upload.loading = false;
    },
    uploadSelfieRequested: (upload, action) => {
      upload.loadingSelfie = true;
    },
    uploadSelfieReceived: (upload, action) => {
      upload.uploadSelfie = action.payload;
      upload.loadingSelfie = false;
      upload.lastFetch = Date.now();
    },
    uploadSelfieRequestFailed: (upload, action) => {
      upload.loadingSelfie = false;
    },
    verifySelfieRequested: (upload, action) => {
      upload.loadingSelfie = true;
    },
    verifySelfieReceived: (upload, action) => {
      upload.verifySelfie = action.payload;
      upload.loadingSelfie = false;
      upload.lastFetch = Date.now();
    },
    verifySelfieRequestFailed: (upload, action) => {
      upload.loadingSelfie = false;
    },
    uploadSalaryRequested: (upload, action) => {
      upload.loadingSalary = true;
    },
    uploadSalaryReceived: (upload, action) => {
      upload.uploadSalary = action.payload;
      upload.loadingSalary = false;
      upload.lastFetch = Date.now();
    },
    uploadSalaryRequestFailed: (upload, action) => {
      upload.loadingSalary = false;
    },
  },
});

export const {
  fullertonRequested,
  fullertonReceived,
  fullertonRequestFailed,
  uploadSelfieRequested,
  uploadSelfieReceived,
  uploadSelfieRequestFailed,
  uploadSalaryRequested,
  uploadSalaryReceived,
  uploadSalaryRequestFailed,
  verifySelfieRequested,
  verifySelfieReceived,
  verifySelfieRequestFailed,
  uploadFosDocsRequested,
  uploadFosDocsReceived,
  uploadFosDocsFailed
} = slice.actions;
export default slice.reducer;

const url = "fullerton/doc/upload";
const url1 = "cs/doc/upload";
const url2 = "cs/doc/upload";
const url3 = "asmDocUpload";
const url4 = "fosDocumentsUpload"


export const uploadFullerton = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      data: params,
      method: "POST",
      callback,
      onStart: fullertonRequested.type,
      onSuccess: fullertonReceived.type,
      onError: fullertonRequestFailed.type,
    })
  );
};
export const uploadPic = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      data: params,
      method: "POST",
      callback,
      onStart: uploadSelfieRequested.type,
      onSuccess: uploadSelfieReceived.type,
      onError: uploadSelfieRequestFailed.type,
    })
  );
};
export const verifyPic = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      data: params,
      method: "POST",
      callback,
      onStart: verifySelfieRequested.type,
      onSuccess: verifySelfieReceived.type,
      onError: verifySelfieRequestFailed.type,
    })
  );
};
export const uploadSalary = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      data: params,
      method: "POST",
      callback,
      onStart: uploadSalaryRequested.type,
      onSuccess: uploadSalaryReceived.type,
      onError: uploadSalaryRequestFailed.type,
    })
  );
};

export const asmDocUpload = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      data: params,
      method: "POST",
      callback,
      onStart: uploadSalaryRequested.type,
      onSuccess: uploadSalaryReceived.type,
      onError: uploadSalaryRequestFailed.type,
    })
  );
};

export const fosDocUpload = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      data: params,
      method: "POST",
      callback,
      onStart: uploadFosDocsRequested.type,
      onSuccess: uploadFosDocsReceived.type,
      onError: uploadFosDocsFailed.type,
    })
  );
};

export const getUpload = createSelector(
  (state) => state.entities.upload,
  (upload) => upload
);
