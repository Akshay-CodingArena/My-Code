import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";
//import moment from "moment";

const slice = createSlice({
  name: "twoWheeler",
  initialState: {
    twList: [],
    loading: false,
    lastFetch: null,
    addressDetails: {},
    loadingAddressDetails: false,
    loadingOffersTWRevolt: false,
    offersTwDataRevolt: [],
    loadingSetOfferTWRevolt: false,
    setOfferTWRevoltData: {},
    ////////////for revolt/////////
    maxDpPercent: 0
  },
  reducers: {
    listRequested: (twoWheeler, action) => {
      twoWheeler.loading = true;
    },
    listReceived: (twoWheeler, action) => {
      twoWheeler.maxDpPercent = action.payload.maxDpPercent;
      twoWheeler.twList = action.payload.twMasterData;
      twoWheeler.loading = false;
      twoWheeler.lastFetch = Date.now();
    },
    listRequestFailed: (twoWheeler, action) => {
      twoWheeler.loading = false;
    },
    addressRequested: (twoWheeler, action) => {
      twoWheeler.loadingAddressDetails = true;
    },
    addressReceived: (twoWheeler, action) => {

      twoWheeler.addressDetails = action.payload.data;
      twoWheeler.loadingAddressDetails = false;
    },
    addressRequestFailed: (twoWheeler, action) => {
      twoWheeler.loadingAddressDetails = false;
    },
    twOfferRevoltRequested: (twoWheeler, action) => {
      twoWheeler.loadingOffersTWRevolt = true;
    },
    twOfferRevoltReceived: (twoWheeler, action) => {
      twoWheeler.offersTwDataRevolt = action.payload.data;
      twoWheeler.loadingOffersTWRevolt = false;
    },
    twOfferRevoltRequestFailed: (twoWheeler, action) => {
      twoWheeler.loadingOffersTWRevolt = false;
    },
    setTWOfferRevoltRequested: (twoWheeler, action) => {

      twoWheeler.loadingSetOfferTWRevolt = true;
    },
    setTWOfferRevoltReceived: (twoWheeler, action) => {

      twoWheeler.setOfferTWRevoltData = action.payload.data;
      twoWheeler.loadingSetOfferTWRevolt = false;
    },
    setTWOfferRevoltRequestFailed: (twoWheeler, action) => {
      twoWheeler.loadingSetOfferTWRevolt = false;
    },
  },
});

export const {
  listRequested,
  listReceived,
  listRequestFailed,
  addressRequested,
  addressReceived,
  addressRequestFailed,
  twOfferRevoltRequested,
  twOfferRevoltReceived,
  twOfferRevoltRequestFailed,
  setTWOfferRevoltRequested,
  setTWOfferRevoltReceived,
  setTWOfferRevoltRequestFailed
} = slice.actions;
export default slice.reducer;

const url = "getTwMasterInfo";
const url2 = "addressUpdate";
const url3 = "getRevoltOffers";
const url4 = "setRevoltOffers";

export const loadTwList = (params) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: params,
      onStart: listRequested.type,
      onSuccess: listReceived.type,
      onError: listRequestFailed.type,
    })
  );
};

export const addressUpdate = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url2,
      method: "POST",
      data: params,
      callback,
      onStart: addressRequested.type,
      onSuccess: addressReceived.type,
      onError: addressRequestFailed.type,
    })
  );
};

export const offersTWRevolt = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: params,
      callback,
      onStart: twOfferRevoltRequested.type,
      onSuccess: twOfferRevoltReceived.type,
      onError: twOfferRevoltRequestFailed.type,
    })
  );
};

export const setOfferTWRevolt = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url4,
      method: "POST",
      data: params,
      callback,
      onStart: setTWOfferRevoltRequested.type,
      onSuccess: setTWOfferRevoltReceived.type,
      onError: setTWOfferRevoltRequestFailed.type,
    })
  );
};

export const getTwoWheeler = createSelector(
  (state) => state.entities.twoWheeler,
  (twoWheeler) => twoWheeler
);
