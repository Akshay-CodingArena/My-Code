import axios from "axios";
import Swal from "sweetalert2";
import * as actions from "../api";
import SecureLS from "secure-ls";

let BaseUrl = process.env.REACT_APP_APIBASE;
let BreUrl = process.env.REACT_APP_BRE_URL;
let aaUrl = process.env.REACT_APP_APIBASE_ACCOUNT_AGGREGATOR;

let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const api =
  ({ dispatch }) =>
    (next) =>
      async (action) => {
        if (action.type !== actions.apiCallBegan.type) return next(action);

        const {
          url,
          method,
          data,
          params,
          onStart,
          onSuccess,
          onError,
          callback = false,
          cibil = false,
          aa_api_call = false
        } = action.payload;
        if (onStart) dispatch({ type: onStart });

        next(action);

        const headers = {
          "Content-Type": "application/json",
          deviceID: "6ebc0c18e7609755",
          "Access-Control-Allow-Origin": window.location.origin.toString(),
        };

        if (localStorage.getItem("accessToken")) {
          headers["accessToken"] = localStorage.getItem("accessToken");
        } else if (localStorage.getItem("TeleVerify_accessToken")) {
          headers["accessToken"] = localStorage.getItem("TeleVerify_accessToken")
        } else if (localStorage.getItem("ASM_accessToken")) {
          headers["accessToken"] = localStorage.getItem("ASM_accessToken")
        }
        try {
          const response = await axios.request({
            baseURL: (cibil === true) ? BreUrl : (aa_api_call) ? aaUrl : BaseUrl,
            headers,
            url,
            method,
            params,
            data,
          });
          // General
          switch (response.data.message) {
            case "Authentication Failed":
            case "Invalid JWT token ":
              Swal.fire({
                position: "center",
                icon: "warning",
                title: response.data.message === "Invalid JWT token " ? "Session Expired.Please login again..." : `${response.data.message.toString()}, logging out from all sessions, please re-login in again...`,
                showConfirmButton: false,
                timer: 3000,
              }).then(() => {

                dispatch(actions.apiCallFailed(response.data.message));
                if (sessionStorage.getItem("logout")) {
                  localStore.removeAll();
                  localStorage.clear();
                  window.location.href = sessionStorage.getItem("logout");
                } else {
                  localStore.removeAll();
                  localStorage.clear();
                  window.location.href = window.location.origin;
                }
                if (onError)
                  dispatch({ type: onError, payload: response.data.message });
                if (callback) callback(response.data);
              });
              break;
            case "Invalid request":
              Swal.fire({
                position: "center",
                icon: "warning",
                title: response.data.errorDetails.toString(),
                showConfirmButton: true,
              }).then(() => {

                dispatch(actions.apiCallFailed(response.data.message));
                if (onError)
                  dispatch({ type: onError, payload: response.data.message });
                if (callback) callback(response.data);
              });
              break;
            default:
              dispatch(actions.apiCallSuccess(response.data));
              if (onSuccess) dispatch({ type: onSuccess, payload: response.data });
              if (callback) callback(response);
              break;
          }
        } catch (error) {
          dispatch(actions.apiCallFailed(error.message));
          if (onError) dispatch({ type: onError, payload: error.message });
          if (callback) callback(error.response);
          console.log(error?.response?.data?.statusCode);
          ///////////////In case of Invalid JWT/////////
          if (error?.response?.data?.statusCode === 403) {
            Swal.fire({
              position: "center",
              icon: "warning",
              title: 'Session Expired.Please login again...',
              showConfirmButton: false,
              timer: 3000,
            }).then(() => {
              localStore.removeAll();
              localStorage.clear();
              if (sessionStorage.getItem("logout")) {
                window.location.href = sessionStorage.getItem("logout")
              }
              else {
                window.location.href = window.location.origin;
              }
            });
          }
          else {
            dispatch(actions.apiCallFailed(error.message));
            if (onError) dispatch({ type: onError, payload: error.message });
            if (callback) callback(error.response);
          }
        }
      };

export default api;