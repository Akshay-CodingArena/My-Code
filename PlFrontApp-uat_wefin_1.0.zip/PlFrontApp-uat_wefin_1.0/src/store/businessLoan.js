import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "businessLoan",
  initialState: {
    loading: false
  },
  reducers: {
    businessLoanRequested: (businessLoan, action) => 
    {
        businessLoan.loading = true;
    },
    businessLoanReceived: (businessLoan, action) => 
    {
        businessLoan.loading = false;
    },
    businessLoanRequestFailed: (businessLoan, action) => {
        businessLoan.loading = false;
    }
  },
});

export const {
    businessLoanRequested,
    businessLoanReceived,
    businessLoanRequestFailed
} = slice.actions;

export default slice.reducer;

const businessLoanApplyUrl = "set/bl/details";

export const applyBusinessLoan =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: businessLoanApplyUrl,
        method: "POST",
        data: params,
        callback,
        onStart: businessLoanRequested.type,
        onSuccess: businessLoanReceived.type,
        onError: businessLoanRequestFailed.type,
      })
    );
  };

export const getBusinessLoanDetails = createSelector(
  (state) => state.entities.businessLoan,
  (businessLoan) => businessLoan
);
