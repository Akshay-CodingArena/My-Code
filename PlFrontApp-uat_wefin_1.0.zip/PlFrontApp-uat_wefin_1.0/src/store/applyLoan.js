import { createSlice } from "@reduxjs/toolkit";
import { createSelector } from "reselect";
import { apiCallBegan } from "./api";

const slice = createSlice({
  name: "applyLoan",
  initialState: {
    applyLoan: {},
    loanDetail: [],
    loadApproval: [],
    loadingApproval: false,
    loadingLoan: false,
    loadingDetail: false,
    lastFetch: null,
  },
  reducers: {
    applyLoanRequested: (applyLoan, action) => {
      applyLoan.loadingLoan = true;
    },
    applyLoanReceived: (applyLoan, action) => {
      applyLoan.applyLoan = action.payload.data;
      applyLoan.loadingLoan = false;
      applyLoan.lastFetch = Date.now();
    },
    applyLoanRequestFailed: (applyLoan, action) => {
      applyLoan.loadingLoan = false;
    },
    detailLoanRequested: (applyLoan, action) => {
      applyLoan.loadingDetail = true;
    },
    detailLoanReceived: (applyLoan, action) => {
      applyLoan.loanDetail = action.payload;
      applyLoan.loadingDetail = false;
      applyLoan.lastFetch = Date.now();
    },
    detailLoanRequestFailed: (applyLoan, action) => {
      applyLoan.loadingDetail = false;
    },
    detailApprovalRequested: (applyLoan, action) => {
      applyLoan.loadingApproval = true;
    },
    detailApprovalReceived: (applyLoan, action) => {
      applyLoan.loadApproval = action.payload.data;
      applyLoan.loadingApproval = false;
      applyLoan.lastFetch = Date.now();
    },
    detailApprovalRequestFailed: (applyLoan, action) => {
      applyLoan.loadingApproval = false;
    },
  },
});

export const {
  applyLoanRequested,
  applyLoanReceived,
  applyLoanRequestFailed,
  detailLoanRequested,
  detailLoanReceived,
  detailLoanRequestFailed,
  detailApprovalRequested,
  detailApprovalReceived,
  detailApprovalRequestFailed,
} = slice.actions;
export default slice.reducer;

const url = "applyLoan";
const url1 = "getLoanDetails";
const url2 = "getapprovaldetails";
const url3 = "ccApplyLoan"
export const loadApplyLoan = (params, callback) => (dispatch, getState) => {

  let newParams = { ...params };
  if (localStorage.getItem("ASM_Id")) {
    newParams['asm_id'] = localStorage.getItem("ASM_Id")
  }

  return dispatch(
    apiCallBegan({
      url: url,
      method: "POST",
      data: newParams,
      callback,
      onStart: applyLoanRequested.type,
      onSuccess: applyLoanReceived.type,
      onError: applyLoanRequestFailed.type,
    })
  );
};

export const loadccApplyLoan = (params, callback) => (dispatch, getState) => {

  let newParams = { ...params };

  if (localStorage.getItem("ASM_Id")) {
    newParams['asm_id'] = localStorage.getItem("ASM_Id");
  }

  return dispatch(
    apiCallBegan({
      url: url3,
      method: "POST",
      data: { ...newParams },
      callback,
      onStart: applyLoanRequested.type,
      onSuccess: applyLoanReceived.type,
      onError: applyLoanRequestFailed.type,
    })
  );
};

export const loadLoanDetail = (params, callback) => (dispatch, getState) => {
  return dispatch(
    apiCallBegan({
      url: url1,
      method: "POST",
      data: params,
      callback,
      onStart: detailLoanRequested.type,
      onSuccess: detailLoanReceived.type,
      onError: detailLoanRequestFailed.type,
    })
  );
};
export const loadApprovalDetail =
  (params, callback) => (dispatch, getState) => {
    return dispatch(
      apiCallBegan({
        url: url2,
        method: "POST",
        data: params,
        callback,
        onStart: detailApprovalRequested.type,
        onSuccess: detailApprovalReceived.type,
        onError: detailApprovalRequestFailed.type,
      })
    );
  };
export const getApplyLoan = createSelector(
  (state) => state.entities.applyLoan,
  (applyLoan) => applyLoan
);
