
import Routes from "./Routes";
import configureStore from "./store/configureStore";
import { Provider } from "react-redux";
// import { firebaseApp, gaLogEvent } from "./init-fcm";
// import CONSTANTS from "./constants/Constants";
// import { useEffect } from "react";
import 'react-loading-skeleton/dist/skeleton.css';
const store = configureStore();

function App() {
  // useEffect(() => {
  //   gaLogEvent(CONSTANTS.GA_EVENTS.WEB_PLATFORM);
  //   return () => {};
  // }, []);
  return (
    <div className="App">
      <Provider store={store}>
        <Routes />
      </Provider>
    </div>
  );
}

export default App;
