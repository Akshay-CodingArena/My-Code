import React from "react";
import ReactDOM from "react-dom";
import "./include/css/bootstrap.min.css";
import App from "./App";
import "./include/css/dev.css";
import reportWebVitals from "./reportWebVitals";
// import * as Sentry from "@sentry/react";
// import { BrowserTracing } from "@sentry/tracing";

// Sentry.init({
//   dsn: "https://b961f557a36348f59fcfbd75064448be@o4504088661196800.ingest.sentry.io/4504117021376512",
//   integrations: [new BrowserTracing()],
//   tracesSampleRate: 1.0,
// });

if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("../public/firebase-messaging-sw.js")
    .then(function (registration) { })
    .catch(function (err) {
      console.log("Service worker registration failed, error:", err);
    });
}

ReactDOM.render(
  <App />,
  document.getElementById("root")
);

reportWebVitals();
