const CryptoJS = require("crypto-js");
const base64=require('base-64')


function payloadEncrypt(data,encryptKey) {
    // encryptKey='123456789abcdefg';
    let clientSecret = base64.encode(encryptKey.toString())
    let cipherText = CryptoJS.AES.encrypt(JSON.stringify(data), clientSecret).toString();
return cipherText;
}



function payloadDecrypt(data,encryptKey){
    // encryptKey='123456789abcdefg';
    let clientSecret = base64.encode(encryptKey.toString())
    let bytes = CryptoJS.AES.decrypt(data, clientSecret);
    let decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    return decryptedData
    }
export  {payloadEncrypt,payloadDecrypt};



