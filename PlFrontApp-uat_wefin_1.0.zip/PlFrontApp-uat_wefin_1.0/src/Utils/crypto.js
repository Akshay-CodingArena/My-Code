const CryptoJS = require("crypto-js");
const base64 = require('base-64');

const secretKey = process.env.REACT_APP_STORAGE_SECRET_KEY;
const getHashEncryption = (k) => CryptoJS.AES.encrypt(k, secretKey).toString();
const getHashDecryption = (k) => CryptoJS.AES.decrypt(k, secretKey).toString(CryptoJS.enc.Utf8);

const getBase64Encryption = (k) => base64.encode(k);
const getBase64Decryption = (k) => base64.decode(k);

export {
    getHashEncryption,
    getHashDecryption,
    getBase64Encryption,
    getBase64Decryption
}