function numberWithHyphen(x) {
    let num=x.toString();
    if (num.length >0) {
        num = num.match(/\d{2}(?=\d{3,4})|\d+/g).join("-");    
      }
    return num;

}
  
  export default numberWithHyphen;
  
  
  
  
  
