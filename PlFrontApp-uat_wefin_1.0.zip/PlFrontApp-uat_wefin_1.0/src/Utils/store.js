import SecureLS from "secure-ls";
import Base64 from "base-64";
let localStore = new SecureLS({
  encodingType: "aes",
  isCompression: true,
});

const encryptStore = (mobile, data) => {
  let key = Base64.encode(mobile && mobile.toString());
  let object = localStore.get(key);
  data = { ...object, ...data };
  localStore.set(key, { ...data });
};

const decryptStore = (mobile) => {
  let key = Base64.encode(mobile && mobile.toString());
  let value = localStore.get(key);
  return value;
};


const clearStore = (mobile) => {
  let key = Base64.encode(mobile && mobile.toString());
  let object = localStore.get(key);
  localStore.set(key, {});
};


export { encryptStore, decryptStore, clearStore };
