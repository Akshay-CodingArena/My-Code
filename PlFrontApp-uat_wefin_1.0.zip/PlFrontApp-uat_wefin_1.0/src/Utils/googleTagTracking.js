const trackingId = "AW-10860415483";
const hitGA = (pageId) =>
  new Promise((resolve, reject) => {
    let callback = (e) => {
      if (e === trackingId) {
        resolve(true);
      } else {
        reject(false);
      }
    };
    window.gtag("event", "conversion", {
      send_to: `${trackingId}/${pageId}`,
      event_callback: callback,
    });
  });

export const gtag_report_conversion = async (pageId) => {
  let r = await hitGA(pageId);
  return r;
};

export const gAKeys = {
  mainLogin: "AlHwCI7lhaYDEPuT07oo",
  loginCreditScore: "r_EkCObm6LsDEPuT07oo",
  loginPersonalLoan: "iwEmCJLe57sDEPuT07oo",
  loginTwoWheelerLoan: "SqPgCK6F6bsDEPuT07oo",
  loginGetCreditCard: "z-wMCJr0tLsDEPuT07oo",
};
