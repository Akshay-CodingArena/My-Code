import { EncryptStorage } from 'encrypt-storage';

// Example of secret_key variable in an .env file
// const encryptStorage = new EncryptStorage(process.env.SECRET_KEY, options);
const options = {
    prefix: '@neofund',
    storageType: 'localStorage',
    encAlgorithm: 'Rabbit',
}


const encryptStorage = new EncryptStorage(process.env.REACT_APP_STORAGE_SECRET_KEY === ''  ? '$2a$12$I8XrHU0Dapcork64XBm4VO9FkmlbNkZ5YZXKFkRRpw6EFgoPK9U8a' : process.env.REACT_APP_STORAGE_SECRET_KEY , options);

const addItemToStorage = (key,value) => (encryptStorage.setItem(window.btoa(key), value));
const getItemFromStorage = (key) => (encryptStorage.getItem(window.btoa(key)));
const clearStorage = () => encryptStorage.clear();
const removeItemFromStorage = (e) => encryptStorage.removeItem(window.btoa(e)); 

const getEncryptString = (e) => encryptStorage.encryptString(e);
const getDecryptString = (e) => encryptStorage.decryptString(e);

export {
    addItemToStorage,
    getItemFromStorage,
    clearStorage,
    getDecryptString,
    getEncryptString,
    removeItemFromStorage
}