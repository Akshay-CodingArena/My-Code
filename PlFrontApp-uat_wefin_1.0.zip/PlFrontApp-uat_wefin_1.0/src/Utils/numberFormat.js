export const numberFormat = (value) => {
  let numberVal = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
  }).format(value);
  let result1 = numberVal.split("₹")
  let result2 = result1[1].split('.')
  let result = '₹ ' + result2[0]
  return result;
}

export const numberFormatASM = (value) => {
  let numberVal = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
  }).format(value);
  let result1 = numberVal.split("₹")
  let result2 = result1[1].split('.')
  let result = result2[0]
  return result;
}